package com.mdt.beolp.beolp_api.entity;

import java.io.Serializable;

import com.mdt.beolp.entity.BeolPChipSumBaseEntity;

/**
 ***************************************************
 * @Title BeolOpticalChipSumEntity
 * @author 林华锋
 * @Date 2017年4月10日上午10:44:46
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class BeolPAPIChipSumEntity extends BeolPChipSumBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
}
