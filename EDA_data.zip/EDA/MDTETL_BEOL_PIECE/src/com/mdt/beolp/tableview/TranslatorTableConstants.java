package com.mdt.beolp.tableview;

public class TranslatorTableConstants {
	public static String TRANSLATOR_CONFIG_T_NAME = "TRANSLATOR_CONFIG_T";
	public static String ETL_FILE_T_NAME = "ETL_FILE_T";
	public static String ETL_FILE_HST_T_NAME = "ETL_FILE_HST_T";
	/*
	public static String ELT_FILE_TMP_T_NAME = "ETL_FILE_TMP_T";
	public static String ARRAY_DATA_FILE_HST_T_NAME = "ARRAY_DATA_FILE_HST_T";
	public static String CF_DATA_FILE_HST_T_NAME = "CF_DATA_FILE_HST_T";
	public static String CELL_DATA_FILE_HST_T_NAME = "CELL_DATA_FILE_HST_T";
	public static String MOD_DATA_FILE_HST_T_NAME = "MOD_DATA_FILE_HST_T";

	public static String DATA_FILE_LOG_T_NAME = "TRANSLATOR_LOG_T";
	public static String TRANSLATOR_HST_SUMMARY_T_NAME = "TRANSLATOR_HST_SUMMARY_T";
	public static String SPC_MODULE_KEY_PARAM_T_NAME = "SPC_MODULE_KEY_PARAM_T";
	public static String STEP_GROUP_CONFIG_T_NAME = "STEP_GROUP_CONFIG_T";
	public static String PANEL_BASE_INFO_T_NAME = "PANEL_BASE_INFO_T";
	
	//step table
	public static String ARRAY_STEP_T_NAME = "ARRAY_STEP_T";
	public static String CF_STEP_T_NAME = "CF_STEP_T";
	public static String CELL_STEP_T_NAME = "CELL_STEP_T";
	public static String CELL2_STEP_T_NAME = "CELL2_STEP_T";
	public static String MOD_STEP_T_NAME = "MOD_STEP_T";
	*/
	
}
