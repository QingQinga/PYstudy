package com.mdt.beolp.tableview;


public class TranslatorConfigView extends BaseTableView{

	void ConfigTableView(){
	}


	public String getTID() {
		return (String)data.get("TID");
	}

	public String getShop() {
		return (String)data.get("SHOP");
	}

	public String getSource() {
		return (String) data.get("SOURCE");
	}

	public String getEquipType() {
		return (String) data.get("EQUIP_TYPE");
	}


	public String getTargetFlagList() {
		return (String) data.get("TARGET_FLAG_LIST");
	}

	public String getWorkDir() {
		return (String) data.get("WORK_DIR");
	}

	public String getHandlerClass() {
		return (String) data.get("HANDLER_CLASS");
	}
	
	public String getMaxCount() {
		return (String) data.get("MAX_COUNT");
	}
	
	public String getPid() {
		return (String) data.get("PID");
	}
	
	public String getRunFlag() {
		return (String) data.get("RUN_FLAG");
	}

}
