package com.mdt.beolp.beolp_ptest.entity;

import java.io.Serializable;

import com.mdt.beolp.entity.BeolPChipBaseEntity;

/**
 ***************************************************
 * @Title BeolOpticalChipEntity
 * @author 林华锋
 * @Date 2017年4月10日上午10:07:24
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class BeolPTESTChipEntity extends BeolPChipBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
}
