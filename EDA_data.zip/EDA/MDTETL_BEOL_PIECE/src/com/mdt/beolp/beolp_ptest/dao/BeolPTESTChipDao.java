package com.mdt.beolp.beolp_ptest.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.beolp.beolp_ptest.entity.BeolPTESTChipEntity;
import com.mdt.beolp.util.DBUtil;

/**
 ***************************************************
 * @Title  BeolOpticalChipDao                                    
 * @author 林华锋
 * @Date   2017年4月10日上午10:09:28
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class BeolPTESTChipDao {

	private static Logger logger = Logger.getLogger(BeolPTESTChipDao.class);
    
	public static boolean addBeolPTESTChip(BeolPTESTChipEntity Entity, Connection conn, String fid) throws Exception {
		
		String view = "CELL2_P_TEST_CHIP_V";
		
		String sql = "INSERT INTO " + view
				  +"(" 
				  +"OPE_NO,"
				  +"CHIP_ID,"
				  +"PRODUCT_ID,"
				  +"RECIPE_ID,"
				  +"CASSETTE_ID,"
				  +"SLOT_NO,"
				  +"ROUTE_ID,"
				  +"GLASS_ID,"
				  +"ARRAY_GLASS_ID,"
				  +"EQ_ID,"
				  +"SUBEQ_ID,"
				  +"SGR_ID,"
				  +"PARENT_SGR_ID,"
				  +"CHIP_NO,"
				  +"START_TIME,"
				  +"END_TIME,"
				  +"JUDGE,"
				  +"USER_ID,"
				  +"PANEL_GRADE,"
				  +"TTL_DEFECT_CNT,"
				  +"TACK_TIME,"
				  +"LASER_REPAIR,"
				  +"ENGINEER_NOTE,"
				  +"NOTE1,"
				  +"NOTE2,"
				  +"NOTE3,"
				  +"CF_GLASS_ID,"
				  +"PG_MODEL_VER"
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?"
				  +")";

		Object[] params = {Entity.getOPE_NO(),
				           Entity.getCHIP_ID(),
				           Entity.getPRODUCT_ID(),
				           Entity.getRECIPE_ID(),
				           Entity.getCASSETTE_ID(),
				           Entity.getSLOT_NO(),
				           Entity.getROUTE_ID(),
				           Entity.getGLASS_ID(),
				           Entity.getARRAY_GLASS_ID(),
				           Entity.getEQ_ID(),
				           Entity.getSUBEQ_ID(),
				           Entity.getSGR_ID(),
				           Entity.getPARENT_SGR_ID(),
				           Entity.getCHIP_NO(),
				           Entity.getSTART_TIME(),
				           Entity.getEND_TIME(),
				           Entity.getJUDGE(),
				           Entity.getUSER_ID(),
				           Entity.getPANEL_GRADE(),
				           Entity.getTTL_DEFECT_CNT(),
				           Entity.getTACK_TIME(),
				           Entity.getLASER_REPAIR(),
				           Entity.getENGINEER_NOTE(),
				           Entity.getNOTE1(),
				           Entity.getNOTE2(),
				           Entity.getNOTE3(),
				           Entity.getCF_GLASS_ID(),
				           Entity.getPG_MODEL_VER()
		                  };
                           
		boolean isErrorRet = true;

		try {

			DBUtil.executeUpdate(sql, params,conn);
			logger.info(" FID: "+fid+"||  ----- Insert into "+ view +" success! ");
		} catch (Exception e) {

			logger.error(" FID: "+fid+"||  ----- Insert into "+ view +" failed! Error Message: " + e.getMessage());
			isErrorRet = false;
			throw e;
		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {
				logger.error(" FID: "+fid+"||  ----- An Error Cased: " + e.getMessage());
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}

	}
	
	
}
