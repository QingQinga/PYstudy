package com.mdt.beolp.excute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.beolp.beolp_maunal_insp.dao.BeolPMaunalInspChipDao;
import com.mdt.beolp.beolp_maunal_insp.dao.BeolPMaunalInspChipSumDao;
import com.mdt.beolp.beolp_maunal_insp.dao.BeolPMaunalInspDefectDao;
import com.mdt.beolp.beolp_maunal_insp.dao.BeolPMaunalInspResultDao;
import com.mdt.beolp.beolp_maunal_insp.entity.BeolPMaunalInspChipEntity;
import com.mdt.beolp.beolp_maunal_insp.entity.BeolPMaunalInspChipSumEntity;
import com.mdt.beolp.beolp_maunal_insp.entity.BeolPMaunalInspDefectEntity;
import com.mdt.beolp.beolp_maunal_insp.entity.BeolPMaunalInspResultEntity;
import com.mdt.beolp.dao.ParameterDao;
import com.mdt.beolp.dao.ProductDao;
import com.mdt.beolp.dao.StepDao;
import com.mdt.beolp.entity.ParameterEntity;
import com.mdt.beolp.entity.ProductEntity;
import com.mdt.beolp.entity.StepEntity;
import com.mdt.beolp.tableview.SessionConstants;
import com.mdt.beolp.util.DataFileFormatUtil;
import com.mdt.beolp.util.DistinctParamNameUtil;
import com.mdt.beolp.util.EdaSpcAbstractLoader;
import com.mdt.beolp.util.GetCFGlassIDUtil;

/**
 ***************************************************
 * @Title  BeolPMaunalInspExcute                                    
 * @author 林华锋
 * @Date   2017年10月17日下午2:48:29
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class BeolPMaunalInspExcute extends EdaSpcAbstractLoader {
	
	private static Logger logger = Logger.getLogger(BeolPMaunalInspExcute.class);

	public BeolPMaunalInspExcute() throws Exception{
		super(SessionConstants.GET_SYSTEM_CONFIG_DIR(), SessionConstants.GET_LOG_CONFIG_DIR());
	}

	public Connection EDA_CONN = null;
	public Connection SPC_CONN = null;
	public String discern; // 识别前字符
	public String[] afterDiscern; // 识别后字符
	public BufferedReader reader;
	public String loaderData = "begin cell2_file_loader.load_data; end;";
	public Statement stmt = null;
	public GetCFGlassIDUtil getCFGlassUtil= new GetCFGlassIDUtil();
	
	/** 实例化实体类对象 Begin **/
    
	public ParameterEntity parameterEntity = new ParameterEntity();
	public ProductEntity productEntity = new ProductEntity();
	public StepEntity stepEntity = new StepEntity();
	public BeolPMaunalInspChipEntity MaunalInspChipEntity = new BeolPMaunalInspChipEntity();
	public BeolPMaunalInspChipSumEntity MaunalInspChipSumEntity = new BeolPMaunalInspChipSumEntity();
	public BeolPMaunalInspDefectEntity MaunalInspDefectEntity = new BeolPMaunalInspDefectEntity();
	public BeolPMaunalInspResultEntity MaunalInspResultEntity = new BeolPMaunalInspResultEntity();    
	
	/** 实例化实体类对象 End **/

	/** DAO */

	public ProductDao productDao; 
	public ParameterDao parameterDao;
	public StepDao stepDao;
	public BeolPMaunalInspChipDao MaunalInspChipDao;
	public BeolPMaunalInspChipSumDao MaunalInspChipSumDao;
	public BeolPMaunalInspDefectDao MaunalInspDefectDao;
	public BeolPMaunalInspResultDao MaunalInspResultDao;

	/** DAO */

	/****** Header_Begin 字段行 */

	public String hFILE_VERSION = null; // 文件版本
	public String hFILE_CREATED_TIME = null; // 创建时间
	public String hEQUIP_TYPE = null; // 设备类型
	public String hEQ_ID = null; // 设备ID
	public String hSubEQ_ID = null; // 子设备ID
	public String hCONTENT = null; // DataBlock内容标题

	/****** Header_End 字段行 */

	/** DOWNLOADED_SHEET_DATA_BEGIN 字段行 */

	public String dsOPE_NO = null;
	public String dsCHIP_ID = null;
	public String dsPRODUCT_ID = null;
	public String dsLOT_ID = null;
	public String dsRECIPE_ID = null;
	public String dsCASSETTE_ID = null;
	public String dsSLOT_NO = null;
	public String dsROUTE_ID = null;

	/** DOWNLOADED_SHEET_DATA_END 字段行 */

	/** CHIP_DATA_BEGIN 字段行 */

	public String cOPE_NO = null;
	public String cCHIP_ID = null;
	public String cCHIP_NO = null;
	public String cSTART_TIME = null;
	public String cEND_TIME = null;
	public String cJUDGE = null;
	public String cUSER_ID = null;
	public String cPANEL_GRADE = null;
	public String cTTL_DEFECT_CNT = null;
	public String cTACK_TIME = null;
	public String cLASER_REPAIR = null;
	public String cENGINEER_NOTE = null;
	public String cNOTE1 = null;
	public String cNOTE2 = null;
	public String cNOTE3 = null;
	public String cPG_MODEL_VER =null;
	
	/** CHIP_DATA_NED 字段行 */

	/** CHIP_SUMMARY_DATA_BEGIN 字段行 */

	public String csOPE_NO = null;
	public String csCHIP_ID = null;
	public String csCHIP_NO = null;
	public String csPARAM_COLLECTION = null;
	public String csPARAM_GROUP = null;
	public String csPARAM_NAME = null;
	public String csPARAM_VALUE = null;
	public String csAVG = null;
	public String csMAX = null;
	public String csMIN = null;
	public String csSTD = null;
	public String csUNIFORMITY = null;
	public String csRANGE = null;
	public String csSPEC_HIGH = null;
	public String csSPEC_LOW = null;
	public String csSPEC_TARGET = null;
	public String csCONTROL_HIGH = null;
	public String csCONTROL_LOW = null;
	public String csTHREE_SIGMA = null;
	public String csEND_TIME = null;

	/** CHIP_SUMMARY_DATA_END 字段行 */

	/** DEFECT_DATA_BEGIN 字段行 */

	public String dOPE_NO = null;
	public String dCHIP_ID = null;
	public String dEND_TIME = null;
	public String dDEFECT_SEQ_NO = null;
	public String dCHIP_NO = null;
	public String dDEFECT_CODE = null;
	public String dDEFECT_DESC = null;
	public String dPANEL_RANK = null;
	public String dIMAGE_DATA = null;
	public String dDEFECT_PATTERN = null;
	public String dTROUBLE_LOT = null;
	public String dREJUDGE_FLAG = null;
	public String dDEFECT_LAYER_TYPE = null;
	public String dSIZE = null;
	public String dS = null;
	public String dG = null;
	public String dPANEL_X = null;
	public String dPANEL_Y = null;
	public String dPANEL_X2 = null;
	public String dPANEL_Y2 = null;
	public String dPANEL_X3 = null;
	public String dPANEL_Y3 = null;
	public String dARRAY_X = null;
	public String dARRAY_Y = null;
	public String dARRAY_X2 = null;
	public String dARRAY_Y2 = null;
	public String dARRAY_X3 = null;
	public String dARRAY_Y3 = null;

	/** DEFECT_DATA_END 字段行 */
	
	/** SITE_DATA_BEGIN 字段行 */
	
	public String sOPE_NO = null;
	public String sCHIP_NO = null;
	public String sEND_TIME = null;
	public String sPARAM_COLLECTION = null;
	public String sPARAM_GROUP = null;
	public String sPARAM_NAME = null;
	public String sSITE_NAME = null;
	public String sPARAM_VALUE = null;
	public String sJUDGE = null;
	public String sX = null;
	public String sY = null;
	public String sSPEC_HIGH = null;
	public String sSPEC_LOW = null;
	public String sSPEC_TARGET = null;
	public String sCONTROL_HIGH = null;
	public String sCONTROL_LOW = null;
	public String sCHIP_ID = null;
	
	/** SITE_DATA_END   字段行 */

	public static void main(String[] args) throws Exception {

		// args:{TID:0,Shop:1,Source:2,eqp_type:3,target_flag:4,WorkDir:5,max_count:6,SystemLocalConfigPath:7,LogConfigPath:8,db_find_method:9,export_log_file:10}
		if (args != null && args.length > 0) {
			SessionConstants.SET_TID(args[0]);
			SessionConstants.SET_SHOP(args[1]);
			SessionConstants.SET_SOURCE(args[2]);
			SessionConstants.SET_EQP_TYPE(args[3]);
			SessionConstants.SET_TARGET_FLAG(args[4]);
			SessionConstants.SET_WORK_DIR(args[5]);
			SessionConstants.SET_MAX_COUNT(args[6]);
			SessionConstants.SET_SYSTEM_CONFIG_DIR(args[7]);
			SessionConstants.SET_LOG_CONFIG_DIR(args[8]);
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(args[9]);
			SessionConstants.SET_EXPORT_LOG_FLAG(args[10]);
		} else {
			SessionConstants.SET_TID("BEOL_PIECE_FILE_MAUNALINSP_1"); // translator_config_t
			SessionConstants.SET_SHOP("BEOL_PIECE");
			SessionConstants.SET_SOURCE("FILE");
			SessionConstants.SET_EQP_TYPE("MAUNALINSP");
			SessionConstants.SET_TARGET_FLAG("0,1,2,3,4,5,6,7,8,9");
			SessionConstants.SET_WORK_DIR("E:\\Test");
			SessionConstants.SET_MAX_COUNT("500");
			SessionConstants.SET_SYSTEM_CONFIG_DIR("E:\\Test\\system.properties");
			SessionConstants.SET_LOG_CONFIG_DIR("config/properties/log4j.properties");
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD("FALSE");
			SessionConstants.SET_EXPORT_LOG_FLAG("TRUE");
		}

		try {
			BeolPMaunalInspExcute MaunalInspExcute = new BeolPMaunalInspExcute();

			MaunalInspExcute.run();

		} catch (Exception e) {
			logger.error(" FID: "+FID+"||  There hava a error! Error Message: " + e.getMessage());
		}

	}


	public void readyToRun(File file) throws Exception {

        logger.info("FID : " + FID + "|| 【 Translator Begin 】");
		
		ReadDFSFile(file);
			
		logger.info("FID : " + FID + "|| 【 Translator End 】");
	}

	@SuppressWarnings("static-access")
	public void ReadDFSFile(File file) throws Exception {
        
		EDA_CONN = getEdaConnection();
		
		if (EDA_CONN.isClosed()) {
			logger.error(" FID: "+FID+"||  The database connection was error");
		}
		
		EDA_CONN.setAutoCommit(false);

		try {
			reader = new BufferedReader(new FileReader(file.getPath()));

			while ((discern = reader.readLine()) != null) {
				if (discern.length() == 0) {
					continue;
				}
				/***********************************************************************
				 * BEGIN ****************** 设备抛出csv文件，读取Header部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("HEADER_BEGIN")) {

					logger.info(" FID: "+FID+"||  【  HEADER_BEGIN 读取开始  】");

					while ((discern = reader.readLine()) != null && getEdaSuccessFlag()) {
						if (DataFileFormatUtil.Shift(discern).startsWith("FILE_VERSION")) {
							afterDiscern = discern.split(":", -1);
							hFILE_VERSION = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("FILE_CREATED_TIME")) {
							afterDiscern = discern.split(":", -1);
							hFILE_CREATED_TIME = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQUIP_TYPE")) {
							afterDiscern = discern.split(":", -1);
							hEQUIP_TYPE = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("SUBEQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hSubEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("CONTENT")) {
							afterDiscern = discern.split(":", -1);
							hCONTENT = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).endsWith("HEADER_END")) {
							break;
						}
					}
					logger.info(" FID: "+FID+"||  【  HEADER_END   读取结束  】");

				}
				/*********************************************************************
				 * END ******************** 设备抛出csv文件，读取Header部分 ****** END *
				 ********************************************************************/

				/***********************************************************************
				 * BEGIN ***************设备抛出csv文件，读取SHEET_DATA部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("DOWNLOADED_SHEET_DATA_BEGIN")) {

					logger.info(" FID: "+FID+"||  【  DOWNLOADED_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DOWNLOADED_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);
                        
						dsOPE_NO = afterDiscern[0];
						dsROUTE_ID = afterDiscern[1];
						dsCHIP_ID = afterDiscern[2];
						dsPRODUCT_ID = afterDiscern[3];
						dsRECIPE_ID = afterDiscern[4];
						dsCASSETTE_ID = afterDiscern[5];
						dsSLOT_NO = afterDiscern[6];

						stepEntity.setSTEP_ID(dsOPE_NO);
						stepEntity.setSTEP_SEQ(dsOPE_NO);
						stepEntity.setSTEP_TYPE("M");
						stepEntity.setSTEP_GROUP(hEQUIP_TYPE);

						setEdaSuccessFlag(stepDao.addStepTable(stepEntity, EDA_CONN,FID));

						productEntity.setPRODUCT_ID(dsPRODUCT_ID);
						productEntity.setPRODUCT_GROUP("DEFAULT");

						setEdaSuccessFlag(productDao.addProductTable(productEntity, EDA_CONN,FID));

						MaunalInspChipEntity.setROUTE_ID(dsROUTE_ID);
						MaunalInspChipEntity.setCHIP_ID(dsCHIP_ID);
						MaunalInspChipEntity.setPRODUCT_ID(dsPRODUCT_ID);
						MaunalInspChipEntity.setRECIPE_ID(dsRECIPE_ID);
						MaunalInspChipEntity.setCASSETTE_ID(dsCASSETTE_ID);
						MaunalInspChipEntity.setSLOT_NO(dsSLOT_NO);
						MaunalInspChipEntity.setEQ_ID(hEQ_ID);
						MaunalInspChipEntity.setSUBEQ_ID(hSubEQ_ID);
						MaunalInspChipEntity.setGLASS_ID(dsCHIP_ID.substring(0, 7));
						MaunalInspChipEntity.setARRAY_GLASS_ID(dsCHIP_ID.substring(0, 7));
						MaunalInspChipEntity.setSGR_ID(lot_id);
						MaunalInspChipEntity.setPARENT_SGR_ID(parent_lot_id); 
										
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}
					logger.info(" FID: "+FID+"||  【  DOWNLOADED_SHEET_DATA_END   读取结束  】");
				}
				/***********************************************************************
				 * END *******设备抛出csv文件，读取DOWNLOADED_SHEET_DATA部分 ****** END **
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN **** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** BEGIN *******
				 ***********************************************************************/
				if (discern.startsWith("CHIP_DATA_BEGIN")) {

					logger.info(" FID: "+FID+"||  【  CHIP_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("CHIP_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						cOPE_NO = afterDiscern[0];
						cCHIP_ID = afterDiscern[1];
						cCHIP_NO = afterDiscern[2];
						cSTART_TIME = afterDiscern[3];
						cEND_TIME = afterDiscern[4];
						cTACK_TIME = afterDiscern[5];
						cUSER_ID = afterDiscern[6];
						cJUDGE = afterDiscern[7];
						cTTL_DEFECT_CNT = afterDiscern[8];
						cPANEL_GRADE = afterDiscern[9];
						cLASER_REPAIR = afterDiscern[10];
						cENGINEER_NOTE = afterDiscern[11];
						cNOTE1 = afterDiscern[12];
						cNOTE2 = afterDiscern[13];
						cNOTE3 = afterDiscern[14];
						cPG_MODEL_VER = afterDiscern[15];
						
						MaunalInspChipEntity.setOPE_NO(cOPE_NO);
						MaunalInspChipEntity.setCHIP_ID(cCHIP_ID);
						MaunalInspChipEntity.setCHIP_NO(cCHIP_NO);
						MaunalInspChipEntity.setSTART_TIME(cSTART_TIME);
						MaunalInspChipEntity.setEND_TIME(cEND_TIME);
						MaunalInspChipEntity.setTACK_TIME(cTACK_TIME);
						MaunalInspChipEntity.setUSER_ID(cUSER_ID);
						MaunalInspChipEntity.setJUDGE(cJUDGE);
						MaunalInspChipEntity.setTTL_DEFECT_CNT(cTTL_DEFECT_CNT);
						MaunalInspChipEntity.setPANEL_GRADE(cPANEL_GRADE);
						MaunalInspChipEntity.setLASER_REPAIR(cLASER_REPAIR);
						MaunalInspChipEntity.setENGINEER_NOTE(cENGINEER_NOTE);
						MaunalInspChipEntity.setNOTE1(cNOTE1);
						MaunalInspChipEntity.setNOTE2(cNOTE2);
						MaunalInspChipEntity.setNOTE3(cNOTE3);
						MaunalInspChipEntity.setPG_MODEL_VER(cPG_MODEL_VER); 
						MaunalInspChipEntity.setCF_GLASS_ID(getCFGlassUtil.getCFID(cCHIP_ID));
						
						
						setEdaSuccessFlag(MaunalInspChipDao.addMaunalInspChip(MaunalInspChipEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info(" FID: "+FID+"||  【  CHIP_DATA_END   读取结束  】");
				}
				/***********************************************************************
				 * END ********** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** BEGIN *
				 ***********************************************************************/

				if (discern.startsWith("CHIP_SUMMARY_DATA_BEGIN")) {

					logger.info(" FID: "+FID+"||  【  CHIP_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("CHIP_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						csOPE_NO =  afterDiscern[0];
						csCHIP_ID =  afterDiscern[1];
						csCHIP_NO =  afterDiscern[2];
						csEND_TIME =  afterDiscern[3];
						csPARAM_COLLECTION =  afterDiscern[4];
						csPARAM_GROUP =  afterDiscern[5];
						csPARAM_NAME =  afterDiscern[6];
						csPARAM_VALUE =  afterDiscern[7];
						csAVG =  afterDiscern[8];
						csMAX =  afterDiscern[9];
						csMIN =  afterDiscern[10];
						csRANGE =  afterDiscern[11];
						csUNIFORMITY =  afterDiscern[12];
						csSTD =  afterDiscern[13];
						csTHREE_SIGMA =  afterDiscern[14];
						csSPEC_HIGH =  afterDiscern[15];
						csSPEC_LOW =  afterDiscern[16];
						csSPEC_TARGET =  afterDiscern[17];
						csCONTROL_HIGH =  afterDiscern[18];
						csCONTROL_LOW =  afterDiscern[19];

						DistinctParamNameUtil paramUtil =new DistinctParamNameUtil();
						int temp = paramUtil.selectParamName(EDA_CONN, csPARAM_NAME);
						if(temp==0){
						   parameterEntity.setPARAM_COLLECTION(cOPE_NO+"_"+dsRECIPE_ID);
						   parameterEntity.setPARAM_NAME(csPARAM_NAME);
						   parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						   parameterEntity.setPARAM_GROUP(csPARAM_GROUP);
						   setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN, FID));
						}
						MaunalInspChipSumEntity.setOPE_NO(cOPE_NO);
						MaunalInspChipSumEntity.setCHIP_ID(cCHIP_ID);
						MaunalInspChipSumEntity.setCHIP_NO(csCHIP_NO);
						MaunalInspChipSumEntity.setEND_TIME(cEND_TIME);
						MaunalInspChipSumEntity.setPARAM_COLLECTION(cOPE_NO+"_"+dsRECIPE_ID);
						MaunalInspChipSumEntity.setPARAM_GROUP(csPARAM_GROUP);
						MaunalInspChipSumEntity.setPARAM_NAME(csPARAM_GROUP+"_"+csPARAM_NAME);
						MaunalInspChipSumEntity.setPARAM_VALUE(csPARAM_VALUE);
						MaunalInspChipSumEntity.setAVG(csAVG);
						MaunalInspChipSumEntity.setMAX(csMAX);
						MaunalInspChipSumEntity.setMIN(csMIN);
						MaunalInspChipSumEntity.setRANGE(csRANGE);
						MaunalInspChipSumEntity.setUNIFORMITY(csUNIFORMITY);
						MaunalInspChipSumEntity.setSTD(csSTD);
						MaunalInspChipSumEntity.setTHREE_SIGMA(csTHREE_SIGMA);
						MaunalInspChipSumEntity.setSPEC_HIGH(csSPEC_HIGH);
						MaunalInspChipSumEntity.setSPEC_LOW(csSPEC_LOW);
						MaunalInspChipSumEntity.setSPEC_TARGET(csSPEC_TARGET);
						MaunalInspChipSumEntity.setCONTROL_HIGH(csCONTROL_HIGH);
						MaunalInspChipSumEntity.setCONTROL_LOW(csCONTROL_LOW);

						setEdaSuccessFlag(MaunalInspChipSumDao.addMaunalInspChipSum(MaunalInspChipSumEntity, EDA_CONN, FID));
	
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info(" FID: "+FID+"||  【  CHIP_SUMMARY_DATA_END   读取结束  】");
				}

				/***********************************************************************
				 ****** END * 设备抛出csv文件，读取 SHEET_SUMMARY_DATA_BEGIN部分 ****** END ****
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取 DEFECT_DATA_BEGIN 部分 ********** BEGIN ********
				 ***********************************************************************/
				if (discern.startsWith("DEFECT_DATA_BEGIN")) {

					logger.info(" FID: "+FID+"||  【  DEFECT_DATA_BEGIN 读取开始  】");
					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DEFECT_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);
                        
						dOPE_NO = afterDiscern[0];
						dCHIP_ID = afterDiscern[1];
						dCHIP_NO = afterDiscern[2];
						dEND_TIME = afterDiscern[3];
						dDEFECT_SEQ_NO = afterDiscern[4];
						dDEFECT_CODE = afterDiscern[5];
						dDEFECT_DESC = afterDiscern[6];
						dIMAGE_DATA = afterDiscern[7];
						dDEFECT_LAYER_TYPE = afterDiscern[8];
						dDEFECT_PATTERN = afterDiscern[9];
						dREJUDGE_FLAG = afterDiscern[10];
						dSIZE = afterDiscern[11];
						dS = afterDiscern[12];
						dG = afterDiscern[13];
						dPANEL_RANK = afterDiscern[14];
						dPANEL_X = afterDiscern[15];
						dPANEL_Y = afterDiscern[16];
						dPANEL_X2 = afterDiscern[17];
						dPANEL_Y2 = afterDiscern[18];
						dPANEL_X3 = afterDiscern[19];
						dPANEL_Y3 = afterDiscern[20];
						dARRAY_X = afterDiscern[21];
						dARRAY_Y = afterDiscern[22];
						dARRAY_X2 = afterDiscern[23];
						dARRAY_Y2 = afterDiscern[24];
						dARRAY_X3 = afterDiscern[25];
						dARRAY_Y3 = afterDiscern[26];
						dTROUBLE_LOT = afterDiscern[27];
						
						MaunalInspDefectEntity.setOPE_NO(cOPE_NO);
						MaunalInspDefectEntity.setCHIP_ID(cCHIP_ID);
						MaunalInspDefectEntity.setEND_TIME(cEND_TIME);
						MaunalInspDefectEntity.setDEFECT_SEQ_NO(dDEFECT_SEQ_NO);
						MaunalInspDefectEntity.setDEFECT_CODE(dDEFECT_CODE);
						MaunalInspDefectEntity.setDEFECT_DESC(dDEFECT_DESC);
						MaunalInspDefectEntity.setIMAGE_DATA(dIMAGE_DATA);
						MaunalInspDefectEntity.setDEFECT_LAYER_TYPE(dDEFECT_LAYER_TYPE);
						MaunalInspDefectEntity.setDEFECT_PATTERN(dDEFECT_PATTERN);
						MaunalInspDefectEntity.setREJUDGE_FLAG(dREJUDGE_FLAG);
						MaunalInspDefectEntity.setDEFECT_SIZE(dSIZE);
						MaunalInspDefectEntity.setS(dS);
						MaunalInspDefectEntity.setG(dG);
						MaunalInspDefectEntity.setPANEL_RANK(dPANEL_RANK);
						MaunalInspDefectEntity.setPANEL_X(dPANEL_X);
						MaunalInspDefectEntity.setPANEL_Y(dPANEL_Y);
						MaunalInspDefectEntity.setPANEL_X2(dPANEL_X2);
						MaunalInspDefectEntity.setPANEL_Y2(dPANEL_Y2);
						MaunalInspDefectEntity.setARRAY_X3(dARRAY_X3);
						MaunalInspDefectEntity.setPANEL_Y3(dPANEL_Y3);
						MaunalInspDefectEntity.setARRAY_X(dARRAY_X);
						MaunalInspDefectEntity.setARRAY_Y(dARRAY_Y);
						MaunalInspDefectEntity.setARRAY_X2(dARRAY_X2);
						MaunalInspDefectEntity.setARRAY_Y2(dARRAY_Y2);
						MaunalInspDefectEntity.setARRAY_X3(dARRAY_X3);
						MaunalInspDefectEntity.setARRAY_Y3(dARRAY_Y3);
						MaunalInspDefectEntity.setTROUBLE_LOT(dTROUBLE_LOT);
						
						setEdaSuccessFlag(MaunalInspDefectDao.addMaunalInspDefect(MaunalInspDefectEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info(" FID: "+FID+"||  【  DEFECT_DATA_END   读取结束  】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取DEFECT_DATA_END部分 ********** END *******
				 ***********************************************************************/
				
				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取 SITE_DATA_BEGIN 部分 ********** BEGIN ********
				 ***********************************************************************/
				if (discern.startsWith("SITE_DATA_BEGIN")) {
					
					logger.info(" FID: "+FID+"||  【  SITE_DATA_BEGIN 读取开始  】");
					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SITE_DATA_END")) {
							break;
						}
						
						afterDiscern = discern.split(",", -1);
						
						sOPE_NO = afterDiscern[0];
						sCHIP_ID = afterDiscern[1];
						sCHIP_NO = afterDiscern[2];
						sEND_TIME = afterDiscern[3];
						sPARAM_COLLECTION = afterDiscern[4];
						sPARAM_GROUP = afterDiscern[5];
						sPARAM_NAME = afterDiscern[6];
						sSITE_NAME = afterDiscern[7];
						sPARAM_VALUE = afterDiscern[8];
						sJUDGE = afterDiscern[9];
						sX = afterDiscern[10];
						sY = afterDiscern[11];
						sSPEC_HIGH = afterDiscern[12];
						sSPEC_LOW = afterDiscern[13];
						sSPEC_TARGET = afterDiscern[14];
						sCONTROL_HIGH = afterDiscern[15];
						sCONTROL_LOW = afterDiscern[16];
						
						MaunalInspResultEntity.setOPE_NO(cOPE_NO);
						MaunalInspResultEntity.setCHIP_ID(cCHIP_ID);
						MaunalInspResultEntity.setCHIP_NO(cCHIP_NO);
						MaunalInspResultEntity.setEND_TIME(cEND_TIME);
						MaunalInspResultEntity.setPARAM_COLLECTION(cOPE_NO+"_"+dsRECIPE_ID);
						MaunalInspResultEntity.setPARAM_GROUP(sPARAM_GROUP);
						MaunalInspResultEntity.setPARAM_NAME(sPARAM_NAME);
						MaunalInspResultEntity.setSITE_NAME(sSITE_NAME);
						MaunalInspResultEntity.setPARAM_VALUE(sPARAM_VALUE);
						MaunalInspResultEntity.setJUDGE(sJUDGE);
						MaunalInspResultEntity.setX(sX);
						MaunalInspResultEntity.setY(sY);
						MaunalInspResultEntity.setSPEC_HIGH(sSPEC_HIGH);
						MaunalInspResultEntity.setSPEC_LOW(sSPEC_LOW);
						MaunalInspResultEntity.setSPEC_TARGET(sSPEC_TARGET);
						MaunalInspResultEntity.setCONTROL_HIGH(sCONTROL_HIGH);
						MaunalInspResultEntity.setCONTROL_LOW(sCONTROL_LOW);

						setEdaSuccessFlag(MaunalInspResultDao.addMaunalInspResult(MaunalInspResultEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}
					
					logger.info(" FID: "+FID+"||  【  SITE_DATA_END   读取结束  】");
				}
				
				/***********************************************************************
				 * END *** 设备抛出csv文件，读取DEFECT_DATA_END部分 ********** END *******
				 ***********************************************************************/
			}

			try {
				if (getEdaSuccessFlag()) {
					stmt = EDA_CONN.createStatement();
					stmt.executeQuery(loaderData);
					stmt.close();
				}
			} catch (Exception e) {
				reader.close();
				setEdaSuccessFlag(false);
				EDA_CONN.rollback();
				logger.error(" FID: "+FID+"||  Call Loader Failed! Error Message:" + e.getMessage());
			}

		} catch (Exception ex) {

			reader.close();
			logger.error(" FID: "+FID+"||  Ready to run error : " + ex.getMessage());

			if (getEdaSuccessFlag()) {
				reader.close();
				setEdaSuccessFlag(false);
			}

		} finally {

			if (reader != null) {
				reader.close();
			}

		}
	}

	/**
	 * 获取其它的文件夹
	 * 
	 * @param getParentPath
	 *            文件的父目录
	 * @param folderName
	 *            文件夹名称
	 * @return
	 */
	public static String GetOtherDir(String getParentPath, String folderName) {
		return getParentPath.substring(0, getParentPath.length() - 6) + folderName;
	}

	@Override
	public String getLoaderName() {
		return null;
	}

	@Override
	public boolean checkFileFormat(File file) throws Exception {
		return false;
	}
}
