package com.mdt.beolp.entity;

import java.io.Serializable;

/**
 ***************************************************
 * @Title BeolDefectBaseEntity
 * @author 林华锋
 * @Date 2017年4月15日下午3:41:38
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class BeolPDefectBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String OPE_NO;
	private String CHIP_ID;
	private String END_TIME;
	private String DEFECT_SEQ_NO;
	private String CHIP_NO;
	private String DEFECT_CODE;
	private String DEFECT_DESC;
	private String PANEL_RANK;
	private String IMAGE_DATA;
	private String DEFECT_PATTERN;
	private String TROUBLE_LOT;
	private String REJUDGE_FLAG;
	private String DEFECT_LAYER_TYPE;
	private String DEFECT_SIZE;
	private String S;
	private String G;
	private String PANEL_X;
	private String PANEL_Y;
	private String PANEL_X2;
	private String PANEL_Y2;
	private String PANEL_X3;
	private String PANEL_Y3;
	private String ARRAY_X;
	private String ARRAY_Y;
	private String ARRAY_X2;
	private String ARRAY_Y2;
	private String ARRAY_X3;
	private String ARRAY_Y3;

	public String getOPE_NO() {
		return OPE_NO;
	}

	public void setOPE_NO(String oPE_NO) {
		OPE_NO = oPE_NO;
	}

	public String getCHIP_ID() {
		return CHIP_ID;
	}

	public void setCHIP_ID(String cHIP_ID) {
		CHIP_ID = cHIP_ID;
	}

	public String getEND_TIME() {
		return END_TIME;
	}

	public void setEND_TIME(String eND_TIME) {
		END_TIME = eND_TIME;
	}

	public String getDEFECT_SEQ_NO() {
		return DEFECT_SEQ_NO;
	}

	public void setDEFECT_SEQ_NO(String dEFECT_SEQ_NO) {
		DEFECT_SEQ_NO = dEFECT_SEQ_NO;
	}

	public String getCHIP_NO() {
		return CHIP_NO;
	}

	public void setCHIP_NO(String cHIP_NO) {
		CHIP_NO = cHIP_NO;
	}

	public String getDEFECT_CODE() {
		return DEFECT_CODE;
	}

	public void setDEFECT_CODE(String dEFECT_CODE) {
		DEFECT_CODE = dEFECT_CODE;
	}

	public String getDEFECT_DESC() {
		return DEFECT_DESC;
	}

	public void setDEFECT_DESC(String dEFECT_DESC) {
		DEFECT_DESC = dEFECT_DESC;
	}

	public String getPANEL_RANK() {
		return PANEL_RANK;
	}

	public void setPANEL_RANK(String pANEL_RANK) {
		PANEL_RANK = pANEL_RANK;
	}

	public String getIMAGE_DATA() {
		return IMAGE_DATA;
	}

	public void setIMAGE_DATA(String iMAGE_DATA) {
		IMAGE_DATA = iMAGE_DATA;
	}

	public String getDEFECT_PATTERN() {
		return DEFECT_PATTERN;
	}

	public void setDEFECT_PATTERN(String dEFECT_PATTERN) {
		DEFECT_PATTERN = dEFECT_PATTERN;
	}

	public String getTROUBLE_LOT() {
		return TROUBLE_LOT;
	}

	public void setTROUBLE_LOT(String tROUBLE_LOT) {
		TROUBLE_LOT = tROUBLE_LOT;
	}

	public String getREJUDGE_FLAG() {
		return REJUDGE_FLAG;
	}

	public void setREJUDGE_FLAG(String rEJUDGE_FLAG) {
		REJUDGE_FLAG = rEJUDGE_FLAG;
	}

	public String getDEFECT_LAYER_TYPE() {
		return DEFECT_LAYER_TYPE;
	}

	public void setDEFECT_LAYER_TYPE(String dEFECT_LAYER_TYPE) {
		DEFECT_LAYER_TYPE = dEFECT_LAYER_TYPE;
	}

	public String getDEFECT_SIZE() {
		return DEFECT_SIZE;
	}

	public void setDEFECT_SIZE(String dEFECT_SIZE) {
		DEFECT_SIZE = dEFECT_SIZE;
	}

	public String getS() {
		return S;
	}

	public void setS(String s) {
		S = s;
	}

	public String getG() {
		return G;
	}

	public void setG(String g) {
		G = g;
	}

	public String getPANEL_X() {
		return PANEL_X;
	}

	public void setPANEL_X(String pANEL_X) {
		PANEL_X = pANEL_X;
	}

	public String getPANEL_Y() {
		return PANEL_Y;
	}

	public void setPANEL_Y(String pANEL_Y) {
		PANEL_Y = pANEL_Y;
	}

	public String getPANEL_X2() {
		return PANEL_X2;
	}

	public void setPANEL_X2(String pANEL_X2) {
		PANEL_X2 = pANEL_X2;
	}

	public String getPANEL_Y2() {
		return PANEL_Y2;
	}

	public void setPANEL_Y2(String pANEL_Y2) {
		PANEL_Y2 = pANEL_Y2;
	}

	public String getPANEL_X3() {
		return PANEL_X3;
	}

	public void setPANEL_X3(String pANEL_X3) {
		PANEL_X3 = pANEL_X3;
	}

	public String getPANEL_Y3() {
		return PANEL_Y3;
	}

	public void setPANEL_Y3(String pANEL_Y3) {
		PANEL_Y3 = pANEL_Y3;
	}

	public String getARRAY_X() {
		return ARRAY_X;
	}

	public void setARRAY_X(String aRRAY_X) {
		ARRAY_X = aRRAY_X;
	}

	public String getARRAY_Y() {
		return ARRAY_Y;
	}

	public void setARRAY_Y(String aRRAY_Y) {
		ARRAY_Y = aRRAY_Y;
	}

	public String getARRAY_X2() {
		return ARRAY_X2;
	}

	public void setARRAY_X2(String aRRAY_X2) {
		ARRAY_X2 = aRRAY_X2;
	}

	public String getARRAY_Y2() {
		return ARRAY_Y2;
	}

	public void setARRAY_Y2(String aRRAY_Y2) {
		ARRAY_Y2 = aRRAY_Y2;
	}

	public String getARRAY_X3() {
		return ARRAY_X3;
	}

	public void setARRAY_X3(String aRRAY_X3) {
		ARRAY_X3 = aRRAY_X3;
	}

	public String getARRAY_Y3() {
		return ARRAY_Y3;
	}

	public void setARRAY_Y3(String aRRAY_Y3) {
		ARRAY_Y3 = aRRAY_Y3;
	}

}
