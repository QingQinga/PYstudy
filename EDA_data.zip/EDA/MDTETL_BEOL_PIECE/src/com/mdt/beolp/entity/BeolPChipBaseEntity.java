package com.mdt.beolp.entity;

import java.io.Serializable;

/**
 ***************************************************
 * @Title BeolChipBaseEntity
 * @author 林华锋
 * @Date 2017年4月15日下午3:39:55
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class BeolPChipBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String OPE_NO;
	private String PRODUCT_ID;
	private String BATCH_ID;
	private String RECIPE_ID;
	private String CASSETTE_ID;
	private String SLOT_NO;
	private String ROUTE_ID;
	private String CHIP_ID;
	private String CHIP_NO;
	private String START_TIME;
	private String END_TIME;
	private String JUDGE;
	private String USER_ID;
	private String PANEL_GRADE;
	private String TTL_DEFECT_CNT;
	private String TACK_TIME;
	private String LASER_REPAIR;
	private String ENGINEER_NOTE;
	private String NOTE1;
	private String NOTE2;
	private String NOTE3;
	private String GLASS_ID;
	private String EQ_ID;
	private String SUBEQ_ID;

	private String PG_MODEL_VER;
	private String SGR_ID;
	private String PARENT_SGR_ID;
	private String ARRAY_GLASS_ID;
	private String CF_GLASS_ID;

	public String getARRAY_GLASS_ID() {
		return ARRAY_GLASS_ID;
	}

	public void setARRAY_GLASS_ID(String aRRAY_GLASS_ID) {
		ARRAY_GLASS_ID = aRRAY_GLASS_ID;
	}

	public String getPG_MODEL_VER() {
		return PG_MODEL_VER;
	}

	public void setPG_MODEL_VER(String pG_MODEL_VER) {
		PG_MODEL_VER = pG_MODEL_VER;
	}

	public String getSGR_ID() {
		return SGR_ID;
	}

	public void setSGR_ID(String sGR_ID) {
		SGR_ID = sGR_ID;
	}

	public String getPARENT_SGR_ID() {
		return PARENT_SGR_ID;
	}

	public void setPARENT_SGR_ID(String pARENT_SGR_ID) {
		PARENT_SGR_ID = pARENT_SGR_ID;
	}

	public String getROUTE_ID() {
		return ROUTE_ID;
	}

	public void setROUTE_ID(String rOUTE_ID) {
		ROUTE_ID = rOUTE_ID;
	}

	public String getEQ_ID() {
		return EQ_ID;
	}

	public void setEQ_ID(String eQ_ID) {
		EQ_ID = eQ_ID;
	}

	public String getSUBEQ_ID() {
		return SUBEQ_ID;
	}

	public void setSUBEQ_ID(String sUBEQ_ID) {
		SUBEQ_ID = sUBEQ_ID;
	}

	public String getOPE_NO() {
		return OPE_NO;
	}

	public void setOPE_NO(String oPE_NO) {
		OPE_NO = oPE_NO;
	}

	public String getPRODUCT_ID() {
		return PRODUCT_ID;
	}

	public void setPRODUCT_ID(String pRODUCT_ID) {
		PRODUCT_ID = pRODUCT_ID;
	}

	public String getBATCH_ID() {
		return BATCH_ID;
	}

	public void setBATCH_ID(String bATCH_ID) {
		BATCH_ID = bATCH_ID;
	}

	public String getRECIPE_ID() {
		return RECIPE_ID;
	}

	public void setRECIPE_ID(String rECIPE_ID) {
		RECIPE_ID = rECIPE_ID;
	}

	public String getCASSETTE_ID() {
		return CASSETTE_ID;
	}

	public void setCASSETTE_ID(String cASSETTE_ID) {
		CASSETTE_ID = cASSETTE_ID;
	}

	public String getSLOT_NO() {
		return SLOT_NO;
	}

	public void setSLOT_NO(String sLOT_NO) {
		SLOT_NO = sLOT_NO;
	}

	public String getCHIP_ID() {
		return CHIP_ID;
	}

	public void setCHIP_ID(String cHIP_ID) {
		CHIP_ID = cHIP_ID;
	}

	public String getCHIP_NO() {
		return CHIP_NO;
	}

	public void setCHIP_NO(String cHIP_NO) {
		CHIP_NO = cHIP_NO;
	}

	public String getSTART_TIME() {
		return START_TIME;
	}

	public void setSTART_TIME(String sTART_TIME) {
		START_TIME = sTART_TIME;
	}

	public String getEND_TIME() {
		return END_TIME;
	}

	public void setEND_TIME(String eND_TIME) {
		END_TIME = eND_TIME;
	}

	public String getJUDGE() {
		return JUDGE;
	}

	public void setJUDGE(String jUDGE) {
		JUDGE = jUDGE;
	}

	public String getUSER_ID() {
		return USER_ID;
	}

	public void setUSER_ID(String uSER_ID) {
		USER_ID = uSER_ID;
	}

	public String getPANEL_GRADE() {
		return PANEL_GRADE;
	}

	public void setPANEL_GRADE(String pANEL_GRADE) {
		PANEL_GRADE = pANEL_GRADE;
	}

	public String getTTL_DEFECT_CNT() {
		return TTL_DEFECT_CNT;
	}

	public void setTTL_DEFECT_CNT(String tTL_DEFECT_CNT) {
		TTL_DEFECT_CNT = tTL_DEFECT_CNT;
	}

	public String getTACK_TIME() {
		return TACK_TIME;
	}

	public void setTACK_TIME(String tACK_TIME) {
		TACK_TIME = tACK_TIME;
	}

	public String getLASER_REPAIR() {
		return LASER_REPAIR;
	}

	public void setLASER_REPAIR(String lASER_REPAIR) {
		LASER_REPAIR = lASER_REPAIR;
	}

	public String getENGINEER_NOTE() {
		return ENGINEER_NOTE;
	}

	public void setENGINEER_NOTE(String eNGINEER_NOTE) {
		ENGINEER_NOTE = eNGINEER_NOTE;
	}

	public String getNOTE1() {
		return NOTE1;
	}

	public void setNOTE1(String nOTE1) {
		NOTE1 = nOTE1;
	}

	public String getNOTE2() {
		return NOTE2;
	}

	public void setNOTE2(String nOTE2) {
		NOTE2 = nOTE2;
	}

	public String getNOTE3() {
		return NOTE3;
	}

	public void setNOTE3(String nOTE3) {
		NOTE3 = nOTE3;
	}

	public String getGLASS_ID() {
		return GLASS_ID;
	}

	public void setGLASS_ID(String gLASS_ID) {
		GLASS_ID = gLASS_ID;
	}

	public String getCF_GLASS_ID() {
		return CF_GLASS_ID;
	}

	public void setCF_GLASS_ID(String cF_GLASS_ID) {
		CF_GLASS_ID = cF_GLASS_ID;
	}

}
