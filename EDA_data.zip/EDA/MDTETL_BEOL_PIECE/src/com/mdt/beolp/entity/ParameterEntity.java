package com.mdt.beolp.entity;
/**
 ***************************************************
 * @Title  ParameterEntity                                    
 * @author 林华锋
 * @Date   2017年4月20日下午5:47:35
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ParameterEntity {
	
	private String PARAM_COLLECTION;
	private String PARAM_NAME;
	private String PARAM_COLLECTION_GROUP;
	private String PARAM_GROUP; 
	private String DATA_LEVEL_FLAG; 
	private String PARAM_TYPE;
	private String DATA_START_TIME; 
	private String DATA_END_TIME;
	private String UPDATE_TIME;
	
	public String getPARAM_COLLECTION() {
		return PARAM_COLLECTION;
	}
	public void setPARAM_COLLECTION(String pARAM_COLLECTION) {
		PARAM_COLLECTION = pARAM_COLLECTION;
	}
	public String getPARAM_NAME() {
		return PARAM_NAME;
	}
	public void setPARAM_NAME(String pARAM_NAME) {
		PARAM_NAME = pARAM_NAME;
	}
	public String getPARAM_COLLECTION_GROUP() {
		return PARAM_COLLECTION_GROUP;
	}
	public void setPARAM_COLLECTION_GROUP(String pARAM_COLLECTION_GROUP) {
		PARAM_COLLECTION_GROUP = pARAM_COLLECTION_GROUP;
	}
	public String getPARAM_GROUP() {
		return PARAM_GROUP;
	}
	public void setPARAM_GROUP(String pARAM_GROUP) {
		PARAM_GROUP = pARAM_GROUP;
	}
	public String getDATA_LEVEL_FLAG() {
		return DATA_LEVEL_FLAG;
	}
	public void setDATA_LEVEL_FLAG(String dATA_LEVEL_FLAG) {
		DATA_LEVEL_FLAG = dATA_LEVEL_FLAG;
	}
	public String getPARAM_TYPE() {
		return PARAM_TYPE;
	}
	public void setPARAM_TYPE(String pARAM_TYPE) {
		PARAM_TYPE = pARAM_TYPE;
	}
	public String getDATA_START_TIME() {
		return DATA_START_TIME;
	}
	public void setDATA_START_TIME(String dATA_START_TIME) {
		DATA_START_TIME = dATA_START_TIME;
	}
	public String getDATA_END_TIME() {
		return DATA_END_TIME;
	}
	public void setDATA_END_TIME(String dATA_END_TIME) {
		DATA_END_TIME = dATA_END_TIME;
	}
	public String getUPDATE_TIME() {
		return UPDATE_TIME;
	}
	public void setUPDATE_TIME(String uPDATE_TIME) {
		UPDATE_TIME = uPDATE_TIME;
	}
	
}
