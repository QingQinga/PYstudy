package com.mdt.beolp.beolp_maunal_insp.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.beolp.beolp_maunal_insp.entity.BeolPMaunalInspDefectEntity;
import com.mdt.beolp.util.DBUtil;

/**
 ***************************************************
 * @Title  CellMaunalInspDefectDao                                     
 * @author 林华锋
 * @Date   2017年4月17日上午10:34:14
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class BeolPMaunalInspDefectDao {

	private static Logger logger = Logger.getLogger(BeolPMaunalInspDefectDao.class);

	public static boolean addMaunalInspDefect(BeolPMaunalInspDefectEntity Entity,Connection conn, String fid) throws Exception {
		 
		String view = "CELL2_MAUNAL_INSP_DEFECT_V";
		
		String sql = "INSERT INTO " + view
				  +"(" 
				  +"OPE_NO,"
		          +"CHIP_ID,"
		          +"END_TIME,"
		          +"DEFECT_SEQ_NO,"
		          +"DEFECT_CODE,"
		          +"DEFECT_DESC,"
		          +"PANEL_RANK,"
		          +"IMAGE_DATA,"
		          +"DEFECT_PATTERN,"
		          +"TROUBLE_LOT,"
		          +"REJUDGE_FLAG,"
		          +"DEFECT_LAYER_TYPE,"
		          +"\"SIZE\","
		          +"S,"
		          +"G,"
		          +"PANEL_X,"
		          +"PANEL_Y,"
		          +"PANEL_X2,"
		          +"PANEL_Y2,"
		          +"PANEL_X3,"
		          +"PANEL_Y3,"
		          +"ARRAY_X,"
		          +"ARRAY_Y,"
		          +"ARRAY_X2,"
		          +"ARRAY_Y2,"
		          +"ARRAY_X3,"
		          +"ARRAY_Y3"
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA'))"
				  +")";

		Object[] params = {Entity.getOPE_NO(),
				           Entity.getCHIP_ID(),
				           Entity.getEND_TIME(),
				           Entity.getDEFECT_SEQ_NO(),
				           Entity.getDEFECT_CODE(),
				           Entity.getDEFECT_DESC(),
				           Entity.getPANEL_RANK(),
				           Entity.getIMAGE_DATA(),
				           Entity.getDEFECT_PATTERN(),
				           Entity.getTROUBLE_LOT(),
				           Entity.getREJUDGE_FLAG(),
				           Entity.getDEFECT_LAYER_TYPE(),
				           Entity.getDEFECT_SIZE(),
				           Entity.getS(),
				           Entity.getG(),
				           Entity.getPANEL_X(),
				           Entity.getPANEL_Y(),
				           Entity.getPANEL_X2(),
				           Entity.getPANEL_Y2(),
				           Entity.getPANEL_X3(),
				           Entity.getPANEL_Y3(),
				           Entity.getARRAY_X(),
				           Entity.getARRAY_Y(),
				           Entity.getARRAY_X2(),
				           Entity.getARRAY_Y2(),
				           Entity.getARRAY_X3(),
				           Entity.getARRAY_Y3()
		                  };
                         
		boolean isErrorRet = true;

		try {
			DBUtil.executeUpdate(sql, params, conn);
		} catch (Exception e) {

			logger.error(" FID: "+fid+"||  ----- Insert into "+ view +" failed! Error Message: " + e.getMessage());

			isErrorRet = false;
			throw e;
		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {
				logger.error(" FID: "+fid+"||  ----- An Error Cased: " + e.getMessage());
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}
  
	}
	
}
