package com.mdt.beolp.util;

import java.math.BigDecimal;

//import com.sun.org.apache.xalan.internal.xsltc.runtime.Hashtable;
import java.util.Hashtable;


/**
*
* @author  HuChen
*/
public class StatisticUtil {

	   /************************************
	   * Get maximum
	   * @param rowData
	   * @return maximum
	   *************************************/
	   public static double GetMaxValue(String rowData)
	   {
		   String[] iRetValue = rowData.split(";", -1) ;
		   double max =Double.parseDouble(iRetValue[0]); 
		   for(int i=0;i<iRetValue.length -1;i++) 
		   { 
			   if(max<Double.parseDouble(iRetValue[i]))
			   { 
				   max = Double.parseDouble(iRetValue[i]); 
			   } 
		   }		   
		   return max;
	   }
	   
	   /************************************
	   * Get Range
	   * @param max
	   * @param min
	   * @return range
	   *************************************/
	   public static double GetRangeValue(String max,String min)
	   {
		   double range=Double.parseDouble(max) - Double.parseDouble(min);

		   return range;
	   }
	   
	   /************************************
	   * Get UNI
	   * @param rowData
	   * @return UNI
	   *************************************/
	   public static double GetUniValue(String max,String min,String avg)
	   {
		   double uni =0;
		   uni =(Double.parseDouble(max) -Double.parseDouble(min))/(2*Double.parseDouble(avg));
		   return uni;
	   }
	   
	   /************************************
	   * Get AVG
	   * @param rowData
	   * @return AVG
	   *************************************/
	   public static double GetAvgValue(String rowData)
	   {
		   String[] iRetValue = rowData.split(";", -1) ;
		   double sum=0;
		   for(int i=0;i<iRetValue.length -1;i++) { 
			   sum += Double.parseDouble(iRetValue[i]);
		   }
		   return sum/(iRetValue.length-1);
	   }
	   
	   /************************************
	   * Get STD
	   * @param rowData
	   * @return STD
	   *************************************/
	   public static double GetStandValue(String rowData)
	   {
		   String[] iRetValue = rowData.split(";", -1) ;
		   if (iRetValue.length==2) 
		   {
			   return 0;
		   }else
		   {
			   double sum=0;
			   double average =0;
			   for(int i=0;i<iRetValue.length-1;i++) { 
				   sum += Double.parseDouble(iRetValue[i]);
			   }
			   average = sum/(iRetValue.length-1);
			   
			   double temp=0;
			   for(int i=0;i<iRetValue.length-1;i++)
			   {
				   temp+=Math.pow((Double.parseDouble(iRetValue[i])-average), 2);
			   }
			   //temp = temp/(iRetValue.length-1);
			   temp = temp/(iRetValue.length-2);// modify by yidong 2012/1/6

			   return   Math.sqrt(temp);
		   }
		  

		   
	   }
	   
	   /************************************
	   * Get COUNT
	   * @param rowData
	   * @return COUNT
	   *************************************/
	   public static int GetCountValue(String rowData)
	   {
		   String[] iRetValue = rowData.split(";", -1) ;
		   return iRetValue.length -1;
	   }
	   
	   /************************************
	   * Get MAX
	   * @param rowData
	   * @return MAX
	   *************************************/
	   public static double GetMinValue(String rowData)
	   {
		   String[] iRetValue = rowData.split(";", -1) ;
		   double max =Double.parseDouble(iRetValue[0]); 
		   for(int i=0;i<iRetValue.length -1;i++) { 
			   if(max>Double.parseDouble(iRetValue[i])) { 
				   max = Double.parseDouble(iRetValue[i]); 
			   } 
		   }
		   
		   return max;
	   }
	   
	   /************************************
		*Double
		* @param d1
		* @param d2
		* @return 
		*************************************/
	    public static double sub(String d1,String d2)
	    {
	    	BigDecimal bd1=new BigDecimal(d1);
	    	BigDecimal bd2=new BigDecimal(d2);
	    	return  bd1.subtract(bd2).doubleValue();
	    }
	    
	    /************************************
		*Double
		* @param d1
		* @param d2
		* @return 
		*************************************/
	    public static double doubleAdd(String d1,String d2)
		{
			    BigDecimal bd1=new BigDecimal(d1);
			    BigDecimal bd2=new BigDecimal(d2);
			    return  bd1.add(bd2).doubleValue();
		}
	    
	    /************************************
		*Double
		* @param d1
		* @param d2
		* @return 
		*************************************/
	    public static   double   convert(double   value)
	    {   
	        long   l1   =   Math.round(value*100);   //��鈭   
	        double   ret   =   l1/100.0;                
	        return   ret;   
	    }
	    
	   public static String GetProduct(String Product)
	   {
		   return Product.substring(2, 7);
	   }
	  
	   
	   /************************************
	    * Get array stepGroup 
	    * @param eqp_type
	    * @return stepGroup 
	    *************************************/
	   public static String getArrayStepGroupByEQPType(String eqp_type)
	   {
			Hashtable ht = new Hashtable();
			ht.put("UPK","TAUPK");
			ht.put("SCN","TASCN");
			ht.put("AOH","TAAOH");
			ht.put("MRE","RTIR");
			ht.put("MSP","TAMSP");
			ht.put("MAC","TAMAC");
			ht.put("PHL","TAPHL");
			ht.put("AOL","TAAOL");
			ht.put("TPE","TATPE");
			ht.put("CDO","TACDO");
			ht.put("ILR","TAILR");
			ht.put("WET","TAWET");
			ht.put("STR","TASTR");
			ht.put("OST","TAOST");
			ht.put("ILC","TAILC");
			ht.put("CVD","TACVD");
			ht.put("NAN","TANAN");
			ht.put("DRY","TADRY");
			ht.put("ATS","TAATS");
			ht.put("FLC","TAFLC");
			ht.put("FLR","TAFLR");
			ht.put("ILR","TAILR");
			ht.put("ITO","TAITO");
			ht.put("OVN","TAOVN");	
			ht.put("SRT","DEFAULT");	
			ht.put("TEG","TATEG");
			
			if(ht.get(eqp_type)!= null)
				return ht.get(eqp_type).toString();
			else
				return "DEFAULT";
	   }
	   
	   /************************************
	    * Get cell stepGroup 
	    * @param eqp_type
	    * @return stepGroup 
	    *************************************/
	   public static String getCellStepGroupByEQPType(String eqp_type)
	   {
			Hashtable ht = new Hashtable();
			ht.put("PTI","PI_FPTI");
			ht.put("BPC","PI");
			ht.put("BPO","PI");
			ht.put("PIP","PI");
			ht.put("PPO","PI");
			ht.put("PII","PI_FPII");
			ht.put("PMI","PI_FPMI");
			ht.put("PWR","PI");
			ht.put("BOC","ODF");
			ht.put("BOO","ODF");
			ht.put("SDP","ODF");
			ht.put("SLI","ODF_FSLI");
			ht.put("DRC","ODF");
			ht.put("LCD","ODF");
			ht.put("VAB","ODF");
			ht.put("SUV","ODF");
			ht.put("MAI","ODF_FMAI");
			ht.put("LCI","ODF_FLCI");
			ht.put("CUT","CUT");
			ht.put("PMO","PI");
			ht.put("UVM","HVA");
			ht.put("AOI","HVA_FAOI");
			ht.put("UVO","HVA");
			ht.put("MAC","HVA_FMAC");
			ht.put("GAP","CELL_GAP");
			ht.put("BUR","CUT_BBUR");
			ht.put("BEV","CUT");
			ht.put("BCN","CUT");
			ht.put("TST","CUT_BTST");
			ht.put("GMO","G_MURA");
			ht.put("PCN","POL");
			ht.put("PAT","POL");
			ht.put("ACV","POL");
			ht.put("LOI","POL_BLOI");
			ht.put("MHU","POL");
			ht.put("LSC","POL");
			ht.put("DPK","POL");
			ht.put("NRP","Repair");
			ht.put("CRP","Repair");
			ht.put("OVN","CUT");
			
			if(ht.get(eqp_type)!= null)
				return ht.get(eqp_type).toString();
			else
				return "DEFAULT";
	   }
	   
	   /************************************
	    * Get cf stepGroup 
	    * @param eqp_type
	    * @return stepGroup 
	    *************************************/
	   public static String getCfStepGroupByEQPType(String eqp_type)
	   {
			Hashtable ht = new Hashtable();
			ht.put("QAI","AOI");
			ht.put("QMA","MACRO");
			ht.put("MTK","THK");
			ht.put("TTP","TTP");
			ht.put("MMA","MCPD");
			ht.put("MAI","AOI");
			ht.put("MTP","TTP");
			ht.put("QMP","MCPD");
			ht.put("ERE","REPAIR");
			ht.put("QSP","SP");
			ht.put("RTK","THK");
			ht.put("RMA","MACRO");
			ht.put("RAI","AOI");
			ht.put("GTK","THK");
			ht.put("GMA","MACRO");
			ht.put("GAI","AOI");
			ht.put("BTK","THK");
			ht.put("BMA","MACRO");
			ht.put("BAI","AOI");
			ht.put("BPH","PSH");
			ht.put("MAC","TEST");
			ht.put("NAN","MEAS");
			ht.put("AOH","TEST");
			ht.put("QRS","RS");
			ht.put("QTP","TTP");
			ht.put("TPE","MEAS");
			ht.put("CDO","MEAS");
			ht.put("ILR","TEST");
			ht.put("QTP","TTP");
			ht.put("STK","THK");
			ht.put("SMA","MACRO");
			ht.put("SAI","AOI");
			ht.put("SPH","PSH");
			ht.put("QPH","PSH");
			ht.put("ERE","REPAIR");
			ht.put("FMA","MACRO");
			
			if(ht.get(eqp_type)!= null)
				return ht.get(eqp_type).toString();
			else
				return "DEFAULT";
	   }
	   
	   /************************************
	    * negative value change positive value
	    * @param rowData
	    * @return UNI
	    *************************************/
	   public static double GetPositiveValue(String number)
	   {
		   if(Double.parseDouble(number) < 0)
		   {
			   number = number.toString().replace("-", "");
		   }
		   
		   return Double.parseDouble(number);
	   }
	   
	   
}
