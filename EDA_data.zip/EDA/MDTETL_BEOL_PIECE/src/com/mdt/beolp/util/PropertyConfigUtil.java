package com.mdt.beolp.util;

import java.util.Properties;

import org.apache.log4j.Logger;

/**
 ***************************************************
 * @Title PropertyConfigUtil
 * @author 林华锋
 * @Date 2017年3月15日下午1:53:48
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class PropertyConfigUtil {

	public static Logger logger = Logger.getLogger(PropertyConfigUtil.class);
	private Properties SYS_Properties;   // 系统参数(System Properties)
	private Properties EV_Properties;    // 环境参数(Environment Properties)
	
	/*************************** 数据库配置 **************************/
	

	/*************************** 文件配置 ****************************/

	public static final String WORK_DIR = "WORK_DIR";

	/*************************** 系统配置 ****************************/
    
	public static final String SYSTEM_GLOBAL_CONFIG = "SYSTEM_GLOBAL_CONFIG";
	public static final String SYSTEM_LOCAL_CONFIG = "SYSTEM_LOCAL_CONFIG";

	/*************************** 环境配置 ****************************/
    
	public static final String JAVA_HOME = "JAVA_HOME";
	public static final String TYNE_HOME = "TYNE_HOME";
   
	/****************************************************************/
	
	
	
	
	
	
	
	
	
	/**
     * 初始化 
     */
	
	public PropertyConfigUtil() {
	        GetEnvironmentUtil envUtil=new GetEnvironmentUtil();	     		
			try {
				EV_Properties = envUtil.getEnvironment();
			} catch (Exception e) {
			    logger.error(" Get Environment Error! Error Message: "+e.getMessage());
			}				       
	}
	
	/**
	 * 获取SYSTEM_GLOBAL_CONFIG
	 * 
	 * @return SYSTEM_GLOBAL_CONFIG
	 * @throws Exception
	 */
	public String getSystemGlobalConfig() throws Exception {
		String str = SYS_Properties.getProperty(SYSTEM_GLOBAL_CONFIG);
		if (str == null) {
			return "";
		} else {
			return SYSTEM_GLOBAL_CONFIG;
		}

	}

	/**
	 * 获取SYSTEM_LOCAL_CONFIG
	 * 
	 * @return SYSTEM_LOCAL_CONFIG
	 * @throws Exception
	 */
	public String getSystemLocalConfig() throws Exception {
		String str = SYS_Properties.getProperty(SYSTEM_LOCAL_CONFIG);
		if (str == null) {
			logger.error(SYSTEM_LOCAL_CONFIG + " not found or config error!");
		}
		return str;
	}

	/**
	 * 获取WorkDir
	 * 
	 * @return WORK_DIR
	 * @throws Exception
	 */
	public String getWorkDir() throws Exception {
		
		String str = EV_Properties.getProperty(WORK_DIR);
		if (str == null) {
			logger.error(WORK_DIR + " not found or doesn't have any values!");
		}
		 return str;
		
	}

	/**
	 * 获取JavaHome
	 * 
	 * @return JAVA_HOME
	 * @throws Exception
	 */
	public String getJavaHome() throws Exception {
		String str = EV_Properties.getProperty(JAVA_HOME);
		if (str == null) {
			logger.error(JAVA_HOME + " not found or config error!");
		}
		return str;
	}

	/**
	 * 获取TyneHome
	 * 
	 * @return TYNE_HOME
	 * @throws Exception
	 */
	public String getTyneHome() throws Exception {
		String str = EV_Properties.getProperty(TYNE_HOME);
		if (str == null) {
			logger.error(TYNE_HOME + " not found or config error! ");
		}
		return str;
	}

	public Properties getSYS_Properties() {
		return SYS_Properties;
	}
    
	public Properties getEV_Properties() {
		return EV_Properties;
	}

}
