package com.mdt.beolp.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 ***************************************************
 * @Title UseDateFormat
 * @author 林华锋
 * @Date 2017年2月21日上午11:13:12
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class DateFormatUtil {
	
	/**
	 * 把日期转为字符串
	 * 
	 * @param date  输入日期(Date 类型)
	 * @return
	 */
	public static String ConverToString(Date date) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return df.format(date);
	}

	/**
	 * 把字符串转为日期
	 * 
	 * @param strDate 输入日期（String 类型）
	 * @return
	 * @throws Exception
	 */
	public static Date ConverToDate(String strDate) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return df.parse(strDate);
	}
}
