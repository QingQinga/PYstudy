package com.mdt.cell.cell_optical_insp.entity;

import java.io.Serializable;

import com.mdt.cell.entity.CellComponentBaseEntity;

/**
 ***************************************************
 * @Title CellAICMComponentEntity
 * @author 林华锋
 * @Date 2017年4月7日下午3:38:12
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CellOpticalComponentEntity extends CellComponentBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String REVIEW_HISTORY;
	private String TAPE_HISTORY;
	private String TP_FLAG;
	private String TT_FLAG;
	private String TL_FLAG;
	private String TM_FLAG;
	private String TR_FLAG;
	private String TB_FLAG;
	private String FRONT_IMAGE_DATA;
	private String BACK_IMAGE_DATA;
	private String SYSTEM_STATUS;
	private String DEFECT_OVERVIEW_IMAGE;
	private String OPTICAL_INSP;
	private String SHOT_CNT;
	private String TTL_DEFECT_CNT;
	private String LIGHT_SET;
	private String LIGHT_SET_W;
	private String LIGHT_SET_R;
	private String LIGHT_SET_G;
	private String LIGHT_SET_B;
	private String LIGHT_SET_T;
	private String LIGHT_SET_C;
	private String BACK_TTL_DEFECT_CNT;
	private String OVERFLOW;

	public String getREVIEW_HISTORY() {
		return REVIEW_HISTORY;
	}

	public void setREVIEW_HISTORY(String rEVIEW_HISTORY) {
		REVIEW_HISTORY = rEVIEW_HISTORY;
	}

	public String getTAPE_HISTORY() {
		return TAPE_HISTORY;
	}

	public void setTAPE_HISTORY(String tAPE_HISTORY) {
		TAPE_HISTORY = tAPE_HISTORY;
	}

	public String getTP_FLAG() {
		return TP_FLAG;
	}

	public void setTP_FLAG(String tP_FLAG) {
		TP_FLAG = tP_FLAG;
	}

	public String getTT_FLAG() {
		return TT_FLAG;
	}

	public void setTT_FLAG(String tT_FLAG) {
		TT_FLAG = tT_FLAG;
	}

	public String getTL_FLAG() {
		return TL_FLAG;
	}

	public void setTL_FLAG(String tL_FLAG) {
		TL_FLAG = tL_FLAG;
	}

	public String getTM_FLAG() {
		return TM_FLAG;
	}

	public void setTM_FLAG(String tM_FLAG) {
		TM_FLAG = tM_FLAG;
	}

	public String getTR_FLAG() {
		return TR_FLAG;
	}

	public void setTR_FLAG(String tR_FLAG) {
		TR_FLAG = tR_FLAG;
	}

	public String getTB_FLAG() {
		return TB_FLAG;
	}

	public void setTB_FLAG(String tB_FLAG) {
		TB_FLAG = tB_FLAG;
	}

	public String getFRONT_IMAGE_DATA() {
		return FRONT_IMAGE_DATA;
	}

	public void setFRONT_IMAGE_DATA(String fRONT_IMAGE_DATA) {
		FRONT_IMAGE_DATA = fRONT_IMAGE_DATA;
	}

	public String getBACK_IMAGE_DATA() {
		return BACK_IMAGE_DATA;
	}

	public void setBACK_IMAGE_DATA(String bACK_IMAGE_DATA) {
		BACK_IMAGE_DATA = bACK_IMAGE_DATA;
	}

	public String getSYSTEM_STATUS() {
		return SYSTEM_STATUS;
	}

	public void setSYSTEM_STATUS(String sYSTEM_STATUS) {
		SYSTEM_STATUS = sYSTEM_STATUS;
	}

	public String getDEFECT_OVERVIEW_IMAGE() {
		return DEFECT_OVERVIEW_IMAGE;
	}

	public void setDEFECT_OVERVIEW_IMAGE(String dEFECT_OVERVIEW_IMAGE) {
		DEFECT_OVERVIEW_IMAGE = dEFECT_OVERVIEW_IMAGE;
	}

	public String getOPTICAL_INSP() {
		return OPTICAL_INSP;
	}

	public void setOPTICAL_INSP(String oPTICAL_INSP) {
		OPTICAL_INSP = oPTICAL_INSP;
	}

	public String getSHOT_CNT() {
		return SHOT_CNT;
	}

	public void setSHOT_CNT(String sHOT_CNT) {
		SHOT_CNT = sHOT_CNT;
	}

	public String getTTL_DEFECT_CNT() {
		return TTL_DEFECT_CNT;
	}

	public void setTTL_DEFECT_CNT(String tTL_DEFECT_CNT) {
		TTL_DEFECT_CNT = tTL_DEFECT_CNT;
	}

	public String getLIGHT_SET() {
		return LIGHT_SET;
	}

	public void setLIGHT_SET(String lIGHT_SET) {
		LIGHT_SET = lIGHT_SET;
	}

	public String getLIGHT_SET_W() {
		return LIGHT_SET_W;
	}

	public void setLIGHT_SET_W(String lIGHT_SET_W) {
		LIGHT_SET_W = lIGHT_SET_W;
	}

	public String getLIGHT_SET_R() {
		return LIGHT_SET_R;
	}

	public void setLIGHT_SET_R(String lIGHT_SET_R) {
		LIGHT_SET_R = lIGHT_SET_R;
	}

	public String getLIGHT_SET_G() {
		return LIGHT_SET_G;
	}

	public void setLIGHT_SET_G(String lIGHT_SET_G) {
		LIGHT_SET_G = lIGHT_SET_G;
	}

	public String getLIGHT_SET_B() {
		return LIGHT_SET_B;
	}

	public void setLIGHT_SET_B(String lIGHT_SET_B) {
		LIGHT_SET_B = lIGHT_SET_B;
	}

	public String getLIGHT_SET_T() {
		return LIGHT_SET_T;
	}

	public void setLIGHT_SET_T(String lIGHT_SET_T) {
		LIGHT_SET_T = lIGHT_SET_T;
	}

	public String getLIGHT_SET_C() {
		return LIGHT_SET_C;
	}

	public void setLIGHT_SET_C(String lIGHT_SET_C) {
		LIGHT_SET_C = lIGHT_SET_C;
	}

	public String getBACK_TTL_DEFECT_CNT() {
		return BACK_TTL_DEFECT_CNT;
	}

	public void setBACK_TTL_DEFECT_CNT(String bACK_TTL_DEFECT_CNT) {
		BACK_TTL_DEFECT_CNT = bACK_TTL_DEFECT_CNT;
	}

	public String getOVERFLOW() {
		return OVERFLOW;
	}

	public void setOVERFLOW(String oVERFLOW) {
		OVERFLOW = oVERFLOW;
	}

}
