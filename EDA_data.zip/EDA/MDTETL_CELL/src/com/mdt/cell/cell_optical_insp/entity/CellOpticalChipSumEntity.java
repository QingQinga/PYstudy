package com.mdt.cell.cell_optical_insp.entity;

import java.io.Serializable;

import com.mdt.cell.entity.CellChipSumBaseEntity;

/**
 ***************************************************
 * @Title CellOpticalChipSumEntity
 * @author 林华锋
 * @Date 2017年4月10日上午10:44:46
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class CellOpticalChipSumEntity extends CellChipSumBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
}
