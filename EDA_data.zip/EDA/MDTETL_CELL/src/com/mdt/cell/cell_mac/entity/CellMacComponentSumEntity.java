package com.mdt.cell.cell_mac.entity;

import java.io.Serializable;

import com.mdt.cell.entity.CellComponentSumBaseEntity;

/**
 ***************************************************
 * @Title CellMacComponentSumEntity
 * @author 林华锋
 * @Date 2017年4月15日下午4:19:20
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CellMacComponentSumEntity extends CellComponentSumBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

}
