package com.mdt.cell.cell_mac.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.cell.cell_mac.entity.CellMacResultEntity;
import com.mdt.cell.util.DBUtil;

/**
 ***************************************************
 * @Title  CellMacResultDao                                    
 * @author 林华锋
 * @Date   2017年4月17日上午11:49:10
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CellMacResultDao {

	private static Logger logger = Logger.getLogger(CellMacResultDao.class);

	public static boolean addCellMacResult(CellMacResultEntity Entity,Connection conn, String fid) throws Exception {

		String view = "CELL_MAC_RESULT_V";
		
		String sql = "INSERT INTO " + view
				  +"(" 
				  +"OPE_NO,"
				  +"SHEET_ID,"
				  +"END_TIME,"
				  +"PARAM_COLLECTION,"
				  +"PARAM_NAME,"
				  +"SITE_NAME,"
				  +"PARAM_VALUE,"
				  +"SPEC_HIGH,"
				  +"SPEC_LOW,"
				  +"SPEC_TARGET,"
				  +"CONTROL_HIGH,"
				  +"CONTROL_LOW,"
				  +"X,"
				  +"Y,"
				  +"CHIP_ID,"
				  +"CHIP_NO,"
				  +"JUDGE,"
				  +"SHOT_ID,"
				  +"SEQ_IN_SHOT,"
				  +"DEFINITION_X,"
				  +"DEFINITION_Y"
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA'))"
				  +")";

		Object[] params = {Entity.getOPE_NO(),
				           Entity.getSHEET_ID(),
				           Entity.getEND_TIME(),
				           Entity.getPARAM_COLLECTION(),
				           Entity.getPARAM_NAME(),
				           Entity.getSITE_NAME(),
				           Entity.getPARAM_VALUE(),
				           Entity.getSPEC_HIGH(),
				           Entity.getSPEC_LOW(),
				           Entity.getSPEC_TARGET(),
				           Entity.getCONTROL_HIGH(),
				           Entity.getCONTROL_LOW(),
				           Entity.getX(),
				           Entity.getY(),
				           Entity.getCHIP_ID(),
				           Entity.getCHIP_NO(),
				           Entity.getJUDGE(),
				           Entity.getSHOT_ID(),
				           Entity.getSEQ_IN_SHOT(),
				           Entity.getDEFINITION_X(),
				           Entity.getDEFINITION_Y()
		                  };
                           
		boolean isErrorRet = true;

		try {
			DBUtil.executeUpdate(sql, params,conn);
			logger.info(" FID: "+fid+"||   ----- Insert into "+ view +" success! ");
		} catch (Exception e) {

			logger.error(" FID: "+fid+"||   ----- Insert into "+ view +" failed! Error Message: " + e.getMessage());

			isErrorRet = false;

		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {
				logger.error(" FID: "+fid+"||   ----- An Error Cased: " + e.getMessage());
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}

	}
	
	
}
