package com.mdt.cell.cell_mura_insp.entity;

import java.io.Serializable;

import com.mdt.cell.entity.CellComponentBaseEntity;

/**
 ***************************************************
 * @Title CellMacroCompenentEntity
 * @author 林华锋
 * @Date 2017年3月29日下午1:36:49
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CellMuraInspComponentEntity extends CellComponentBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String TTL_DEFECT_CNT;
	private String SHOT_CNT;
	public String getTTL_DEFECT_CNT() {
		return TTL_DEFECT_CNT;
	}
	public void setTTL_DEFECT_CNT(String tTL_DEFECT_CNT) {
		TTL_DEFECT_CNT = tTL_DEFECT_CNT;
	}
	public String getSHOT_CNT() {
		return SHOT_CNT;
	}
	public void setSHOT_CNT(String sHOT_CNT) {
		SHOT_CNT = sHOT_CNT;
	}

	

}
