package com.mdt.cell.cell_mura_insp.entity;

import java.io.Serializable;

import com.mdt.cell.entity.CellDefectBaseEntity;

/**
 ***************************************************
 * @Title  CellMacroDefectEntity                                    
 * @author 林华锋
 * @Date   2017年4月15日下午4:08:21
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CellMuraInspDefectEntity extends CellDefectBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;
}
