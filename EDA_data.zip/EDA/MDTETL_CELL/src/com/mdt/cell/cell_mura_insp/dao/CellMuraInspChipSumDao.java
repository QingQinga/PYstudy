package com.mdt.cell.cell_mura_insp.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.cell.cell_mura_insp.entity.CellMuraInspChipSumEntity;
import com.mdt.cell.util.DBUtil;

/**
 ***************************************************
 * @Title  CellMuraInspChipSumDao                                    
 * @author 林华锋
 * @Date   2017年4月17日上午10:17:32
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class CellMuraInspChipSumDao {
	
	private static Logger logger = Logger.getLogger(CellMuraInspChipSumDao.class);

	public static boolean addCellMuraInspChipSum(CellMuraInspChipSumEntity Entity,Connection conn, String fid) throws Exception {
   
		String view ="CELL_MURA_INSP_CHIP_SUMMARY_V";

		String sql = "INSERT INTO " + view
				  +"(" 
				  +"OPE_NO,"
				  +"SHEET_ID,"
				  +"END_TIME,"
				  +"CHIP_ID,"
				  +"CHIP_NO,"
				  +"PARAM_COLLECTION,"
				  +"PARAM_NAME,"
				  +"AVG,"
				  +"MAX,"
				  +"MIN,"
				  +"STD,"
				  +"UNIFORMITY,"
				  +"RANGE,"
				  +"SPEC_HIGH,"
				  +"SPEC_LOW,"
				  +"SPEC_TARGET,"
				  +"CONTROL_HIGH,"
				  +"CONTROL_LOW,"
				  +"THREE_SIGMA"
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA'))"
				  +")";

		Object[] params = {Entity.getOPE_NO(),
				           Entity.getSHEET_ID(),
				           Entity.getEND_TIME(),
				           Entity.getCHIP_ID(),
				           Entity.getCHIP_NO(),
				           Entity.getPARAM_COLLECTION(),
				           Entity.getPARAM_NAME(),
				           Entity.getAVG(),
				           Entity.getMAX(),
				           Entity.getMIN(),
				           Entity.getSTD(),
				           Entity.getUNIFORMITY(),
				           Entity.getRANGE(),
				           Entity.getSPEC_HIGH(),
				           Entity.getSPEC_LOW(),
				           Entity.getSPEC_TARGET(),
				           Entity.getCONTROL_HIGH(),
				           Entity.getCONTROL_LOW(),
				           Entity.getTHREE_SIGMA()
		                  };
                           
                           
		boolean isErrorRet = true;

		try {

			DBUtil.executeUpdate(sql, params, conn);
		} catch (Exception e) {

			logger.error(" FID: "+fid+"||   ----- Insert into "+ view +" failed! Error Message: " + e.getMessage());

			isErrorRet = false;
			throw e;
		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {
				logger.error(" FID: "+fid+"||   ----- An Error Cased: " + e.getMessage());
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}

	}
}
