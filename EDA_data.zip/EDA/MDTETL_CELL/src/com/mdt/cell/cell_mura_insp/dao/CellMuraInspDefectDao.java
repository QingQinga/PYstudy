package com.mdt.cell.cell_mura_insp.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.cell.cell_mura_insp.entity.CellMuraInspDefectEntity;
import com.mdt.cell.util.DBUtil;

/**
 ***************************************************
 * @Title  CellMuraInspDefectDao                                     
 * @author 林华锋
 * @Date   2017年4月17日上午10:34:14
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CellMuraInspDefectDao {

	private static Logger logger = Logger.getLogger(CellMuraInspDefectDao.class);

	public static boolean addCellMuraInspDefect(CellMuraInspDefectEntity Entity,Connection conn, String fid) throws Exception {
		
		String view = "CELL_MURA_INSP_DEFECT_V";
		
		String sql = "INSERT INTO " + view
				  +"(" 
				  +"OPE_NO,"
		          +"SHEET_ID,"
		          +"END_TIME,"
		          +"CHIP_ID,"
		          +"CHIP_NO,"
		          +"DEFECT_JUDGE,"
		          +"DEFECT_CODE,"
		          +"DEFECT_CODE_DESC,"
		          +"DEFECT_PATTERN,"
		          +"DEFECT_LAYER_TYPE,"
		          +"IMAGE_DATA,"
		          +"MAIN_DEFECT_FLAG,"
		          +"REJUDGE_FLAG,"
		          +"DEFECT_SEQ_NO,"
		          +"DEFECT_GROUP,"
		          +"DEFECT_SIZE,"
		          +"DEFECT_RANK,"
		          +"CAPTURE_NO,"
		          +"S,"
		          +"G,"
		          +"X,"
		          +"Y,"
		          +"X2,"
		          +"Y2,"
		          +"X3,"
		          +"Y3,"
		          +"ARRAY_X,"
		          +"ARRAY_Y,"
		          +"ARRAY_X2,"
		          +"ARRAY_Y2,"
		          +"ARRAY_X3,"
		          +"ARRAY_Y3"
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA'))"
				  +")";

		Object[] params = {Entity.getOPE_NO(),
				           Entity.getSHEET_ID(),
				           Entity.getEND_TIME(),
				           Entity.getCHIP_ID(),
				           Entity.getCHIP_NO(),
				           Entity.getDEFECT_JUDGE(),
				           Entity.getDEFECT_CODE(),
				           Entity.getDEFECT_CODE_DESC(),
				           Entity.getDEFECT_PATTERN(),
				           Entity.getDEFECT_LAYER_TYPE(),
				           Entity.getIMAGE_DATA(),
				           Entity.getMAIN_DEFECT_FLAG(),
				           Entity.getREJUDGE_FLAG(),
				           Entity.getDEFECT_SEQ_NO(),
				           Entity.getDEFECT_GROUP(),
				           Entity.getDEFECT_SIZE(),
				           Entity.getDEFECT_RANK(),
				           Entity.getCAPTURE_NO(),
				           Entity.getS(),
				           Entity.getG(),
				           Entity.getX(),
				           Entity.getY(),
				           Entity.getX2(),
				           Entity.getY2(),
				           Entity.getX3(),
				           Entity.getY3(),
				           Entity.getARRAY_X(),
				           Entity.getARRAY_Y(),
				           Entity.getARRAY_X2(),
				           Entity.getARRAY_Y2(),
				           Entity.getARRAY_X3(),
				           Entity.getARRAY_Y3()
		                  };
                           
		boolean isErrorRet = true;

		try {
			DBUtil.executeUpdate(sql, params, conn);
		} catch (Exception e) {

			logger.error(" FID: "+fid+"||   ----- Insert into "+ view +" failed! Error Message: " + e.getMessage());

			isErrorRet = false;
			throw e;
		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {
				logger.error(" FID: "+fid+"||   ----- An Error Cased: " + e.getMessage());
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}

	}
	
}
