package com.mdt.cell.cell_mura_insp.entity;

import java.io.Serializable;

import com.mdt.cell.entity.CellResultBaseEntity;

/**
 ***************************************************
 * @Title CellMuraInspResultEntity
 * @author 林华锋
 * @Date 2017年4月17日下午3:20:08
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CellMuraInspResultEntity extends CellResultBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String COLOR_NAME;
	private String THICKNESS_NAME;

	public String getCOLOR_NAME() {
		return COLOR_NAME;
	}

	public void setCOLOR_NAME(String cOLOR_NAME) {
		COLOR_NAME = cOLOR_NAME;
	}

	public String getTHICKNESS_NAME() {
		return THICKNESS_NAME;
	}

	public void setTHICKNESS_NAME(String tHICKNESS_NAME) {
		THICKNESS_NAME = tHICKNESS_NAME;
	}

}
