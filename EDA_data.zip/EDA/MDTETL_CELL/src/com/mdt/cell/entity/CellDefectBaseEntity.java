package com.mdt.cell.entity;

import java.io.Serializable;

/**
 ***************************************************
 * @Title CellDefectBaseEntity
 * @author 林华锋
 * @Date 2017年4月15日下午3:41:38
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CellDefectBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String OPE_NO;
	private String SHEET_ID;
	private String END_TIME;
	private String CHIP_ID;
	private String CHIP_NO;
	private String DEFECT_JUDGE;
	private String DEFECT_CODE;
	private String DEFECT_CODE_DESC;
	private String DEFECT_PATTERN;
	private String DEFECT_LAYER_TYPE;
	private String IMAGE_DATA;
	private String MAIN_DEFECT_FLAG;
	private String REJUDGE_FLAG;
	private String DEFECT_SEQ_NO;
	private String DEFECT_GROUP;
	private String DEFECT_SIZE;
	private String DEFECT_RANK;
	private String CAPTURE_NO;
	private String S;
	private String G;
	private String X;
	private String Y;
	private String X2;
	private String Y2;
	private String X3;
	private String y3;
	private String ARRAY_X;
	private String ARRAY_Y;
	private String ARRAY_X2;
	private String ARRAY_Y2;
	private String ARRAY_X3;
	private String ARRAY_Y3;

	public String getOPE_NO() {
		return OPE_NO;
	}

	public void setOPE_NO(String oPE_NO) {
		OPE_NO = oPE_NO;
	}

	public String getSHEET_ID() {
		return SHEET_ID;
	}

	public void setSHEET_ID(String sHEET_ID) {
		SHEET_ID = sHEET_ID;
	}

	public String getEND_TIME() {
		return END_TIME;
	}

	public void setEND_TIME(String eND_TIME) {
		END_TIME = eND_TIME;
	}

	public String getCHIP_ID() {
		return CHIP_ID;
	}

	public void setCHIP_ID(String cHIP_ID) {
		CHIP_ID = cHIP_ID;
	}

	public String getCHIP_NO() {
		return CHIP_NO;
	}

	public void setCHIP_NO(String cHIP_NO) {
		CHIP_NO = cHIP_NO;
	}

	public String getDEFECT_JUDGE() {
		return DEFECT_JUDGE;
	}

	public void setDEFECT_JUDGE(String dEFECT_JUDGE) {
		DEFECT_JUDGE = dEFECT_JUDGE;
	}

	public String getDEFECT_CODE() {
		return DEFECT_CODE;
	}

	public void setDEFECT_CODE(String dEFECT_CODE) {
		DEFECT_CODE = dEFECT_CODE;
	}

	public String getDEFECT_CODE_DESC() {
		return DEFECT_CODE_DESC;
	}

	public void setDEFECT_CODE_DESC(String dEFECT_CODE_DESC) {
		DEFECT_CODE_DESC = dEFECT_CODE_DESC;
	}

	public String getDEFECT_PATTERN() {
		return DEFECT_PATTERN;
	}

	public void setDEFECT_PATTERN(String dEFECT_PATTERN) {
		DEFECT_PATTERN = dEFECT_PATTERN;
	}

	public String getDEFECT_LAYER_TYPE() {
		return DEFECT_LAYER_TYPE;
	}

	public void setDEFECT_LAYER_TYPE(String dEFECT_LAYER_TYPE) {
		DEFECT_LAYER_TYPE = dEFECT_LAYER_TYPE;
	}

	public String getIMAGE_DATA() {
		return IMAGE_DATA;
	}

	public void setIMAGE_DATA(String iMAGE_DATA) {
		IMAGE_DATA = iMAGE_DATA;
	}

	public String getMAIN_DEFECT_FLAG() {
		return MAIN_DEFECT_FLAG;
	}

	public void setMAIN_DEFECT_FLAG(String mAIN_DEFECT_FLAG) {
		MAIN_DEFECT_FLAG = mAIN_DEFECT_FLAG;
	}

	public String getREJUDGE_FLAG() {
		return REJUDGE_FLAG;
	}

	public void setREJUDGE_FLAG(String rEJUDGE_FLAG) {
		REJUDGE_FLAG = rEJUDGE_FLAG;
	}

	public String getDEFECT_SEQ_NO() {
		return DEFECT_SEQ_NO;
	}

	public void setDEFECT_SEQ_NO(String dEFECT_SEQ_NO) {
		DEFECT_SEQ_NO = dEFECT_SEQ_NO;
	}

	public String getDEFECT_GROUP() {
		return DEFECT_GROUP;
	}

	public void setDEFECT_GROUP(String dEFECT_GROUP) {
		DEFECT_GROUP = dEFECT_GROUP;
	}

	public String getDEFECT_SIZE() {
		return DEFECT_SIZE;
	}

	public void setDEFECT_SIZE(String dEFECT_SIZE) {
		DEFECT_SIZE = dEFECT_SIZE;
	}

	public String getDEFECT_RANK() {
		return DEFECT_RANK;
	}

	public void setDEFECT_RANK(String dEFECT_RANK) {
		DEFECT_RANK = dEFECT_RANK;
	}

	public String getCAPTURE_NO() {
		return CAPTURE_NO;
	}

	public void setCAPTURE_NO(String cAPTURE_NO) {
		CAPTURE_NO = cAPTURE_NO;
	}

	public String getS() {
		return S;
	}

	public void setS(String s) {
		S = s;
	}

	public String getG() {
		return G;
	}

	public void setG(String g) {
		G = g;
	}

	public String getX() {
		return X;
	}

	public void setX(String x) {
		X = x;
	}

	public String getY() {
		return Y;
	}

	public void setY(String y) {
		Y = y;
	}

	public String getX2() {
		return X2;
	}

	public void setX2(String x2) {
		X2 = x2;
	}

	public String getY2() {
		return Y2;
	}

	public void setY2(String y2) {
		Y2 = y2;
	}

	public String getX3() {
		return X3;
	}

	public void setX3(String x3) {
		X3 = x3;
	}

	public String getY3() {
		return y3;
	}

	public void setY3(String y3) {
		this.y3 = y3;
	}

	public String getARRAY_X() {
		return ARRAY_X;
	}

	public void setARRAY_X(String aRRAY_X) {
		ARRAY_X = aRRAY_X;
	}

	public String getARRAY_Y() {
		return ARRAY_Y;
	}

	public void setARRAY_Y(String aRRAY_Y) {
		ARRAY_Y = aRRAY_Y;
	}

	public String getARRAY_X2() {
		return ARRAY_X2;
	}

	public void setARRAY_X2(String aRRAY_X2) {
		ARRAY_X2 = aRRAY_X2;
	}

	public String getARRAY_Y2() {
		return ARRAY_Y2;
	}

	public void setARRAY_Y2(String aRRAY_Y2) {
		ARRAY_Y2 = aRRAY_Y2;
	}

	public String getARRAY_X3() {
		return ARRAY_X3;
	}

	public void setARRAY_X3(String aRRAY_X3) {
		ARRAY_X3 = aRRAY_X3;
	}

	public String getARRAY_Y3() {
		return ARRAY_Y3;
	}

	public void setARRAY_Y3(String aRRAY_Y3) {
		ARRAY_Y3 = aRRAY_Y3;
	}

}
