package com.mdt.cell.entity;

public class StepEntity {

	private String STEP_ID;
	private String STEP_SEQ;
	private String STEP_DESC;
	private String STEP_GROUP;
	private String STEP_TYPE;
	private String UPDATE_TIME;

	public String getSTEP_ID() {
		return STEP_ID;
	}

	public void setSTEP_ID(String sTEP_ID) {
		STEP_ID = sTEP_ID;
	}

	public String getSTEP_SEQ() {
		return STEP_SEQ;
	}

	public void setSTEP_SEQ(String sTEP_SEQ) {
		STEP_SEQ = sTEP_SEQ;
	}

	public String getSTEP_DESC() {
		return STEP_DESC;
	}

	public void setSTEP_DESC(String sTEP_DESC) {
		STEP_DESC = sTEP_DESC;
	}

	public String getSTEP_GROUP() {
		return STEP_GROUP;
	}

	public void setSTEP_GROUP(String sTEP_GROUP) {
		STEP_GROUP = sTEP_GROUP;
	}

	public String getSTEP_TYPE() {
		return STEP_TYPE;
	}

	public void setSTEP_TYPE(String sTEP_TYPE) {
		STEP_TYPE = sTEP_TYPE;
	}

	public String getUPDATE_TIME() {
		return UPDATE_TIME;
	}

	public void setUPDATE_TIME(String uPDATE_TIME) {
		UPDATE_TIME = uPDATE_TIME;
	}

}
