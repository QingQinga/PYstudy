package com.mdt.cell.entity;

import java.io.Serializable;

/**
 ***************************************************
 * @Title  CellChipBaseEntity                                    
 * @author 林华锋
 * @Date   2017年4月15日下午3:39:55
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CellChipBaseEntity implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String OPE_NO;
	private String SHEET_ID;
	private String END_TIME;
	private String CHIP_ID;
	private String CHIP_NO;
	private String CHIP_JUDGE;
	private String MAIN_DEFECT_CODE;
	private String PANEL_RANK;
	private String PANEL_TTL_DEFECT_CNT;
    private String USER_ID; 
    
	public String getOPE_NO() {
		return OPE_NO;
	}

	public void setOPE_NO(String oPE_NO) {
		OPE_NO = oPE_NO;
	}

	public String getSHEET_ID() {
		return SHEET_ID;
	}

	public void setSHEET_ID(String sHEET_ID) {
		SHEET_ID = sHEET_ID;
	}

	public String getEND_TIME() {
		return END_TIME;
	}

	public void setEND_TIME(String eND_TIME) {
		END_TIME = eND_TIME;
	}

	public String getCHIP_ID() {
		return CHIP_ID;
	}

	public void setCHIP_ID(String cHIP_ID) {
		CHIP_ID = cHIP_ID;
	}

	public String getCHIP_NO() {
		return CHIP_NO;
	}

	public void setCHIP_NO(String cHIP_NO) {
		CHIP_NO = cHIP_NO;
	}

	public String getCHIP_JUDGE() {
		return CHIP_JUDGE;
	}

	public void setCHIP_JUDGE(String cHIP_JUDGE) {
		CHIP_JUDGE = cHIP_JUDGE;
	}

	public String getMAIN_DEFECT_CODE() {
		return MAIN_DEFECT_CODE;
	}

	public void setMAIN_DEFECT_CODE(String mAIN_DEFECT_CODE) {
		MAIN_DEFECT_CODE = mAIN_DEFECT_CODE;
	}

	public String getPANEL_RANK() {
		return PANEL_RANK;
	}

	public void setPANEL_RANK(String pANEL_RANK) {
		PANEL_RANK = pANEL_RANK;
	}

	public String getPANEL_TTL_DEFECT_CNT() {
		return PANEL_TTL_DEFECT_CNT;
	}

	public void setPANEL_TTL_DEFECT_CNT(String pANEL_TTL_DEFECT_CNT) {
		PANEL_TTL_DEFECT_CNT = pANEL_TTL_DEFECT_CNT;
	}

	public String getUSER_ID() {
		return USER_ID;
	}

	public void setUSER_ID(String uSER_ID) {
		USER_ID = uSER_ID;
	}
	
	
	
}
