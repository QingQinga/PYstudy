package com.mdt.cell.tableview;

public class ETLFileHstTableView extends ETLFileTableView{
	
	public String getTID() {
		return (String)data.get("TID");
	}
	@SuppressWarnings("unchecked")
	public void setTID(String TID) {
		data.put("TID", TID);
	}

	public String getDATA_FILE_PATH() {
		return (String)data.get("DATA_FILE_PATH");
	}
	@SuppressWarnings("unchecked")
	public void setDATA_FILE_PATH(String DATA_FILE_PATH) {
		data.put("DATA_FILE_PATH", DATA_FILE_PATH);
	}
	
	public String getEDA_STATUS() {
		return (String)data.get("EDA_STATUS");
	}
	
	@SuppressWarnings("unchecked")
	public void setEDA_STATUS(String EDA_STATUS) {
		data.put("EDA_STATUS", EDA_STATUS);
	}

	public String getEDA_FINISH_TIME() {
		return (String)data.get("EDA_FINISH_TIME");
	}
	@SuppressWarnings("unchecked")
	public void setEDA_FINISH_TIME(String EDA_FINISH_TIME) {
		data.put("EDA_FINISH_TIME", EDA_FINISH_TIME);
	}
	
	public String getEDA_ERROR_MSG() {
		return (String)data.get("EDA_ERROR_MSG");
	}
	@SuppressWarnings("unchecked")
	public void setEDA_ERROR_MSG(String EDA_ERROR_MSG) {
		data.put("EDA_ERROR_MSG", EDA_ERROR_MSG);
	}
	
	public String getSPC_STATUS() {
		return (String)data.get("SPC_STATUS");
	}
	@SuppressWarnings("unchecked")
	public void setSPC_STATUS(String SPC_STATUS) {
		data.put("SPC_STATUS", SPC_STATUS);
	}

	public String getSPC_FINISH_TIME() {
		return (String)data.get("SPC_FINISH_TIME");
	}
	@SuppressWarnings("unchecked")
	public void setSPC_FINISH_TIME(String SPC_FINISH_TIME) {
		data.put("SPC_FINISH_TIME", SPC_FINISH_TIME);
	}
	
	public String getSPC_ERROR_MSG() {
		return (String)data.get("SPC_ERROR_MSG");
	}
	@SuppressWarnings("unchecked")
	public void setSPC_ERROR_MSG(String SPC_ERROR_MSG) {
		data.put("SPC_ERROR_MSG", SPC_ERROR_MSG);
	}
	
}
