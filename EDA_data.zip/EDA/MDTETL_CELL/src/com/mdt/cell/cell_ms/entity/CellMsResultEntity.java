package com.mdt.cell.cell_ms.entity;

import java.io.Serializable;

import com.mdt.cell.entity.CellResultBaseEntity;

/**
 ***************************************************
 * @Title CellMacResultEntity
 * @author 林华锋
 * @Date 2017年4月15日下午4:41:03
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CellMsResultEntity extends CellResultBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String SHOT_ID;
	private String SEQ_IN_SHOT;
	private String DEFINITION_X;
	private String DEFINITION_Y;

	public String getSHOT_ID() {
		return SHOT_ID;
	}

	public void setSHOT_ID(String sHOT_ID) {
		SHOT_ID = sHOT_ID;
	}

	public String getSEQ_IN_SHOT() {
		return SEQ_IN_SHOT;
	}

	public void setSEQ_IN_SHOT(String sEQ_IN_SHOT) {
		SEQ_IN_SHOT = sEQ_IN_SHOT;
	}

	public String getDEFINITION_X() {
		return DEFINITION_X;
	}

	public void setDEFINITION_X(String dEFINITION_X) {
		DEFINITION_X = dEFINITION_X;
	}

	public String getDEFINITION_Y() {
		return DEFINITION_Y;
	}

	public void setDEFINITION_Y(String dEFINITION_Y) {
		DEFINITION_Y = dEFINITION_Y;
	}

}
