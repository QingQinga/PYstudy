package com.mdt.cell.util;

import java.math.BigDecimal;

//import com.sun.org.apache.xalan.internal.xsltc.runtime.Hashtable;
import java.util.Hashtable;


/**
*
* @author  HuChen
*/
public class StatisticUtil {

	   /************************************
	   * Get maximum
	   * @param rowData
	   * @return maximum
	   *************************************/
	   public static double GetMaxValue(String rowData)
	   {
		   String[] iRetValue = rowData.split(";", -1) ;
		   double max =Double.parseDouble(iRetValue[0]); 
		   for(int i=0;i<iRetValue.length -1;i++) 
		   { 
			   if(max<Double.parseDouble(iRetValue[i]))
			   { 
				   max = Double.parseDouble(iRetValue[i]); 
			   } 
		   }		   
		   return max;
	   }
	   
	   /************************************
	   * Get Range
	   * @param max
	   * @param min
	   * @return range
	   *************************************/
	   public static double GetRangeValue(String max,String min)
	   {
		   double range=Double.parseDouble(max) - Double.parseDouble(min);

		   return range;
	   }
	   
	   /************************************
	   * Get UNI
	   * @param rowData
	   * @return UNI
	   *************************************/
	   public static double GetUniValue(String max,String min,String avg)
	   {
		   double uni =0;
		   uni =(Double.parseDouble(max) -Double.parseDouble(min))/(2*Double.parseDouble(avg));
		   return uni;
	   }
	   
	   /************************************
	   * Get AVG
	   * @param rowData
	   * @return AVG
	   *************************************/
	   public static double GetAvgValue(String rowData)
	   {
		   String[] iRetValue = rowData.split(";", -1) ;
		   double sum=0;
		   for(int i=0;i<iRetValue.length -1;i++) { 
			   sum += Double.parseDouble(iRetValue[i]);
		   }
		   return sum/(iRetValue.length-1);
	   }
	   
	   /************************************
	   * Get STD
	   * @param rowData
	   * @return STD
	   *************************************/
	   public static double GetStandValue(String rowData)
	   {
		   String[] iRetValue = rowData.split(";", -1) ;
		   if (iRetValue.length==2) 
		   {
			   return 0;
		   }else
		   {
			   double sum=0;
			   double average =0;
			   for(int i=0;i<iRetValue.length-1;i++) { 
				   sum += Double.parseDouble(iRetValue[i]);
			   }
			   average = sum/(iRetValue.length-1);
			   
			   double temp=0;
			   for(int i=0;i<iRetValue.length-1;i++)
			   {
				   temp+=Math.pow((Double.parseDouble(iRetValue[i])-average), 2);
			   }
			   //temp = temp/(iRetValue.length-1);
			   temp = temp/(iRetValue.length-2);// modify by yidong 2012/1/6

			   return   Math.sqrt(temp);
		   }
		  

		   
	   }
	   
	   /************************************
	   * Get COUNT
	   * @param rowData
	   * @return COUNT
	   *************************************/
	   public static int GetCountValue(String rowData)
	   {
		   String[] iRetValue = rowData.split(";", -1) ;
		   return iRetValue.length -1;
	   }
	   
	   /************************************
	   * Get MAX
	   * @param rowData
	   * @return MAX
	   *************************************/
	   public static double GetMinValue(String rowData)
	   {
		   String[] iRetValue = rowData.split(";", -1) ;
		   double max =Double.parseDouble(iRetValue[0]); 
		   for(int i=0;i<iRetValue.length -1;i++) { 
			   if(max>Double.parseDouble(iRetValue[i])) { 
				   max = Double.parseDouble(iRetValue[i]); 
			   } 
		   }
		   
		   return max;
	   }
	   
	   /************************************
		*Double
		* @param d1
		* @param d2
		* @return 
		*************************************/
	    public static double sub(String d1,String d2)
	    {
	    	BigDecimal bd1=new BigDecimal(d1);
	    	BigDecimal bd2=new BigDecimal(d2);
	    	return  bd1.subtract(bd2).doubleValue();
	    }
	    
	    /************************************
		*Double
		* @param d1
		* @param d2
		* @return 
		*************************************/
	    public static double doubleAdd(String d1,String d2)
		{
			    BigDecimal bd1=new BigDecimal(d1);
			    BigDecimal bd2=new BigDecimal(d2);
			    return  bd1.add(bd2).doubleValue();
		}
	    
	    /************************************
		*Double
		* @param d1
		* @param d2
		* @return 
		*************************************/
	    public static   double   convert(double   value)
	    {   
	        long   l1   =   Math.round(value*100);   //��鈭   
	        double   ret   =   l1/100.0;                
	        return   ret;   
	    }
	    
	   public static String GetProduct(String Product)
	   {
		   return Product.substring(2, 7);
	   }
	  

	   /************************************
	    * negative value change positive value
	    * @param rowData
	    * @return UNI
	    *************************************/
	   public static double GetPositiveValue(String number)
	   {
		   if(Double.parseDouble(number) < 0)
		   {
			   number = number.toString().replace("-", "");
		   }
		   
		   return Double.parseDouble(number);
	   }
	   
	   
}
