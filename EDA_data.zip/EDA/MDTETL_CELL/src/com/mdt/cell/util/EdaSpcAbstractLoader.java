package com.mdt.cell.util;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.LinkedList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.mdt.cell.tableview.ETLFileTableView;
import com.mdt.cell.tableview.SessionConstants;

public abstract class EdaSpcAbstractLoader
{
	private static Connection eda_conn;
	private static Connection spc_conn;
	private static Connection tm_conn;
	protected static LoaderProperty m_prop;
	private static Logger logger = Logger.getLogger(EdaSpcAbstractLoader.class);

	@SuppressWarnings("rawtypes")
	private static LinkedList all_files = new LinkedList();
	public static boolean getFileInfoFromDB = true;
	public static boolean edaSuccessFlag = true;//true:eda run successfully,false:eda run fail
	public static boolean spcSuccessFlag = true;//true:spc run successfully,false:spc run fail
	public static boolean spcRunFlag = false;
	public static LogDBUtil logDBUtil = new LogDBUtil();
	
	public static String eda_enable;
	public static String spc_enable;
    
	public abstract String getLoaderName();
	public abstract void readyToRun(File file) throws Exception;
	public abstract boolean checkFileFormat(File file) throws Exception;
	//public abstract File Run(ETLFileTableView tableView) throws Exception;
	
	protected static String lot_id;
	protected static String parent_lot_id;
	protected static String FID;
	protected static String date_dir;
	protected static String product_id;
    
    /************************************
	* Initialize connection information,And create EDA DB AND EDC DB connection
	*************************************/
	public EdaSpcAbstractLoader(String systemConfigDir,String logConfigDir) throws Exception
	{	
				
		if(systemConfigDir == null || logConfigDir ==  null){
			m_prop = new LoaderProperty();
			logConfigDir = m_prop.GetLog4jConfigDir();
			SessionConstants.SET_TID(m_prop.GetTID());
	    	SessionConstants.SET_SHOP(m_prop.GetShop());
	    	SessionConstants.SET_SOURCE(m_prop.GetDataSource());
	    	SessionConstants.SET_EQP_TYPE(m_prop.GetEqpType());
	    	SessionConstants.SET_TARGET_FLAG(m_prop.GetTargetFlag());
	    	SessionConstants.SET_WORK_DIR(m_prop.GetWorkDir());
	    	SessionConstants.SET_MAX_COUNT(m_prop.GetMaxCount());
	    	if(!m_prop.GetSystemGlobalConfig().equalsIgnoreCase(""))
	    		SessionConstants.SET_SYSTEM_CONFIG_DIR(m_prop.GetSystemGlobalConfig());
	    	else if(!m_prop.GetSystemLocalConfig().equalsIgnoreCase(""))
	    		SessionConstants.SET_SYSTEM_CONFIG_DIR(m_prop.GetSystemLocalConfig());
	    	SessionConstants.SET_LOG_CONFIG_DIR(logConfigDir);
	    	SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(m_prop.getActivateDbFindMtehod());
	    	SessionConstants.SET_EXPORT_LOG_FLAG(m_prop.GetExportLogFlag());
		}else{
			m_prop = new LoaderProperty(systemConfigDir,logConfigDir);
		}
		
		//logDBUtil.getLogDBProperties();
    	PropertyConfigurator.configure(logConfigDir);
    	
		logger.info("systemConfigDir="+systemConfigDir);
    	logger.info("logConfigDir="+logConfigDir);

		spc_enable = m_prop.GetSpc_Eenble();
		
		/**Create EDA DB connection**/
		setEdaConnection();

		/**Create SPC DB connection**/
		if(spc_enable.equalsIgnoreCase("true"))
		{	
			setSpcConnection();
		}
		
		setTMConnection();
			
	}
		
	
	/************************************
	* Find all files from source folder,and move to related folder,and rename file
	*************************************/
	@SuppressWarnings("unchecked")
	public void run() throws Exception
	{
		try
		{	
			Timestamp today = new Timestamp(System.currentTimeMillis());
			SimpleDateFormat dateDirFmt = new SimpleDateFormat("yyyyMM");
			date_dir = dateDirFmt.format(today);
		
			String dfs_root_path = m_prop.GetDfsRootPath();
			setStartTime(new Timestamp(System.currentTimeMillis()));
			
			//get file list
			if("false".equalsIgnoreCase(SessionConstants.GET_ACTIVATE_DB_FIND_METHOD()))
			{	
				logger.info("Geting data files from Source folder......");
				getFileInfoFromDB = false;
				String dirs = SessionConstants.GET_WORK_DIR() + File.separator + "SOURCE";
				
				File fileSource = new File(dirs);
				
				runByDebug(fileSource);
				
				return;
											
			}else {
				logger.info("Geting data files from DB......");
				String PID = new Long(SystemUtil.getPID()).toString();

		    	try{
		    		TranslatorTableControlUtil.updateConfigPID(getTMConnection(), SessionConstants.GET_TID(), PID);
		    	}catch(Exception ex){
		    		String ex_detial_message = LogHandlerUtil.getStackTraceMessage(ex);
					logger.error("[Error]Update PID failed.");
					logger.error(ex_detial_message);
		    	}
				/** Get data files from DB **/
		    	getListFileFromDb();
			}
				
			ETLFileTableView[] dmyFileTableViews = (ETLFileTableView[]) all_files.toArray(new ETLFileTableView[all_files.size()]); 
			
			//if file count > max_count, run_count = max_count
			int run_count = dmyFileTableViews.length;
			if(SessionConstants.GET_MAX_COUNT() != null){
				try{
					int max_count = Integer.parseInt(SessionConstants.GET_MAX_COUNT().trim());
					if (max_count > 0 && max_count < dmyFileTableViews.length){
						run_count = max_count;
					}
				}catch(Exception ex){
					
				}
			}
			logger.info("Total " + run_count + " file(s) found  ");
			
			// start main flow
			String dmyFilePath = null;
			for(int j=0; j < run_count; j++)
			{
				FID = dmyFileTableViews[j].getFID();
				product_id = dmyFileTableViews[j].getPRODUCT_ID();
				dmyFilePath = dfs_root_path + dmyFileTableViews[j].getFILE_SRC_DIR();
				File dmyFile = new File(dmyFilePath);				
				
				if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
					logger.info("Processing " + (j+1) + " of " + run_count + " : " + dmyFile.getPath() + "...");
				}
				
				//update etl_file_t field 'PARSE_FLAG'
				if(getFileInfoFromDB)
				{
					try{
						TranslatorTableControlUtil.updateETLFileParseFlag(getTMConnection(),dmyFileTableViews[j].getFID());
						dmyFileTableViews[j].setPARSE_FLAG("Y");
					}catch(Exception ex){
						if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
							logger.error("Can't update etl_file_t field 'PARSE_FLAG'.");
						}
						continue;
					}
				}
				
				//init CURRENT_FILE_SRC_DIR
				dmyFileTableViews[j].setCURRENT_FILE_SRC_DIR("");
				//check dummy file status
				boolean checkDmyFileStatus = checkDmyFileStatus(dmyFile);		
				//move dummy file to translator source folder
				boolean movefileResult = false;
				if(checkDmyFileStatus) { 
					try {						
						movefileResult = FileUtil.MoveFile(dmyFile.getParent(), SessionConstants.GET_WORK_DIR() + 
								File.separator + "SOURCE", dmyFile.getName());
					}
					catch (Exception e) {						
						if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
							logger.error("Can't move dummy file to translator source folder.");
						}
						continue;
					}
					if (movefileResult){ //movefileResult
						dmyFileTableViews[j].setCURRENT_FILE_SRC_DIR(SessionConstants.GET_WORK_DIR() + 
							File.separator + "SOURCE" + File.separator + dmyFileTableViews[j].getFILE_NAME());
						dmyFile = new File(dmyFileTableViews[j].getCURRENT_FILE_SRC_DIR());
					}
					else {
						checkDmyFileStatus = false;
					}
				}

				boolean checkDataFileStatus = false;
				String dataFilePath = null;
				File dataFile = null;
				//check data file status
				if(checkDmyFileStatus)
				{ 	
					//by dummy get data file path
					dataFilePath = getDataFilePath(dmyFileTableViews[j]);
					
					if (dataFilePath != null ){			
						dataFile = new File(dataFilePath);
						//check data file status
						checkDataFileStatus = checkDataFileStatus(dataFile);
					}
				}
				
				//copy etl_file_t to etl_file_hst_t
				transferETLFileToHst(getTMConnection(),dmyFileTableViews[j]);
				
				if(checkDmyFileStatus && checkDataFileStatus)
				{   
					Timestamp fileStart = new Timestamp(System.currentTimeMillis());
						
					try
					{
						//update TID, DATA_PATH
						TranslatorTableControlUtil.updateETLFileHst(getTMConnection(), "TRANSLATOR",  new String[]{SessionConstants.GET_TID(),dataFilePath,dmyFileTableViews[j].getFID()});
						
						readyToRun(dataFile);
																	
						if(getEdaSuccessFlag() && getSpcSuccessFlag()) {
							dmyFileEndHandle(dmyFileTableViews[j].getFID(), dmyFile, dataFile, "SUCCESS", dmyFileTableViews[j].getCURRENT_FILE_SRC_DIR(),"");											
						}else if (!getEdaSuccessFlag()) {							
							dmyFileEndHandle(dmyFileTableViews[j].getFID(), dmyFile, dataFile, "EDA_ERROR", dmyFileTableViews[j].getCURRENT_FILE_SRC_DIR(), "Parsing data file fail(EDA)");
						}else if (!getSpcSuccessFlag()) {							
							dmyFileEndHandle(dmyFileTableViews[j].getFID(), dmyFile, dataFile, "SPC_ERROR", dmyFileTableViews[j].getCURRENT_FILE_SRC_DIR(), "Parsing data file fail(SPC)");
						}
						/*
						else {
							dmyFileEndHandle(dmyFileTableViews[j].getFID(), dmyFile, dataFile, "BOTH_ERROR", dmyFileTableViews[j].getCURRENT_FILE_SRC_DIR(), "Parsing data file fail");
						}
						*/
					}
					catch(Exception e)
					{
						if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
							logger.error(e.getMessage());
						}
						
						dmyFileEndHandle(dmyFileTableViews[j].getFID(), dmyFile, dataFile, "EDA_ERROR", dmyFileTableViews[j].getCURRENT_FILE_SRC_DIR(), "Parsing data file fail: " + e.getMessage());	
					}
					finally
					{
						Timestamp fileEnd = new Timestamp(System.currentTimeMillis());
						SimpleDateFormat fmt = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
						logger.info("Start Process file at:" + fmt.format(fileStart));
						logger.info("End Process file at:" + fmt.format(fileEnd));
						
						try{
							if(eda_conn != null)
							  eda_conn.commit();
							if(spc_conn != null)
							  spc_conn.commit();
							
						}catch(SQLException ex){
							logger.error(ex.getMessage());
						}
					}
				    
					System.gc();
				}
				else
				{
					if (!checkDmyFileStatus) {
						
						dmyFileEndHandle(dmyFileTableViews[j].getFID(), dmyFile, dataFile, "EDA_ERROR", dmyFileTableViews[j].getCURRENT_FILE_SRC_DIR(), "Check dummy file status is not ok");
					}
					else if (!checkDataFileStatus) {
						
						dmyFileEndHandle(dmyFileTableViews[j].getFID(), dmyFile, dataFile, "EDA_ERROR", dmyFileTableViews[j].getCURRENT_FILE_SRC_DIR(), "Check data file status is not ok");
					}
				}
				
				//data file handle
				if(getFileInfoFromDB){
					try{
						//logger.info("delete data_file");
						TranslatorTableControlUtil.deleteETLFile(getTMConnection(), new String[]{dmyFileTableViews[j].getFID()});
					}catch(Exception ex){
						if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
							logger.error("Can't delete etl_file_t record.");
						}
						//throw ex;
					}
				}
			}
			
		}
		catch(Exception ex){
			
			logger.error(ex.getMessage());
		}
		finally
		{
			if(getFileInfoFromDB)
			{
				try{
					TranslatorTableControlUtil.updateConfigPID(getTMConnection(), SessionConstants.GET_TID(), "");
					TranslatorTableControlUtil.updateConfigRunFlag(getTMConnection(), SessionConstants.GET_TID(), "");
				}catch(Exception ex){
					logger.error(LogHandlerUtil.getStackTraceMessage(ex));
				}
			}
			
			if(eda_conn != null)
				eda_conn.close();
			if(spc_conn != null)
				spc_conn.close();
			
			if(tm_conn != null)
			{
				if(getFileInfoFromDB)
					tm_conn.commit();
				
				tm_conn.close();	
			}
			
			setEndTime(new Timestamp(System.currentTimeMillis()));
			SimpleDateFormat fmt = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
				logger.info("Loader started at:" + fmt.format(getStartTime()));
				logger.info("Loader ended at:" + fmt.format(getEndTime()));	
				logger.info("=======================End=======================");
			}
		}
		
	}
	
	
    /************************************
	* Find all files from source folder
	*************************************/
	@SuppressWarnings("unchecked")
	public void getListFileFromDb()
	{	
		ETLFileTableView[] dmyFileTableViews = null;
		
		try{
			String[] paramValueList = new String[4];
			paramValueList[0] = SessionConstants.GET_SOURCE();
			paramValueList[1] = SessionConstants.GET_SHOP();
			paramValueList[2] = SessionConstants.GET_EQP_TYPE();
			paramValueList[3] = SessionConstants.GET_TARGET_FLAG(); 
			
			dmyFileTableViews = TranslatorTableControlUtil.getETLFileList(getTMConnection(), paramValueList , SessionConstants.GET_MAX_COUNT());
			
		}catch(Exception ex){

			if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
				logger.info("Get file list from DB is failed");
			}
		}
		
		for (int i = 0; i < dmyFileTableViews.length; i++) {
			
			all_files.add(dmyFileTableViews[i]);
		}
		
	}
	
	/************************************
	* Find all files from source folder,and file type is "TXT" or "CSV"
	*************************************/
	@SuppressWarnings("unchecked")
	public static void getListFileFromSoruce(File f, String[] fileOtherInfo)
	{	
		
	   if (f.isDirectory()) 
	   {
		   File[] t = f.listFiles();
		   
		   for(int i = 0; i < t.length; i++)
		   {
			   getListFileFromSoruce(t[i],fileOtherInfo);	
		   }
	   } 
	   else
	   { 
		   String isSourceDir = f.getParentFile().toString().substring(f.getParentFile().toString().length() -6, f.getParentFile().toString().length());		   

		   if(isSourceDir.equalsIgnoreCase("source"))
		   {
			   if(f.getAbsolutePath().endsWith("dmy") || f.getAbsolutePath().endsWith("DMY"))
			   {
				   ETLFileTableView dmyFileTableView = new ETLFileTableView();
				   dmyFileTableView.setFID("0");
				   dmyFileTableView.setEQUIP_TYPE(fileOtherInfo[0]);
				   dmyFileTableView.setFILE_SOURCE(fileOtherInfo[1]);
				   dmyFileTableView.setSHOP(fileOtherInfo[2]);
				   dmyFileTableView.setFILE_NAME(f.getName());
				   dmyFileTableView.setFILE_SIZE(new Long(f.length()).toString());
				   dmyFileTableView.setFILE_SRC_DIR(f.getParent());
				   int i = f.getName().lastIndexOf('.');
				   if (i > 0) {
					   dmyFileTableView.setFILE_TYPE(f.getName().substring(i+1));
				   }
				   
				   all_files.add(dmyFileTableView);   
			   }
		   }
	   }
	}
			
	/************************************
	* Set EDA connection
	* @param Connection
	*************************************/
	public void setEdaConnection(Connection conn)
	{
		eda_conn = conn;
	}
	
	public static void setEdaConnection() throws Exception
	{
		if(eda_conn == null || eda_conn.isClosed()){
			String user;
			String url ="";
			if(m_prop.GetEdaUserPrefix().toUpperCase().compareTo(m_prop.GetEdaUsername().toUpperCase())==0)
				user = m_prop.GetEdaUsername();
			else
				user = m_prop.GetEdaUserPrefix() + "$U$" + m_prop.GetEdaUsername();
			url = "jdbc:oracle:thin:@" + m_prop.GetEdaHostname() + ":" + m_prop.GetPort() + ":" + m_prop.GetEdaSid();
			
			try
			{
				eda_conn = DBUtil.getConn(url, user, m_prop.GetEdaPassword());
			}
			catch (Exception e) {
				if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
					logger.error("Create EDA DB connection  faild.error message:" + e.getMessage());
				}
			}
		}
	}
	
	/************************************
	* Get EDA connection
	* @return Connection
	*************************************/
	public static Connection getEdaConnection() throws Exception
	{
		if(eda_conn == null || eda_conn.isClosed()){
			setEdaConnection();
		}
		return eda_conn;
	}
	
	/************************************
	* Set SPC connection
	* @param Connection
	*************************************/
	public void setSpcConnection(Connection conn)
	{
		spc_conn = conn;
	}
	
	public static void setSpcConnection() throws Exception
	{
		if(spc_conn == null || spc_conn.isClosed()){
			String user;
			String url ="";
			if(m_prop.GetSpcUserPrefix().toUpperCase().compareTo(m_prop.GetSpcUsername().toUpperCase())==0)
				user = m_prop.GetSpcUsername();
			else
				user = m_prop.GetSpcUserPrefix() + "$U$" + m_prop.GetSpcUsername();
			url = "jdbc:oracle:thin:@" + m_prop.GetSpcHostname() + ":" + m_prop.GetPort() + ":" + m_prop.GetSpcSid();
			
			try
			{
				spc_conn = DBUtil.getConn(url, user, m_prop.GetSpcPassword());
			}
			catch (Exception e) {
				if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
					logger.error("Create SPC DB connection  faild.error message:" + e.getMessage());
				}
			}
		}
	}
	
	/************************************
	* Get SPC connection
	* @return Connection
	*************************************/
	public static Connection getSpcConnection() throws Exception
	{
		if(spc_conn == null || spc_conn.isClosed()){
			setSpcConnection();
		}
		return spc_conn;
	}
			
	/************************************
	* Set Translator manage connection
	* @param Connection
	*************************************/
	public void setTMConnection(Connection conn)
	{
		tm_conn = conn;
	}
    
    public void setTMConnection() throws Exception
	{
		if(tm_conn == null || tm_conn.isClosed()){
			
			String user;
			String url ="";
			if(m_prop.GetTranslatorUserPrefix().toUpperCase().compareTo(m_prop.GetTranslatorUsername().toUpperCase())==0)
				user = m_prop.GetTranslatorUsername();
			else
				user = m_prop.GetTranslatorUserPrefix() + "$U$" + m_prop.GetTranslatorUsername();
			url = "jdbc:oracle:thin:@" + m_prop.GetTranslatorHostname() + ":" + m_prop.GetPort() + ":" + m_prop.GetTranslatorSid();

			try
			{
				tm_conn = DBUtil.getConn(url, user, m_prop.GetTranslatorPassword());
			}
			catch (Exception e) {
				logger.error("Create Translator DB connection  faild.error message:" + e.getMessage());	
			}
		}
	}
    
    public Connection getTMConnection() throws Exception
	{
		if(tm_conn == null || tm_conn.isClosed()){
			setTMConnection();
		}
		return tm_conn;
	}
	
	/************************************
	* Set LoaderProperty
	* @param LoaderProperty(class)
	*************************************/
	public void setLoaderProperty(LoaderProperty prop)
	{
		m_prop = prop;
	}
	
	/************************************
	* Get LoaderProperty
	* @return LoaderProperty(class)
	*************************************/
	public LoaderProperty getLoaderProperty()
	{
		return m_prop;
	}
	
	/************************************
	* Get EdaSuccessFlag
	* @return boolean
	*************************************/
	public static boolean getEdaSuccessFlag()
	{
		return edaSuccessFlag;
	}
	
	/************************************
	* Set EdaSuccessFlag
	* @param boolean
	*************************************/
	public static void setEdaSuccessFlag(boolean b)
	{
		edaSuccessFlag = b;
	}
	
	/************************************
	* Get SpcSuccessFlag
	* @return boolean
	*************************************/
	public static boolean getSpcSuccessFlag()
	{
		return spcSuccessFlag;
	}
	
	/************************************
	* Set SpcSuccessFlag
	* @param boolean
	*************************************/
	public static void setSpcSuccessFlag(boolean b)
	{
		spcSuccessFlag = b;
	}
			
	/************************************
	* Get startTime
	* @return startTime
	*************************************/
    private Timestamp startTime;
    public Timestamp getStartTime()
    {
        return startTime;
    }

	/************************************
	* Set startTime
	* @param startTime
	*************************************/
    public void setStartTime(Timestamp t)
    {
    	startTime = t;
    }
    
	/************************************
	* Get endTime
	* @return endTime
	*************************************/
    private Timestamp endTime;
    public Timestamp getEndTime()
    {
        return endTime;
    }

	/************************************
	* Get endTime
	* @param SetEndTime
	*************************************/
    public void setEndTime(Timestamp t)
    {
    	endTime = t;
    }
    
    private int failedFiles = 0;
    public int getFailedFileCount()
    {
        return failedFiles;
    }

    public void setFailedFileCount(int n)
    {
    	failedFiles = n;
    }

    private int successFiles = 0;
    public void setSuccessFileCount(int n)
    {
    	successFiles = n;
    }

    public int getSuccessFiles()
    {
        return successFiles + failedFiles;
    }
    
    public String getOtherFolders(String getParentPath,String folderName)
    {
    	return getParentPath.substring(0, getParentPath.length()-6) + folderName;
    }
		
	public void dmyFileEndHandle(String fid, File dmyFile, File dataFile, String status, String reallyFilePath, String error_msg)throws Exception{
		
		boolean moveDmyFileResult = false;
		String currentFileSrcDir = null; 
		String destDirPath = null;
		
		if ("SUCCESS".equals(status)) {
			
			setSuccessFileCount(getSuccessFiles() + 1);
			
			//update etl_file_hst_t eda status
			if(getFileInfoFromDB){
				TranslatorTableControlUtil.updateETLFileHst(getTMConnection(), "EDA",  new String[]{"SUCCESS", "", fid});
				
				if(spc_enable.equalsIgnoreCase("true") && spcRunFlag)
					TranslatorTableControlUtil.updateETLFileHst(getTMConnection(), "SPC",  new String[]{"SUCCESS", "", fid});
			}
			
			if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG()))
				logger.info(dmyFile.getName() + " loaded successfully.");
            
			//move dmy file to backup folder
			destDirPath = getOtherFolders(dmyFile.getParent(), "BACKUP") + File.separator + product_id + File.separator + date_dir; 
			moveDmyFileResult = FileUtil.MoveFile(dmyFile.getParent(), destDirPath, dmyFile.getName());
			
			//update etl_file_hst_t current_file_src_dir
			if(getFileInfoFromDB){
				if(moveDmyFileResult)
					currentFileSrcDir = destDirPath + File.separator + dmyFile.getName();
				else
					currentFileSrcDir = dmyFile.getParent() + File.separator + dmyFile.getName();
				
				TranslatorTableControlUtil.updateETLFileCurrentSrcDir(getTMConnection(), new String[]{currentFileSrcDir, fid});
			}
			
			if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG()))
				logger.info(dmyFile.getName() + " was moved to " + destDirPath + " result: " + moveDmyFileResult);			
			
		}
		else if ("EDA_ERROR".equals(status)) {
			
			setFailedFileCount(getFailedFileCount() + 1);
			
			//update etl_file_hst_t eda status
			if(getFileInfoFromDB){
				TranslatorTableControlUtil.updateETLFileHst(getTMConnection(), "EDA",  new String[]{"ERROR", error_msg, fid});
			}
			
			if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG()))
				logger.error(dmyFile.getName() + " insert EDA data fail.");
			
			if(!reallyFilePath.equals("")) {
				
				//move dmy file to error folder
				destDirPath = getOtherFolders(dmyFile.getParent(), "ERROR") + File.separator + product_id + File.separator + date_dir; 
				moveDmyFileResult = FileUtil.MoveFile(dmyFile.getParent(), destDirPath, dmyFile.getName());
				
				//update etl_file_hst_t current_file_src_dir
				if(getFileInfoFromDB){
					if(moveDmyFileResult)
						currentFileSrcDir = destDirPath + File.separator + dmyFile.getName();
					else
						currentFileSrcDir = dmyFile.getParent() + File.separator + dmyFile.getName();
					
					TranslatorTableControlUtil.updateETLFileCurrentSrcDir(getTMConnection(),  new String[]{currentFileSrcDir,fid});
				}	
				
				if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
					logger.error(dmyFile.getName() + " was moved to " + destDirPath + " result: " + moveDmyFileResult);
				}
			}
									
		}
		else if ("SPC_ERROR".equals(status)) {
			
			setFailedFileCount(getFailedFileCount() + 1);
			
			//update etl_file_hst_t eda status
			if(getFileInfoFromDB){
				TranslatorTableControlUtil.updateETLFileHst(getTMConnection(), "EDA",  new String[]{"SUCCESS", "", fid});
				TranslatorTableControlUtil.updateETLFileHst(getTMConnection(), "SPC",  new String[]{"ERROR", error_msg, fid});
			}
			
			if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG()))
				logger.error(dmyFile.getName() + " insert SPC data error.");
			
			if(!reallyFilePath.equals("")) {
				
				//move dmy file to error folder
				destDirPath = getOtherFolders(dmyFile.getParent(), "ERROR") + File.separator + product_id + File.separator + date_dir; 
				moveDmyFileResult = FileUtil.MoveFile(dmyFile.getParent(), destDirPath, dmyFile.getName());
				
				//update etl_file_hst_t current_file_src_dir
				if(getFileInfoFromDB){
					if(moveDmyFileResult)
						currentFileSrcDir = destDirPath + File.separator + dmyFile.getName();
					else
						currentFileSrcDir = dmyFile.getParent() + File.separator + dmyFile.getName();
					
					TranslatorTableControlUtil.updateETLFileCurrentSrcDir(getTMConnection(),  new String[]{currentFileSrcDir,fid});
				}	
				
				if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
					logger.error(dmyFile.getName() + " was moved to " + destDirPath + " result: " + moveDmyFileResult);
				}
			}
									
		}
		
	}
	
	
	public String getDataFilePath(ETLFileTableView dmyFileTableViews )throws Exception{
		
		lot_id = null;
		parent_lot_id = null;		
		String componet_id = null;
		
		String dataFilePath = m_prop.GetDfsRootPath() + File.separator;
		//name_rule: lot_id(length=6) sheet_id(length=7) cut_id(length=8) panel_id(length=10)
		try{
			int idx1 = dmyFileTableViews.getFILE_NAME().indexOf("_");
			int idx2 = dmyFileTableViews.getFILE_NAME().indexOf("_", idx1+1);
			int idx3 = dmyFileTableViews.getFILE_NAME().indexOf("_", idx2+1);
			int idx4 = dmyFileTableViews.getFILE_NAME().indexOf("_", idx3+1);
			
			lot_id = dmyFileTableViews.getFILE_NAME().substring(idx2+1, idx3);
			componet_id = dmyFileTableViews.getFILE_NAME().substring(idx3+1, idx4);
			
			if(dmyFileTableViews.getSHOP().equals("ARRAY"))
			{
				parent_lot_id = getLotSheetCutID(lot_id,"LOT");
				
				dataFilePath += dmyFileTableViews.getSHOP() + File.separator + 
							   dmyFileTableViews.getEQUIP_TYPE() + File.separator +
				               dmyFileTableViews.getPRODUCT_ID() + File.separator + 
				               parent_lot_id + File.separator + 
				               getLotSheetCutID(componet_id,"SHEET") + File.separator + 
				               "SOURCE" + File.separator + 
				               dmyFileTableViews.getFILE_NAME().replace("dmy", "csv").replace("_" + lot_id, "");
			}
			else if(dmyFileTableViews.getSHOP().equals("CF") || dmyFileTableViews.getSHOP().equals("CELL") 
					|| dmyFileTableViews.getSHOP().equals("BEOL") || dmyFileTableViews.getSHOP().equals("BEOL_PIECE"))
			{
				parent_lot_id = getLotSheetCutID(lot_id,"SGR");
				
				dataFilePath += dmyFileTableViews.getSHOP() + File.separator + 
				   			   dmyFileTableViews.getEQUIP_TYPE() + File.separator +
				   			   dmyFileTableViews.getPRODUCT_ID() + File.separator + 
				   			   parent_lot_id + File.separator + 
	                           getLotSheetCutID(componet_id,"SHEET") + File.separator;
				
				dataFilePath += "SOURCE" + File.separator + 
	               dmyFileTableViews.getFILE_NAME().replace("dmy", "csv").replace("_" + lot_id +"_" +componet_id , "_"+componet_id);				
			}
			
		}catch(Exception ex){
			if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG()))
				logger.error("getDataFilePath() fail:" + ex.getMessage());
			return null;
		}
		
		return dataFilePath;
	}
	
	public String getLotSheetCutID(String componet_id,String type)throws Exception{
		
		String value = null;
		
		/*	
		if (componet_id.length() > 10)
			value =  null;
		 */
		if (("LOT").equals(type) && componet_id.length() < 7)
			value = null;
		else if (("SHEET").equals(type) && componet_id.length() < 7)
			value = null;
		else if (("CUT").equals(type) && componet_id.length() < 8)
			value = null;		
		
		try{
			if (("LOT").equals(type))
				value = componet_id.substring(0, 6);
			else if (("SHEET").equals(type)) {
				if (componet_id.trim().length() >= 10) {
					value = componet_id;
				}
				else {
					value = componet_id.substring(0, 7);
				}
			}
			else if (("CUT").equals(type))
				value = componet_id.substring(0, 8);
			else
				value = null;
			
		    if (("SGR").equals(type)) {
		    	
		    	if (componet_id.contains(".")) 
		    	{
		    		value = componet_id.substring(0,componet_id.indexOf("."));
		    	}
		    	else
		    	{
		    		value =	componet_id;
		    	}
		    }
				
		}catch(Exception ex){
			throw new Exception("process getLotSheetCutID() fail:" + ex.getMessage());
		}
		
		if (value == null) {
			throw new Exception("process getLotSheetCutID() fail");
		}
		
		return value;			
	}
	
	public boolean checkDmyFileStatus(File dmyFile)throws Exception{
		
		boolean checkStatus = true;
		if(!dmyFile.exists() || dmyFile.isDirectory())	
		{
			if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
				if(!dmyFile.exists()){
					logger.error("Dummy file is not exist!("+dmyFile.getAbsolutePath()+")");
				}
				else if(dmyFile.isDirectory()){
					logger.error("Dummy file path is Directory!("+dmyFile.getAbsolutePath()+")");
				}			
			}
			checkStatus = false;
		}		
		return checkStatus;
	}
	
	public boolean checkDataFileStatus(File dataFile)throws Exception{
		
		boolean checkStatus = true;
		if(dataFile.length() == 0 || !dataFile.exists() || dataFile.isDirectory())	
		{
			if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG())){
				if(!dataFile.exists()){
					logger.error("Data file is not exist!("+dataFile.getAbsolutePath()+")");
				}
				else if(dataFile.isDirectory()){
					logger.error("Data file path is Directory!("+dataFile.getAbsolutePath()+")");
				}
				else if(dataFile.length() == 0){
					logger.error("This data file is empty!("+dataFile.getAbsolutePath()+")");
				}					
			}
			checkStatus = false;
		}		
		return checkStatus;
	}
	
	public void transferETLFileToHst(Connection conn, ETLFileTableView dmyFileTableViews)throws Exception{
		
		try {
			TranslatorTableControlUtil.transferETLFileToHst(getTMConnection(), 
					new String[]{dmyFileTableViews.getFID(),
								 dmyFileTableViews.getSHOP(),
								 dmyFileTableViews.getEQUIP_TYPE(),
								 dmyFileTableViews.getEQUIP_ID(),
								 dmyFileTableViews.getPRODUCT_ID(),
								 dmyFileTableViews.getFILE_SOURCE(),
								 dmyFileTableViews.getFILE_SRC_DIR(),
								 dmyFileTableViews.getCURRENT_FILE_SRC_DIR(),
								 dmyFileTableViews.getFILE_NAME(),
								 dmyFileTableViews.getFILE_TYPE(),
								 dmyFileTableViews.getFILE_SIZE(),
								 dmyFileTableViews.getTARGET_FLAG(),
								 dmyFileTableViews.getFILE_CREATE_TIME(),
								 dmyFileTableViews.getFILE_ENTER_DB_TIME(),
								 dmyFileTableViews.getPARSE_FLAG()});
			
		}
		catch(Exception e) {
			
		}
	}
	
	public void runByDebug(File fileSource) 
	{	
		boolean moveDmyFileResult = false;
		File[] fileList = fileSource.listFiles();
		
		for (File file: fileList) {
			
			if(file.getAbsolutePath().endsWith("csv") || file.getAbsolutePath().endsWith("CSV"))
			{
				try {
					
					readyToRun(file);
					
					if(getEdaSuccessFlag() && getSpcSuccessFlag()) {
						moveDmyFileResult = FileUtil.MoveFile(file.getParent(), getOtherFolders(file.getParent(), "BACKUP"), file.getName());	
						if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG()))
							logger.info(file.getName() + " was moved to " + getOtherFolders(file.getParent(), "BACKUP") + " result: " + moveDmyFileResult);	
					}else if (!getEdaSuccessFlag()) {							
						moveDmyFileResult = FileUtil.MoveFile(file.getParent(), getOtherFolders(file.getParent(), "BACKUP"), file.getName());
						if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG()))
							logger.info(file.getName() + " was moved to " + getOtherFolders(file.getParent(), "BACKUP") + " result: " + moveDmyFileResult);	
					}else if (!getSpcSuccessFlag()) {							
						moveDmyFileResult = FileUtil.MoveFile(file.getParent(), getOtherFolders(file.getParent(), "BACKUP"), file.getName());
						if("true".equalsIgnoreCase(SessionConstants.GET_EXPORT_LOG_FLAG()))
							logger.info(file.getName() + " was moved to " + getOtherFolders(file.getParent(), "BACKUP") + " result: " + moveDmyFileResult);	
					}
										
					try{
						if(eda_conn != null)
						  eda_conn.commit();
						if(spc_conn != null)
						  spc_conn.commit();
						
					}catch(SQLException ex){
						logger.error(ex.getMessage());
					}
					
				} catch (Exception e) {

					logger.error(e.getMessage());
					
				} 
		
			}
						
		}
						
	}
	
	public static String replaceBlankToNull(String str) {

		if (str == null) {
			return null;
		} else if (str.trim().equals("")) {
			return null;
		} else {
			return str;
		}
	}
}