package com.mdt.cell.util;

import java.io.FileInputStream;
import java.util.Properties;

/**
 ***************************************************
 * @Title SystemConfig 系统配置
 * @author 林华锋
 * @Date 2017年2月27日上午11:06:37
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class SystemConfigUtil {
    
	public static Properties properties = new Properties();

	public static Properties getProperties(String configUrl) {

		try {

			SystemConfigUtil.class.getClassLoader();

			FileInputStream fis = new FileInputStream(configUrl);
            
			properties.load(fis);

			fis.close();

		} catch (Exception e) {

			e.printStackTrace();
		}
		
		return properties;

	}

}
