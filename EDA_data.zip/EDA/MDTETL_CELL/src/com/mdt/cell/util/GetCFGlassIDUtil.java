package com.mdt.cell.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

/**
 ***************************************************
 * @Title  GetCFGlassIDUtil                                    
 * @author 林华锋
 * @Date   2018年3月12日下午2:02:55
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class GetCFGlassIDUtil {

	private static Logger logger = Logger.getLogger(GetCFGlassIDUtil.class);
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	String CFGlassId = null;
	String url = "jdbc:db2://10.96.32.39:60600/CHISDB";
	String user = "edaetl";
	String password = "eda1234";
	
    String str = "";
	public String getCFID(String CHIP_ID){
	        
		 String sql ="SELECT PARAM_VAL FROM CELPPT.ASHTPRM WHERE SHT_ID = '"+CHIP_ID.trim().substring(0, 7)+"AAA"+"' AND PARAM_EXT = 'CF_SHT_ID' AND PARAM_NAME = 'CF_SHT_ID'";
		
		 try {
               
				Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
				
				conn = DriverManager.getConnection(url, user, password);
			    ps = conn.prepareStatement(sql);
				rs = ps.executeQuery();

				while (rs.next()) {
					CFGlassId = rs.getString(1);
				}
				
				str = CFGlassId;

			} catch (Exception sqle) {
				logger.error("get CFGlassId: " + CFGlassId + " failed :" + sqle.getMessage());
			}finally{
				if(conn !=null || ps != null ||rs!=null){
					  try {
						rs.close();
						ps.close();
						conn.close();
					} catch (SQLException e) {
						logger.error("get " + conn + " failed :" + e.getMessage());
					}
						
				}
			}
		    
			return str.trim();
	 }
	
}
