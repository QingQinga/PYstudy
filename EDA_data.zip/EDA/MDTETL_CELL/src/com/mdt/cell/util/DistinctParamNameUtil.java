package com.mdt.cell.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 ***************************************************
 * @Title DistinctParamNameUtil
 * @author 林华锋
 * @Date 2017年10月19日下午12:38:08
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class DistinctParamNameUtil {

	PreparedStatement ps = null;
	ResultSet rs = null;
	int count = 0;

	public int selectParamName(Connection conn, String ParamName) {
		try {
			String sql = "select count(0) from edaldr.ldr_cell_param_t where param_name = ?";

			ps = conn.prepareStatement(sql);

			ps.setString(1, ParamName);

			rs = ps.executeQuery();

			while (rs.next()) {
			   count = rs.getInt(1);
			}
			
		} catch (Exception sqle) {
			
		} finally{
			if(ps != null ||rs!=null){
				try{
					rs.close();
					ps.close();
					
				}catch(Exception e){
					
				}
					
			}
			
		}
	     return count;
	}

}
