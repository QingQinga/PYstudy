package com.mdt.cell.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.cell.entity.StepEntity;
import com.mdt.cell.util.DBUtil;

/**
 ***************************************************
 * @Title StepDao 处理基本表Step
 * @author 林华锋
 * @Date 2017年2月14日下午3:17:28
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class StepDao {

	private static Logger logger = Logger.getLogger(StepDao.class);

	/**
	 * 基本表Step 插入语句
	 * 
	 * @param stepEntity
	 *            Step类对象
	 * @param conn
	 *            数据库连接
	 * @return
	 */
	public static boolean addStepTable(StepEntity Entity, Connection conn, String fid) {

		String loaderStep = "begin cell1_base_loader.load_step; end;";
		String sql = "INSERT INTO ldr_cell_step_t (" + "STEP_ID,STEP_GROUP,STEP_SEQ,STEP_TYPE" + ") VALUES (" + "?,?,?,?)";
        Object[] params = {Entity.getSTEP_ID(),Entity.getSTEP_GROUP(),Entity.getSTEP_SEQ(),Entity.getSTEP_TYPE()};
		
        boolean isErrorRet = true;
        
		logger.info(" FID: "+fid+"||   LDR_CELL_STEP_T SQL: " + sql);
		try {
            DBUtil.executeUpdate(sql, params,conn);
			logger.info(" FID: "+fid+"||   INSERT ldr_cell_step_t SUCCESS! 插入LDR_CELL_STEP_T成功！");
			DBUtil.stmt = conn.createStatement();
			DBUtil.stmt.execute(loaderStep);
			logger.info(" FID: "+fid+"||   CALL Step Loader Success!");
		} catch (Exception ex) {
			logger.error(" FID: "+fid+"||   INSERT ldr_cell_step_t Failed! Error Message:" + ex.getMessage());
			isErrorRet = false;
		} finally {
			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
					DBUtil.stmt.close();
				}
			} catch (SQLException ex) {
				logger.error(" FID: "+fid+"||   An Error Caused:" + ex.getMessage());
				isErrorRet = false;
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}
	}
}
