package com.mdt.cell.excute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.cell.cell_mac.dao.CellMacComponentDao;
import com.mdt.cell.cell_mac.dao.CellMacComponentSumDao;
import com.mdt.cell.cell_mac.dao.CellMacResultDao;
import com.mdt.cell.cell_mac.entity.CellMacComponentEntity;
import com.mdt.cell.cell_mac.entity.CellMacComponentSumEntity;
import com.mdt.cell.cell_mac.entity.CellMacResultEntity;
import com.mdt.cell.dao.ParameterDao;
import com.mdt.cell.dao.ProductDao;
import com.mdt.cell.dao.StepDao;
import com.mdt.cell.entity.ParameterEntity;
import com.mdt.cell.entity.ProductEntity;
import com.mdt.cell.entity.StepEntity;
import com.mdt.cell.spc.dao.LOAD_CEL_GAP_SHEET;
import com.mdt.cell.spc.dao.LOAD_CEL_MAC_SHEET;
import com.mdt.cell.spc.entity.SpcLoaderEntity;
import com.mdt.cell.tableview.SessionConstants;
import com.mdt.cell.util.DataFileFormatUtil;
import com.mdt.cell.util.EdaSpcAbstractLoader;

/**
 ***************************************************
 * @Title CellMACExcute
 * @author 林华锋
 * @Date 2017年5月11日上午9:51:59
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class CellMACExcute extends EdaSpcAbstractLoader {

	private static Logger logger = Logger.getLogger(CellMacroExcute.class);

	public CellMACExcute() throws Exception{
		super(SessionConstants.GET_SYSTEM_CONFIG_DIR(), SessionConstants.GET_LOG_CONFIG_DIR());
	}

	public Connection EDA_CONN = null;
	public Connection SPC_CONN = null;
	public String discern; // 识别前字符
	public String[] afterDiscern; // 识别后字符
	public BufferedReader reader;
	public String loaderData = "begin cell1_file_loader.load_data; end;";
	public Statement stmt = null;

	/** 实例化实体类对象 Begin **/

	public ParameterEntity parameterEntity = new ParameterEntity();
	public ProductEntity productEntity = new ProductEntity();
	public StepEntity stepEntity = new StepEntity();
	public CellMacComponentEntity macComponentEntity = new CellMacComponentEntity();
	public CellMacComponentSumEntity macComponentSumEntity = new CellMacComponentSumEntity();
	public CellMacResultEntity macResultEntity = new CellMacResultEntity();

	/** 实例化实体类对象 End **/

	/** DAO */

	public ProductDao productDao;
	public ParameterDao parameterDao;
	public StepDao stepDao;
	public CellMacComponentDao macComponentDao;
	public CellMacComponentSumDao macComponentSumDao;
	public CellMacResultDao macResultDao;

	/** DAO */

	/****** Header_Begin 字段行 */

	public String hFILE_VERSION = null; // 文件版本
	public String hFILE_CREATED_TIME = null; // 创建时间
	public String hEQUIP_TYPE = null; // 设备类型
	public String hEQ_ID = null; // 设备ID
	public String hSubEQ_ID = null; // 子设备ID
	public String hCONTENT = null; // DataBlock内容标题

	/***** Header_End 字段行 */

	/** DOWNLOADED_SHEET_DATA_BEGIN 字段行 */

	public String dsOPE_NO = null;
	public String dsSHEET_ID = null;
	public String dsPRODUCT_ID = null;
	public String dsRECIPE_ID = null;
	public String dsCASSETTE_ID = null;
	public String dsSLOT_NO = null;
	public String dsROUTE_ID = null;

	/** DOWNLOADED_SHEET_DATA_END 字段行 */

	/** EQP_SHEET_DATA_BEGIN 字段行 */

	public String esOPE_NO = null;
	public String esSHEET_ID = null;
	public String esSTART_TIME = null;
	public String esEND_TIME = null;
	public String esSAMPLING_FLAG = null;
	public String esUSER_ID = null;
	public String esABNORMAL_FLAG = null;
	public String esMAIN_JUDGE = null;
	public String esSHEET_JUDGE = null;
	public String esTTL_PANEL_CNT = null;
	public String esTACK_TIME = null;
	public String esCOMPONENT_TYPE = null;
	public String esOK_PANEL_COUNT = null;
	public String esNG_PANEL_COUNT = null;
	public String esYIELD = null;
	
	public String esMODEL_NAME = null;
	public String esPROCESS_MODE = null;
	public String esSHOT_CNT = null;

	/** EQP_SHEET_DATA_END 字段行 */

	/** SHEET_SUMMARY_DATA_BEGIN 字段行 */

	public String ssOPE_NO = null;
	public String ssSHEET_ID = null;
	public String ssEND_TIME = null;
	public String ssPARAM_COLLECTION = null;
	public String ssPARAM_GROUP = null;
	public String ssPARAM_NAME = null;
	public String ssAVG = null;
	public String ssMAX = null;
	public String ssMIN = null;
	public String ssSTD = null;
	public String ssUNIFORMITY = null;
	public String ssRANGE = null;
	public String ss3SIGMA = null;
	public String ssSPEC_HIGH = null;
	public String ssSPEC_LOW = null;
	public String ssSPEC_TARGET = null;
	public String ssCONTROL_HIGH = null;
	public String ssCONTROL_LOW = null;

	/** SHEET_SUMMARY_DATA_END 字段行 */

	/** SITE_DATA_BEGIN 字段行 */

	public String sOPE_NO = null;
	public String sSHEET_ID = null;
	public String sEND_TIME = null;
	public String sPARAM_COLLECTION = null;
	public String sPARAM_GROUP = null;
	public String sPARAM_NAME = null;
	public String sSITE_NAME = null;
	public String sPARAM_VALUE = null;
	public String sSPEC_HIGH = null;
	public String sSPEC_LOW = null;
	public String sSPEC_TARGET = null;
	public String sCONTROL_HIGH = null;
	public String sCONTROL_LOW = null;
	public String sX = null;
	public String sY = null;
	public String sCHIP_ID = null;
	public String sCHIP_NO = null;
	public String sJUDGE = null;
	public String sSHOT_ID = null;
	public String sSEQ_IN_SHOT = null;
	public String sDEFINITION_X = null;
	public String sDEFINITION_Y = null;

	/** SITE_DATA_END 字段行 */

	public static void main(String[] args) throws Exception {

		// args:{TID:0,Shop:1,Source:2,eqp_type:3,target_flag:4,WorkDir:5,max_count:6,SystemLocalConfigPath:7,LogConfigPath:8,db_find_method:9,export_log_file:10}
		if (args != null && args.length > 0) {
			SessionConstants.SET_TID(args[0]);
			SessionConstants.SET_SHOP(args[1]);
			SessionConstants.SET_SOURCE(args[2]);
			SessionConstants.SET_EQP_TYPE(args[3]);
			SessionConstants.SET_TARGET_FLAG(args[4]);
			SessionConstants.SET_WORK_DIR(args[5]);
			SessionConstants.SET_MAX_COUNT(args[6]);
			SessionConstants.SET_SYSTEM_CONFIG_DIR(args[7]);
			SessionConstants.SET_LOG_CONFIG_DIR(args[8]);
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(args[9]);
			SessionConstants.SET_EXPORT_LOG_FLAG(args[10]);
		} else {
			SessionConstants.SET_TID("CELL_FILE_MAC_1"); // translator_config_t
			SessionConstants.SET_SHOP("CELL");
			SessionConstants.SET_SOURCE("FILE");
			SessionConstants.SET_EQP_TYPE("MAC");
			SessionConstants.SET_TARGET_FLAG("0,1,2,3,4,5,6,7,8,9");
			SessionConstants.SET_WORK_DIR("E:\\TEST");
			SessionConstants.SET_MAX_COUNT("100");
			SessionConstants.SET_SYSTEM_CONFIG_DIR("E:\\TEST\\system.properties");
			SessionConstants.SET_LOG_CONFIG_DIR("config/properties/log4j.properties");
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD("FALSE");
			SessionConstants.SET_EXPORT_LOG_FLAG("TRUE");
		}

		try {
			CellMACExcute MACExcute = new CellMACExcute();

			MACExcute.run();

		} catch (Exception e) {
			logger.error("FID : " + FID + "|| There hava a error! Error Message: " + e.getMessage());
		}

	}

	@Override
	public void readyToRun(File file) throws Exception {

		logger.info("FID : " + FID + "|| 【 Translator Begin 】");
		
		ReadDFSFile(file);
			
		logger.info("FID : " + FID + "|| 【 Translator End 】");
	}

	@SuppressWarnings("static-access")
	public void ReadDFSFile(File file) throws Exception {
        
		EDA_CONN = getEdaConnection();
		
		if (EDA_CONN.isClosed()) {
			logger.error("FID : " + FID + "|| The database connection was error");
		}
		
		EDA_CONN.setAutoCommit(false);
		try {
			String sPARAM_NAMES = ""; 
			String sPARAM_VALUES = "";
			reader = new BufferedReader(new FileReader(file.getPath()));

			while ((discern = reader.readLine()) != null) {
				if (discern.length() == 0) {
					continue;
				}
				/***********************************************************************
				 * BEGIN ****************** 设备抛出csv文件，读取Header部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("HEADER_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  HEADER_BEGIN 读取开始 】");

					while ((discern = reader.readLine()) != null && getEdaSuccessFlag()) {
						if (DataFileFormatUtil.Shift(discern).startsWith("FILE_VERSION")) {
							afterDiscern = discern.split(":", -1);
							hFILE_VERSION = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("FILE_CREATED_TIME")) {
							afterDiscern = discern.split(":", -1);
							hFILE_CREATED_TIME = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQUIP_TYPE")) {
							afterDiscern = discern.split(":", -1);
							hEQUIP_TYPE = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("SUBEQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hSubEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("CONTENT")) {
							afterDiscern = discern.split(":", -1);
							hCONTENT = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).endsWith("HEADER_END")) {
							break;
						}
					}
					logger.info("FID : " + FID + "|| 【  HEADER_END 读取结束 】");

				}
				/*********************************************************************
				 * END ******************** 设备抛出csv文件，读取Header部分 ****** END *
				 ********************************************************************/

				/***********************************************************************
				 * BEGIN ***************设备抛出csv文件，读取SHEET_DATA部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("DOWNLOADED_SHEET_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  DOWNLOADED_SHEET_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DOWNLOADED_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);
						
						dsOPE_NO = afterDiscern[0];
						dsROUTE_ID = afterDiscern[1];
						dsSHEET_ID = afterDiscern[2];
						dsPRODUCT_ID = afterDiscern[3];
						dsRECIPE_ID = afterDiscern[4];
						dsCASSETTE_ID = afterDiscern[5];
						dsSLOT_NO = afterDiscern[6];

						productEntity.setPRODUCT_ID(dsPRODUCT_ID);
						productEntity.setPRODUCT_GROUP("DEFAULT");

						setEdaSuccessFlag(productDao.addProductTable(productEntity, EDA_CONN,FID));

						macComponentEntity.setROUTE_ID(dsROUTE_ID);
						macComponentEntity.setPRODUCT_ID(dsPRODUCT_ID);
						macComponentEntity.setRECIPE_ID(dsRECIPE_ID);
						macComponentEntity.setCASSETTE_ID(dsCASSETTE_ID);
						macComponentEntity.setSLOT_NO(dsSLOT_NO);
						macComponentEntity.setSGR_ID(lot_id);
						macComponentEntity.setPARENT_SGR_ID(parent_lot_id);
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}
					logger.info("FID : " + FID + "|| 【  DOWNLOADED_SHEET_DATA_END 读取结束 】");
				}
				/***********************************************************************
				 * END *******设备抛出csv文件，读取DOWNLOADED_SHEET_DATA部分 ****** END **
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN **** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** BEGIN *******
				 ***********************************************************************/
				if (discern.startsWith("EQP_SHEET_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  EQP_SHEET_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("EQP_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						esOPE_NO = afterDiscern[0];
						esSHEET_ID = afterDiscern[1];
						esCOMPONENT_TYPE = afterDiscern[2];
						esSTART_TIME = afterDiscern[3];
						esEND_TIME = afterDiscern[4];
						esTACK_TIME = afterDiscern[5];
						esSAMPLING_FLAG = afterDiscern[6];
						esABNORMAL_FLAG = afterDiscern[7];
						esUSER_ID = afterDiscern[8];
						esMAIN_JUDGE = afterDiscern[9];
						esSHEET_JUDGE = afterDiscern[10];
						esTTL_PANEL_CNT = afterDiscern[11];
						esSHOT_CNT = afterDiscern[12];
						esMODEL_NAME = afterDiscern[13];
						esPROCESS_MODE = afterDiscern[14];
						esOK_PANEL_COUNT = afterDiscern[15];
						esNG_PANEL_COUNT = afterDiscern[16];
						esYIELD = afterDiscern[17];
						
						if (esCOMPONENT_TYPE.equals("7")) {
							esCOMPONENT_TYPE = "1";
						} else if (esCOMPONENT_TYPE.equals("8")) {
							esCOMPONENT_TYPE = "2";
						} else if (esCOMPONENT_TYPE.equals("NA")||esCOMPONENT_TYPE.equals("na")||esCOMPONENT_TYPE.equals("Na")){
							esCOMPONENT_TYPE = null;
						}
                        
						esOPE_NO = esOPE_NO+"_"+hEQ_ID.trim().substring(2, 4)+hEQ_ID.trim().substring(5, 6); //CELL OPE_NO update
                        
						stepEntity.setSTEP_ID(esOPE_NO);
						stepEntity.setSTEP_SEQ(esOPE_NO);
						stepEntity.setSTEP_TYPE("M");
						stepEntity.setSTEP_GROUP(hEQUIP_TYPE);

						setEdaSuccessFlag(stepDao.addStepTable(stepEntity, EDA_CONN, FID));
						
						String GLASS_ID = esSHEET_ID.substring(0,esSHEET_ID.length()-3);
						
						macComponentEntity.setOPE_NO(esOPE_NO);
						macComponentEntity.setSHEET_ID(esSHEET_ID);
						macComponentEntity.setGLASS_ID(GLASS_ID);
						macComponentEntity.setEQ_ID(hEQ_ID);
						macComponentEntity.setSUBEQ_ID(hSubEQ_ID);
						macComponentEntity.setCOMPONENT_TYPE(esCOMPONENT_TYPE);
						macComponentEntity.setSTART_TIME(esSTART_TIME);
						macComponentEntity.setEND_TIME(esEND_TIME);
						macComponentEntity.setTACK_TIME(esTACK_TIME);
						macComponentEntity.setSAMPLING_FLAG(esSAMPLING_FLAG);
						macComponentEntity.setABNORMAL_FLAG(esABNORMAL_FLAG);
						macComponentEntity.setUSER_ID(esUSER_ID);
						macComponentEntity.setMAIN_JUDGE(esMAIN_JUDGE);
						macComponentEntity.setSHEET_JUDGE(esSHEET_JUDGE);
						macComponentEntity.setTTL_PANEL_CNT(esTTL_PANEL_CNT);
						macComponentEntity.setSHOT_CNT(esSHOT_CNT);
						macComponentEntity.setMODEL_NAME(esMODEL_NAME);
						macComponentEntity.setPROCESS_MODE(esPROCESS_MODE);
						macComponentEntity.setOK_PANEL_COUNT(esOK_PANEL_COUNT);
						macComponentEntity.setNG_PANEL_COUNT(esNG_PANEL_COUNT);
						macComponentEntity.setYIELD(esYIELD);
						
						setEdaSuccessFlag(macComponentDao.addCellMacCompenent(macComponentEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID : " + FID + "|| 【  EQP_SHEET_DATA_END 读取结束 】");
				}
				/***********************************************************************
				 * END ********** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** BEGIN *
				 ***********************************************************************/

				if (discern.startsWith("SHEET_SUMMARY_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  SHEET_SUMMARY_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SHEET_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						ssOPE_NO = afterDiscern[0];
						ssSHEET_ID = afterDiscern[1];
						ssEND_TIME = afterDiscern[2];
						ssPARAM_COLLECTION = afterDiscern[3];
						ssPARAM_GROUP = afterDiscern[4];
						ssPARAM_NAME = afterDiscern[5];
						ssAVG = afterDiscern[6];
						ssMAX = afterDiscern[7];
						ssMIN = afterDiscern[8];
						ssRANGE = afterDiscern[9];
						ssUNIFORMITY = afterDiscern[10];
						ssSTD = afterDiscern[11];
						ss3SIGMA = afterDiscern[12];
						ssSPEC_HIGH = afterDiscern[13];
						ssSPEC_LOW = afterDiscern[14];
						ssSPEC_TARGET = afterDiscern[15];
						ssCONTROL_HIGH = afterDiscern[16];
						ssCONTROL_LOW = afterDiscern[17];

						parameterEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						parameterEntity.setPARAM_NAME(ssPARAM_NAME);
						parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						parameterEntity.setPARAM_GROUP(ssPARAM_GROUP);

						setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN,FID));

						macComponentSumEntity.setOPE_NO(esOPE_NO);
						macComponentSumEntity.setSHEET_ID(esSHEET_ID);
						macComponentSumEntity.setEND_TIME(esEND_TIME);
						macComponentSumEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						macComponentSumEntity.setPARAM_NAME(ssPARAM_NAME);
						macComponentSumEntity.setAVG(ssAVG);
						macComponentSumEntity.setMAX(ssMAX);
						macComponentSumEntity.setMIN(ssMIN);
						macComponentSumEntity.setSTD(ssSTD);
						macComponentSumEntity.setUNIFORMITY(ssUNIFORMITY);
						macComponentSumEntity.setRANGE(ssRANGE);
						macComponentSumEntity.setThree_SIGMA(ss3SIGMA);
						macComponentSumEntity.setSPEC_HIGH(ssSPEC_HIGH);
						macComponentSumEntity.setSPEC_LOW(ssSPEC_LOW);
						macComponentSumEntity.setSPEC_TARGET(ssSPEC_TARGET);
						macComponentSumEntity.setCONTROL_HIGH(ssCONTROL_HIGH);
						macComponentSumEntity.setCONTROL_LOW(ssCONTROL_LOW);
						
						setEdaSuccessFlag(macComponentSumDao.addCellMacComponentSum(macComponentSumEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID : " + FID + "|| 【  SHEET_SUMMARY_DATA_END 读取结束 】");
				}

				/***********************************************************************
				 * END * 设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** END ****
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("SITE_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  SITE_DATA_BEGIN 读取开始 】");
					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SITE_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						sOPE_NO = afterDiscern[0];
						sSHEET_ID = afterDiscern[1];
						sCHIP_ID = afterDiscern[2];
						sCHIP_NO = afterDiscern[3];
						sEND_TIME = afterDiscern[4];
						sPARAM_COLLECTION = afterDiscern[5];
						sPARAM_GROUP = afterDiscern[6];
						sPARAM_NAME = afterDiscern[7];
						sSITE_NAME = afterDiscern[8];
						sPARAM_VALUE = afterDiscern[9];
						sJUDGE = afterDiscern[10];
						sX = afterDiscern[11];
						sY = afterDiscern[12];
						sSPEC_HIGH = afterDiscern[13];
						sSPEC_LOW = afterDiscern[14];
						sSPEC_TARGET = afterDiscern[15];
						sCONTROL_HIGH = afterDiscern[16];
						sCONTROL_LOW = afterDiscern[17];
						sSHOT_ID = afterDiscern[18];
						sSEQ_IN_SHOT = afterDiscern[19];
						sDEFINITION_X = afterDiscern[20];
						sDEFINITION_Y = afterDiscern[21];
						
						macResultEntity.setOPE_NO(esOPE_NO);
						macResultEntity.setSHEET_ID(esSHEET_ID);
						macResultEntity.setCHIP_ID(sCHIP_ID);
						macResultEntity.setCHIP_NO(sCHIP_NO);
						macResultEntity.setEND_TIME(esEND_TIME);
						macResultEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						macResultEntity.setPARAM_GROUP(sPARAM_GROUP);
						macResultEntity.setPARAM_NAME(sPARAM_NAME);
						macResultEntity.setSITE_NAME(sSITE_NAME);
						macResultEntity.setPARAM_VALUE(sPARAM_VALUE);
						macResultEntity.setJUDGE(sJUDGE);
						macResultEntity.setX(sX);
						macResultEntity.setY(sY);
						macResultEntity.setSPEC_HIGH(sSPEC_HIGH);
						macResultEntity.setSPEC_LOW(sSPEC_LOW);
						macResultEntity.setSPEC_TARGET(sSPEC_TARGET);
						macResultEntity.setCONTROL_HIGH(sCONTROL_HIGH);
						macResultEntity.setCONTROL_LOW(sCONTROL_LOW);
						macResultEntity.setSHOT_ID(sSHOT_ID);
						macResultEntity.setSEQ_IN_SHOT(sSEQ_IN_SHOT);
						macResultEntity.setDEFINITION_X(sDEFINITION_X);
						macResultEntity.setDEFINITION_Y(sDEFINITION_Y);
						
						setEdaSuccessFlag(macResultDao.addCellMacResult(macResultEntity, EDA_CONN, FID));
					
						//for SPC
						if (sPARAM_NAME != null && sPARAM_NAME.length() > 0 && !sPARAM_NAME.trim().equals("")
							&& sPARAM_VALUE != null && sPARAM_VALUE.length() > 0 && !sPARAM_VALUE.trim().equals("") 
							&& !sPARAM_VALUE.trim().equalsIgnoreCase("NA"))
						{
							sPARAM_NAMES += sPARAM_NAME + ","; 
							sPARAM_VALUES += sPARAM_VALUE + ",";
						}
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID : " + FID + "|| 【  SITE_DATA_END 读取结束 】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END *******
				 ***********************************************************************/

			}

			try {
				if (getEdaSuccessFlag()) {
					stmt = EDA_CONN.createStatement();
					stmt.executeQuery(loaderData);
					stmt.close();
				}
			} catch (Exception e) {
				reader.close();
				setEdaSuccessFlag(false);
				EDA_CONN.rollback();
				logger.error("FID : " + FID + "|| Call Loader Failed! Error Message:" + e.getMessage());
			}
			
			//SPC handle
			try {
				spcRunFlag = true;
				logger.info("FID: " + FID + "|| spc_enable = " + spc_enable);
				
				if (spc_enable.equalsIgnoreCase("true") && getEdaSuccessFlag()) {
					
					logger.info("FID: " + FID + "|| Start SPC running..");
					
					SPC_CONN = getSpcConnection();
					
					if (SPC_CONN.isClosed()) {
						
						logger.error("FID: " + FID + "|| The SPC database connection was error");

						setSpcSuccessFlag(false);
					}
					
					if (getSpcSuccessFlag()) {
						
						SpcLoaderEntity entity = new SpcLoaderEntity();
						
						entity.setProduct_id(replaceBlankToNull(dsPRODUCT_ID));
						entity.setRecipe_id(replaceBlankToNull(dsRECIPE_ID));
						entity.setEquip_type(replaceBlankToNull(hEQUIP_TYPE));
						entity.setEq_id(replaceBlankToNull(hEQ_ID));
						entity.setSubeq_id(replaceBlankToNull(hSubEQ_ID));
						entity.setOpe_no(replaceBlankToNull(dsOPE_NO));
						entity.setRoute_id(replaceBlankToNull(dsROUTE_ID));
						entity.setCassette_id(replaceBlankToNull(dsCASSETTE_ID));
						entity.setStart_time(replaceBlankToNull(esEND_TIME)); //special handle
						entity.setSheet_id(replaceBlankToNull(dsSHEET_ID));
						
						if(sPARAM_NAMES != null && sPARAM_VALUES != null
						   && !sPARAM_NAMES.trim().equals("") && !sPARAM_VALUES.trim().equals("")){
							
							logger.info("FID: " + FID + "|| call SPC loader.");

							setSpcSuccessFlag(LOAD_CEL_MAC_SHEET.prepareSpcData(entity, sPARAM_NAMES, sPARAM_VALUES, SPC_CONN));
						}
					}
				}
				
			} catch (Exception ex) {
				
				setSpcSuccessFlag(false);

				logger.error("FID: " + FID + "|| Process SPC parsing error : " + ex.getMessage());

			}//spc handle end
			
		} catch (Exception ex) {

			reader.close();

			if (getEdaSuccessFlag()) {
				reader.close();
				setEdaSuccessFlag(false);
			}

		} finally {

			if (reader != null) {
				reader.close();
			}
		}
	}

	@Override
	public String getLoaderName() {
		return null;
	}

	@Override
	public boolean checkFileFormat(File file) throws Exception {
		return false;
	}
}
