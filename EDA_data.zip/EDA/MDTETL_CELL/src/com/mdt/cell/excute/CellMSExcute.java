package com.mdt.cell.excute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.cell.cell_ms.dao.CellMsComponentDao;
import com.mdt.cell.cell_ms.dao.CellMsComponentSumDao;
import com.mdt.cell.cell_ms.dao.CellMsResultDao;
import com.mdt.cell.cell_ms.entity.CellMsComponentEntity;
import com.mdt.cell.cell_ms.entity.CellMsComponentSumEntity;
import com.mdt.cell.cell_ms.entity.CellMsResultEntity;
import com.mdt.cell.dao.ParameterDao;
import com.mdt.cell.dao.ProductDao;
import com.mdt.cell.dao.StepDao;
import com.mdt.cell.entity.ParameterEntity;
import com.mdt.cell.entity.ProductEntity;
import com.mdt.cell.entity.StepEntity;
import com.mdt.cell.tableview.SessionConstants;
import com.mdt.cell.util.DataFileFormatUtil;
import com.mdt.cell.util.EdaSpcAbstractLoader;

/**
 ***************************************************
 * @Title CellMACExcute
 * @author 林华锋
 * @Date 2017年5月11日上午9:51:59
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class CellMSExcute extends EdaSpcAbstractLoader {

	private static Logger logger = Logger.getLogger(CellMSExcute.class);

	public CellMSExcute() throws Exception{
		super(SessionConstants.GET_SYSTEM_CONFIG_DIR(), SessionConstants.GET_LOG_CONFIG_DIR());
	}

	public Connection EDA_CONN = null;
	public Connection SPC_CONN = null;
	public String discern; // 识别前字符
	public String[] afterDiscern; // 识别后字符
	public BufferedReader reader;
	public String loaderData = "begin cell1_file_loader.load_data; end;";
	public Statement stmt = null;

	/** 实例化实体类对象 Begin **/

	public ParameterEntity parameterEntity = new ParameterEntity();
	public ProductEntity productEntity = new ProductEntity();
	public StepEntity stepEntity = new StepEntity();
	public CellMsComponentEntity msComponentEntity = new CellMsComponentEntity();
	public CellMsComponentSumEntity msComponentSumEntity = new CellMsComponentSumEntity();
	public CellMsResultEntity msResultEntity = new CellMsResultEntity();

	/** 实例化实体类对象 End **/

	/** DAO */

	public ProductDao productDao;
	public ParameterDao parameterDao;
	public StepDao stepDao;
	public CellMsComponentDao msComponentDao;
	public CellMsComponentSumDao msComponentSumDao;
	public CellMsResultDao msResultDao;

	/** DAO */

	/****** Header_Begin 字段行 */

	public String hFILE_VERSION = null; // 文件版本
	public String hFILE_CREATED_TIME = null; // 创建时间
	public String hEQUIP_TYPE = null; // 设备类型
	public String hEQ_ID = null; // 设备ID
	public String hSubEQ_ID = null; // 子设备ID
	public String hCONTENT = null; // DataBlock内容标题

	/***** Header_End 字段行 */

	/** DOWNLOADED_SHEET_DATA_BEGIN 字段行 */

	public String dsOPE_NO = null;
	public String dsSHEET_ID = null;
	public String dsPRODUCT_ID = null;
	public String dsRECIPE_ID = null;
	public String dsCASSETTE_ID = null;
	public String dsSLOT_NO = null;
	public String dsROUTE_ID = null;

	/** DOWNLOADED_SHEET_DATA_END 字段行 */

	/** EQP_SHEET_DATA_BEGIN 字段行 */

	public String esOPE_NO = null;
	public String esSHEET_ID = null;
	public String esSTART_TIME = null;
	public String esEND_TIME = null;
	public String esSAMPLING_FLAG = null;
	public String esUSER_ID = null;
	public String esABNORMAL_FLAG = null;
	public String esMAIN_JUDGE = null;
	public String esSHEET_JUDGE = null;
	public String esTTL_PANEL_CNT = null;
	public String esTACK_TIME = null;
	public String esCOMPONENT_TYPE = null;
	public String esOK_PANEL_COUNT = null;
	public String esNG_PANEL_COUNT = null;
	public String esYIELD = null;
	
	public String esMODEL_NAME = null;
	public String esPROCESS_MODE = null;
	public String esSHOT_CNT = null;

	/** EQP_SHEET_DATA_END 字段行 */

	/** SHEET_SUMMARY_DATA_BEGIN 字段行 */

	public String ssOPE_NO = null;
	public String ssSHEET_ID = null;
	public String ssEND_TIME = null;
	public String ssPARAM_COLLECTION = null;
	public String ssPARAM_GROUP = null;
	public String ssPARAM_NAME = null;
	public String ssAVG = null;
	public String ssMAX = null;
	public String ssMIN = null;
	public String ssSTD = null;
	public String ssUNIFORMITY = null;
	public String ssRANGE = null;
	public String ss3SIGMA = null;
	public String ssSPEC_HIGH = null;
	public String ssSPEC_LOW = null;
	public String ssSPEC_TARGET = null;
	public String ssCONTROL_HIGH = null;
	public String ssCONTROL_LOW = null;

	/** SHEET_SUMMARY_DATA_END 字段行 */

	/** SITE_DATA_BEGIN 字段行 */

	public String sOPE_NO = null;
	public String sSHEET_ID = null;
	public String sEND_TIME = null;
	public String sPARAM_COLLECTION = null;
	public String sPARAM_GROUP = null;
	public String sPARAM_NAME = null;
	public String sSITE_NAME = null;
	public String sPARAM_VALUE = null;
	public String sSPEC_HIGH = null;
	public String sSPEC_LOW = null;
	public String sSPEC_TARGET = null;
	public String sCONTROL_HIGH = null;
	public String sCONTROL_LOW = null;
	public String sX = null;
	public String sY = null;
	public String sCHIP_ID = null;
	public String sCHIP_NO = null;
	public String sJUDGE = null;
	public String sSHOT_ID = null;
	public String sSEQ_IN_SHOT = null;
	public String sDEFINITION_X = null;
	public String sDEFINITION_Y = null;

	/** SITE_DATA_END 字段行 */

	public static void main(String[] args) throws Exception {

		// args:{TID:0,Shop:1,Source:2,eqp_type:3,target_flag:4,WorkDir:5,max_count:6,SystemLocalConfigPath:7,LogConfigPath:8,db_find_method:9,export_log_file:10}
		if (args != null && args.length > 0) {
			SessionConstants.SET_TID(args[0]);
			SessionConstants.SET_SHOP(args[1]);
			SessionConstants.SET_SOURCE(args[2]);
			SessionConstants.SET_EQP_TYPE(args[3]);
			SessionConstants.SET_TARGET_FLAG(args[4]);
			SessionConstants.SET_WORK_DIR(args[5]);
			SessionConstants.SET_MAX_COUNT(args[6]);
			SessionConstants.SET_SYSTEM_CONFIG_DIR(args[7]);
			SessionConstants.SET_LOG_CONFIG_DIR(args[8]);
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(args[9]);
			SessionConstants.SET_EXPORT_LOG_FLAG(args[10]);
		} else {
			SessionConstants.SET_TID("CELL_FILE_MS_1"); // translator_config_t
			SessionConstants.SET_SHOP("CELL");
			SessionConstants.SET_SOURCE("FILE");
			SessionConstants.SET_EQP_TYPE("MS");
			SessionConstants.SET_TARGET_FLAG("0,1,2,3,4,5,6,7,8,9");
			SessionConstants.SET_WORK_DIR("E:\\TEST");
			SessionConstants.SET_MAX_COUNT("100");
			SessionConstants.SET_SYSTEM_CONFIG_DIR("E:\\TEST\\system.properties");
			SessionConstants.SET_LOG_CONFIG_DIR("config/properties/log4j.properties");
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD("FALSE");
			SessionConstants.SET_EXPORT_LOG_FLAG("TRUE");
		}

		try {
			CellMSExcute MSExcute = new CellMSExcute();

			MSExcute.run();

		} catch (Exception e) {
			logger.error("FID : " + FID + "|| There hava a error! Error Message: " + e.getMessage());
		}

	}

	@Override
	public void readyToRun(File file) throws Exception {

		logger.info("FID : " + FID + "|| 【 Translator Begin 】");
		
		ReadDFSFile(file);
			
		logger.info("FID : " + FID + "|| 【 Translator End 】");
	}

	@SuppressWarnings("static-access")
	public void ReadDFSFile(File file) throws Exception {
        
		EDA_CONN = getEdaConnection();
		
		if (EDA_CONN.isClosed()) {
			logger.error("FID : " + FID + "|| The database connection was error");
		}
		
		EDA_CONN.setAutoCommit(false);
		try {
			
			reader = new BufferedReader(new FileReader(file.getPath()));

			while ((discern = reader.readLine()) != null) {
				if (discern.length() == 0) {
					continue;
				}
				/***********************************************************************
				 * BEGIN ****************** 设备抛出csv文件，读取Header部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("HEADER_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  HEADER_BEGIN 读取开始 】");

					while ((discern = reader.readLine()) != null && getEdaSuccessFlag()) {
						if (DataFileFormatUtil.Shift(discern).startsWith("FILE_VERSION")) {
							afterDiscern = discern.split(":", -1);
							hFILE_VERSION = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("FILE_CREATED_TIME")) {
							afterDiscern = discern.split(":", -1);
							hFILE_CREATED_TIME = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQUIP_TYPE")) {
							afterDiscern = discern.split(":", -1);
							hEQUIP_TYPE = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("SUBEQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hSubEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("CONTENT")) {
							afterDiscern = discern.split(":", -1);
							hCONTENT = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).endsWith("HEADER_END")) {
							break;
						}
					}
					logger.info("FID : " + FID + "|| 【  HEADER_END 读取结束 】");

				}
				/*********************************************************************
				 * END ******************** 设备抛出csv文件，读取Header部分 ****** END *
				 ********************************************************************/

				/***********************************************************************
				 * BEGIN ***************设备抛出csv文件，读取SHEET_DATA部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("DOWNLOADED_SHEET_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  DOWNLOADED_SHEET_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DOWNLOADED_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);
						
						dsOPE_NO = afterDiscern[0];
						dsROUTE_ID = afterDiscern[1];
						dsSHEET_ID = afterDiscern[2];
						dsPRODUCT_ID = afterDiscern[3];
						dsRECIPE_ID = afterDiscern[4];
						dsCASSETTE_ID = afterDiscern[5];
						dsSLOT_NO = afterDiscern[6];

						productEntity.setPRODUCT_ID(dsPRODUCT_ID);
						productEntity.setPRODUCT_GROUP("DEFAULT");

						setEdaSuccessFlag(productDao.addProductTable(productEntity, EDA_CONN,FID));

						msComponentEntity.setROUTE_ID(dsROUTE_ID);
						msComponentEntity.setPRODUCT_ID(dsPRODUCT_ID);
						msComponentEntity.setRECIPE_ID(dsRECIPE_ID);
						msComponentEntity.setCASSETTE_ID(dsCASSETTE_ID);
						msComponentEntity.setSLOT_NO(dsSLOT_NO);
						msComponentEntity.setSGR_ID(lot_id);
						msComponentEntity.setPARENT_SGR_ID(parent_lot_id);
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}
					logger.info("FID : " + FID + "|| 【  DOWNLOADED_SHEET_DATA_END 读取结束 】");
				}
				/***********************************************************************
				 * END *******设备抛出csv文件，读取DOWNLOADED_SHEET_DATA部分 ****** END **
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN **** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** BEGIN *******
				 ***********************************************************************/
				if (discern.startsWith("EQP_SHEET_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  EQP_SHEET_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("EQP_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						esOPE_NO = afterDiscern[0];
						esSHEET_ID = afterDiscern[1];
						esCOMPONENT_TYPE = afterDiscern[2];
						esSTART_TIME = afterDiscern[3];
						esEND_TIME = afterDiscern[4];
						esTACK_TIME = afterDiscern[5];
						esSAMPLING_FLAG = afterDiscern[6];
						esABNORMAL_FLAG = afterDiscern[7];
						esUSER_ID = afterDiscern[8];
						esMAIN_JUDGE = afterDiscern[9];
						esSHEET_JUDGE = afterDiscern[10];
						esTTL_PANEL_CNT = afterDiscern[11];
						esSHOT_CNT = afterDiscern[12];
						esMODEL_NAME = afterDiscern[13];
						esPROCESS_MODE = afterDiscern[14];
						esOK_PANEL_COUNT = afterDiscern[15];
						esNG_PANEL_COUNT = afterDiscern[16];
						esYIELD = afterDiscern[17];
						
						if (esCOMPONENT_TYPE.equals("7")) {
							esCOMPONENT_TYPE = "1";
						} else if (esCOMPONENT_TYPE.equals("8")) {
							esCOMPONENT_TYPE = "2";
						} else if (esCOMPONENT_TYPE.equals("NA")||esCOMPONENT_TYPE.equals("na")||esCOMPONENT_TYPE.equals("Na")){
							esCOMPONENT_TYPE = null;
						}
                        
						esOPE_NO = esOPE_NO+"_"+hEQ_ID.trim().substring(2, 4)+hEQ_ID.trim().substring(5, 6); //CELL OPE_NO update
                        
						stepEntity.setSTEP_ID(esOPE_NO);
						stepEntity.setSTEP_SEQ(esOPE_NO);
						stepEntity.setSTEP_TYPE("M");
						stepEntity.setSTEP_GROUP(hEQUIP_TYPE);

						setEdaSuccessFlag(stepDao.addStepTable(stepEntity, EDA_CONN, FID));
						
						String GLASS_ID = esSHEET_ID.substring(0,esSHEET_ID.length()-3);
						
						msComponentEntity.setOPE_NO(esOPE_NO);
						msComponentEntity.setSHEET_ID(esSHEET_ID);
						msComponentEntity.setGLASS_ID(GLASS_ID);
						msComponentEntity.setEQ_ID(hEQ_ID);
						msComponentEntity.setSUBEQ_ID(hSubEQ_ID);
						msComponentEntity.setCOMPONENT_TYPE(esCOMPONENT_TYPE);
						msComponentEntity.setSTART_TIME(esSTART_TIME);
						msComponentEntity.setEND_TIME(esEND_TIME);
						msComponentEntity.setTACK_TIME(esTACK_TIME);
						msComponentEntity.setSAMPLING_FLAG(esSAMPLING_FLAG);
						msComponentEntity.setABNORMAL_FLAG(esABNORMAL_FLAG);
						msComponentEntity.setUSER_ID(esUSER_ID);
						msComponentEntity.setMAIN_JUDGE(esMAIN_JUDGE);
						msComponentEntity.setSHEET_JUDGE(esSHEET_JUDGE);
						msComponentEntity.setTTL_PANEL_CNT(esTTL_PANEL_CNT);
						msComponentEntity.setSHOT_CNT(esSHOT_CNT);
						msComponentEntity.setMODEL_NAME(esMODEL_NAME);
						msComponentEntity.setPROCESS_MODE(esPROCESS_MODE);
						msComponentEntity.setOK_PANEL_COUNT(esOK_PANEL_COUNT);
						msComponentEntity.setNG_PANEL_COUNT(esNG_PANEL_COUNT);
						msComponentEntity.setYIELD(esYIELD);
						
						setEdaSuccessFlag(msComponentDao.addCellMsCompenent(msComponentEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID : " + FID + "|| 【  EQP_SHEET_DATA_END 读取结束 】");
				}
				/***********************************************************************
				 * END ********** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** BEGIN *
				 ***********************************************************************/

				if (discern.startsWith("SHEET_SUMMARY_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  SHEET_SUMMARY_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SHEET_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						ssOPE_NO = afterDiscern[0];
						ssSHEET_ID = afterDiscern[1];
						ssEND_TIME = afterDiscern[2];
						ssPARAM_COLLECTION = afterDiscern[3];
						ssPARAM_GROUP = afterDiscern[4];
						ssPARAM_NAME = afterDiscern[5];
						ssAVG = afterDiscern[6];
						ssMAX = afterDiscern[7];
						ssMIN = afterDiscern[8];
						ssRANGE = afterDiscern[9];
						ssUNIFORMITY = afterDiscern[10];
						ssSTD = afterDiscern[11];
						ss3SIGMA = afterDiscern[12];
						ssSPEC_HIGH = afterDiscern[13];
						ssSPEC_LOW = afterDiscern[14];
						ssSPEC_TARGET = afterDiscern[15];
						ssCONTROL_HIGH = afterDiscern[16];
						ssCONTROL_LOW = afterDiscern[17];

						parameterEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						parameterEntity.setPARAM_NAME(ssPARAM_NAME);
						parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						parameterEntity.setPARAM_GROUP(ssPARAM_GROUP);

						setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN,FID));

						msComponentSumEntity.setOPE_NO(esOPE_NO);
						msComponentSumEntity.setSHEET_ID(esSHEET_ID);
						msComponentSumEntity.setEND_TIME(esEND_TIME);
						msComponentSumEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						msComponentSumEntity.setPARAM_NAME(ssPARAM_NAME);
						msComponentSumEntity.setAVG(ssAVG);
						msComponentSumEntity.setMAX(ssMAX);
						msComponentSumEntity.setMIN(ssMIN);
						msComponentSumEntity.setSTD(ssSTD);
						msComponentSumEntity.setUNIFORMITY(ssUNIFORMITY);
						msComponentSumEntity.setRANGE(ssRANGE);
						msComponentSumEntity.setThree_SIGMA(ss3SIGMA);
						msComponentSumEntity.setSPEC_HIGH(ssSPEC_HIGH);
						msComponentSumEntity.setSPEC_LOW(ssSPEC_LOW);
						msComponentSumEntity.setSPEC_TARGET(ssSPEC_TARGET);
						msComponentSumEntity.setCONTROL_HIGH(ssCONTROL_HIGH);
						msComponentSumEntity.setCONTROL_LOW(ssCONTROL_LOW);
						
						setEdaSuccessFlag(msComponentSumDao.addCellMsComponentSum(msComponentSumEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID : " + FID + "|| 【  SHEET_SUMMARY_DATA_END 读取结束 】");
				}

				/***********************************************************************
				 * END * 设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** END ****
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("SITE_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  SITE_DATA_BEGIN 读取开始 】");
					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SITE_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						sOPE_NO = afterDiscern[0];
						sSHEET_ID = afterDiscern[1];
						sCHIP_ID = afterDiscern[2];
						sCHIP_NO = afterDiscern[3];
						sEND_TIME = afterDiscern[4];
						sPARAM_COLLECTION = afterDiscern[5];
						sPARAM_GROUP = afterDiscern[6];
						sPARAM_NAME = afterDiscern[7];
						sSITE_NAME = afterDiscern[8];
						sPARAM_VALUE = afterDiscern[9];
						sJUDGE = afterDiscern[10];
						sX = afterDiscern[11];
						sY = afterDiscern[12];
						sSPEC_HIGH = afterDiscern[13];
						sSPEC_LOW = afterDiscern[14];
						sSPEC_TARGET = afterDiscern[15];
						sCONTROL_HIGH = afterDiscern[16];
						sCONTROL_LOW = afterDiscern[17];
						sSHOT_ID = afterDiscern[18];
						sSEQ_IN_SHOT = afterDiscern[19];
						sDEFINITION_X = afterDiscern[20];
						sDEFINITION_Y = afterDiscern[21];
						
						msResultEntity.setOPE_NO(esOPE_NO);
						msResultEntity.setSHEET_ID(esSHEET_ID);
						msResultEntity.setCHIP_ID(sCHIP_ID);
						msResultEntity.setCHIP_NO(sCHIP_NO);
						msResultEntity.setEND_TIME(esEND_TIME);
						msResultEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						msResultEntity.setPARAM_GROUP(sPARAM_GROUP);
						msResultEntity.setPARAM_NAME(sPARAM_NAME);
						msResultEntity.setSITE_NAME(sSITE_NAME);
						msResultEntity.setPARAM_VALUE(sPARAM_VALUE);
						msResultEntity.setJUDGE(sJUDGE);
						msResultEntity.setX(sX);
						msResultEntity.setY(sY);
						msResultEntity.setSPEC_HIGH(sSPEC_HIGH);
						msResultEntity.setSPEC_LOW(sSPEC_LOW);
						msResultEntity.setSPEC_TARGET(sSPEC_TARGET);
						msResultEntity.setCONTROL_HIGH(sCONTROL_HIGH);
						msResultEntity.setCONTROL_LOW(sCONTROL_LOW);
						msResultEntity.setSHOT_ID(sSHOT_ID);
						msResultEntity.setSEQ_IN_SHOT(sSEQ_IN_SHOT);
						msResultEntity.setDEFINITION_X(sDEFINITION_X);
						msResultEntity.setDEFINITION_Y(sDEFINITION_Y);
						
						setEdaSuccessFlag(msResultDao.addCellMsResult(msResultEntity, EDA_CONN, FID));
					}

					logger.info("FID : " + FID + "|| 【  SITE_DATA_END 读取结束 】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END *******
				 ***********************************************************************/

			}

			try {
				if (getEdaSuccessFlag()) {
					stmt = EDA_CONN.createStatement();
					stmt.executeQuery(loaderData);
					stmt.close();
				}
			} catch (Exception e) {
				reader.close();
				setEdaSuccessFlag(false);
				EDA_CONN.rollback();
				logger.error("FID : " + FID + "|| Call Loader Failed! Error Message:" + e.getMessage());
			}
				
		} catch (Exception ex) {

			reader.close();

			if (getEdaSuccessFlag()) {
				reader.close();
				setEdaSuccessFlag(false);
			}

		} finally {

			if (reader != null) {
				reader.close();
			}
		}
	}

	@Override
	public String getLoaderName() {
		return null;
	}

	@Override
	public boolean checkFileFormat(File file) throws Exception {
		return false;
	}
}
