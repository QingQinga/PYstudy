package com.mdt.cell.excute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

import org.apache.log4j.Logger;


import com.mdt.cell.cell_cell_insp.dao.CellInspChipDao;
import com.mdt.cell.cell_cell_insp.dao.CellInspChipSumDao;
import com.mdt.cell.cell_cell_insp.dao.CellInspComponentDao;
import com.mdt.cell.cell_cell_insp.dao.CellInspComponentSumDao;
import com.mdt.cell.cell_cell_insp.dao.CellInspResultDao;
import com.mdt.cell.cell_cell_insp.entity.CellInspChipEntity;
import com.mdt.cell.cell_cell_insp.entity.CellInspChipSumEntity;
import com.mdt.cell.cell_cell_insp.entity.CellInspComponentEntity;
import com.mdt.cell.cell_cell_insp.entity.CellInspComponentSumEntity;
import com.mdt.cell.cell_cell_insp.entity.CellInspResultEntity;
import com.mdt.cell.dao.ParameterDao;
import com.mdt.cell.dao.ProductDao;
import com.mdt.cell.dao.StepDao;
import com.mdt.cell.entity.ParameterEntity;
import com.mdt.cell.entity.ProductEntity;
import com.mdt.cell.entity.StepEntity;
import com.mdt.cell.spc.dao.LOAD_CEL_GAP_SHEET;
import com.mdt.cell.spc.entity.SpcLoaderEntity;
import com.mdt.cell.tableview.SessionConstants;
import com.mdt.cell.util.DataFileFormatUtil;
import com.mdt.cell.util.DistinctParamNameUtil;
import com.mdt.cell.util.EdaSpcAbstractLoader;

/**
 ***************************************************
 * @Title  CellCellGapExcute                                    
 * @author 林华锋
 * @Date   2017年4月19日下午5:12:13
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CellCellGapExcute extends EdaSpcAbstractLoader {

	private static Logger logger = Logger.getLogger(CellCellGapExcute.class);

	public CellCellGapExcute() throws Exception{
		super(SessionConstants.GET_SYSTEM_CONFIG_DIR(), SessionConstants.GET_LOG_CONFIG_DIR());
	}

	public Connection EDA_CONN = null;
	public Connection SPC_CONN = null;
	public String discern; // 识别前字符
	public String[] afterDiscern; // 识别后字符
	public BufferedReader reader;
	public String loaderData = "begin cell1_file_loader.load_data; end;";
	public Statement stmt = null;

	/** 实例化实体类对象 Begin **/

	public ParameterEntity parameterEntity = new ParameterEntity();
	public ProductEntity productEntity = new ProductEntity();
	public StepEntity stepEntity = new StepEntity();
	public CellInspComponentEntity cellInspComponentEntity = new CellInspComponentEntity();
	public CellInspComponentSumEntity cellInspComponentSumEntity = new CellInspComponentSumEntity();
	public CellInspChipEntity cellInspChipEntity = new CellInspChipEntity();
	public CellInspChipSumEntity cellInspChipSumEntity = new CellInspChipSumEntity();
	public CellInspResultEntity cellInspResultEntity = new CellInspResultEntity();

	/** 实例化实体类对象 End **/

	/** DAO */

	public ProductDao productDao;
	public ParameterDao parameterDao;
	public StepDao stepDao;
	public CellInspChipDao cellInspChipDao;
	public CellInspChipSumDao cellInspChipSumDao;
	public CellInspComponentDao cellInspComponentDao;
	public CellInspComponentSumDao cellInspComponentSumDao;
	public CellInspResultDao cellInspResultDao;
	/** DAO */

	/****** Header_Begin 字段行 */

	public String hFILE_VERSION = null; // 文件版本
	public String hFILE_CREATED_TIME = null; // 创建时间
	public String hEQUIP_TYPE = null; // 设备类型
	public String hEQ_ID = null; // 设备ID
	public String hSubEQ_ID = null; // 子设备ID
	public String hCONTENT = null; // DataBlock内容标题

	/***** Header_End 字段行 */

	/** DOWNLOADED_SHEET_DATA_BEGIN 字段行 */


	public String dsOPE_NO = null;
	public String dsSHEET_ID = null;
	public String dsPRODUCT_ID = null;
	public String dsRECIPE_ID = null;
	public String dsCASSETTE_ID = null;
	public String dsSLOT_NO = null;
	public String dsROUTE_ID = null;

	/** DOWNLOADED_SHEET_DATA_END 字段行 */

	/** EQP_SHEET_DATA_BEGIN 字段行 */

    public String esOPE_NO = null;
	public String esSHEET_ID = null;
	public String esSTART_TIME = null;
	public String esEND_TIME = null;
	public String esSAMPLING_FLAG = null;
	public String esUSER_ID = null;
	public String esABNORMAL_FLAG = null;
	public String esMAIN_JUDGE = null;
	public String esSHEET_JUDGE = null;
	public String esTTL_PANEL_CNT = null;
	public String esTACK_TIME = null;
	public String esCOMPONENT_TYPE = null;
	public String esOK_PANEL_COUNT = null;
	public String esNG_PANEL_COUNT = null;
	public String esYIELD = null;
	public String esTTL_DEFECT_CNT = null;
	public String esSHOT_CNT = null;
    public String esOK_PANEL_CNT = null;
	public String esNG_PANEL_CNT = null;
	
	/** EQP_SHEET_DATA_END 字段行 */

	/** SHEET_SUMMARY_DATA_BEGIN 字段行 */

	public String ssOPE_NO = null;
	public String ssSHEET_ID = null;
	public String ssEND_TIME = null;
	public String ssPARAM_COLLECTION = null;
	public String ssPARAM_GROUP = null;
	public String ssPARAM_NAME = null;
	public String ssAVG = null;
	public String ssMAX = null;
	public String ssMIN = null;
	public String ssSTD = null;
	public String ssUNIFORMITY = null;
	public String ssRANGE = null;
	public String ss3SIGMA = null;
	public String ssSPEC_HIGH = null;
	public String ssSPEC_LOW = null;
	public String ssSPEC_TARGET = null;
	public String ssCONTROL_HIGH = null;
	public String ssCONTROL_LOW = null;
    public String ssCOLOR_NAME = null;
    public String ssTHICKNESS_NAME = null;
	
	/** SHEET_SUMMARY_DATA_END 字段行 */

	/** CHIP_DATA_BEGIN 字段行 */

	public String cOPE_NO = null;
	public String cSHEET_ID = null;
	public String cEND_TIME = null;
	public String cCHIP_ID = null;
	public String cCHIP_NO = null;
	public String cCHIP_JUDGE = null;
	public String cMAIN_DEFECT_CODE = null;
	public String cPANEL_RANK = null;
	public String cPANEL_TTL_DEFECT_CNT = null;

	/** CHIP_DATA_END 字段行 */

	/** CHIP_SUMMARY_DATA_BEGIN 字段行 */

	public String csOPE_NO = null;
	public String csSHEET_ID = null;
	public String csEND_TIME = null;
	public String csCHIP_ID = null;
	public String csCHIP_NO = null;
	public String csPARAM_COLLECTION = null;
	public String csPARAM_GROUP = null;
	public String csPARAM_NAME = null;
	public String csAVG = null;
	public String csMAX = null;
	public String csMIN = null;
	public String csSTD = null;
	public String csUNIFORMITY = null;
	public String csRANGE = null;
	public String csSPEC_HIGH = null;
	public String csSPEC_LOW = null;
	public String csSPEC_TARGET = null;
	public String csCONTROL_HIGH = null;
	public String csCONTROL_LOW = null;
	public String cs3SIGMA = null;
	
	/** CHIP_SUMMARY_DATA_END 字段行 */

	/** SITE_DATA_BEGIN 字段行 */

	public String sOPE_NO = null;
	public String sSHEET_ID = null;
	public String sEND_TIME = null;
	public String sPARAM_COLLECTION = null;
	public String sPARAM_GROUP = null;
	public String sPARAM_NAME = null;
	public String sSITE_NAME = null;
	public String sPARAM_VALUE = null;
	public String sSPEC_HIGH = null;
	public String sSPEC_LOW = null;
	public String sSPEC_TARGET = null;
	public String sCONTROL_HIGH = null;
	public String sCONTROL_LOW = null;
	public String sX = null;
	public String sY = null;
	public String sCHIP_ID = null;
	public String sCHIP_NO = null;
	public String sJUDGE = null;
    public String sCOLOR_NAME = null;
    public String sTHICKNESS_NAME = null;
    
	/** SITE_DATA_END 字段行 */

	/** DEFECT_DATA_BEGIN 字段行 */

	public String dOPE_NO = null;
	public String dSHEET_ID = null;
	public String dEND_TIME = null;
	public String dCHIP_ID = null;
	public String dCHIP_NO = null;
	public String dDEFECT_JUDGE = null;
	public String dDEFECT_CODE = null;
	public String dDEFECT_CODE_DESC = null;
	public String dDEFECT_PATTERN = null;
	public String dDEFECT_LAYER_TYPE = null;
	public String dIMAGE_DATA = null;
	public String dMAIN_DEFECT_FLAG = null;
	public String dREJUDGE_FLAG = null;
	public String dDEFECT_SEQ_NO = null;
	public String dDEFECT_GROUP = null;
	public String dDEFECT_SIZE = null;
	public String dDEFECT_RANK = null;
	public String dCAPTURE_NO = null;
	public String dS = null;
	public String dG = null;
	public String dX = null;
	public String dY = null;
	public String dX2 = null;
	public String dY2 = null;
	public String dX3 = null;
	public String dy3 = null;
	public String dARRAY_X = null;
	public String dARRAY_Y = null;
	public String dARRAY_X2 = null;
	public String dARRAY_Y2 = null;
	public String dARRAY_X3 = null;
	public String dARRAY_Y3 = null;
	
	/** DEFECT_DATA_END 字段行 */
	
	public static void main(String[] args) throws Exception {

		// args:{TID:0,Shop:1,Source:2,eqp_type:3,target_flag:4,WorkDir:5,max_count:6,SystemLocalConfigPath:7,LogConfigPath:8,db_find_method:9,export_log_file:10}
		if (args != null && args.length > 0) {
			SessionConstants.SET_TID(args[0]);
			SessionConstants.SET_SHOP(args[1]);
			SessionConstants.SET_SOURCE(args[2]);
			SessionConstants.SET_EQP_TYPE(args[3]);
			SessionConstants.SET_TARGET_FLAG(args[4]);
			SessionConstants.SET_WORK_DIR(args[5]);
			SessionConstants.SET_MAX_COUNT(args[6]);
			SessionConstants.SET_SYSTEM_CONFIG_DIR(args[7]);
			SessionConstants.SET_LOG_CONFIG_DIR(args[8]);
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(args[9]);
			SessionConstants.SET_EXPORT_LOG_FLAG(args[10]);
		} else {
			SessionConstants.SET_TID("CELL_FILE_CELL_GAP_1"); // translator_config_t
			SessionConstants.SET_SHOP("CELL");
			SessionConstants.SET_SOURCE("FILE");
			SessionConstants.SET_EQP_TYPE("CELL_GAP");
			SessionConstants.SET_TARGET_FLAG("0,1,2,3,4,5,6,7,8,9");
			SessionConstants.SET_WORK_DIR("E:\\TEST");
			SessionConstants.SET_MAX_COUNT("100");
			SessionConstants.SET_SYSTEM_CONFIG_DIR("E:\\TEST\\system.properties");
			SessionConstants.SET_LOG_CONFIG_DIR("config/properties/log4j.properties");
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD("FALSE");
			SessionConstants.SET_EXPORT_LOG_FLAG("TRUE");
		}

		try {
			CellCellGapExcute CellGapExcute = new CellCellGapExcute();

			CellGapExcute.run();

		} catch (Exception e) {
			logger.error("FID : " + FID + "|| There hava a error! Error Message: " + e.getMessage());
		}

	}

	@Override
	public void readyToRun(File file) throws Exception {

		logger.info("FID : " + FID + "|| 【 Translator Begin 】");
		
		ReadDFSFile(file);
			
		logger.info("FID : " + FID + "|| 【 Translator End 】");
	}

	@SuppressWarnings("static-access")
	public void ReadDFSFile(File file) throws Exception {
        
		EDA_CONN = getEdaConnection();
		
		if (EDA_CONN.isClosed()) {
			logger.error("FID : " + FID + "|| The database connection was error");
		}
		
		EDA_CONN.setAutoCommit(false);
		try {
			
			String sPARAM_NAMES = ""; 
			String sPARAM_VALUES = "";
			reader = new BufferedReader(new FileReader(file.getPath()));

			while ((discern = reader.readLine()) != null) {
				if (discern.length() == 0) {
					continue;
				}
				/***********************************************************************
				 * BEGIN ****************** 设备抛出csv文件，读取Header部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("HEADER_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  HEADER_BEGIN 读取开始 】");

					while ((discern = reader.readLine()) != null && getEdaSuccessFlag()) {
						if (DataFileFormatUtil.Shift(discern).startsWith("FILE_VERSION")) {
							afterDiscern = discern.split(":", -1);
							hFILE_VERSION = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("FILE_CREATED_TIME")) {
							afterDiscern = discern.split(":", -1);
							hFILE_CREATED_TIME = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQUIP_TYPE")) {
							afterDiscern = discern.split(":", -1);
							hEQUIP_TYPE = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("SUBEQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hSubEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("CONTENT")) {
							afterDiscern = discern.split(":", -1);
							hCONTENT = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).endsWith("HEADER_END")) {
							break;
						}
					}
					logger.info("FID : " + FID + "|| 【  HEADER_END 读取结束 】");

				}
				/*********************************************************************
				 * END ******************** 设备抛出csv文件，读取Header部分 ****** END *
				 ********************************************************************/

				/***********************************************************************
				 * BEGIN ***************设备抛出csv文件，读取SHEET_DATA部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("DOWNLOADED_SHEET_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  DOWNLOADED_SHEET_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DOWNLOADED_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);
						
						dsOPE_NO =afterDiscern[0];
						dsROUTE_ID =afterDiscern[1];
						dsSHEET_ID =afterDiscern[2];
						dsPRODUCT_ID =afterDiscern[3];
						dsRECIPE_ID =afterDiscern[4];
						dsCASSETTE_ID =afterDiscern[5];
						dsSLOT_NO =afterDiscern[6];
								
						productEntity.setPRODUCT_ID(dsPRODUCT_ID);
						productEntity.setPRODUCT_GROUP("DEFAULT");
						
						setEdaSuccessFlag(productDao.addProductTable(productEntity, EDA_CONN,FID));
									
						cellInspComponentEntity.setROUTE_ID(dsROUTE_ID);
						cellInspComponentEntity.setPRODUCT_ID(dsPRODUCT_ID);
						cellInspComponentEntity.setRECIPE_ID(dsRECIPE_ID);
						cellInspComponentEntity.setCASSETTE_ID(dsCASSETTE_ID);
						cellInspComponentEntity.setSLOT_NO(dsSLOT_NO);
						cellInspComponentEntity.setSGR_ID(lot_id);
						cellInspComponentEntity.setPARENT_SGR_ID(parent_lot_id);
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
						
					}
					logger.info("FID : " + FID + "|| 【  DOWNLOADED_SHEET_DATA_END 读取结束 】");
				}
				/***********************************************************************
				 * END *******设备抛出csv文件，读取DOWNLOADED_SHEET_DATA部分 ****** END **
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN **** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** BEGIN *******
				 ***********************************************************************/
				if (discern.startsWith("EQP_SHEET_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  EQP_SHEET_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("EQP_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						esOPE_NO = afterDiscern[0];
						esSHEET_ID = afterDiscern[1];
						esSTART_TIME = afterDiscern[2];
						esEND_TIME = afterDiscern[3];
						esTACK_TIME = afterDiscern[4];
						esSAMPLING_FLAG = afterDiscern[5];
						esABNORMAL_FLAG = afterDiscern[6];
						esUSER_ID = afterDiscern[7];
						esMAIN_JUDGE = afterDiscern[8];
						esSHEET_JUDGE = afterDiscern[9];
						esTTL_PANEL_CNT = afterDiscern[10];
						esCOMPONENT_TYPE = afterDiscern[11];
						esYIELD = afterDiscern[12];
						esOK_PANEL_CNT = afterDiscern[13];
						esNG_PANEL_CNT = afterDiscern[14];
						
						if (esCOMPONENT_TYPE.equals("7")) {
							esCOMPONENT_TYPE = "1";
						} else if (esCOMPONENT_TYPE.equals("8")) {
							esCOMPONENT_TYPE = "2";
						} else if (esCOMPONENT_TYPE.equals("NA")||esCOMPONENT_TYPE.equals("na")||esCOMPONENT_TYPE.equals("Na")){
							esCOMPONENT_TYPE = null;
						}
                        
						esOPE_NO = esOPE_NO+"_"+hEQ_ID.trim().substring(2, 4)+hEQ_ID.trim().substring(5, 6); //CELL OPE_NO update
                        
						stepEntity.setSTEP_ID(esOPE_NO);
						stepEntity.setSTEP_SEQ(esOPE_NO);
						stepEntity.setSTEP_TYPE("M");
						stepEntity.setSTEP_GROUP(hEQUIP_TYPE);

						setEdaSuccessFlag(stepDao.addStepTable(stepEntity, EDA_CONN, FID));
						
						String GLASS_ID = esSHEET_ID.substring(0,esSHEET_ID.length()-3);
						
						cellInspComponentEntity.setOPE_NO(esOPE_NO);
						cellInspComponentEntity.setSHEET_ID(esSHEET_ID);
						cellInspComponentEntity.setGLASS_ID(GLASS_ID);
						cellInspComponentEntity.setEQ_ID(hEQ_ID);
						cellInspComponentEntity.setSUBEQ_ID(hSubEQ_ID);
						cellInspComponentEntity.setSTART_TIME(esSTART_TIME);
						cellInspComponentEntity.setEND_TIME(esEND_TIME);
						cellInspComponentEntity.setSAMPLING_FLAG(esSAMPLING_FLAG);
						cellInspComponentEntity.setUSER_ID(esUSER_ID);
						cellInspComponentEntity.setABNORMAL_FLAG(esABNORMAL_FLAG);
						cellInspComponentEntity.setMAIN_JUDGE(esMAIN_JUDGE);
						cellInspComponentEntity.setSHEET_JUDGE(esSHEET_JUDGE);
						cellInspComponentEntity.setTTL_PANEL_CNT(esTTL_PANEL_CNT);
						cellInspComponentEntity.setTACK_TIME(esTACK_TIME);
						cellInspComponentEntity.setCOMPONENT_TYPE(esCOMPONENT_TYPE);
						cellInspComponentEntity.setOK_PANEL_COUNT(esOK_PANEL_COUNT);
						cellInspComponentEntity.setNG_PANEL_COUNT(esNG_PANEL_COUNT);
						cellInspComponentEntity.setYIELD(esYIELD);

						setEdaSuccessFlag(cellInspComponentDao.addCellInspCompenent(cellInspComponentEntity,EDA_CONN,FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID : " + FID + "|| 【  EQP_SHEET_DATA_END 读取结束 】");
				}
				/***********************************************************************
				 * END ********** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** BEGIN *
				 ***********************************************************************/

				if (discern.startsWith("SHEET_SUMMARY_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  SHEET_SUMMARY_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SHEET_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						ssOPE_NO = afterDiscern[0];
						ssSHEET_ID = afterDiscern[1];
						ssEND_TIME = afterDiscern[2];
						ssPARAM_COLLECTION = afterDiscern[3];
						ssPARAM_GROUP = afterDiscern[4];
						ssPARAM_NAME = afterDiscern[5];
						ssAVG = afterDiscern[6];
						ssMAX = afterDiscern[7];
						ssMIN = afterDiscern[8];
						ssRANGE = afterDiscern[9];
						ssUNIFORMITY = afterDiscern[10];
						ssSTD = afterDiscern[11];
						ss3SIGMA = afterDiscern[12];
						ssSPEC_HIGH = afterDiscern[13];
						ssSPEC_LOW = afterDiscern[14];
						ssSPEC_TARGET = afterDiscern[15];
						ssCONTROL_HIGH = afterDiscern[16];
						ssCONTROL_LOW = afterDiscern[17];
						
						parameterEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						parameterEntity.setPARAM_NAME(ssPARAM_NAME);
						parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						parameterEntity.setPARAM_GROUP(ssPARAM_GROUP);
						
						setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN,FID));
						
						cellInspComponentSumEntity.setOPE_NO(esOPE_NO);
						cellInspComponentSumEntity.setSHEET_ID(esSHEET_ID);
						cellInspComponentSumEntity.setEND_TIME(esEND_TIME);
						cellInspComponentSumEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						cellInspComponentSumEntity.setPARAM_NAME(ssPARAM_NAME);
						cellInspComponentSumEntity.setAVG(ssAVG);
						cellInspComponentSumEntity.setMAX(ssMAX);
						cellInspComponentSumEntity.setMIN(ssMIN);
						cellInspComponentSumEntity.setSTD(ssSTD);
						cellInspComponentSumEntity.setUNIFORMITY(ssUNIFORMITY);
						cellInspComponentSumEntity.setRANGE(ssRANGE);
						cellInspComponentSumEntity.setThree_SIGMA(ss3SIGMA);
						cellInspComponentSumEntity.setSPEC_HIGH(ssSPEC_HIGH);
						cellInspComponentSumEntity.setSPEC_LOW(ssSPEC_LOW);
						cellInspComponentSumEntity.setSPEC_TARGET(ssSPEC_TARGET);
						cellInspComponentSumEntity.setCONTROL_HIGH(ssCONTROL_HIGH);
						cellInspComponentSumEntity.setCONTROL_LOW(ssCONTROL_LOW);
						
						setEdaSuccessFlag(cellInspComponentSumDao.addCellInspComponentSum(cellInspComponentSumEntity,EDA_CONN,FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
						
					}

					logger.info("FID : " + FID + "|| 【  SHEET_SUMMARY_DATA_END 读取结束 】");
				}

				/***********************************************************************
				 * END * 设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** END ****
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取CHIP_DATA_BEGIN部分 ******** BEGIN *****
				 ***********************************************************************/
				if (discern.startsWith("CHIP_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  CHIP_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("CHIP_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						cOPE_NO = afterDiscern[0];
						cSHEET_ID = afterDiscern[1];
						cCHIP_ID = afterDiscern[2];
						cCHIP_NO = afterDiscern[3];
						cEND_TIME = afterDiscern[4];
						//UserID = afterDiscern[5];  //机台未上抛
						cCHIP_JUDGE = afterDiscern[6];
						cMAIN_DEFECT_CODE = afterDiscern[7];
						cPANEL_TTL_DEFECT_CNT = afterDiscern[8];
						cPANEL_RANK = afterDiscern[9];
                        
						cellInspChipEntity.setOPE_NO(esOPE_NO);
						cellInspChipEntity.setSHEET_ID(esSHEET_ID);
						cellInspChipEntity.setEND_TIME(esEND_TIME);
						cellInspChipEntity.setCHIP_ID(cCHIP_ID);
						cellInspChipEntity.setCHIP_NO(cCHIP_NO);
						cellInspChipEntity.setCHIP_JUDGE(cCHIP_JUDGE);
						cellInspChipEntity.setMAIN_DEFECT_CODE(cMAIN_DEFECT_CODE);
						cellInspChipEntity.setPANEL_RANK(cPANEL_RANK);
						cellInspChipEntity.setPANEL_TTL_DEFECT_CNT(cPANEL_TTL_DEFECT_CNT);
						
						setEdaSuccessFlag(cellInspChipDao.addCellInspChip(cellInspChipEntity,EDA_CONN,FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID : " + FID + "|| 【  CHIP_DATA_END 读取结束 】");
				}
				/***********************************************************************
				 * END *** 设备抛出csv文件，读取CHIP_DATA_BEGIN部分 ******** END ********
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取CHIP_SUMMARY_DATA_BEGIN部分 ** BEGIN ***
				 ***********************************************************************/

				if (discern.startsWith("CHIP_SUMMARY_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  CHIP_SUMMARY_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("CHIP_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);
                        
						csOPE_NO = afterDiscern[0];
						csSHEET_ID = afterDiscern[1];
						csCHIP_ID = afterDiscern[2];
						csCHIP_NO = afterDiscern[3];
						csEND_TIME = afterDiscern[4];
						csPARAM_COLLECTION = afterDiscern[5];
						csPARAM_GROUP = afterDiscern[6];
						csPARAM_NAME = afterDiscern[7];
						csAVG = afterDiscern[8];
						csMAX = afterDiscern[9];
						csMIN = afterDiscern[10];
						csRANGE = afterDiscern[11];
						csUNIFORMITY = afterDiscern[12];
						csSTD = afterDiscern[13];
						cs3SIGMA = afterDiscern[14];
						csSPEC_HIGH = afterDiscern[15];
						csSPEC_LOW = afterDiscern[16];
						csSPEC_TARGET = afterDiscern[17];
						csCONTROL_HIGH = afterDiscern[18];
						csCONTROL_LOW = afterDiscern[19];

						DistinctParamNameUtil paramUtil =new DistinctParamNameUtil();
						int temp = paramUtil.selectParamName(EDA_CONN, csPARAM_NAME);
						if(temp==0){
						   parameterEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						   parameterEntity.setPARAM_NAME(csPARAM_NAME);
						   parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						   parameterEntity.setPARAM_GROUP(csPARAM_GROUP);
						   setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN, FID));
						}
						
						cellInspChipSumEntity.setOPE_NO(esOPE_NO);
						cellInspChipSumEntity.setSHEET_ID(esSHEET_ID);
						cellInspChipSumEntity.setEND_TIME(esEND_TIME);
						cellInspChipSumEntity.setCHIP_ID(csCHIP_ID);
						cellInspChipSumEntity.setCHIP_NO(csCHIP_NO);
						cellInspChipSumEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						cellInspChipSumEntity.setPARAM_NAME(csPARAM_NAME);
						cellInspChipSumEntity.setAVG(csAVG);
						cellInspChipSumEntity.setMAX(csMAX);
						cellInspChipSumEntity.setMIN(csMIN);
						cellInspChipSumEntity.setSTD(csSTD);
						cellInspChipSumEntity.setUNIFORMITY(csUNIFORMITY);
						cellInspChipSumEntity.setRANGE(csRANGE);
						cellInspChipSumEntity.setSPEC_HIGH(csSPEC_HIGH);
						cellInspChipSumEntity.setSPEC_LOW(csSPEC_LOW);
						cellInspChipSumEntity.setSPEC_TARGET(csSPEC_TARGET);
						cellInspChipSumEntity.setCONTROL_HIGH(csCONTROL_HIGH);
						cellInspChipSumEntity.setCONTROL_LOW(csCONTROL_LOW);
						cellInspChipSumEntity.setTHREE_SIGMA(cs3SIGMA);
						
						setEdaSuccessFlag(cellInspChipSumDao.addCellInspChipSum(cellInspChipSumEntity,EDA_CONN,FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID : " + FID + "|| 【  CHIP_SUMMARY_DATA_END 读取结束 】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取CHIP_SUMMARY_DATA_BEGIN部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("SITE_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  SITE_DATA_BEGIN 读取开始 】");
					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SITE_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						sOPE_NO = afterDiscern[0];
						sSHEET_ID = afterDiscern[1];
						sCHIP_ID = afterDiscern[2];
						sCHIP_NO = afterDiscern[3];
						sEND_TIME = afterDiscern[4];
						sPARAM_COLLECTION = afterDiscern[5];
						sPARAM_GROUP = afterDiscern[6];
						sPARAM_NAME = afterDiscern[7];
						sSITE_NAME = afterDiscern[8];
						sPARAM_VALUE = afterDiscern[9];
						sJUDGE = afterDiscern[10];
						sX = afterDiscern[11];
						sY = afterDiscern[12];
						sSPEC_HIGH = afterDiscern[13];
						sSPEC_LOW = afterDiscern[14];
						sSPEC_TARGET = afterDiscern[15];
						sCONTROL_HIGH = afterDiscern[16];
						sCONTROL_LOW = afterDiscern[17];
					   
						cellInspResultEntity.setOPE_NO(esOPE_NO);
						cellInspResultEntity.setSHEET_ID(esSHEET_ID);
						cellInspResultEntity.setCHIP_ID(sCHIP_ID);
						cellInspResultEntity.setCHIP_NO(sCHIP_NO);
						cellInspResultEntity.setEND_TIME(esEND_TIME);
						cellInspResultEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						cellInspResultEntity.setPARAM_GROUP(sPARAM_GROUP);
						cellInspResultEntity.setPARAM_NAME(sPARAM_NAME);
						cellInspResultEntity.setSITE_NAME(sSITE_NAME);
						cellInspResultEntity.setPARAM_VALUE(sPARAM_VALUE);
						cellInspResultEntity.setJUDGE(sJUDGE);
						cellInspResultEntity.setX(sX);
						cellInspResultEntity.setY(sY);
						cellInspResultEntity.setSPEC_HIGH(sSPEC_HIGH);
						cellInspResultEntity.setSPEC_LOW(sSPEC_LOW);
						cellInspResultEntity.setSPEC_TARGET(sSPEC_TARGET);
						cellInspResultEntity.setCONTROL_HIGH(sCONTROL_HIGH);
						cellInspResultEntity.setCONTROL_LOW(sCONTROL_LOW);
						
						setEdaSuccessFlag(cellInspResultDao.addCellInspResult(cellInspResultEntity, EDA_CONN, FID));
						
					  //for SPC
						if (sPARAM_NAME != null && sPARAM_NAME.length() > 0 && !sPARAM_NAME.trim().equals("")
							&& sPARAM_VALUE != null && sPARAM_VALUE.length() > 0 && !sPARAM_VALUE.trim().equals("") 
							&& !sPARAM_VALUE.trim().equalsIgnoreCase("NA"))
						{
							sPARAM_NAMES += sPARAM_NAME + ","; 
							sPARAM_VALUES += sPARAM_VALUE + ",";
						}
						
					    
					    
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID : " + FID + "|| 【  SITE_DATA_END 读取结束 】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END *******
				 ***********************************************************************/
			}

			try {
				if (getEdaSuccessFlag()) {
					stmt = EDA_CONN.createStatement();
					stmt.executeQuery(loaderData);;
					stmt.close();
				}
			} catch (Exception e) {
				reader.close();
				setEdaSuccessFlag(false);
				EDA_CONN.rollback();
				logger.error("FID : " + FID + "|| Call Loader Failed! Error Message:" + e.getMessage());
			}
			
			//SPC handle
			try {
				spcRunFlag = true;
				logger.info("FID: " + FID + "|| spc_enable = " + spc_enable);
				
				if (spc_enable.equalsIgnoreCase("true") && getEdaSuccessFlag()) {
					
					logger.info("FID: " + FID + "|| Start SPC running..");
					
					SPC_CONN = getSpcConnection();
					
					if (SPC_CONN.isClosed()) {
						
						logger.error("FID: " + FID + "|| The SPC database connection was error");

						setSpcSuccessFlag(false);
					}
					
					if (getSpcSuccessFlag()) {
						
						SpcLoaderEntity entity = new SpcLoaderEntity();
						
						entity.setProduct_id(replaceBlankToNull(dsPRODUCT_ID));
						entity.setRecipe_id(replaceBlankToNull(dsRECIPE_ID));
						entity.setEquip_type(replaceBlankToNull(hEQUIP_TYPE));
						entity.setEq_id(replaceBlankToNull(hEQ_ID));
						entity.setSubeq_id(replaceBlankToNull(hSubEQ_ID));
						entity.setOpe_no(replaceBlankToNull(dsOPE_NO));
						entity.setRoute_id(replaceBlankToNull(dsROUTE_ID));
						entity.setCassette_id(replaceBlankToNull(dsCASSETTE_ID));
						entity.setStart_time(replaceBlankToNull(esEND_TIME)); //special handle
						entity.setSheet_id(replaceBlankToNull(dsSHEET_ID));
						
						if(sPARAM_NAMES != null && sPARAM_VALUES != null
						   && !sPARAM_NAMES.trim().equals("") && !sPARAM_VALUES.trim().equals("")){
							
							logger.info("FID: " + FID + "|| call SPC loader.");

							setSpcSuccessFlag(LOAD_CEL_GAP_SHEET.prepareSpcData(entity, sPARAM_NAMES, sPARAM_VALUES, SPC_CONN));
						}
					}
				}
				
			} catch (Exception ex) {
				
				setSpcSuccessFlag(false);

				logger.error("FID: " + FID + "|| Process SPC parsing error : " + ex.getMessage());

			}
		} catch (Exception ex) {

			reader.close();
            
			if (getEdaSuccessFlag()) {
				reader.close();
				setEdaSuccessFlag(false);
			}

		} finally {
			
			if (reader != null) {
				reader.close();
			}

		}
	}

	@Override
	public String getLoaderName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkFileFormat(File file) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}
}
