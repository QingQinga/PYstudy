package com.mdt.cf.cf_ttp.entity;

import java.io.Serializable;

import com.mdt.cf.entity.CFGlassBaseEntity;

/**
 ***************************************************
 * @Title CFTTPGlassEnttiy
 * @author 林华锋
 * @Date 2017年4月20日上午9:43:37
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFTTPGlassEntity extends CFGlassBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String MODEL_NAME;
	private String PROCESS_MODE;
	private String SHOT_CNT;

	public String getMODEL_NAME() {
		return MODEL_NAME;
	}

	public void setMODEL_NAME(String mODEL_NAME) {
		MODEL_NAME = mODEL_NAME;
	}

	public String getPROCESS_MODE() {
		return PROCESS_MODE;
	}

	public void setPROCESS_MODE(String pROCESS_MODE) {
		PROCESS_MODE = pROCESS_MODE;
	}

	public String getSHOT_CNT() {
		return SHOT_CNT;
	}

	public void setSHOT_CNT(String sHOT_CNT) {
		SHOT_CNT = sHOT_CNT;
	}

}
