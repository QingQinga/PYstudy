package com.mdt.cf.spc.entity;

public class SpcLoaderEntity {
	
	
	public String product_id;
	public String recipe_id;
	public String param_name;	
	public String equip_type;
	public String eq_id;
	public String subeq_id;
	public String ope_no;
	public String route_id;
	public String cassette_id;	
	public String start_time;
	public String sheet_id;
	public String avg;
	public String std;
	public String max;
	public String min;
	public String count;
	public String uni;
	public String raw_data;
	public String param_value;
	public String module_name;
	
	
	public String getModule_name() {
		return module_name;
	}
	public void setModule_name(String module_name) {
		this.module_name = module_name;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	public String getRecipe_id() {
		return recipe_id;
	}
	public void setRecipe_id(String recipe_id) {
		this.recipe_id = recipe_id;
	}
	public String getParam_name() {
		return param_name;
	}
	public void setParam_name(String param_name) {
		this.param_name = param_name;
	}
	public String getEquip_type() {
		return equip_type;
	}
	public void setEquip_type(String equip_type) {
		this.equip_type = equip_type;
	}
	public String getEq_id() {
		return eq_id;
	}
	public void setEq_id(String eq_id) {
		this.eq_id = eq_id;
	}
	public String getSubeq_id() {
		return subeq_id;
	}
	public void setSubeq_id(String subeq_id) {
		this.subeq_id = subeq_id;
	}
	public String getOpe_no() {
		return ope_no;
	}
	public void setOpe_no(String ope_no) {
		this.ope_no = ope_no;
	}
	public String getRoute_id() {
		return route_id;
	}
	public void setRoute_id(String route_id) {
		this.route_id = route_id;
	}
	public String getCassette_id() {
		return cassette_id;
	}
	public void setCassette_id(String cassette_id) {
		this.cassette_id = cassette_id;
	}
	public String getStart_time() {
		return start_time;
	}
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	public String getSheet_id() {
		return sheet_id;
	}
	public void setSheet_id(String sheet_id) {
		this.sheet_id = sheet_id;
	}
	public String getAvg() {
		return avg;
	}
	public void setAvg(String avg) {
		this.avg = avg;
	}
	public String getStd() {
		return std;
	}
	public void setStd(String std) {
		this.std = std;
	}
	public String getMax() {
		return max;
	}
	public void setMax(String max) {
		this.max = max;
	}
	public String getMin() {
		return min;
	}
	public void setMin(String min) {
		this.min = min;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getUni() {
		return uni;
	}
	public void setUni(String uni) {
		this.uni = uni;
	}
	public String getRaw_data() {
		return raw_data;
	}
	public void setRaw_data(String raw_data) {
		this.raw_data = raw_data;
	}
	public String getParam_value() {
		return param_value;
	}
	public void setParam_value(String param_value) {
		this.param_value = param_value;
	}
	
	
}
