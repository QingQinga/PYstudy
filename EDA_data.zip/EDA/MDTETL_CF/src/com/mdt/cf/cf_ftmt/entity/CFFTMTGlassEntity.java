package com.mdt.cf.cf_ftmt.entity;

import java.io.Serializable;

import com.mdt.cf.entity.CFGlassBaseEntity;

/**
 ***************************************************
 * @Title CFFTMTGlassEntity
 * @author 林华锋
 * @Date 2017年4月20日上午10:10:28
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFFTMTGlassEntity extends CFGlassBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String SHOT_CNT;
 
	public String getSHOT_CNT() {
		return SHOT_CNT;
	}
	    
	public void setSHOT_CNT(String sHOT_CNT) {
		SHOT_CNT = sHOT_CNT;
	}

}
