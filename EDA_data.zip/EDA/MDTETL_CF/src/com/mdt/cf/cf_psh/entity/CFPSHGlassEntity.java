package com.mdt.cf.cf_psh.entity;

import java.io.Serializable;

import com.mdt.cf.entity.CFGlassBaseEntity;

/**
 ***************************************************
 * @Title CFPSHGlassEntity
 * @author 林华锋
 * @Date 2017年4月20日上午10:02:11
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFPSHGlassEntity extends CFGlassBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String LAYER;
	private String SHOT_CNT;
	private String WHITE_LIGHT_USE_TIME;

	public String getLAYER() {
		return LAYER;
	}

	public void setLAYER(String lAYER) {
		LAYER = lAYER;
	}

	public String getSHOT_CNT() {
		return SHOT_CNT;
	}

	public void setSHOT_CNT(String sHOT_CNT) {
		SHOT_CNT = sHOT_CNT;
	}

	public String getWHITE_LIGHT_USE_TIME() {
		return WHITE_LIGHT_USE_TIME;
	}

	public void setWHITE_LIGHT_USE_TIME(String wHITE_LIGHT_USE_TIME) {
		WHITE_LIGHT_USE_TIME = wHITE_LIGHT_USE_TIME;
	}

	
	
}
