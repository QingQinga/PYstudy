package com.mdt.cf.cf_psh.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.cf.cf_psh.entity.CFPSHChipEntity;
import com.mdt.cf.util.DBUtil;

/**
 ***************************************************
 * @Title  CFPSHChipDao                                    
 * @author 林华锋
 * @Date   2017年4月20日下午2:09:10
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFPSHChipDao {

	private static Logger logger = Logger.getLogger(CFPSHChipDao.class);

	public static boolean addCFPSHChip(CFPSHChipEntity Entity, Connection conn, String fid) throws Exception {
		
		String view = "CF_PSH_CHIP_V"; 
		
		String sql = "INSERT INTO " + view
		          + "(" 
				  +"OPE_NO,"
				  +"SHEET_ID,"
				  +"END_TIME,"
				  +"CHIP_ID,"
				  +"CHIP_NO,"
				  +"CHIP_JUDGE,"
				  +"MAIN_DEFECT_CODE,"
				  +"PANEL_TTL_DEFECT_CNT"
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA'))"
				  +")";

		Object[] params = {Entity.getOPE_NO(),
				           Entity.getSHEET_ID(),
				           Entity.getEND_TIME(),
				           Entity.getCHIP_ID(),
				           Entity.getCHIP_NO(),
				           Entity.getCHIP_JUDGE(),
				           Entity.getMAIN_DEFECT_CODE(),
				           Entity.getPANEL_TTL_DEFECT_CNT()
		                  };
                           
		boolean isErrorRet = true;

		try {

			DBUtil.executeUpdate(sql, params, conn);

		} catch (Exception e) {

			logger.error("FID: " + fid + "|| ----- INSERT CF_PSH_CHIP_V Failed! Error Message: " + e.getMessage());

			isErrorRet = false;
			throw e;
		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {
				logger.error("FID: " + fid + "|| ----- An Error Cased: " + e.getMessage());
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}

	}
}
