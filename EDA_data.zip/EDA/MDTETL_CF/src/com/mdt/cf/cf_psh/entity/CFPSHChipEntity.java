package com.mdt.cf.cf_psh.entity;

import java.io.Serializable;

import com.mdt.cf.entity.CFChipBaseEntity;

/**
 ***************************************************
 * @Title  CFPSHChipEntity                                    
 * @author 林华锋
 * @Date   2017年4月20日上午9:53:43
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFPSHChipEntity extends CFChipBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;

}
