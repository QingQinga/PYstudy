package com.mdt.cf.cf_psh.entity;

import java.io.Serializable;

import com.mdt.cf.entity.CFResultBaseEntity;

/**
 ***************************************************
 * @Title CFPSHResultEntity
 * @author 林华锋
 * @Date 2017年4月20日上午10:04:51
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFPSHResultEntity extends CFResultBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String SHOT_ID;
	private String PS_SITE_GROUP;
	private String HEAD_NO;
	private String HEAD_OFFSET;
	private String SEQ_IN_SHOT;
	private String DEFINITION_X;
	private String DEFINITION_Y;

	public String getSHOT_ID() {
		return SHOT_ID;
	}

	public void setSHOT_ID(String sHOT_ID) {
		SHOT_ID = sHOT_ID;
	}

	public String getPS_SITE_GROUP() {
		return PS_SITE_GROUP;
	}

	public void setPS_SITE_GROUP(String pS_SITE_GROUP) {
		PS_SITE_GROUP = pS_SITE_GROUP;
	}

	public String getHEAD_NO() {
		return HEAD_NO;
	}

	public void setHEAD_NO(String hEAD_NO) {
		HEAD_NO = hEAD_NO;
	}
	
	public String getHEAD_OFFSET() {
		return HEAD_OFFSET;
	}

	public void setHEAD_OFFSET(String hEAD_OFFSET) {
		HEAD_OFFSET = hEAD_OFFSET;
	}

	public String getSEQ_IN_SHOT() {
		return SEQ_IN_SHOT;
	}

	public void setSEQ_IN_SHOT(String sEQ_IN_SHOT) {
		SEQ_IN_SHOT = sEQ_IN_SHOT;
	}

	public String getDEFINITION_X() {
		return DEFINITION_X;
	}

	public void setDEFINITION_X(String dEFINITION_X) {
		DEFINITION_X = dEFINITION_X;
	}

	public String getDEFINITION_Y() {
		return DEFINITION_Y;
	}

	public void setDEFINITION_Y(String dEFINITION_Y) {
		DEFINITION_Y = dEFINITION_Y;
	}

}
