package com.mdt.cf.cf_psh.entity;

import java.io.Serializable;

import com.mdt.cf.entity.CFChipSumBaseEntity;

/**
 ***************************************************
 * @Title CFPSHChipSumEntity
 * @author 林华锋
 * @Date 2017年4月20日上午10:00:30
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFPSHChipSumEntity extends CFChipSumBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

}
