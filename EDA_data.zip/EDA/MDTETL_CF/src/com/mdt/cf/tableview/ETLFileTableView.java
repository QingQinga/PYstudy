package com.mdt.cf.tableview;


public class ETLFileTableView extends BaseTableView{
	

	public String getFID() {
		return (String)data.get("FID");
	}
	@SuppressWarnings("unchecked")
	public void setFID(String fID) {
		data.put("FID",fID);
	}
	
	public String getSHOP() {
		return (String)data.get("SHOP");
	}
	@SuppressWarnings("unchecked")
	public void setSHOP(String sHOP) {
		data.put("SHOP", sHOP);
	}

	public String getEQUIP_TYPE() {
		return (String)data.get("EQUIP_TYPE");
	}
	@SuppressWarnings("unchecked")
	public void setEQUIP_TYPE(String EQUIP_TYPE) {
		data.put("EQUIP_TYPE", EQUIP_TYPE);
	}
	
	public String getEQUIP_ID() {
		return (String)data.get("EQUIP_ID");
	}
	@SuppressWarnings("unchecked")
	public void setEQUIP_ID(String EQUIP_ID) {
		data.put("EQUIP_ID", EQUIP_ID);
	}
	
	public String getPRODUCT_ID() {
		return (String)data.get("PRODUCT_ID");
	}
	@SuppressWarnings("unchecked")
	public void setPRODUCT_ID(String PRODUCT_ID) {
		data.put("PRODUCT_ID", PRODUCT_ID);
	}
	/*
	public String getLOT_ID() {
		return (String)data.get("LOT_ID");
	}
	public void setLOT_ID(String LOT_ID) {
		data.put("LOT_ID", LOT_ID);
	}
	
	public String getGLASS_ID() {
		return (String)data.get("GLASS_ID");
	}
	public void setGLASS_ID(String GLASS_ID) {
		data.put("GLASS_ID", GLASS_ID);
	}
	
	public String getCUT_ID() {
		return (String)data.get("CUT_ID");
	}
	public void setCUT_ID(String CUT_ID) {
		data.put("CUT_ID", CUT_ID);
	}
	
	public String getPANEL_ID() {
		return (String)data.get("PANEL_ID");
	}
	public void setPANEL_ID(String PANEL_ID) {
		data.put("PANEL_ID", PANEL_ID);
	}
	*/
	public String getFILE_SOURCE() {
		return (String)data.get("FILE_SOURCE");
	}
	@SuppressWarnings("unchecked")
	public void setFILE_SOURCE(String fILE_SOURCE) {
		data.put("FILE_SOURCE", fILE_SOURCE);
	}
	
	public String getFILE_SRC_DIR() {
		return (String)data.get("FILE_SRC_DIR");
	}
	@SuppressWarnings("unchecked")
	public void setFILE_SRC_DIR(String fILE_SRC_DIR) {
		data.put("FILE_SRC_DIR", fILE_SRC_DIR);
	}
	
	public String getFILE_NAME() {
		return (String)data.get("FILE_NAME");
	}
	@SuppressWarnings("unchecked")
	public void setFILE_NAME(String fILE_NAME) {
		data.put("FILE_NAME", fILE_NAME);
	}
	
	public String getFILE_TYPE() {
		return (String)data.get("FILE_TYPE");
	}
	@SuppressWarnings("unchecked")
	public void setFILE_TYPE(String fILE_TYPE) {
		data.put("FILE_TYPE", fILE_TYPE);
	}
	
	public String getFILE_SIZE() {
		return (String)data.get("FILE_SIZE");
	}
	@SuppressWarnings("unchecked")
	public void setFILE_SIZE(String fILE_SIZE) {
		data.put("FILE_SIZE", fILE_SIZE);
	}
	
	public String getTARGET_FLAG() {
		return (String)data.get("TARGET_FLAG");
	}
	@SuppressWarnings("unchecked")
	public void setTARGET_FLAG(String tARGET_FLAG) {
		data.put("TARGET_FLAG", tARGET_FLAG);
	}

	public String getFILE_CREATE_TIME() {
		return (String)data.get("FILE_CREATE_TIME");
	}
	@SuppressWarnings("unchecked")
	public void setFILE_CREATE_TIME(String fILE_CREATE_TIME) {
		data.put("FILE_CREATE_TIME", fILE_CREATE_TIME);
	}

	public String getFILE_ENTER_DB_TIME() {
		return (String)data.get("FILE_ENTER_DB_TIME");
	}
	@SuppressWarnings("unchecked")
	public void setFILE_ENTER_DB_TIME(String fILE_ENTER_DB_TIME) {
		data.put("FILE_ENTER_DB_TIME", fILE_ENTER_DB_TIME);
	}

	public String getPARSE_FLAG() {
		return (String)data.get("PARSE_FLAG");
	}
	@SuppressWarnings("unchecked")
	public void setPARSE_FLAG(String PARSE_FLAG) {
		data.put("PARSE_FLAG", PARSE_FLAG);
	}

	public String getCURRENT_FILE_SRC_DIR() {
		return (String)data.get("CURRENT_FILE_SRC_DIR");
	}
	@SuppressWarnings("unchecked")
	public void setCURRENT_FILE_SRC_DIR(String CURRENT_FILE_SRC_DIR) {
		data.put("CURRENT_FILE_SRC_DIR", CURRENT_FILE_SRC_DIR);
	}

}
