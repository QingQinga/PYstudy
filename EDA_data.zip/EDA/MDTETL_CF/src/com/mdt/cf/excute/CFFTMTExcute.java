package com.mdt.cf.excute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.cf.cf_ftmt.dao.CFFTMTGlassDao;
import com.mdt.cf.cf_ftmt.dao.CFFTMTGlassSumDao;
import com.mdt.cf.cf_ftmt.dao.CFFTMTResultDao;
import com.mdt.cf.cf_ftmt.entity.CFFTMTGlassEntity;
import com.mdt.cf.cf_ftmt.entity.CFFTMTGlassSumEntity;
import com.mdt.cf.cf_ftmt.entity.CFFTMTResultEntity;
import com.mdt.cf.dao.ParameterDao;
import com.mdt.cf.dao.ProductDao;
import com.mdt.cf.dao.StepDao;
import com.mdt.cf.entity.ParameterEntity;
import com.mdt.cf.entity.ProductEntity;
import com.mdt.cf.entity.StepEntity;
import com.mdt.cf.spc.dao.LOAD_CF_FTMT_SHEET;
import com.mdt.cf.spc.entity.SpcLoaderEntity;

import com.mdt.cf.tableview.SessionConstants;
import com.mdt.cf.util.DataFileFormatUtil;
import com.mdt.cf.util.DateFormatUtil;
import com.mdt.cf.util.EdaSpcAbstractLoader;
import com.mdt.cf.util.UpdateOpeNoUtil;

public class CFFTMTExcute extends EdaSpcAbstractLoader {

	private static Logger logger = Logger.getLogger(CFFTMTExcute.class);

	public CFFTMTExcute() throws Exception {
		super(SessionConstants.GET_SYSTEM_CONFIG_DIR(), SessionConstants.GET_LOG_CONFIG_DIR());
	}

	public Connection EDA_CONN = null;
	public Connection SPC_CONN = null;
	public String discern; // 识别前字符
	public String[] afterDiscern; // 识别后字符
	public BufferedReader reader;
	public String loaderData = "begin cf_file_loader.load_data; end;";
	public Statement stmt = null;

	/** 实例化实体类对象 Begin **/

	public ParameterEntity parameterEntity = new ParameterEntity();
	public ProductEntity productEntity = new ProductEntity();
	public StepEntity stepEntity = new StepEntity();
	public CFFTMTGlassEntity ftmtGlassEntity = new CFFTMTGlassEntity();
	public CFFTMTGlassSumEntity ftmtGlassSumEntity = new CFFTMTGlassSumEntity();
	public CFFTMTResultEntity ftmtResultEntity = new CFFTMTResultEntity();
	public UpdateOpeNoUtil updateOpeNoUtil = new UpdateOpeNoUtil();
	/** 实例化实体类对象 End **/

	/** DAO */

	public ProductDao productDao;
	public ParameterDao parameterDao;
	public StepDao stepDao;
	public CFFTMTGlassDao ftmtGlassDao;
	public CFFTMTGlassSumDao ftmtGlassSumDao;
	public CFFTMTResultDao ftmtResultDao;

	/** DAO */

	/****** Header_Begin 字段行 */

	public String hFILE_VERSION = null; // 文件版本
	public String hFILE_CREATED_TIME = null; // 创建时间
	public String hEQUIP_TYPE = null; // 设备类型
	public String hEQ_ID = null; // 设备ID
	public String hSubEQ_ID = null; // 子设备ID
	public String hCONTENT = null; // DataBlock内容标题

	/***** Header_End 字段行 */

	/** DOWNLOADED_SHEET_DATA_BEGIN 字段行 */

	public String dsOPE_NO = null;
	public String dsSHEET_ID = null;
	public String dsPRODUCT_ID = null;
	public String dsLOT_ID = null;
	public String dsRECIPE_ID = null;
	public String dsCASSETTE_ID = null;
	public String dsSLOT_NO = null;
	public String dsROUTE_ID = null;

	/** DOWNLOADED_SHEET_DATA_END 字段行 */

	/** EQP_SHEET_DATA_BEGIN 字段行 */

	public String esOPE_NO = null;
	public String esSHEET_ID = null;
	public String esSTART_TIME = null;
	public String esEND_TIME = null;
	public String esSAMPLING_FLAG = null;
	public String esUSER_ID = null;
	public String esABNORMAL_FLAG = null;
	public String esMAIN_JUDGE = null;
	public String esSHEET_JUDGE = null;
	public String esTTL_PANEL_CNT = null;
	public String esTACK_TIME = null;
	public String esCOMPONENT_TYPE = null;
	public String esSHOT_CNT = null;

	/** EQP_SHEET_DATA_END 字段行 */

	/** SHEET_SUMMARY_DATA_BEGIN 字段行 */

	public String ssOPE_NO = null;
	public String ssSHEET_ID = null;
	public String ssEND_TIME = null;
	public String ssPARAM_COLLECTION = null;
	public String ssPARAM_GROUP = null;
	public String ssPARAM_NAME = null;
	public String ssAVG = null;
	public String ssMAX = null;
	public String ssMIN = null;
	public String ssSTD = null;
	public String ssUNIFORMITY = null;
	public String ssRANGE = null;
	public String ss3SIGMA = null;
	public String ssSPEC_HIGH = null;
	public String ssSPEC_LOW = null;
	public String ssSPEC_TARGET = null;
	public String ssCONTROL_HIGH = null;
	public String ssCONTROL_LOW = null;

	public String ssCOLOR_NAME = null;
	public String ssTHICKNESS_NAME = null;

	/** SHEET_SUMMARY_DATA_END 字段行 */

	/** SITE_DATA_BEGIN 字段行 */

	public String sOPE_NO = null;
	public String sSHEET_ID = null;
	public String sEND_TIME = null;
	public String sSITE_NAME = null;
	public String sPARAM_COLLECTION = null;
	public String sPARAM_GROUP = null;
	public String sPARAM_NAME = null;
	public String sPARAM_VALUE = null;
	public String sX = null;
	public String sY = null;
	public String sSPEC_HIGH = null;
	public String sSPEC_LOW = null;
	public String sSPEC_TARGET = null;
	public String sCONTROL_HIGH = null;
	public String sCONTROL_LOW = null;
	public String sCHIP_ID = null;
	public String sCHIP_NO = null;
	public String sJUDGE = null;

	/** SITE_DATA_END 字段行 */

	/**
	 * ExcuteCenter
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		// args:{TID:0,Shop:1,Source:2,eqp_type:3,target_flag:4,WorkDir:5,max_count:6,SystemLocalConfigPath:7,LogConfigPath:8,db_find_method:9,export_log_file:10}
		if (args != null && args.length > 0) {
			SessionConstants.SET_TID(args[0]);
			SessionConstants.SET_SHOP(args[1]);
			SessionConstants.SET_SOURCE(args[2]);
			SessionConstants.SET_EQP_TYPE(args[3]);
			SessionConstants.SET_TARGET_FLAG(args[4]);
			SessionConstants.SET_WORK_DIR(args[5]);
			SessionConstants.SET_MAX_COUNT(args[6]);
			SessionConstants.SET_SYSTEM_CONFIG_DIR(args[7]);
			SessionConstants.SET_LOG_CONFIG_DIR(args[8]);
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(args[9]);
			SessionConstants.SET_EXPORT_LOG_FLAG(args[10]);
		} else {
			SessionConstants.SET_TID("CF_FILE_FTMT_1"); // translator_config_t
			SessionConstants.SET_SHOP("CF");
			SessionConstants.SET_SOURCE("FILE");
			SessionConstants.SET_EQP_TYPE("FTMT");
			SessionConstants.SET_TARGET_FLAG("0,1,2,3,4,5,6,7,8,9");
			SessionConstants.SET_WORK_DIR("E:\\Test");
			SessionConstants.SET_MAX_COUNT("500");
			SessionConstants.SET_SYSTEM_CONFIG_DIR("E:\\Test\\system.properties");
			SessionConstants.SET_LOG_CONFIG_DIR("config/properties/log4j.properties");
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD("FALSE");
			SessionConstants.SET_EXPORT_LOG_FLAG("TRUE");
		}

		try {
			CFFTMTExcute FTMTExcute = new CFFTMTExcute();

			FTMTExcute.run();

		} catch (Exception e) {
			logger.error("FID: " + FID + "|| There hava a error! Error Message: " + e.getMessage());
		}
	}

	@Override
	public void readyToRun(File file) throws Exception {
		logger.info("FID: " + FID + "|| 【 Translator Begin 】");

		ReadDFSFile(file);

		logger.info("FID: " + FID + "|| 【 Translator End 】");
	}

	@SuppressWarnings("static-access")
	public void ReadDFSFile(File file) throws Exception {

		EDA_CONN = getEdaConnection();

		if (EDA_CONN.isClosed()) {
			logger.error("FID: " + FID + "|| The database connection was error");
		}

		EDA_CONN.setAutoCommit(false);

		try {
			String sPARAM_NAMES = ""; // for spc
			String sPARAM_VALUES = "";
			reader = new BufferedReader(new FileReader(file.getPath()));

			while ((discern = reader.readLine()) != null) {
				if (discern.length() == 0) {
					continue;
				}
				/***********************************************************************
				 * BEGIN ****************** 设备抛出csv文件，读取Header部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("HEADER_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  HEADER_BEGIN 读取开始  】");

					while ((discern = reader.readLine()) != null && getEdaSuccessFlag()) {
						if (DataFileFormatUtil.Shift(discern).startsWith("FILE_VERSION")) {
							afterDiscern = discern.split(":", -1);
							hFILE_VERSION = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("FILE_CREATED_TIME")) {
							afterDiscern = discern.split(":", -1);
							hFILE_CREATED_TIME = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQUIP_TYPE")) {
							afterDiscern = discern.split(":", -1);
							hEQUIP_TYPE = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("SUBEQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hSubEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("CONTENT")) {
							afterDiscern = discern.split(":", -1);
							hCONTENT = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).endsWith("HEADER_END")) {
							break;
						}
					}
					logger.info("FID: " + FID + "|| 【  HEADER_END 读取结束  】");

				}
				/*********************************************************************
				 * END ******************** 设备抛出csv文件，读取Header部分 ****** END *
				 ********************************************************************/

				/***********************************************************************
				 * BEGIN ***************设备抛出csv文件，读取SHEET_DATA部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("DOWNLOADED_SHEET_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  DOWNLOADED_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DOWNLOADED_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						dsOPE_NO = afterDiscern[0];
						dsROUTE_ID = afterDiscern[1];
						dsSHEET_ID = afterDiscern[2];
						dsPRODUCT_ID = afterDiscern[3];
						dsRECIPE_ID = afterDiscern[4];
						dsCASSETTE_ID = afterDiscern[5];
						dsSLOT_NO = afterDiscern[6];

						productEntity.setPRODUCT_ID(dsPRODUCT_ID);
						productEntity.setPRODUCT_GROUP("DEFAULT");

						setEdaSuccessFlag(productDao.addProductTable(productEntity, EDA_CONN, FID));

						ftmtGlassEntity.setROUTE_ID(dsROUTE_ID);
						ftmtGlassEntity.setSHEET_ID(dsSHEET_ID);
						ftmtGlassEntity.setPRODUCT_ID(dsPRODUCT_ID);
						ftmtGlassEntity.setRECIPE_ID(dsRECIPE_ID);
						ftmtGlassEntity.setCASSETTE_ID(dsCASSETTE_ID);
						ftmtGlassEntity.setSLOT_NO(dsSLOT_NO);

						ftmtGlassEntity.setSGR_ID(lot_id); // Debg
																	// Mode手动给值
						ftmtGlassEntity.setPARENT_SGR_ID(parent_lot_id); // Debg
																		// Mode手动给值
						ftmtGlassEntity.setLOT_ID(ftmtGlassEntity.getSGR_ID());

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID: " + FID + "|| 【  DOWNLOADED_SHEET_DATA_END 读取结束  】");

				}
				/***********************************************************************
				 * END *******设备抛出csv文件，读取DOWNLOADED_SHEET_DATA部分 ****** END **
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN **** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** BEGIN *******
				 ***********************************************************************/
				if (discern.startsWith("EQP_SHEET_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  EQP_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("EQP_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						esOPE_NO = afterDiscern[0];
						esSHEET_ID = afterDiscern[1];
						esCOMPONENT_TYPE = afterDiscern[2];
						esSTART_TIME = afterDiscern[3];
						esEND_TIME = afterDiscern[4];
						esTACK_TIME = afterDiscern[5];
						esSAMPLING_FLAG = afterDiscern[6];
						esABNORMAL_FLAG = afterDiscern[7];
						esUSER_ID = afterDiscern[8];
						esMAIN_JUDGE = afterDiscern[9];
						esSHEET_JUDGE = afterDiscern[10];
						esTTL_PANEL_CNT = afterDiscern[11];
						esSHOT_CNT = afterDiscern[12];

						if (esCOMPONENT_TYPE.equals("7")) {
							esCOMPONENT_TYPE = "1";
						} else if (esCOMPONENT_TYPE.equals("8")) {
							esCOMPONENT_TYPE = "2";
						}

						esOPE_NO = updateOpeNoUtil.updateNewOPENO(hEQ_ID, esOPE_NO); // CF
																						// update
																						// OPE_NO
																						// SECOND

						stepEntity.setSTEP_ID(esOPE_NO);
						stepEntity.setSTEP_SEQ(esOPE_NO);
						stepEntity.setSTEP_TYPE("M");
						stepEntity.setSTEP_GROUP(hEQUIP_TYPE);

						setEdaSuccessFlag(stepDao.addStepTable(stepEntity, EDA_CONN, FID));
						ftmtGlassEntity.setEQ_ID(hEQ_ID);
						ftmtGlassEntity.setSUBEQ_ID(hSubEQ_ID);
						ftmtGlassEntity.setOPE_NO(esOPE_NO);
						ftmtGlassEntity.setSHEET_ID(esSHEET_ID);
						ftmtGlassEntity.setCOMPONENT_TYPE(esCOMPONENT_TYPE);
						ftmtGlassEntity.setSTART_TIME(esSTART_TIME);
						ftmtGlassEntity.setEND_TIME(esEND_TIME);
						ftmtGlassEntity.setTACK_TIME(esTACK_TIME);
						ftmtGlassEntity.setSAMPLING_FLAG(esSAMPLING_FLAG);
						ftmtGlassEntity.setABNORMAL_FLAG(esABNORMAL_FLAG);
						ftmtGlassEntity.setUSER_ID(esUSER_ID);
						ftmtGlassEntity.setMAIN_JUDGE(esMAIN_JUDGE);
						ftmtGlassEntity.setSHEET_JUDGE(esSHEET_JUDGE);
						ftmtGlassEntity.setTTL_PANEL_CNT(esTTL_PANEL_CNT);
						ftmtGlassEntity.setSHOT_CNT(esSHOT_CNT);

						setEdaSuccessFlag(ftmtGlassDao.addCFFTMTGlass(ftmtGlassEntity, EDA_CONN, FID));

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID: " + FID + "|| 【  EQP_SHEET_DATA_END 读取结束  】");

				}
				/***********************************************************************
				 * END ********** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** BEGIN *
				 ***********************************************************************/

				if (discern.startsWith("SHEET_SUMMARY_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  SHEET_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SHEET_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						ssOPE_NO = afterDiscern[0];
						ssSHEET_ID = afterDiscern[1];
						ssEND_TIME = afterDiscern[2];
						ssPARAM_COLLECTION = afterDiscern[3];
						ssPARAM_GROUP = afterDiscern[4];
						ssPARAM_NAME = afterDiscern[5];
						ssAVG = afterDiscern[6];
						ssMAX = afterDiscern[7];
						ssMIN = afterDiscern[8];
						ssRANGE = afterDiscern[9];
						ssUNIFORMITY = afterDiscern[10];
						ssSTD = afterDiscern[11];
						ss3SIGMA = afterDiscern[12];
						ssSPEC_HIGH = afterDiscern[13];
						ssSPEC_LOW = afterDiscern[14];
						ssSPEC_TARGET = afterDiscern[15];
						ssCONTROL_HIGH = afterDiscern[16];
						ssCONTROL_LOW = afterDiscern[17];
						ssCOLOR_NAME = afterDiscern[18];
						ssTHICKNESS_NAME = afterDiscern[19];

						parameterEntity.setPARAM_COLLECTION(esOPE_NO + "_" + dsRECIPE_ID);
						parameterEntity.setPARAM_NAME(ssPARAM_NAME);
						parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						parameterEntity.setPARAM_GROUP(ssPARAM_GROUP);

						setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN, FID));

						ftmtGlassSumEntity.setOPE_NO(esOPE_NO);
						ftmtGlassSumEntity.setSHEET_ID(esSHEET_ID);
						ftmtGlassSumEntity.setEND_TIME(esEND_TIME);
						ftmtGlassSumEntity.setPARAM_COLLECTION(esOPE_NO + "_" + dsRECIPE_ID);
						ftmtGlassSumEntity.setPARAM_GROUP(ssPARAM_GROUP);
						ftmtGlassSumEntity.setPARAM_NAME(ssPARAM_NAME);
						ftmtGlassSumEntity.setAVG(ssAVG);
						ftmtGlassSumEntity.setMAX(ssMAX);
						ftmtGlassSumEntity.setMIN(ssMIN);
						ftmtGlassSumEntity.setRANGE(ssRANGE);
						ftmtGlassSumEntity.setUNIFORMITY(ssUNIFORMITY);
						ftmtGlassSumEntity.setSTD(ssSTD);
						ftmtGlassSumEntity.setTHREE_SIGMA(ss3SIGMA);
						ftmtGlassSumEntity.setSPEC_HIGH(ssSPEC_HIGH);
						ftmtGlassSumEntity.setSPEC_LOW(ssSPEC_LOW);
						ftmtGlassSumEntity.setSPEC_TARGET(ssSPEC_TARGET);
						ftmtGlassSumEntity.setCONTROL_HIGH(ssCONTROL_HIGH);
						ftmtGlassSumEntity.setCONTROL_LOW(ssCONTROL_LOW);
						ftmtGlassSumEntity.setCOLOR_NAME(ssCOLOR_NAME);
						ftmtGlassSumEntity.setTHICKNESS_NAME(ssTHICKNESS_NAME);

						setEdaSuccessFlag(ftmtGlassSumDao.addCFFTMTGlassSum(ftmtGlassSumEntity, EDA_CONN, FID));

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID: " + FID + "|| 【  SHEET_SUMMARY_DATA_END 读取结束  】");

				}

				/***********************************************************************
				 * END * 设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** END ****
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("SITE_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  SITE_DATA_BEGIN 读取开始  】");
					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SITE_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						sOPE_NO = afterDiscern[0];
						sSHEET_ID = afterDiscern[1];
						sCHIP_ID = afterDiscern[2];
						sCHIP_NO = afterDiscern[3];
						sEND_TIME = afterDiscern[4];
						sPARAM_COLLECTION = afterDiscern[5];
						sPARAM_GROUP = afterDiscern[6];
						sPARAM_NAME = afterDiscern[7];
						sSITE_NAME = afterDiscern[8];
						sPARAM_VALUE = afterDiscern[9];
						sJUDGE = afterDiscern[10];
						sX = afterDiscern[11];
						sY = afterDiscern[12];
						sSPEC_HIGH = afterDiscern[13];
						sSPEC_LOW = afterDiscern[14];
						sSPEC_TARGET = afterDiscern[15];
						sCONTROL_HIGH = afterDiscern[16];
						sCONTROL_LOW = afterDiscern[17];
						
						// for SPC
						if (sPARAM_NAME != null && sPARAM_NAME.length() > 0 && !sPARAM_NAME.trim().equals("")
								&& sPARAM_VALUE != null && sPARAM_VALUE.length() > 0 && !sPARAM_VALUE.trim().equals("")
								&& !sPARAM_VALUE.trim().equalsIgnoreCase("NA")) {
							sPARAM_NAMES += sPARAM_NAME + ",";
							sPARAM_VALUES += sPARAM_VALUE + ",";
						}

						ftmtResultEntity.setOPE_NO(esOPE_NO);
						ftmtResultEntity.setSHEET_ID(esSHEET_ID);
						ftmtResultEntity.setCHIP_ID(sCHIP_ID);
						ftmtResultEntity.setCHIP_NO(sCHIP_NO);
						ftmtResultEntity.setEND_TIME(esEND_TIME);
						ftmtResultEntity.setPARAM_COLLECTION(esOPE_NO + "_" + dsRECIPE_ID);
						ftmtResultEntity.setPARAM_GROUP(sPARAM_GROUP);
						ftmtResultEntity.setPARAM_NAME(sPARAM_NAME);
						ftmtResultEntity.setSITE_NAME(sSITE_NAME);
						ftmtResultEntity.setPARAM_VALUE(sPARAM_VALUE);
						ftmtResultEntity.setJUDGE(sJUDGE);
						ftmtResultEntity.setX(sX);
						ftmtResultEntity.setY(sY);
						ftmtResultEntity.setSPEC_HIGH(sSPEC_HIGH);
						ftmtResultEntity.setSPEC_LOW(sSPEC_LOW);
						ftmtResultEntity.setSPEC_TARGET(sSPEC_TARGET);
						ftmtResultEntity.setCONTROL_HIGH(sCONTROL_HIGH);
						ftmtResultEntity.setCONTROL_LOW(sCONTROL_LOW);

						setEdaSuccessFlag(ftmtResultDao.addCFFTMTResult(ftmtResultEntity, EDA_CONN, FID));

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID: " + FID + "|| 【  SITE_DATA_END 读取结束  】");

				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END *******
				 ***********************************************************************/

			}

			try {
				if (getEdaSuccessFlag()) {
					stmt = EDA_CONN.createStatement();
					stmt.executeQuery(loaderData);
					stmt.close();
				}
			} catch (Exception e) {
				reader.close();
				setEdaSuccessFlag(false);
				EDA_CONN.rollback();

				logger.error("FID: " + FID + "|| Call Loader Failed! Error Message:" + e.getMessage());

			}
			// SPC handle
			try {
				spcRunFlag = true;
				logger.info("FID : " + FID + "|| spc_enable = " + spc_enable);
				if (spc_enable.equalsIgnoreCase("true") && getEdaSuccessFlag()) {

					logger.info("FID : " + FID + "|| Start SPC running..");

					SPC_CONN = getSpcConnection();

					if (SPC_CONN.isClosed()) {
						logger.error("FID : " + FID + "|| The SPC database connection was error");
						setSpcSuccessFlag(false);
					}

					if (getSpcSuccessFlag()) {

						SpcLoaderEntity entity = new SpcLoaderEntity();

						entity.setEq_id(replaceBlankToNull(hEQ_ID));
						entity.setProduct_id(replaceBlankToNull(dsPRODUCT_ID));
						entity.setRecipe_id(replaceBlankToNull(dsRECIPE_ID));
						entity.setEquip_type(replaceBlankToNull(hEQUIP_TYPE));
						entity.setSubeq_id(replaceBlankToNull(hSubEQ_ID));
						entity.setOpe_no(replaceBlankToNull(dsOPE_NO));
						entity.setRoute_id(replaceBlankToNull(dsROUTE_ID));
						entity.setCassette_id(replaceBlankToNull(dsCASSETTE_ID));
						entity.setStart_time(replaceBlankToNull(esEND_TIME)); // special
																				// handle
						entity.setSheet_id(replaceBlankToNull(dsSHEET_ID));

						if (sPARAM_NAMES != null && sPARAM_VALUES != null && !sPARAM_NAMES.trim().equals("")
								&& !sPARAM_VALUES.trim().equals("")) {
							logger.info("FID : " + FID + "|| call SPC loader.");
							setSpcSuccessFlag(
									LOAD_CF_FTMT_SHEET.prepareSpcData(entity, sPARAM_NAMES, sPARAM_VALUES, SPC_CONN));
						}
					}
				}
			} catch (Exception ex) {

				setSpcSuccessFlag(false);
				logger.error("FID : " + FID + "|| Process SPC parsing error : " + ex.getMessage());
			}

		} catch (Exception ex) {

			reader.close();

			logger.error("FID: " + FID + "|| Ready to run error : " + ex.getMessage());

			if (getEdaSuccessFlag()) {
				reader.close();
				setEdaSuccessFlag(false);
			}

		} finally {

			if (reader != null) {
				reader.close();
			}

		}
	}

	@Override
	public String getLoaderName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkFileFormat(File file) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}
}
