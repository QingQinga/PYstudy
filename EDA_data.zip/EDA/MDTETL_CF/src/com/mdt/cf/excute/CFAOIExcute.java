package com.mdt.cf.excute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.cf.cf_optical_insp.dao.CFOpticalChipDao;
import com.mdt.cf.cf_optical_insp.dao.CFOpticalChipSumDao;
import com.mdt.cf.cf_optical_insp.dao.CFOpticalDefectDao;
import com.mdt.cf.cf_optical_insp.dao.CFOpticalGlassDao;
import com.mdt.cf.cf_optical_insp.dao.CFOpticalGlassSumDao;
import com.mdt.cf.cf_optical_insp.dao.CFOpticalResultDao;
import com.mdt.cf.cf_optical_insp.entity.CFOpticalChipEntity;
import com.mdt.cf.cf_optical_insp.entity.CFOpticalChipSumEntity;
import com.mdt.cf.cf_optical_insp.entity.CFOpticalDefectEntity;
import com.mdt.cf.cf_optical_insp.entity.CFOpticalGlassEntity;
import com.mdt.cf.cf_optical_insp.entity.CFOpticalGlassSumEntity;
import com.mdt.cf.cf_optical_insp.entity.CFOpticalResultEntity;
import com.mdt.cf.dao.ParameterDao;
import com.mdt.cf.dao.ProductDao;
import com.mdt.cf.dao.StepDao;
import com.mdt.cf.entity.ParameterEntity;
import com.mdt.cf.entity.ProductEntity;
import com.mdt.cf.entity.StepEntity;
//import com.mdt.cf.spc.dao.LOAD_CF_AOI_SHEET;
//import com.mdt.cf.spc.entity.SpcLoaderEntity;
import com.mdt.cf.tableview.SessionConstants;
import com.mdt.cf.util.DataFileFormatUtil;
import com.mdt.cf.util.DateFormatUtil;
import com.mdt.cf.util.EdaSpcAbstractLoader;
import com.mdt.cf.util.UpdateOpeNoUtil;

/**
 ***************************************************
 * @Title CFAOIExcute
 * @author 林华锋
 * @Date 2017年4月22日上午8:55:42
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFAOIExcute extends EdaSpcAbstractLoader {

	private static Logger logger = Logger.getLogger(CFAOIExcute.class);
	
	public CFAOIExcute() throws Exception {
		super(SessionConstants.GET_SYSTEM_CONFIG_DIR(), SessionConstants.GET_LOG_CONFIG_DIR());
	}
	
	public Connection EDA_CONN = null;
	//public Connection SPC_CONN = null;
	public String discern; // 识别前字符
	public String[] afterDiscern; // 识别后字符
	public BufferedReader reader;
	public String loaderData = "begin cf_file_loader.load_data; end;";
	public Statement stmt = null;
	
    /** 实例化实体类对象 Begin **/

	public ParameterEntity parameterEntity = new ParameterEntity();
	public ProductEntity productEntity = new ProductEntity();
	public StepEntity stepEntity = new StepEntity();
	public CFOpticalGlassEntity opticalGlassEntity = new CFOpticalGlassEntity();
	public CFOpticalGlassSumEntity opticalGlassSumEntity = new CFOpticalGlassSumEntity();
	public CFOpticalChipEntity opticalChipEntity = new CFOpticalChipEntity();
	public CFOpticalChipSumEntity opticalChipSumEntity = new CFOpticalChipSumEntity();
	public CFOpticalDefectEntity opticalDefectEntity = new CFOpticalDefectEntity();
	public CFOpticalResultEntity opticalResultEntity = new CFOpticalResultEntity();
	public UpdateOpeNoUtil updateOpeNoUtil = new UpdateOpeNoUtil();
	
	/** 实例化实体类对象 End **/

	/** DAO */

	public ProductDao productDao;
	public ParameterDao parameterDao;
	public StepDao stepDao;
	public CFOpticalGlassDao opticalGlassDao;
	public CFOpticalGlassSumDao opticalGlassSumDao;
	public CFOpticalChipDao opticalChipDao;
	public CFOpticalChipSumDao opticalChipSumDao;
	public CFOpticalResultDao opticalResultDao;
	public CFOpticalDefectDao opticalDefectDao;
	
	/** DAO */

	/****** Header_Begin 字段行 */

	public String hFILE_VERSION = null; // 文件版本
	public String hFILE_CREATED_TIME = null; // 创建时间
	public String hEQUIP_TYPE = null; // 设备类型
	public String hEQ_ID = null; // 设备ID
	public String hSubEQ_ID = null; // 子设备ID
	public String hCONTENT = null; // DataBlock内容标题

	/***** Header_End 字段行 */

	/** DOWNLOADED_SHEET_DATA_BEGIN 字段行 */

	public String dsOPE_NO = null;
	public String dsSHEET_ID = null;
	public String dsPRODUCT_ID = null;
	public String dsRECIPE_ID = null;
	public String dsCASSETTE_ID = null;
	public String dsSLOT_NO = null;
	public String dsROUTE_ID = null;

	/** DOWNLOADED_SHEET_DATA_END 字段行 */

	/** EQP_SHEET_DATA_BEGIN 字段行 */

	public String esOPE_NO = null;
	public String esSHEET_ID = null;
	public String esSTART_TIME = null;
	public String esEND_TIME = null;			// 这个END_TIME带给所有DATA_BLOCK
	public String esSAMPLING_FLAG = null;
	public String esUSER_ID = null;
	public String esABNORMAL_FLAG = null;
	public String esMAIN_JUDGE = null;
	public String esSHEET_JUDGE = null;
	public String esTTL_PANEL_CNT = null;
	public String esTACK_TIME = null;
	public String esCOMPONENT_TYPE = null;
	public String esOK_PANEL_COUNT = null;
	public String esNG_PANEL_COUNT = null;
	public String esYIELD = null;

	public String esREVIEW_HISTORY = null;
	public String esTAPE_HISTORY = null;
	public String esTP_FLAG = null;
	public String esTT_FLAG = null;
	public String esTL_FLAG = null;
	public String esTM_FLAG = null;
	public String esTR_FLAG = null;
	public String esTB_FLAG = null;
	public String esFRONT_IMAGE_DATA = null;
	public String esBACK_IMAGE_DATA = null;
	public String esSYSTEM_STATUS = null;
	public String esDEFECT_OVERVIEW_IMAGE = null;
	public String esSHOT_CNT = null;
	public String esTTL_DEFECT_CNT = null;
	public String esLIGHT_SET = null;
	public String esLIGHT_SET_W = null;
	public String esLIGHT_SET_R = null;
	public String esLIGHT_SET_G = null;
	public String esLIGHT_SET_B = null;
	public String esLIGHT_SET_T = null;
	public String esLIGHT_SET_C = null;
	public String esBACK_TTL_DEFECT_CNT = null;
	public String esOVERFLOW = null;

	/** EQP_SHEET_DATA_END 字段行 */

	/** SHEET_SUMMARY_DATA_BEGIN 字段行 */

	public String ssOPE_NO = null;
	public String ssSHEET_ID = null;
	public String ssEND_TIME = null;
	public String ssPARAM_COLLECTION = null;
	public String ssPARAM_GROUP = null;
	public String ssPARAM_NAME = null;
	public String ssAVG = null;
	public String ssMAX = null;
	public String ssMIN = null;
	public String ssSTD = null;
	public String ssUNIFORMITY = null;
	public String ssRANGE = null;
	public String ss3SIGMA = null;
	public String ssSPEC_HIGH = null;
	public String ssSPEC_LOW = null;
	public String ssSPEC_TARGET = null;
	public String ssCONTROL_HIGH = null;
	public String ssCONTROL_LOW = null;

	public String ssUP_DOWN_FLAG = null;

	/** SHEET_SUMMARY_DATA_END 字段行 */

	/** CHIP_DATA_BEGIN 字段行 */

	public String cOPE_NO = null;
	public String cSHEET_ID = null;
	public String cEND_TIME = null;
	public String cCHIP_ID = null;
	public String cCHIP_NO = null;
	public String cUSER_ID = null; // spec需多加userID
	public String cCHIP_JUDGE = null;
	public String cMAIN_DEFECT_CODE = null;
	public String cPANEL_RANK = null; // user需求删除
	public String cPANEL_TTL_DEFECT_CNT = null;

	/** CHIP_DATA_END 字段行 */

	/** CHIP_SUMMARY_DATA_BEGIN 字段行 */

	public String csOPE_NO = null;
	public String csSHEET_ID = null;
	public String csEND_TIME = null;
	public String csCHIP_ID = null;
	public String csCHIP_NO = null;
	public String csPARAM_COLLECTION = null;
	public String csPARAM_GROUP = null;
	public String csPARAM_NAME = null;
	public String csAVG = null;
	public String csMAX = null;
	public String csMIN = null;
	public String csSTD = null;
	public String csUNIFORMITY = null;
	public String csRANGE = null;
	public String csSPEC_HIGH = null;
	public String csSPEC_LOW = null;
	public String csSPEC_TARGET = null;
	public String csCONTROL_HIGH = null;
	public String csCONTROL_LOW = null;
	public String cs3SIGMA = null;

	/** CHIP_SUMMARY_DATA_END 字段行 */

	/** SITE_DATA_BEGIN 字段行 */

	public String sOPE_NO = null;
	public String sSHEET_ID = null;
	public String sEND_TIME = null;
	public String sPARAM_COLLECTION = null;
	public String sPARAM_GROUP = null;
	public String sPARAM_NAME = null;
	public String sSITE_NAME = null;
	public String sPARAM_VALUE = null;
	public String sSPEC_HIGH = null;
	public String sSPEC_LOW = null;
	public String sSPEC_TARGET = null;
	public String sCONTROL_HIGH = null;
	public String sCONTROL_LOW = null;
	public String sX = null;
	public String sY = null;
	public String sCHIP_ID = null;
	public String sCHIP_NO = null;
	public String sJUDGE = null;

	public String sLAYER = null;
	public String sUP_DOWN_FLAG = null;

	/** SITE_DATA_END 字段行 */

	/** DEFECT_DATA_BEGIN 字段行 */

	public String dOPE_NO = null;
	public String dSHEET_ID = null;
	public String dEND_TIME = null;
	public String dCHIP_ID = null;
	public String dCHIP_NO = null;
	public String dDEFECT_JUDGE = null;
	public String dDEFECT_CODE = null;
	public String dDEFECT_CODE_DESC = null;
	public String dDEFECT_PATTERN = null;
	public String dDEFECT_LAYER_TYPE = null;
	public String dIMAGE_DATA = null;
	public String dMAIN_DEFECT_FLAG = null;
	public String dREJUDGE_FLAG = null;
	public String dDEFECT_SEQ_NO = null;
	public String dDEFECT_GROUP = null;
	public String dDEFECT_SIZE = null;
	public String dDEFECT_RANK = null;
	public String dCAPTURE_NO = null;
	public String dS = null;
	public String dG = null;
	public String dX = null;
	public String dY = null;
	public String dX2 = null;
	public String dY2 = null;
	public String dX3 = null;
	public String dY3 = null;
	public String dARRAY_X = null;
	public String dARRAY_Y = null;
	public String dARRAY_X2 = null;
	public String dARRAY_Y2 = null;
	public String dARRAY_X3 = null;
	public String dARRAY_Y3 = null;

	public String dAUTO_REPAIR_NOTE = null;
	public String dAUTO_LASER_NOTE = null;
	public String dINK_COLOR = null;
	public String dMANUAL_DEFC_CODE_JUDGE_FLAG = null;
	public String dSEAL_HEAD = null;
	public String dDEFECT_STATUS = null;
	public String dAUTO_DEFECT_CODE = null;
	public String dMANUAL_DEFECT_CODE = null;
	public String dJUDGE_HISTROY = null;
	public String dREJUDGE_DEF = null;
	public String dUP_DOWN_FLAG = null;
	public String dCCD_NO = null;
	public String dSIZE_X = null;
	public String dSIZE_Y = null;
	public String dAREA_UM = null;
	public String dAREA_PIXEL = null;
	public String dNOTE_PRE_PROD_INSP = null;
	public String dORIGINAL_HEIGHT = null;
	public String dMODIFICATION_HEIGHT = null;
	public String dPOLISH_TIMES = null;
	public String dLASER_AREA = null;
	public String dLASER_X_LENGTH = null;
	public String dLASER_Y_LENGTH = null;
	public String dLASER_TIMES = null;
	public String dMEASURE_DIAMETER = null;
	public String dINK_NEEDLE_DIAMETER = null;
	public String dINK_AREA = null;
	public String dINK_X_LENGTH = null;
	public String dINK_Y_LENGTH = null;
	public String dINK_TIMES = null;
	public String dLASER_WAVELENGTH = null;
	public String dLASER_SHOT_TIMES = null;
	public String dLASER_ENERGY = null;
	public String dGRAY_LEVEL_DELTA = null;

	/** DEFECT_DATA_END 字段行 */

	/**
	 * ExcuteCenter
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		
		// args:{TID:0,Shop:1,Source:2,eqp_type:3,target_flag:4,WorkDir:5,max_count:6,SystemLocalConfigPath:7,LogConfigPath:8,db_find_method:9,export_log_file:10}
		if (args != null && args.length > 0) {
			SessionConstants.SET_TID(args[0]);
			SessionConstants.SET_SHOP(args[1]);
			SessionConstants.SET_SOURCE(args[2]);
			SessionConstants.SET_EQP_TYPE(args[3]);
			SessionConstants.SET_TARGET_FLAG(args[4]);
			SessionConstants.SET_WORK_DIR(args[5]);
			SessionConstants.SET_MAX_COUNT(args[6]);
			SessionConstants.SET_SYSTEM_CONFIG_DIR(args[7]);
			SessionConstants.SET_LOG_CONFIG_DIR(args[8]);
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(args[9]);
			SessionConstants.SET_EXPORT_LOG_FLAG(args[10]);
		} else {
			SessionConstants.SET_TID("CF_FILE_AOI_1"); // translator_config_t
			SessionConstants.SET_SHOP("CF");
			SessionConstants.SET_SOURCE("FILE");
			SessionConstants.SET_EQP_TYPE("AOI");
			SessionConstants.SET_TARGET_FLAG("0,1,2,3,4,5,6,7,8,9");
			SessionConstants.SET_WORK_DIR("E:\\TEST");
			SessionConstants.SET_MAX_COUNT("500");
			SessionConstants.SET_SYSTEM_CONFIG_DIR("E:\\Test\\system.properties");
			SessionConstants.SET_LOG_CONFIG_DIR("config/properties/log4j.properties");
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD("FALSE");
			SessionConstants.SET_EXPORT_LOG_FLAG("TRUE");
		}

		try {

			CFAOIExcute AOIExcute = new CFAOIExcute();

			AOIExcute.run();

		} catch (Exception e) {
			logger.error("FID: " + FID + "|| There hava a error! Error Message: " + e.getMessage());
		}
	}

	@Override
	public void readyToRun(File file) throws Exception {
		logger.info("FID: " + FID + "|| 【 Translator Begin 】");
		
		ReadDFSFile(file);
			
		logger.info("FID: " + FID + "|| 【 Translator End 】");
	}

	@SuppressWarnings("static-access")
	public void ReadDFSFile(File file) throws Exception {
          
		EDA_CONN = getEdaConnection();
		
		if (EDA_CONN.isClosed()) {
			logger.error("FID: " + FID + "|| The database connection was error");
		}
		
		EDA_CONN.setAutoCommit(false);

		try {
			
//			String sPARAM_NAMES = ""; 
//			String sPARAM_VALUES = "";
			
			reader = new BufferedReader(new FileReader(file.getPath()));

			while ((discern = reader.readLine()) != null) {
				if (discern.length() == 0) {
					continue;
				}
				/***********************************************************************
				 * BEGIN ****************** 设备抛出csv文件，读取Header部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("HEADER_BEGIN")) {

					logger.info("FID: " + FID + "|| 【 HEADER_BEGIN 读取开始 】");

					while ((discern = reader.readLine()) != null && getEdaSuccessFlag()) {
						if (DataFileFormatUtil.Shift(discern).startsWith("FILE_VERSION")) {
							afterDiscern = discern.split(":", -1);
							hFILE_VERSION = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("FILE_CREATED_TIME")) {
							afterDiscern = discern.split(":", -1);
							hFILE_CREATED_TIME = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQUIP_TYPE")) {
							afterDiscern = discern.split(":", -1);
							hEQUIP_TYPE = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("SUBEQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hSubEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("CONTENT")) {
							afterDiscern = discern.split(":", -1);
							hCONTENT = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).endsWith("HEADER_END")) {
							break;
						}
					}

					logger.info("FID: " + FID + "|| 【 HEADER_END 读取结束 】");

				}
				/*********************************************************************
				 * END ******************** 设备抛出csv文件，读取Header部分 ****** END *
				 ********************************************************************/

				/***********************************************************************
				 * BEGIN ***************设备抛出csv文件，读取SHEET_DATA部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("DOWNLOADED_SHEET_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【 DOWNLOADED_SHEET_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称
					
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DOWNLOADED_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						//dsOPE_NO = afterDiscern[0];
						dsROUTE_ID = afterDiscern[1];
						dsSHEET_ID = afterDiscern[2];
						dsPRODUCT_ID = afterDiscern[3];
						dsRECIPE_ID = afterDiscern[4];
						dsCASSETTE_ID = afterDiscern[5];
						dsSLOT_NO = afterDiscern[6];
                        
						productEntity.setPRODUCT_ID(dsPRODUCT_ID);
						productEntity.setPRODUCT_GROUP("DEFAULT");

						setEdaSuccessFlag(productDao.addProductTable(productEntity, EDA_CONN, FID));
						
						opticalGlassEntity.setROUTE_ID(dsROUTE_ID);
						opticalGlassEntity.setSHEET_ID(dsSHEET_ID);
						opticalGlassEntity.setPRODUCT_ID(dsPRODUCT_ID);
						opticalGlassEntity.setRECIPE_ID(dsRECIPE_ID);
						opticalGlassEntity.setCASSETTE_ID(dsCASSETTE_ID);
						opticalGlassEntity.setSLOT_NO(dsSLOT_NO);
                        opticalGlassEntity.setSGR_ID(lot_id); // Debg Mode手动给值
                        opticalGlassEntity.setPARENT_SGR_ID(parent_lot_id); // Debg Mode手动给值
                        opticalGlassEntity.setLOT_ID(opticalGlassEntity.getSGR_ID());
						
                        if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID: " + FID + "|| 【 DOWNLOADED_SHEET_DATA_END 读取结束 】");
					
				}
				/***********************************************************************
				 * END *******设备抛出csv文件，读取DOWNLOADED_SHEET_DATA部分 ****** END **
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN **** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** BEGIN *******
				 ***********************************************************************/
				if (discern.startsWith("EQP_SHEET_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【 EQP_SHEET_DATA_BEGIN 读取开始 】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("EQP_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						esOPE_NO = afterDiscern[0];
						esSHEET_ID = afterDiscern[1];
						esSTART_TIME = afterDiscern[2];
						esEND_TIME = afterDiscern[3];
						esTACK_TIME = afterDiscern[4];
						esSAMPLING_FLAG = afterDiscern[5];
						esABNORMAL_FLAG = afterDiscern[6];
						esUSER_ID = afterDiscern[7];
						esMAIN_JUDGE = afterDiscern[8];
						esSHEET_JUDGE = afterDiscern[9];
						esTTL_PANEL_CNT = afterDiscern[10];
						esSHOT_CNT = afterDiscern[11];
						esREVIEW_HISTORY = afterDiscern[12];
						esTAPE_HISTORY = afterDiscern[13];
						esTP_FLAG = afterDiscern[14];
						esTT_FLAG = afterDiscern[15];
						esTL_FLAG = afterDiscern[16];
						esTM_FLAG = afterDiscern[17];
						esTR_FLAG = afterDiscern[18];
						esTB_FLAG = afterDiscern[19];
						esTTL_DEFECT_CNT = afterDiscern[20];
						esLIGHT_SET = afterDiscern[21];
						esLIGHT_SET_W = afterDiscern[22];
						esLIGHT_SET_R = afterDiscern[23];
						esLIGHT_SET_G = afterDiscern[24];
						esLIGHT_SET_B = afterDiscern[25];
						esLIGHT_SET_T = afterDiscern[26];
						esLIGHT_SET_C = afterDiscern[27];
						esFRONT_IMAGE_DATA = afterDiscern[28];
						esBACK_IMAGE_DATA = afterDiscern[29];
						esSYSTEM_STATUS = afterDiscern[30];
						esDEFECT_OVERVIEW_IMAGE = afterDiscern[31];
						esBACK_TTL_DEFECT_CNT = afterDiscern[32];
						esOVERFLOW = afterDiscern[33];
						esCOMPONENT_TYPE = afterDiscern[34];
						esOK_PANEL_COUNT = afterDiscern[35];
						esNG_PANEL_COUNT = afterDiscern[36];
						esYIELD = afterDiscern[37];

						if(esCOMPONENT_TYPE.equals("7")){
							esCOMPONENT_TYPE = "1";
						}else if(esCOMPONENT_TYPE.equals("8")){
							esCOMPONENT_TYPE = "2";
						}
						
						esOPE_NO = updateOpeNoUtil.updateNewOPENO(hEQ_ID, esOPE_NO);  // CF update OPE_NO SECOND
						
						stepEntity.setSTEP_ID(esOPE_NO);
						stepEntity.setSTEP_SEQ(esOPE_NO);
						stepEntity.setSTEP_TYPE("M");
						stepEntity.setSTEP_GROUP(hEQUIP_TYPE);

						setEdaSuccessFlag(stepDao.addStepTable(stepEntity, EDA_CONN, FID));
						
						opticalGlassEntity.setOPE_NO(esOPE_NO);   //需要从db2判断     change by john
						opticalGlassEntity.setEQ_ID(hEQ_ID);
						opticalGlassEntity.setSUBEQ_ID(hSubEQ_ID);
						opticalGlassEntity.setSTART_TIME(esSTART_TIME);
						opticalGlassEntity.setEND_TIME(esEND_TIME);
						opticalGlassEntity.setTACK_TIME(esTACK_TIME);
						opticalGlassEntity.setSAMPLING_FLAG(esSAMPLING_FLAG);
						opticalGlassEntity.setABNORMAL_FLAG(esABNORMAL_FLAG);
						opticalGlassEntity.setUSER_ID(esUSER_ID);
						opticalGlassEntity.setMAIN_JUDGE(esMAIN_JUDGE);
						opticalGlassEntity.setSHEET_JUDGE(esSHEET_JUDGE);
						opticalGlassEntity.setTTL_PANEL_CNT(esTTL_PANEL_CNT);
						opticalGlassEntity.setTACK_TIME(esTACK_TIME);
						opticalGlassEntity.setCOMPONENT_TYPE(esCOMPONENT_TYPE);
						opticalGlassEntity.setOK_PANEL_COUNT(esOK_PANEL_COUNT);
						opticalGlassEntity.setNG_PANEL_COUNT(esNG_PANEL_COUNT);
						opticalGlassEntity.setYIELD(esYIELD);
						opticalGlassEntity.setREVIEW_HISTORY(esREVIEW_HISTORY);
						opticalGlassEntity.setTAPE_HISTORY(esTAPE_HISTORY);
						opticalGlassEntity.setTP_FLAG(esTP_FLAG);
						opticalGlassEntity.setTT_FLAG(esTT_FLAG);
						opticalGlassEntity.setTL_FLAG(esTL_FLAG);
						opticalGlassEntity.setTM_FLAG(esTM_FLAG);
						opticalGlassEntity.setTR_FLAG(esTR_FLAG);
						opticalGlassEntity.setTB_FLAG(esTB_FLAG);
						opticalGlassEntity.setFRONT_IMAGE_DATA(esFRONT_IMAGE_DATA);
						opticalGlassEntity.setBACK_IMAGE_DATA(esBACK_IMAGE_DATA);
						opticalGlassEntity.setSYSTEM_STATUS(esSYSTEM_STATUS);
						opticalGlassEntity.setDEFECT_OVERVIEW_IMAGE(esDEFECT_OVERVIEW_IMAGE);
						opticalGlassEntity.setSHOT_CNT(esSHOT_CNT);
						opticalGlassEntity.setTTL_DEFECT_CNT(esTTL_DEFECT_CNT);
						opticalGlassEntity.setLIGHT_SET(esLIGHT_SET);
						opticalGlassEntity.setLIGHT_SET_W(esLIGHT_SET_W);
						opticalGlassEntity.setLIGHT_SET_R(esLIGHT_SET_R);
						opticalGlassEntity.setLIGHT_SET_G(esLIGHT_SET_G);
						opticalGlassEntity.setLIGHT_SET_B(esLIGHT_SET_B);
						opticalGlassEntity.setLIGHT_SET_T(esLIGHT_SET_T);
						opticalGlassEntity.setLIGHT_SET_C(esLIGHT_SET_C);
						opticalGlassEntity.setBACK_TTL_DEFECT_CNT(esBACK_TTL_DEFECT_CNT);
						opticalGlassEntity.setOVERFLOW(esOVERFLOW);
						
						setEdaSuccessFlag(opticalGlassDao.addCFOpticalGlass(opticalGlassEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID: " + FID + "|| 【  EQP_SHEET_DATA_END 读取结束  】");
					
				}
				/***********************************************************************
				 * END ********** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** BEGIN *
				 ***********************************************************************/

				if (discern.startsWith("SHEET_SUMMARY_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  SHEET_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SHEET_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						ssOPE_NO = afterDiscern[0];
						ssSHEET_ID = afterDiscern[1];
						ssEND_TIME = afterDiscern[2];
						ssPARAM_COLLECTION = afterDiscern[3];
						ssPARAM_GROUP = afterDiscern[4];
						ssPARAM_NAME = afterDiscern[5];
						ssAVG = afterDiscern[6];
						ssMAX = afterDiscern[7];
						ssMIN = afterDiscern[8];
						ssRANGE = afterDiscern[9];
						ssUNIFORMITY = afterDiscern[10];
						ssSTD = afterDiscern[11];
						ss3SIGMA = afterDiscern[12];
						ssSPEC_HIGH = afterDiscern[13];
						ssSPEC_LOW = afterDiscern[14];
						ssSPEC_TARGET = afterDiscern[15];
						ssCONTROL_HIGH = afterDiscern[16];
						ssCONTROL_LOW = afterDiscern[17];
                        ssUP_DOWN_FLAG = afterDiscern[18];
//                      //for spc
//						if (ssPARAM_NAME != null && ssPARAM_NAME.length() > 0 && !ssPARAM_NAME.trim().equals("")
//								&& ssAVG != null && ssAVG.length() > 0 && !ssAVG.trim().equals("") 
//								&& !ssAVG.trim().equalsIgnoreCase("NA"))
//							{
//								sPARAM_NAMES += ssPARAM_NAME + ","; 
//								sPARAM_VALUES += ssAVG + ",";
//							}
                        
                        parameterEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						parameterEntity.setPARAM_NAME(ssPARAM_NAME);
						parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						parameterEntity.setPARAM_GROUP(ssPARAM_GROUP);

						setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN, FID));
                        
                        opticalGlassSumEntity.setOPE_NO(esOPE_NO);
                        opticalGlassSumEntity.setSHEET_ID(esSHEET_ID);
                        opticalGlassSumEntity.setEND_TIME(esEND_TIME);
                        opticalGlassSumEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
                        opticalGlassSumEntity.setPARAM_GROUP(ssPARAM_GROUP);
                        opticalGlassSumEntity.setPARAM_NAME(ssPARAM_NAME);
                        opticalGlassSumEntity.setAVG(ssAVG);
                        opticalGlassSumEntity.setMAX(ssMAX);
                        opticalGlassSumEntity.setMIN(ssMIN);
                        opticalGlassSumEntity.setRANGE(ssRANGE);
                        opticalGlassSumEntity.setUNIFORMITY(ssUNIFORMITY);
                        opticalGlassSumEntity.setSTD(ssSTD);
                        opticalGlassSumEntity.setTHREE_SIGMA(ss3SIGMA);
                        opticalGlassSumEntity.setSPEC_HIGH(ssSPEC_HIGH);
                        opticalGlassSumEntity.setSPEC_LOW(ssSPEC_LOW);
                        opticalGlassSumEntity.setSPEC_TARGET(ssSPEC_TARGET);
                        opticalGlassSumEntity.setCONTROL_HIGH(ssCONTROL_HIGH);
                        opticalGlassSumEntity.setCONTROL_LOW(ssCONTROL_LOW);
                        opticalGlassSumEntity.setUP_DOWN_FLAG(ssUP_DOWN_FLAG);
                        
                        setEdaSuccessFlag(opticalGlassSumDao.addCFOpticalGlassSum(opticalGlassSumEntity, EDA_CONN, FID));
                        
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID: " + FID + "|| 【  SHEET_SUMMARY_DATA_END 读取结束  】");
					
				}

				/***********************************************************************
				 * END * 设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** END ****
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取CHIP_DATA_BEGIN部分 ******** BEGIN *****
				 ***********************************************************************/
				if (discern.startsWith("CHIP_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  CHIP_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("CHIP_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						cOPE_NO = afterDiscern[0];
						cSHEET_ID = afterDiscern[1];
						cCHIP_ID = afterDiscern[2];
						cCHIP_NO = afterDiscern[3];
						cEND_TIME = afterDiscern[4];
						cCHIP_JUDGE = afterDiscern[5];
						cMAIN_DEFECT_CODE = afterDiscern[6];
						cPANEL_TTL_DEFECT_CNT = afterDiscern[7];
						cPANEL_RANK = afterDiscern[8]; 

						opticalChipEntity.setOPE_NO(esOPE_NO);
						opticalChipEntity.setSHEET_ID(esSHEET_ID);
						opticalChipEntity.setCHIP_ID(cCHIP_ID);
						opticalChipEntity.setCHIP_NO(cCHIP_NO);
						opticalChipEntity.setEND_TIME(esEND_TIME);
						opticalChipEntity.setCHIP_JUDGE(cCHIP_JUDGE);
						opticalChipEntity.setMAIN_DEFECT_CODE(cMAIN_DEFECT_CODE);
						opticalChipEntity.setPANEL_TTL_DEFECT_CNT(cPANEL_TTL_DEFECT_CNT);
						opticalChipEntity.setPANEL_RANK(cPANEL_RANK);
						
						setEdaSuccessFlag(opticalChipDao.addCFOpticalChip(opticalChipEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID: " + FID + "|| 【  CHIP_DATA_END 读取结束  】");
					
				}
				/***********************************************************************
				 * END *** 设备抛出csv文件，读取CHIP_DATA_BEGIN部分 ******** END ********
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取CHIP_SUMMARY_DATA_BEGIN部分 ** BEGIN ***
				 ***********************************************************************/

				if (discern.startsWith("CHIP_SUMMARY_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  CHIP_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("CHIP_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);
						csOPE_NO = afterDiscern[0];
						csSHEET_ID = afterDiscern[1];
						csCHIP_ID = afterDiscern[2];
						csCHIP_NO = afterDiscern[3];
						csEND_TIME = afterDiscern[4];
						csPARAM_COLLECTION = afterDiscern[5];
						csPARAM_GROUP = afterDiscern[6];
						csPARAM_NAME = afterDiscern[7];
						csAVG = afterDiscern[8];
						csMAX = afterDiscern[9];
						csMIN = afterDiscern[10];
						csRANGE = afterDiscern[11];
						csUNIFORMITY = afterDiscern[12];
						csSTD = afterDiscern[13];
						cs3SIGMA = afterDiscern[14];
						csSPEC_HIGH = afterDiscern[15];
						csSPEC_LOW = afterDiscern[16];
						csSPEC_TARGET = afterDiscern[17];
						csCONTROL_HIGH = afterDiscern[18];
						csCONTROL_LOW = afterDiscern[19];
						
						opticalChipSumEntity.setOPE_NO(esOPE_NO);
						opticalChipSumEntity.setSHEET_ID(esSHEET_ID);
						opticalChipSumEntity.setCHIP_ID(csCHIP_ID);
						opticalChipSumEntity.setCHIP_NO(csCHIP_NO);
						opticalChipSumEntity.setEND_TIME(esEND_TIME);
						opticalChipSumEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						opticalChipSumEntity.setPARAM_NAME(csPARAM_NAME);
						opticalChipSumEntity.setAVG(csAVG);
						opticalChipSumEntity.setMAX(csMAX);
						opticalChipSumEntity.setMIN(csMIN);
						opticalChipSumEntity.setRANGE(csRANGE);
						opticalChipSumEntity.setUNIFORMITY(csUNIFORMITY);
						opticalChipSumEntity.setSTD(csSTD);
						opticalChipSumEntity.setTHREE_SIGMA(cs3SIGMA);
						opticalChipSumEntity.setSPEC_HIGH(csSPEC_HIGH);
						opticalChipSumEntity.setSPEC_LOW(csSPEC_LOW);
						opticalChipSumEntity.setSPEC_TARGET(csSPEC_TARGET);
						opticalChipSumEntity.setCONTROL_HIGH(csCONTROL_HIGH);
						opticalChipSumEntity.setCONTROL_LOW(csCONTROL_LOW);
						
						setEdaSuccessFlag(opticalChipSumDao.addCFOpticalChipSum(opticalChipSumEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID: " + FID + "|| 【  CHIP_SUMMARY_DATA_END 读取结束  】");
					
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取CHIP_SUMMARY_DATA_BEGIN部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("SITE_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  SITE_DATA_BEGIN 读取开始  】");
					
					discern = reader.readLine(); // 读取字段行名称
					
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SITE_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						sOPE_NO = afterDiscern[0];
						sSHEET_ID = afterDiscern[1];
						sCHIP_ID = afterDiscern[2];
						sCHIP_NO = afterDiscern[3];
						sEND_TIME = afterDiscern[4];
						sPARAM_COLLECTION = afterDiscern[5];
						sPARAM_GROUP = afterDiscern[6];
						sPARAM_NAME = afterDiscern[7];
						sSITE_NAME = afterDiscern[8];
						sPARAM_VALUE = afterDiscern[9];
						sJUDGE = afterDiscern[10];
						sX = afterDiscern[11];
						sY = afterDiscern[12];
						sSPEC_HIGH = afterDiscern[13];
						sSPEC_LOW = afterDiscern[14];
						sSPEC_TARGET = afterDiscern[15];
						sCONTROL_HIGH = afterDiscern[16];
						sCONTROL_LOW = afterDiscern[17];
						sLAYER = afterDiscern[18];
						sUP_DOWN_FLAG = afterDiscern[19];

						opticalResultEntity.setOPE_NO(esOPE_NO);
						opticalResultEntity.setSHEET_ID(esSHEET_ID);
						opticalResultEntity.setCHIP_ID(sCHIP_ID);
						opticalResultEntity.setCHIP_NO(sCHIP_NO);
						opticalResultEntity.setEND_TIME(esEND_TIME);
						opticalResultEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						opticalResultEntity.setPARAM_GROUP(sPARAM_GROUP);
						opticalResultEntity.setPARAM_NAME(sPARAM_NAME);
						opticalResultEntity.setSITE_NAME(sSITE_NAME);
						opticalResultEntity.setJUDGE(sJUDGE);
						opticalResultEntity.setX(sX);
						opticalResultEntity.setY(sY);
						opticalResultEntity.setSPEC_HIGH(sSPEC_HIGH);
						opticalResultEntity.setSPEC_LOW(sSPEC_LOW);
						opticalResultEntity.setSPEC_TARGET(sSPEC_TARGET);
						opticalResultEntity.setCONTROL_HIGH(sCONTROL_HIGH);
						opticalResultEntity.setSPEC_LOW(sSPEC_LOW);
						opticalResultEntity.setLAYER(sLAYER);
						opticalResultEntity.setUP_DOWN_FLAG(sUP_DOWN_FLAG);
									
						setEdaSuccessFlag(opticalResultDao.addCFOpticalResult(opticalResultEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID: " + FID + "|| 【  SITE_DATA_END 读取结束  】");
					
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END *******
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("DEFECT_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  DEFECT_DATA_BEGIN 读取开始  】");
					
					discern = reader.readLine(); // 读取字段行名称
					
					int index = 0;
					
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DEFECT_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						dOPE_NO = afterDiscern[0];
						dSHEET_ID = afterDiscern[1];
						dCHIP_ID = afterDiscern[2];
						dCHIP_NO = afterDiscern[3];
						dEND_TIME = afterDiscern[4];
						//dDEFECT_SEQ_NO = afterDiscern[5];
						dDEFECT_JUDGE = afterDiscern[6];
						dDEFECT_GROUP = afterDiscern[7];
						dDEFECT_CODE = afterDiscern[8];
						dDEFECT_CODE_DESC = afterDiscern[9];
						dDEFECT_LAYER_TYPE = afterDiscern[10];
						dIMAGE_DATA = afterDiscern[11];
						dMAIN_DEFECT_FLAG = afterDiscern[12];
						dDEFECT_PATTERN = afterDiscern[13];
						dREJUDGE_FLAG = afterDiscern[14];
						dDEFECT_SIZE = afterDiscern[15];
						dS = afterDiscern[16];
						dG = afterDiscern[17];
						dDEFECT_RANK = afterDiscern[18];
						dCAPTURE_NO = afterDiscern[19];
						dX = afterDiscern[20];
						dY = afterDiscern[21];
						dX2 = afterDiscern[22];
						dY2 = afterDiscern[23];
						dX3 = afterDiscern[24];
						dY3 = afterDiscern[25];
						dARRAY_X = afterDiscern[26];
						dARRAY_Y = afterDiscern[27];
						dARRAY_X2 = afterDiscern[28];
						dARRAY_Y2 = afterDiscern[29];
						dARRAY_X3 = afterDiscern[30];
						dARRAY_Y3 = afterDiscern[31];
						dDEFECT_STATUS = afterDiscern[32];
						dAUTO_DEFECT_CODE = afterDiscern[33];
						dMANUAL_DEFECT_CODE = afterDiscern[34];
						dAUTO_REPAIR_NOTE = afterDiscern[35];
						dAUTO_LASER_NOTE = afterDiscern[36];
						dINK_COLOR = afterDiscern[37];
						dCCD_NO = afterDiscern[38];
						dSIZE_X = afterDiscern[39];
						dSIZE_Y = afterDiscern[40];
						dAREA_UM = afterDiscern[41];
						dAREA_PIXEL = afterDiscern[42];
						dNOTE_PRE_PROD_INSP = afterDiscern[43];
						dMANUAL_DEFC_CODE_JUDGE_FLAG = afterDiscern[44];
						dORIGINAL_HEIGHT = afterDiscern[45];
						dMODIFICATION_HEIGHT = afterDiscern[46];
						dPOLISH_TIMES = afterDiscern[47];
						dLASER_AREA = afterDiscern[48];
						dLASER_X_LENGTH = afterDiscern[49];
						dLASER_Y_LENGTH = afterDiscern[50];
						dLASER_TIMES = afterDiscern[51];
						dMEASURE_DIAMETER = afterDiscern[52];
						dINK_NEEDLE_DIAMETER = afterDiscern[53];
						dINK_AREA = afterDiscern[54];
						dINK_X_LENGTH = afterDiscern[55];
						dINK_Y_LENGTH = afterDiscern[56];
						dINK_TIMES = afterDiscern[57];
						dLASER_WAVELENGTH = afterDiscern[58];
						dLASER_SHOT_TIMES = afterDiscern[59];
						dLASER_ENERGY = afterDiscern[60];
						dSEAL_HEAD = afterDiscern[61];
						dGRAY_LEVEL_DELTA = afterDiscern[62];
						dJUDGE_HISTROY = afterDiscern[63];
						dREJUDGE_DEF = afterDiscern[64];
						dUP_DOWN_FLAG = afterDiscern[65];

						opticalDefectEntity.setOPE_NO(esOPE_NO);
						opticalDefectEntity.setSHEET_ID(esSHEET_ID);
						opticalDefectEntity.setCHIP_ID(dCHIP_ID);
						opticalDefectEntity.setCHIP_NO(dCHIP_NO);
						opticalDefectEntity.setEND_TIME(esEND_TIME);
						opticalDefectEntity.setDEFECT_SEQ_NO(++index + "");  //by sheet 和 by chip  不确定性
						opticalDefectEntity.setDEFECT_JUDGE(dDEFECT_JUDGE);
						opticalDefectEntity.setDEFECT_CODE(dDEFECT_CODE);
						opticalDefectEntity.setDEFECT_CODE_DESC(dDEFECT_CODE_DESC);
						opticalDefectEntity.setDEFECT_LAYER_TYPE(dDEFECT_LAYER_TYPE);
						opticalDefectEntity.setIMAGE_DATA(dIMAGE_DATA);
						opticalDefectEntity.setMAIN_DEFECT_FLAG(dMAIN_DEFECT_FLAG);
						opticalDefectEntity.setDEFECT_PATTERN(dDEFECT_PATTERN);
						opticalDefectEntity.setREJUDGE_FLAG(dREJUDGE_FLAG);
						opticalDefectEntity.setDEFECT_SIZE(dDEFECT_SIZE);
						opticalDefectEntity.setS(dS);
						opticalDefectEntity.setG(dG);
						opticalDefectEntity.setDEFECT_RANK(dDEFECT_RANK);
						opticalDefectEntity.setCAPTURE_NO(dCAPTURE_NO);
						opticalDefectEntity.setX(dX);
						opticalDefectEntity.setY(dY);
						opticalDefectEntity.setX2(dX2);
						opticalDefectEntity.setY2(dY2);
						opticalDefectEntity.setX3(dX3);
						opticalDefectEntity.setY3(dY3);
						opticalDefectEntity.setARRAY_X(dARRAY_X);
						opticalDefectEntity.setARRAY_Y(dARRAY_Y);
						opticalDefectEntity.setARRAY_X2(dARRAY_X2);
						opticalDefectEntity.setARRAY_Y2(dARRAY_Y2);
						opticalDefectEntity.setARRAY_X3(dARRAY_X3);
						opticalDefectEntity.setARRAY_Y3(dARRAY_Y3);
						opticalDefectEntity.setDEFECT_STATUS(dDEFECT_STATUS);
						opticalDefectEntity.setAUTO_DEFECT_CODE(dAUTO_DEFECT_CODE);
						opticalDefectEntity.setMANUAL_DEFECT_CODE(dMANUAL_DEFECT_CODE);
						opticalDefectEntity.setAUTO_REPAIR_NOTE(dAUTO_REPAIR_NOTE);
						opticalDefectEntity.setAUTO_LASER_NOTE(dAUTO_LASER_NOTE);
						opticalDefectEntity.setINK_COLOR(dINK_COLOR);
						opticalDefectEntity.setCCD_NO(dCCD_NO);
						opticalDefectEntity.setSIZE_X(dSIZE_X);
						opticalDefectEntity.setSIZE_Y(dSIZE_Y);
						opticalDefectEntity.setAREA_UM(dAREA_UM);
						opticalDefectEntity.setAREA_PIXEL(dAREA_PIXEL);
						opticalDefectEntity.setNOTE_PRE_PROD_INSP(dNOTE_PRE_PROD_INSP);
						opticalDefectEntity.setMANUAL_DEFC_CODE_JUDGE_FLAG(dMANUAL_DEFC_CODE_JUDGE_FLAG);
						opticalDefectEntity.setORIGINAL_HEIGHT(dORIGINAL_HEIGHT);
						opticalDefectEntity.setMODIFICATION_HEIGHT(dMODIFICATION_HEIGHT);
						opticalDefectEntity.setPOLISH_TIMES(dPOLISH_TIMES);
						opticalDefectEntity.setLASER_AREA(dLASER_AREA);
						opticalDefectEntity.setLASER_X_LENGTH(dLASER_X_LENGTH);
						opticalDefectEntity.setLASER_Y_LENGTH(dLASER_Y_LENGTH);
						opticalDefectEntity.setLASER_TIMES(dLASER_TIMES);
						opticalDefectEntity.setMEASURE_DIAMETER(dMEASURE_DIAMETER);
						opticalDefectEntity.setINK_NEEDLE_DIAMETER(dINK_NEEDLE_DIAMETER);
						opticalDefectEntity.setINK_AREA(dINK_AREA);
						opticalDefectEntity.setINK_X_LENGTH(dINK_X_LENGTH);
						opticalDefectEntity.setINK_Y_LENGTH(dINK_Y_LENGTH);
						opticalDefectEntity.setINK_TIMES(dINK_TIMES);
						opticalDefectEntity.setLASER_WAVELENGTH(dLASER_WAVELENGTH);
						opticalDefectEntity.setLASER_SHOT_TIMES(dLASER_SHOT_TIMES);
						opticalDefectEntity.setLASER_ENERGY(dLASER_ENERGY);
						opticalDefectEntity.setSEAL_HEAD(dSEAL_HEAD);
						opticalDefectEntity.setGRAY_LEVEL_DELTA(dGRAY_LEVEL_DELTA);
						opticalDefectEntity.setJUDGE_HISTROY(dJUDGE_HISTROY);
						opticalDefectEntity.setREJUDGE_DEF(dREJUDGE_DEF);
						opticalDefectEntity.setUP_DOWN_FLAG(dUP_DOWN_FLAG);
						
						setEdaSuccessFlag(opticalDefectDao.addCFOpticalDefect(opticalDefectEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID: " + FID + " || 【  DEFECT_DATA_END 读取结束  】");
					
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END *******
				 ***********************************************************************/
			}


			try {
				if (getEdaSuccessFlag()) {
					stmt = EDA_CONN.createStatement();
					stmt.executeQuery(loaderData);
					stmt.close();
				}
			} catch (Exception e) {
				reader.close();
				setEdaSuccessFlag(false);
				EDA_CONN.rollback();

				logger.error("FID: " + FID + "|| Call Loader Failed! Error Message:" + e.getMessage());

			}
//			//SPC handle
//			try {
//				spcRunFlag = true;
//				logger.info(" FID: "+FID+"|| spc_enable = " + spc_enable);
//				
//				if (spc_enable.equalsIgnoreCase("true") && getEdaSuccessFlag()) {
//					
//					logger.info(" FID: "+FID+"|| Start SPC running..");
//					
//					SPC_CONN = getSpcConnection();
//					
//					if (SPC_CONN.isClosed()) {
//						logger.error(" FID: "+FID+"|| The SPC database connection was error");
//						setSpcSuccessFlag(false);
//					}
//					
//					if (getSpcSuccessFlag()) {
//						
//						SpcLoaderEntity entity = new SpcLoaderEntity();
//						
//						entity.setProduct_id(replaceBlankToNull(dsPRODUCT_ID));
//						entity.setRecipe_id(replaceBlankToNull(dsRECIPE_ID));
//						entity.setEquip_type(replaceBlankToNull(hEQUIP_TYPE));
//						entity.setEq_id(replaceBlankToNull(hEQ_ID));
//						entity.setSubeq_id(replaceBlankToNull(hSubEQ_ID));
//						entity.setOpe_no(replaceBlankToNull(dsOPE_NO));
//						entity.setRoute_id(replaceBlankToNull(dsROUTE_ID));
//						entity.setCassette_id(replaceBlankToNull(dsCASSETTE_ID));
//						entity.setStart_time(replaceBlankToNull(esEND_TIME)); //special handle
//						entity.setSheet_id(replaceBlankToNull(dsSHEET_ID));
//						
//						if(sPARAM_NAMES != null && sPARAM_VALUES != null
//						   && !sPARAM_NAMES.trim().equals("") && !sPARAM_VALUES.trim().equals("")){
//							logger.info(" FID: "+FID+"|| call SPC loader.");
//							setSpcSuccessFlag(LOAD_CF_AOI_SHEET.prepareSpcData(entity, sPARAM_NAMES, sPARAM_VALUES, SPC_CONN));
//						}
//					}
//				}
//				
//			} catch (Exception ex) {
//				
//				setSpcSuccessFlag(false);
//				logger.error(" FID: "+FID+"|| Process SPC parsing error : " + ex.getMessage());
//			}

		} catch (Exception ex) {

			reader.close();

			logger.error("FID: " + FID + "|| Ready to run error : " + ex.getMessage());

			if (getEdaSuccessFlag()) {
				reader.close();
				setEdaSuccessFlag(false);
			}

		} finally {

			if (reader != null) {
				reader.close();
			}
		}
	}
	
	@Override
	public String getLoaderName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkFileFormat(File file) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}
}
