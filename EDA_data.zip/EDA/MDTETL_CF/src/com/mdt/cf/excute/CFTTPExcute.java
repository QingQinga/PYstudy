package com.mdt.cf.excute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.cf.cf_ttp.dao.CFTTPGlassDao;
import com.mdt.cf.cf_ttp.dao.CFTTPGlassSumDao;
import com.mdt.cf.cf_ttp.dao.CFTTPResultDao;
import com.mdt.cf.cf_ttp.entity.CFTTPGlassEntity;
import com.mdt.cf.cf_ttp.entity.CFTTPGlassSumEntity;
import com.mdt.cf.cf_ttp.entity.CFTTPResultEntity;
import com.mdt.cf.dao.ParameterDao;
import com.mdt.cf.dao.ProductDao;
import com.mdt.cf.dao.StepDao;
import com.mdt.cf.entity.ParameterEntity;
import com.mdt.cf.entity.ProductEntity;
import com.mdt.cf.entity.StepEntity;
import com.mdt.cf.spc.dao.LOAD_CF_TTP_SHEET;
import com.mdt.cf.spc.entity.SpcLoaderEntity;
import com.mdt.cf.tableview.SessionConstants;
import com.mdt.cf.util.DataFileFormatUtil;
import com.mdt.cf.util.EdaSpcAbstractLoader;
import com.mdt.cf.util.UpdateOpeNoUtil;

/**
 ***************************************************
 * @Title  CFTTPExcute                                    
 * @author 林华锋
 * @Date   2017年4月21日下午5:09:13
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFTTPExcute extends EdaSpcAbstractLoader {
	private static Logger logger = Logger.getLogger(CFTTPExcute.class);

	public CFTTPExcute() throws Exception {
		super(SessionConstants.GET_SYSTEM_CONFIG_DIR(), SessionConstants.GET_LOG_CONFIG_DIR());
	}

	public Connection EDA_CONN = null;
	public Connection SPC_CONN = null;
	public String discern; // 识别前字符
	public String[] afterDiscern; // 识别后字符
	public BufferedReader reader;
	public String loaderData = "begin cf_file_loader.load_data; end;";
	public Statement stmt = null;

	/** 实例化实体类对象 Begin **/

	public ParameterEntity parameterEntity = new ParameterEntity();
	public ProductEntity productEntity = new ProductEntity();
	public StepEntity stepEntity = new StepEntity();
    public CFTTPGlassEntity ttpGlassEntity = new CFTTPGlassEntity();
	public CFTTPGlassSumEntity ttpGlassSumEntity = new CFTTPGlassSumEntity();
	public CFTTPResultEntity ttpResultEntity = new CFTTPResultEntity();
	public UpdateOpeNoUtil updateOpeNoUtil = new UpdateOpeNoUtil();
	/** 实例化实体类对象 End **/

	/** DAO */

	public ProductDao productDao;
	public ParameterDao parameterDao;
	public StepDao stepDao;
    public CFTTPGlassDao ttpGlassDao;
    public CFTTPGlassSumDao ttpGlassSumDao;
    public CFTTPResultDao ttpResultDao;
	
	/** DAO */

	/****** Header_Begin 字段行 */

	public String hFILE_VERSION = null; // 文件版本
	public String hFILE_CREATED_TIME = null; // 创建时间
	public String hEQUIP_TYPE = null; // 设备类型
	public String hEQ_ID = null; // 设备ID
	public String hSubEQ_ID = null; // 子设备ID
	public String hCONTENT = null; // DataBlock内容标题

	/***** Header_End 字段行 */

	/** DOWNLOADED_SHEET_DATA_BEGIN 字段行 */

	public String dsOPE_NO = null;
	public String dsSHEET_ID = null;
	public String dsPRODUCT_ID = null;
	public String dsLOT_ID = null;
	public String dsRECIPE_ID = null;
	public String dsCASSETTE_ID = null;
	public String dsSLOT_NO = null;
	public String dsROUTE_ID = null;

	/** DOWNLOADED_SHEET_DATA_END 字段行 */

	/** EQP_SHEET_DATA_BEGIN 字段行 */

	public String esOPE_NO = null;
	public String esSHEET_ID = null;
	public String esSAMPLING_FLAG = null;
	public String esUSER_ID = null;
	public String esABNORMAL_FLAG = null;
	public String esSTART_TIME = null;
	public String esEND_TIME = null;
	public String esMAIN_JUDGE = null;
	public String esSHEET_JUDGE = null;
	public String esTTL_PANEL_CNT = null;
	public String esTACK_TIME = null;

	public String esCOMPONENT_TYPE=null;
	public String esMODEL_NAME = null;
	public String esPROCESS_MODE = null;
	public String esSHOT_CNT = null;


	/** EQP_SHEET_DATA_END 字段行 */

	/** SHEET_SUMMARY_DATA_BEGIN 字段行 */

	public String ssOPE_NO = null;
	public String ssSHEET_ID = null;
	public String ssEND_TIME = null;
	public String ssPARAM_COLLECTION = null;
	public String ssPARAM_GROUP = null;
	public String ssPARAM_NAME = null;
	public String ssAVG = null;
	public String ssMAX = null;
	public String ssMIN = null;
	public String ssSTD = null;
	public String ssUNIFORMITY = null;
	public String ssRANGE = null;
	public String ss3SIGMA = null;
	public String ssSPEC_HIGH = null;
	public String ssSPEC_LOW = null;
	public String ssSPEC_TARGET = null;
	public String ssCONTROL_HIGH = null;
	public String ssCONTROL_LOW = null;
	public String ssCOLOR_NAME = null;
	public String ssPARAM_JUDGE = null;

	/** SHEET_SUMMARY_DATA_END 字段行 */

	/** SITE_DATA_BEGIN 字段行 */

	public String sOPE_NO = null;
	public String sSHEET_ID = null;
	public String sEND_TIME = null;
	public String sSITE_NAME = null;
	public String sPARAM_COLLECTION = null;
	public String sPARAM_GROUP = null;
	public String sPARAM_NAME = null;
	public String sPARAM_VALUE = null;
	public String sX = null;
	public String sY = null;
	public String sZ = null;
	public String sSPEC_HIGH = null;
	public String sSPEC_LOW = null;
	public String sSPEC_TARGET = null;
	public String sCONTROL_HIGH = null;
	public String sCONTROL_LOW = null;
	public String sCHIP_ID = null;
	public String sCHIP_NO = null;
	public String sJUDGE = null;
	
	public String sSHOT_ID = null;
	public String sSEQ_IN_SHOT = null;
	public String sDEFINITION_X = null;
	public String sDEFINITION_Y = null;

	/** SITE_DATA_END 字段行 */

	/** DEFECT_DATA_BEGIN 字段行 */

	public String dOPE_NO;
	public String dSHEET_ID;
	public String dEND_TIME;
	public String dDEFECT_SEQ_NO;
	public String dCHIP_ID;
	public String dCHIP_NO;
	public String dDEFECT_CODE;
	public String dDEFECT_CODE_DESC;
	public String dDEFECT_PATTERN;
	public String dDEFECT_SIZE_TYPE;
	public String dIMAGE_DATA;
	public String dMAIN_DEFECT_FLAG;
	public String dREJUDGE_FLAG;
	public String dSIZE;
	public String dS;
	public String dG;
	public String dX;
	public String dY;
	public String dX2;
	public String dY2;
	public String dX3;
	public String dY3;
	public String dDEFECT_SITE_AVG;
	public String dREPEAT_FLAG;
	public String dDEFECT_TYPE;
	public String dREASON;
	public String dGRAY_LEVEL;
	public String dDEFECT_GL_AVE;
	public String dPARTICLE_SIZE;
	public String dPARTICLE_SIZE_X;
	public String dPARTICLE_SIZE_Y;
	public String dDEFECT_VOL;
	public String dTH_VOL;
	public String dS2;
	public String dG2;
	public String dMAX_VOL;
	public String dMIN_VOL;
	public String dSNR;
	public String dDDS;
	public String dDEVIATION;
	public String dORIGINAL_X;
	public String dORIGINAL_Y;
	public String dMURA_RANGE_X;
	public String dMURA_RANGE_Y;

	/** DEFECT_DATA_END 字段行 */

	/**
	 * ExcuteCenter
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		// args:{TID:0,Shop:1,Source:2,eqp_type:3,target_flag:4,WorkDir:5,max_count:6,SystemLocalConfigPath:7,LogConfigPath:8,db_find_method:9,export_log_file:10}
		if (args != null && args.length > 0) {
			SessionConstants.SET_TID(args[0]);
			SessionConstants.SET_SHOP(args[1]);
			SessionConstants.SET_SOURCE(args[2]);
			SessionConstants.SET_EQP_TYPE(args[3]);
			SessionConstants.SET_TARGET_FLAG(args[4]);
			SessionConstants.SET_WORK_DIR(args[5]);
			SessionConstants.SET_MAX_COUNT(args[6]);
			SessionConstants.SET_SYSTEM_CONFIG_DIR(args[7]);
			SessionConstants.SET_LOG_CONFIG_DIR(args[8]);
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(args[9]);
			SessionConstants.SET_EXPORT_LOG_FLAG(args[10]);
		} else {
			SessionConstants.SET_TID("CF_FILE_TTP_1"); // translator_config_t
			SessionConstants.SET_SHOP("CF");
			SessionConstants.SET_SOURCE("FILE");
			SessionConstants.SET_EQP_TYPE("TTP");
			SessionConstants.SET_TARGET_FLAG("0,1,2,3,4,5,6,7,8,9");
			SessionConstants.SET_WORK_DIR("E:\\TEST");
			SessionConstants.SET_MAX_COUNT("100");
			SessionConstants.SET_SYSTEM_CONFIG_DIR("E:\\TEST\\system.properties");
			SessionConstants.SET_LOG_CONFIG_DIR("config/properties/log4j.properties");
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD("FALSE");
			SessionConstants.SET_EXPORT_LOG_FLAG("TRUE");
		}
		
		try {
			CFTTPExcute TTPExcute = new CFTTPExcute();

			TTPExcute.run();

		} catch (Exception e) {
			logger.error("FID: " + FID + "|| There hava a error! Error Message: " + e.getMessage());
		}
	}

	
	@Override
	public void readyToRun(File file) throws Exception {
		logger.info("FID: " + FID + "|| 【 Translator Begin 】");
		
		ReadDFSFile(file);
			
		logger.info("FID: " + FID + "|| 【 Translator End 】");
	}

	@SuppressWarnings("static-access")
	public void ReadDFSFile(File file) throws Exception {

		EDA_CONN = getEdaConnection();
		
		if (EDA_CONN.isClosed()) {
			logger.error("FID: " + FID + "|| The database connection was error");
		}
		
		EDA_CONN.setAutoCommit(false);

		try {
			
			String sPARAM_NAMES = ""; 
			String sPARAM_VALUES = "";
			
			reader = new BufferedReader(new FileReader(file.getPath()));

			while ((discern = reader.readLine()) != null) {
				if (discern.length() == 0) {
					continue;
				}
				/***********************************************************************
				 * BEGIN ****************** 设备抛出csv文件，读取Header部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("HEADER_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  HEADER_BEGIN 读取开始  】");

					while ((discern = reader.readLine()) != null && getEdaSuccessFlag()) {
						if (DataFileFormatUtil.Shift(discern).startsWith("FILE_VERSION")) {
							afterDiscern = discern.split(":", -1);
							hFILE_VERSION = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("FILE_CREATED_TIME")) {
							afterDiscern = discern.split(":", -1);
							hFILE_CREATED_TIME = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQUIP_TYPE")) {
							afterDiscern = discern.split(":", -1);
							hEQUIP_TYPE = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("SUBEQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hSubEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("CONTENT")) {
							afterDiscern = discern.split(":", -1);
							hCONTENT = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).endsWith("HEADER_END")) {
							break;
						}
					}
					
					logger.info("FID: " + FID + "|| 【  HEADER_END 读取结束  】");

				}
				/*********************************************************************
				 * END ******************** 设备抛出csv文件，读取Header部分 ****** END *
				 ********************************************************************/

				/***********************************************************************
				 * BEGIN ***************设备抛出csv文件，读取SHEET_DATA部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("DOWNLOADED_SHEET_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  DOWNLOADED_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DOWNLOADED_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						dsOPE_NO = afterDiscern[0];
						dsROUTE_ID = afterDiscern[1];
						dsSHEET_ID = afterDiscern[2];
						dsPRODUCT_ID = afterDiscern[3];
						dsRECIPE_ID = afterDiscern[4];
						dsCASSETTE_ID = afterDiscern[5];
						dsSLOT_NO = afterDiscern[6];
 
						productEntity.setPRODUCT_ID(dsPRODUCT_ID);
						productEntity.setPRODUCT_GROUP("DEFAULT");

						setEdaSuccessFlag(productDao.addProductTable(productEntity, EDA_CONN, FID));

						ttpGlassEntity.setROUTE_ID(dsROUTE_ID);
						ttpGlassEntity.setSHEET_ID(dsSHEET_ID);
						ttpGlassEntity.setPRODUCT_ID(dsPRODUCT_ID);
						ttpGlassEntity.setRECIPE_ID(dsRECIPE_ID);
						ttpGlassEntity.setCASSETTE_ID(dsCASSETTE_ID);
						ttpGlassEntity.setSLOT_NO(dsSLOT_NO);
						ttpGlassEntity.setSGR_ID(lot_id); // Debg Mode手动给值						
                        ttpGlassEntity.setPARENT_SGR_ID(parent_lot_id); // Debg Mode手动给值
                        ttpGlassEntity.setLOT_ID(ttpGlassEntity.getSGR_ID());
                        
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}
					
					logger.info("FID: " + FID + "|| 【  DOWNLOADED_SHEET_DATA_END 读取结束  】");
					
				}
				/***********************************************************************
				 * END *******设备抛出csv文件，读取DOWNLOADED_SHEET_DATA部分 ****** END **
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN **** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** BEGIN *******
				 ***********************************************************************/
				if (discern.startsWith("EQP_SHEET_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  EQP_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("EQP_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						esOPE_NO = afterDiscern[0];
						esSHEET_ID = afterDiscern[1];
						esCOMPONENT_TYPE = afterDiscern[2];
						esSTART_TIME = afterDiscern[3];
						esEND_TIME = afterDiscern[4];
						esTACK_TIME = afterDiscern[5];
						esSAMPLING_FLAG = afterDiscern[6];
						esABNORMAL_FLAG = afterDiscern[7];
						esUSER_ID = afterDiscern[8];
						esMAIN_JUDGE = afterDiscern[9];
						esSHEET_JUDGE = afterDiscern[10];
						esTTL_PANEL_CNT = afterDiscern[11];
						esSHOT_CNT = afterDiscern[12];
						esMODEL_NAME = afterDiscern[13];
						esPROCESS_MODE = afterDiscern[14];
						
						if(esCOMPONENT_TYPE.equals("7")){
							esCOMPONENT_TYPE = "1";
						}else if(esCOMPONENT_TYPE.equals("8")){
							esCOMPONENT_TYPE = "2";
						}
						
						esOPE_NO = updateOpeNoUtil.updateNewOPENO(hEQ_ID, esOPE_NO);  // CF update OPE_NO SECOND
						
						stepEntity.setSTEP_ID(esOPE_NO);
						stepEntity.setSTEP_SEQ(esOPE_NO);
						stepEntity.setSTEP_TYPE("M");
						stepEntity.setSTEP_GROUP(hEQUIP_TYPE);

						setEdaSuccessFlag(stepDao.addStepTable(stepEntity, EDA_CONN, FID));
						
						ttpGlassEntity.setEQ_ID(hEQ_ID);
						ttpGlassEntity.setSUBEQ_ID(hSubEQ_ID);
						ttpGlassEntity.setOPE_NO(esOPE_NO);
						ttpGlassEntity.setSHEET_ID(esSHEET_ID);
						ttpGlassEntity.setSTART_TIME(esSTART_TIME);
						ttpGlassEntity.setEND_TIME(esEND_TIME);
						ttpGlassEntity.setTACK_TIME(esTACK_TIME);
						ttpGlassEntity.setCOMPONENT_TYPE(esCOMPONENT_TYPE);
						ttpGlassEntity.setSAMPLING_FLAG(esSAMPLING_FLAG);
						ttpGlassEntity.setABNORMAL_FLAG(esABNORMAL_FLAG);
						ttpGlassEntity.setUSER_ID(esUSER_ID);
						ttpGlassEntity.setMAIN_JUDGE(esMAIN_JUDGE);
						ttpGlassEntity.setSHEET_JUDGE(esSHEET_JUDGE);
						ttpGlassEntity.setTTL_PANEL_CNT(esTTL_PANEL_CNT);
						ttpGlassEntity.setSHOT_CNT(esSHOT_CNT);
						ttpGlassEntity.setMODEL_NAME(esMODEL_NAME);
						ttpGlassEntity.setPROCESS_MODE(esPROCESS_MODE);
						
						setEdaSuccessFlag(ttpGlassDao.addCFTTPGlass(ttpGlassEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID: " + FID + "|| 【  EQP_SHEET_DATA_END 读取结束  】");
					
				}
				/***********************************************************************
				 * END ********** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** BEGIN *
				 ***********************************************************************/

				if (discern.startsWith("SHEET_SUMMARY_DATA_BEGIN")) {

					logger.info("FID: " + FID + "|| 【  SHEET_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SHEET_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						ssOPE_NO = afterDiscern[0];
						ssSHEET_ID = afterDiscern[1];
						ssEND_TIME = afterDiscern[2];
						ssPARAM_COLLECTION = afterDiscern[3];
						ssPARAM_GROUP = afterDiscern[4];
						ssPARAM_NAME = afterDiscern[5];
						ssAVG = afterDiscern[6];
						ssMAX = afterDiscern[7];
						ssMIN = afterDiscern[8];
						ssRANGE = afterDiscern[9];
						ssUNIFORMITY = afterDiscern[10];
						ssSTD = afterDiscern[11];
						ss3SIGMA = afterDiscern[12];
						ssSPEC_HIGH = afterDiscern[13];
						ssSPEC_LOW = afterDiscern[14];
						ssSPEC_TARGET = afterDiscern[15];
						ssCONTROL_HIGH = afterDiscern[16];
						ssCONTROL_LOW = afterDiscern[17];
						
				        parameterEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
					    parameterEntity.setPARAM_NAME(ssPARAM_NAME);
					    parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
					    parameterEntity.setPARAM_GROUP(ssPARAM_GROUP);

					    setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN, FID));
						
						ttpGlassSumEntity.setOPE_NO(esOPE_NO);
						ttpGlassSumEntity.setSHEET_ID(esSHEET_ID);
						ttpGlassSumEntity.setEND_TIME(esEND_TIME);
						ttpGlassSumEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						ttpGlassSumEntity.setPARAM_GROUP(ssPARAM_GROUP);
						ttpGlassSumEntity.setPARAM_NAME(ssPARAM_NAME);
						ttpGlassSumEntity.setAVG(ssAVG);
						ttpGlassSumEntity.setMAX(ssMAX);
						ttpGlassSumEntity.setMIN(ssMIN);
						ttpGlassSumEntity.setRANGE(ssRANGE);
						ttpGlassSumEntity.setUNIFORMITY(ssUNIFORMITY);
						ttpGlassSumEntity.setSTD(ssSTD);
						ttpGlassSumEntity.setTHREE_SIGMA(ss3SIGMA);
						ttpGlassSumEntity.setSPEC_HIGH(ssSPEC_HIGH);
						ttpGlassSumEntity.setSPEC_LOW(ssSPEC_LOW);
						ttpGlassSumEntity.setSPEC_TARGET(ssSPEC_TARGET);
						ttpGlassSumEntity.setCONTROL_HIGH(ssCONTROL_HIGH);
						ttpGlassSumEntity.setCONTROL_LOW(ssCONTROL_LOW);
						
						setEdaSuccessFlag(ttpGlassSumDao.addCFTTPGlassSum(ttpGlassSumEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID: " + FID + "|| 【  SHEET_SUMMARY_DATA_END 读取结束  】");
					
				}

				/***********************************************************************
				 * END * 设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** END ****
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("SITE_DATA_BEGIN")) {
					
					discern = reader.readLine(); // 读取字段行名称
					logger.info("FID: " + FID + "|| 【  SITE_DATA_BEGIN 读取开始  】");
                    
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SITE_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						sOPE_NO = afterDiscern[0];
						sSHEET_ID = afterDiscern[1];
						sCHIP_ID = afterDiscern[2];
						sCHIP_NO = afterDiscern[3];
						sEND_TIME = afterDiscern[4];
						sPARAM_COLLECTION = afterDiscern[5];
						sPARAM_GROUP = afterDiscern[6];
						sPARAM_NAME = afterDiscern[7];
						sSITE_NAME = afterDiscern[8];
						sPARAM_VALUE = afterDiscern[9];
						sJUDGE = afterDiscern[10];
						sX = afterDiscern[11];
						sY = afterDiscern[12];
						sZ = afterDiscern[13];
						sSPEC_HIGH = afterDiscern[14];
						sSPEC_LOW = afterDiscern[15];
						sSPEC_TARGET = afterDiscern[16];
						sCONTROL_HIGH = afterDiscern[17];
						sCONTROL_LOW = afterDiscern[18];
						sSHOT_ID = afterDiscern[19];
						sSEQ_IN_SHOT = afterDiscern[20];
						sDEFINITION_X = afterDiscern[21];
						sDEFINITION_Y = afterDiscern[22];
						
						//for SPC
						if (sPARAM_NAME != null && sPARAM_NAME.length() > 0 && !sPARAM_NAME.trim().equals("")
								&& sPARAM_VALUE != null && sPARAM_VALUE.length() > 0 && !sPARAM_VALUE.trim().equals("") 
								&& !sPARAM_VALUE.trim().equalsIgnoreCase("NA"))
							{
								sPARAM_NAMES += sPARAM_NAME + ","; 
								sPARAM_VALUES += sPARAM_VALUE + ",";
							}
						
						ttpResultEntity.setOPE_NO(esOPE_NO);
						ttpResultEntity.setSHEET_ID(esSHEET_ID);
						ttpResultEntity.setEND_TIME(esEND_TIME);
						ttpResultEntity.setCHIP_ID(sCHIP_ID);
						ttpResultEntity.setCHIP_NO(sCHIP_NO);
						ttpResultEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						ttpResultEntity.setPARAM_GROUP(sPARAM_GROUP);
						ttpResultEntity.setPARAM_NAME(sPARAM_NAME);
						ttpResultEntity.setSITE_NAME(sSITE_NAME);
						ttpResultEntity.setPARAM_VALUE(sPARAM_VALUE);
						ttpResultEntity.setJUDGE(sJUDGE);
						ttpResultEntity.setX(sX);
						ttpResultEntity.setY(sY);
						ttpResultEntity.setZ(sZ);
						ttpResultEntity.setSPEC_HIGH(sSPEC_HIGH);
						ttpResultEntity.setSPEC_LOW(sSPEC_LOW);
						ttpResultEntity.setSPEC_TARGET(sSPEC_TARGET);
						ttpResultEntity.setCONTROL_HIGH(sCONTROL_HIGH);
						ttpResultEntity.setCONTROL_LOW(sCONTROL_LOW);
						ttpResultEntity.setSHOT_ID(sSHOT_ID);
						ttpResultEntity.setSEQ_IN_SHOT(sSEQ_IN_SHOT);
						ttpResultEntity.setDEFINITION_X(sDEFINITION_X);
						ttpResultEntity.setDEFINITION_Y(sDEFINITION_Y);
						
						setEdaSuccessFlag(ttpResultDao.addCFTTPResult(ttpResultEntity, EDA_CONN, FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID: " + FID + "|| 【  SITE_DATA_END 读取结束  】");
					
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END *******
				 ***********************************************************************/

			}

			try {
				if (getEdaSuccessFlag()) {
					stmt = EDA_CONN.createStatement();
					stmt.executeQuery(loaderData);
					stmt.close();
				}
			} catch (Exception e) {
				reader.close();
				setEdaSuccessFlag(false);
				EDA_CONN.rollback();

				logger.error("FID: " + FID + "|| Call Loader Failed! Error Message:" + e.getMessage());

			}
			
			//SPC handle
			try {
				spcRunFlag = true;
				logger.info("FID : " + FID + "|| spc_enable = " + spc_enable);
				if (spc_enable.equalsIgnoreCase("true") && getEdaSuccessFlag()) {
					
					logger.info("FID : " + FID + "|| Start SPC running..");
					
					SPC_CONN = getSpcConnection();
					
					if (SPC_CONN.isClosed()) {
						logger.error("FID : " + FID + "|| The SPC database connection was error");
						setSpcSuccessFlag(false);
					}
					
					if (getSpcSuccessFlag()) {
						
						SpcLoaderEntity entity = new SpcLoaderEntity();
						
						entity.setEq_id(replaceBlankToNull(hEQ_ID));
						entity.setProduct_id(replaceBlankToNull(dsPRODUCT_ID));
						entity.setRecipe_id(replaceBlankToNull(dsRECIPE_ID));
						entity.setEquip_type(replaceBlankToNull(hEQUIP_TYPE));
						entity.setSubeq_id(replaceBlankToNull(hSubEQ_ID));
						entity.setOpe_no(replaceBlankToNull(dsOPE_NO));
						entity.setRoute_id(replaceBlankToNull(dsROUTE_ID));
						entity.setCassette_id(replaceBlankToNull(dsCASSETTE_ID));
						entity.setStart_time(replaceBlankToNull(esEND_TIME)); //special handle
						entity.setSheet_id(replaceBlankToNull(dsSHEET_ID));
						
						if(sPARAM_NAMES != null && sPARAM_VALUES != null
						   && !sPARAM_NAMES.trim().equals("") && !sPARAM_VALUES.trim().equals("")){
							logger.info("FID : " + FID + "|| call SPC loader.");
							setSpcSuccessFlag(LOAD_CF_TTP_SHEET.prepareSpcData(entity, sPARAM_NAMES, sPARAM_VALUES, SPC_CONN));
						}
					}
				}
			} catch (Exception ex) {
				
				setSpcSuccessFlag(false);
				logger.error("FID : " + FID + "|| Process SPC parsing error : " + ex.getMessage());
			}
			
		} catch (Exception ex) {

			reader.close();

			logger.error("FID: " + FID + "|| Ready to run error : " + ex.getMessage());

			if (getEdaSuccessFlag()) {
				reader.close();
				setEdaSuccessFlag(false);
			}

		} finally {

			if (reader != null) {
				reader.close();
			}

		}
	}

	@Override
	public String getLoaderName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkFileFormat(File file) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}
}
