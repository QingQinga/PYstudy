package com.mdt.cf.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.cf.entity.ParameterEntity;
import com.mdt.cf.util.DBUtil;

/**
 ***************************************************
 * @Title ParameterDao 处理基本表Parameter
 * @author 林华锋
 * @Date 2017年2月13日下午5:27:15
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ParameterDao {

	private static Logger logger = Logger.getLogger(ParameterDao.class);
	
	/**
	 * 基本表Parameter插入语句
	 * 
	 * @param parameterEntity
	 *            实体类对象
	 * @param conn
	 *            数据库连接
	 * @return
	 */
	public static boolean addParameterTable(ParameterEntity Entity, Connection conn, String fid) {

		String loaderParameter = "begin cf_base_loader.load_param; end;";

		String sql = "INSERT INTO ldr_cf_param_t ("
				+ "PARAM_COLLECTION,PARAM_NAME,PARAM_COLLECTION_GROUP,PARAM_GROUP" + ") VALUES (" + "?,?,?,?)";
		Object[] params = {
				Entity.getPARAM_COLLECTION(), 
				Entity.getPARAM_NAME(), 
				Entity.getPARAM_COLLECTION_GROUP(),
				Entity.getPARAM_GROUP()};

		boolean isErrorRet = true;

		logger.info("FID: " + fid + "|| LDR_CF_PARAM_T SQL: " + sql);
		try {
			DBUtil.executeUpdate(sql, params, conn);
			logger.info("FID: " + fid + "|| INSERT ldr_cf_param_t success!");
			DBUtil.stmt = conn.createStatement();
			DBUtil.stmt.execute(loaderParameter);
			logger.info("FID: " + fid + "|| CALL Parameter Loader Success!");
		} catch (Exception ex) {
			logger.error("FID: " + fid + "|| INSERT ldr_cf_param_t Failed! Error Message: " + ex.getMessage());
			isErrorRet = false;
		} finally {
			try {
				if (DBUtil.pstmt != null)
					DBUtil.pstmt.close();
				DBUtil.stmt.close();
			} catch (SQLException ex) {
				logger.error("FID: " + fid + "|| An Error Caused: " + ex.getMessage());
				isErrorRet = false;
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}
	}

}
