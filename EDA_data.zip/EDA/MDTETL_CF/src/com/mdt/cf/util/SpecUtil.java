package com.mdt.cf.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 ***************************************************
 * @Title SpecUtil
 * @author 林华锋
 * @Date 2017年4月14日下午3:04:00
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class SpecUtil {
	
	public static void main(String[] args) throws Exception{
		
		String strExtract1="OPE_NO,ROUTE_ID,SHEET_ID,PRODUCT_ID,RECIPE_ID,CASSETTE_ID,SLOT_NO";
		String[] from=strExtract1.split(",");
	    
		List<String> lettleList = compare(from, download_dataSpec());
		for (String str : lettleList) {
			System.out.println("download_data 少了：" + str);
		}

		List<String> manyList = compareMoreThan(download_dataSpec(), from);

		for (String str : manyList) {
			System.out.println("download_data 多了：" + str);
		}
		
		String strExtract2="OPE_NO,SHEET_ID,PRODUCT_ID,START_TIME,END_TIME,TACK_TIME,SAMPLING_FLAG,ABNORMAL_FLAG,USER_ID,MAIN_JUDGE,SHEET_JUDGE,TTL_PANEL_CNT,PORT_NO,HEAT_ID,HEAT_TEMPERATURE,HEAT_TURN_ON_OFF,TEG_FLAG,BACKLIGHT_ID,BACKLIGHT_TURN_ON_OFF";

		String[] from2=strExtract2.split(",");
		
		List<String> lettleList2 = compare(from2, eqp_dataSpec());
		for (String str : lettleList2) {
			System.out.println("eqp_data 少了：" + str);
		}
 
		List<String> manyList2 = compareMoreThan(eqp_dataSpec(), from2);

		for (String str : manyList2) {
			System.out.println("eqp_data 多了：" + str);
		}
		
		String strExtract3="OPE_NO,SHEET_ID,END_TIME,PARAM_COLLECTION,PARAM_GROUP,PARAM_NAME,AVG,MAX,MIN,RANGE,UNIFORMITY,STD,3SIGMA,SPEC_HIGH,SPEC_LOW,SPEC_TARGET,CONTROL_HIGH,CONTROL_LOW,PARAM_JUDGE";
		String[] from3=strExtract3.split(",");
		
		List<String> lettleList3 = compare(from3, sheet_sum_dataSpec());
		for (String str : lettleList3) {
			System.out.println("sheet_sum_data 少了：" + str);
		}

		List<String> manyList3 = compareMoreThan(sheet_sum_dataSpec(), from3);

		for (String str : manyList3) {
			System.out.println("sheet_sum_data 多了：" + str);
		}
		
		String strExtract4="OPE_NO,SHEET_ID,CHIP_ID,CHIP_NO,END_TIME,JUDGE,MAIN_DEFECT_CODE,TTL_DEFECT_CNT,PANEL_SKIL_R,PANEL_FAIL_R,PATTERN_NAME,ESS_FAIL";
		String[] from4=strExtract4.split(",");
		
		List<String> lettleList4 = compare(from4, chip_dataSpec());
		for (String str : lettleList4) {
			System.out.println("chip_data 少了：" + str);
		}

		List<String> manyList4 = compareMoreThan(chip_dataSpec(), from4);

		for (String str : manyList4) {
			System.out.println("chip_data 多了：" + str);
		}
		
		String strExtract5="OPE_NO,SHEET_ID,CHIP_ID,CHIP_NO,END_TIME,PARAM_COLLECTION,PARAM_GROUP,PARAM_NAME,PARAM_VALUE,AVG,MAX,MIN,RANGE,UNIFORMITY,STD,3SIGMA,SPEC_HIGH,SPEC_LOW,SPEC_TARGET,CONTROL_HIGH,CONTROL_LOW";
		String[] from5=strExtract5.split(",");
		
		List<String> lettleList5 = compare(from5, chip_sum_dataSpec());
		for (String str : lettleList5) {
			System.out.println("chip_sum_data 少了：" + str);
		}

		List<String> manyList5 = compareMoreThan(chip_sum_dataSpec(), from5);

		for (String str : manyList5) {
			System.out.println("chip_sum_data 多了：" + str);
		}
		
		String strExtract6="OPE_NO,SHEET_ID,CHIP_ID,CHIP_NO,END_TIME,PARAM_COLLECTION,PARAM_GROUP,PARAM_NAME,SITE_NAME,PARAM_VALUE,JUDGE,X,Y,SPEC_HIGH,SPEC_LOW,SPEC_TARGET,CONTROL_HIGH,CONTROL_LOW,SUB_SITE_NAME";
		String[] from6=strExtract6.split(",");
		
		List<String> lettleList6 = compare(from6, site_dataSpec());
		for (String str : lettleList6) {
			System.out.println("site_data 少了：" + str);
		}

		List<String> manyList6 = compareMoreThan(site_dataSpec(), from6);

		for (String str : manyList6) {
			System.out.println("site_data 多了：" + str);
		}
		
		String strExtract7="OPE_NO,SHEET_ID,CHIP_ID,CHIP_NO,END_TIME,DEFECT_SEQ_NO,DEFECT_CODE,DEFECT_CODE_DESC,DEFECT_SIZE_TYPE,IMAGE_DATA,MAIN_DEFECT_FLAG,DEFECT_PATTERN,REJUDGE_FLAG,SIZE,S,G,X,Y,X2,Y2,X3,Y3,DEFECT_SITE_AVG,REPEAT_FLAG,DEFECT_TYPE,REASON,GRAY_LEVEL,DEFECT_GL_AVE,PARTICLE_SIZE,PARTICLE_SIZE_X,PARTICLE_SIZE_Y,DEFECT_VOL,TH_VOL,S2,G2,MAX_VOL,MIN_VOLSNR,DDS,DEVIATION,ORIGINAL_X,ORIGINMAL_Y,MURA_RANGE_X,MURA_RANGE_Y";
		String[] from7=strExtract7.split(",");
		
		List<String> lettleList7 = compare(from7, defect_dataSpec());
		for (String str : lettleList7) {
			System.out.println("defect_data 少了：" + str);
		}

		List<String> manyList7 = compareMoreThan(defect_dataSpec(), from7);

		for (String str : manyList7) {
			System.out.println("defect_data 多了：" + str);
		}
		
	}
	
	public static List<String> compare(String[] extract, String[] spec) {

		List<String> list1 = Arrays.asList(extract);
		List<String> list2 = new ArrayList<String>();
		for (String t : spec) {
			if (!list1.contains(t)) {
				list2.add(t);
			}
		}
		return list2;
		
	}

	public static List<String> compareMoreThan(String[] spec, String[] extract) {
		
		List<String> list1 = Arrays.asList(extract);
		List<String> list2 = new ArrayList<String>();
		
		for (String t : spec) {
			if (!list1.contains(t)) {
				list2.add(t);
			}
		}
		return list2;
	}
	
	public static String[] download_dataSpec(){
		String[] spec = {"OPE_NO",
				         "SHEET_ID",
				         "PRODUCT_ID",
				         "RECIPE_ID",
				         "CASSETTE_ID",
				         "SLOT_NO",
				         "ROUTE_ID"
				         };
		
		return spec;
	}
	
	public static String[] eqp_dataSpec(){
		String[] spec = {"OPE_NO",
				         "SHEET_ID",
				         "SAMPLING_FLAG",
				         "USER_ID",
				         "ABNORMAL_FLAG",
				         "START_TIME",
				         "END_TIME",
				         "MAIN_JUDGE",
				         "SHEET_JUDGE",
				         "TTL_PANEL_CNT",
				         "TACK_TIME"
				         };
		return spec;
		
	}
	
	public static String[] sheet_sum_dataSpec(){
		
		String[] spec = {"OPE_NO",
				         "SHEET_ID",
				         "END_TIME",
				         "PARAM_COLLECTION",
				         "PARAM_GROUP",
				         "PARAM_NAME",
				         "PARAM_VALUE",
				         "AVG",
				         "MAX",
				         "MIN",
				         "STD",
				         "UNIFORMITY",
				         "RANGE",
				         "SPEC_HIGH",
				         "SPEC_LOW",
				         "SPEC_TARGET",
				         "CONTROL_HIGH",
				         "CONTROL_LOW",
				         "3SIGMA",
				         "PARAM_JUDGE"
		                };
		return spec;
	}
   
	public static String[] chip_dataSpec(){
		String[] spec = {"OPE_NO",
				         "SHEET_ID",
				         "END_TIME",
				         "CHIP_ID",
				         "CHIP_NO",
				         "JUDGE",
				         "MAIN_DEFECT_CODE",
				         "TTL_DEFECT_CNT"
		                 };
		return spec;
		
	}
	
	public static String[] chip_sum_dataSpec(){
		String[] spec = {"OPE_NO",
				         "SHEET_ID",
				         "END_TIME",
				         "PARAM_COLLECTION",
				         "PARAM_GROUP",
				         "PARAM_NAME",
				         "AVG",
				         "MAX",
				         "MIN",
				         "STD",
				         "UNIFORMITY",
				         "RANGE",
				         "SPEC_HIGH",
				         "SPEC_LOW",
				         "SPEC_TARGET",
				         "CONTROL_HIGH",
				         "CONTROL_LOW",
				         "3SIGMA",
				         "CHIP_ID",
				         "CHIP_NO"
		                };
		return spec;
		
	}
	
	public static String[] site_dataSpec(){
		String[] spec = {"OPE_NO",
				         "SHEET_ID",
				         "END_TIME",
				         "SITE_NAME",
				         "PARAM_COLLECTION",
				         "PARAM_GROUP",
				         "PARAM_NAME",
				         "PARAM_VALUE",
				         "X",
				         "Y",
				         "SPEC_HIGH",
				         "SPEC_LOW",
				         "SPEC_TARGET",
				         "CONTROL_HIGH",
				         "CONTROL_LOW",
				         "CHIP_ID",
				         "CHIP_NO",
				         "JUDGE"
		};
		return spec;
	}
	
	public static String[] defect_dataSpec(){
		String[] spec = {"OPE_NO",
				         "SHEET_ID",
				         "END_TIME",
				         "DEFECT_SEQ_NO",
				         "CHIP_ID",
				         "CHIP_NO",
				         "DEFECT_CODE",
				         "DEFECT_CODE_DESC",
				         "DEFECT_PATTERN",
				         "DEFECT_SIZE_TYPE",
				         "IMAGE_DATA",
				         "MAIN_DEFECT_FLAG",
				         "REJUDGE_FLAG",
				         "SIZE",
				         "S",
				         "G",
				         "X",
				         "Y",
				         "X2",
				         "Y2",
				         "X3",
				         "Y3"
				         };
		   return spec;
	}
	
}
