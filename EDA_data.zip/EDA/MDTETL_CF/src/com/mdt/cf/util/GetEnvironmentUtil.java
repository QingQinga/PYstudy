package com.mdt.cf.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

/**
 ***************************************************
 * @Title GetEnvironmentUtil
 * @author 林华锋
 * @Date 2017年3月16日上午10:37:12
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class GetEnvironmentUtil {

	public static Logger logger = Logger.getLogger(GetEnvironmentUtil.class);
	public static String line = "";
	public static String environmentKey = "";
	public static String environmentValue = "";
	public static int systemType = 0;
	public static Process process = null;
	public static BufferedReader bufferedReader = null;

	/**
	 * 初始化
	 */
	public GetEnvironmentUtil() {

	}

	public static int getSystemType() {
		Properties properties = new Properties();
		properties = System.getProperties();
		String execSystemName = properties.getProperty("os.name");
		int sysType = 0;
		if ((execSystemName.indexOf("Win")) != -1) {
			sysType = 0; // Window
		} else {
			sysType = 1; // Other system
		}
		return sysType;
	}
    
	public Properties getEnvironment() throws Exception {

		Properties properties = new Properties();
		try {
			if (getSystemType() == 0) {
				process = Runtime.getRuntime().exec("cmd /c set");
			} else {
				process = Runtime.getRuntime().exec("env");  // 数组  key=value
			}
            
			bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));

			while ((line = bufferedReader.readLine()) != null) {
				StringTokenizer token = new StringTokenizer(line, "=");
				if (token.countTokens() == 2) {
					environmentKey = token.nextToken();
					environmentValue = token.nextToken();
					properties.setProperty(environmentKey.toUpperCase(), environmentValue);
				}
			}

			bufferedReader.close();
			process.destroy();
			return properties;
		} catch (IOException ioe) {
			throw new Exception(ioe.getMessage());
		}

	}


}
