package com.mdt.cf.util;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

/**
 ***************************************************
 * @Title FileUtil
 * @author 林华锋
 * @Date 2017年3月15日上午10:08:26
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class FileUtil {

	public static Logger logger = Logger.getLogger(FileUtil.class);

	public FileUtil() {

	}

	/**
	 * 检验文件的路径
	 * 
	 * @param FilePath
	 *            文件的路径
	 * @return
	 */
	synchronized public static String FormatPath(String FilePath) {
		String sep = System.getProperty("file.separator");

		if (FilePath.getBytes()[FilePath.length() - 1] == sep.getBytes()[sep.length() - 1])
			return FilePath;
		else
			return FilePath + sep;
	}

	/**
	 * 检验文件夹是否存在
	 * 
	 * @param FilePath
	 *            文件路径
	 * @return
	 */
	public static boolean CheckDirExists(String FilePath) {
		File dir = new File(FilePath);
		if (!dir.isDirectory())
			return false;
		else
			return true;
	}

	/**
	 * 来源端文件成功处理后转移到目标端文件夹底下
	 * 
	 * @param sourceDir
	 *            来源端文件夹
	 * @param targetDir
	 *            目标端文件夹
	 * @param FileName
	 *            文件名称
	 */
	synchronized public static boolean MoveFile(String srcDir, String destDir, String fileName) {
		
		boolean result = false;
		File srcFile = new File(formatPath(srcDir) + fileName);
		File destFile = new File(formatPath(destDir) + fileName);
		
        if(!new File(destDir).exists())
        {
        	new File(destDir).mkdirs();
        }
        
        try {
        	
        	if(destFile.exists())
        	{
        		FileUtils.deleteQuietly(destFile);	
        	}
        	
        	logger.info("move file to path : " + destDir);
        	FileUtils.moveFile(srcFile, destFile);
        	
        	if (!srcFile.exists() && destFile.exists())
        		result = true;
        	
        } catch (Exception e) {
        	logger.error("move file exception : " + e.getMessage());
        	result = false;
        }
		
		logger.info("move file result:" + result);

		return result;
	}

	/**
	 * 创建文件夹
	 * 
	 * @param TargetDirName
	 *            文件夹名称
	 * @return
	 */
	public static boolean CreateDir(String TargetDirName) {
		File dir = new File(TargetDirName);
		if (dir.exists()) {
			return false;
		}
		if (!TargetDirName.endsWith(File.separator)) {
			TargetDirName = TargetDirName + File.separator;
		}

		if (dir.mkdirs()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 重命名文件夹
	 * 
	 * @param SourceFile
	 *            来源端文件
	 * @param EDA
	 *            来源端
	 * @return
	 */
	public static File ReNameTheFile(File SourceFile, String EDA) {
		File rename_file = new File(SourceFile.getParent() + File.separator + EDA + SourceFile.getName());

		SourceFile.renameTo(rename_file);

		return rename_file;

	}

	synchronized public static String formatPath(String str) {
		String sep = System.getProperty("file.separator");

		if (str.getBytes()[str.length() - 1] == sep.getBytes()[sep.length() - 1])
			return str;
		else
			return str + sep;
	}

	public static boolean checkDirExists(String path) {
		File dir = new File(path);
		if (!dir.isDirectory())
			return false;
		else
			return true;
	}
}
