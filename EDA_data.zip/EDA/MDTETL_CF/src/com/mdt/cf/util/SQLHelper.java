package com.mdt.cf.util;


import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import com.mdt.cf.tableview.ETLFileTableView;
import com.mdt.cf.tableview.TranslatorConfigView;
import com.mdt.cf.tableview.TranslatorTableConstants;


public class SQLHelper {
	
	public static Object getTableResult(Connection conn, String sql, Object[] paramValueList, String tableName) throws java.sql.SQLException {		
		Object obj=null;
		ResultSet rs = null;
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(sql);
			setInputParamData(stmt,paramValueList);			
			//stmt.execute();
			
			rs = stmt.executeQuery();
			
			obj=resultSet2DataList(rs,tableName);
					
		} catch (SQLException exp) {
			
			throw exp;
		} finally {
			if(rs!=null)
				rs.close();			
			if(stmt!=null)
				stmt.close();			
		}

		return obj;
	}
	
	public static Object getTableResult(Connection conn, String sql, String tableName) throws java.sql.SQLException {		
		Object obj=null;
		ResultSet rs = null;
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(sql);		
			//stmt.execute();
			
			rs = stmt.executeQuery();
			
			obj=resultSet2DataList(rs,tableName);
					
		} catch (SQLException exp) {
			
			throw exp;
		} finally {
			if(rs!=null)
				rs.close();			
			if(stmt!=null)
				stmt.close();			
		}

		return obj;
	}
	
	public static void setInputParamData(PreparedStatement stmt,Object[] paramValueList) throws SQLException{
		
		if (paramValueList != null) {
			for (int i = 0; i < paramValueList.length; i++) {
				int index=i+1;
				if (paramValueList[i] instanceof String)
				{
					if (paramValueList[i]!=null){
						stmt.setString(index, (String)paramValueList[i]);
					}else
						stmt.setString(index, null);
				}
				else if (paramValueList[i] instanceof Boolean)
				{
					if (paramValueList[i]!=null)
						stmt.setBoolean(index, true);
					else
						stmt.setBoolean(index, false);						
				}
				else if (paramValueList[i] instanceof BigDecimal)
				{
					
					if (paramValueList[i]!=null)
						stmt.setBigDecimal(index, (BigDecimal)paramValueList[i]);
					else
						stmt.setBigDecimal(index, null);
					
				}
				else if (paramValueList[i] instanceof Timestamp)
				{
					if (paramValueList[i]!=null)
						stmt.setTimestamp(index, (Timestamp)paramValueList[i]);
					else
						stmt.setTimestamp(index, null);						
				}
			}
		}
	}
	
	public static Object resultSet2DataList(ResultSet rs, String tableName) throws SQLException{
		if(TranslatorTableConstants.TRANSLATOR_CONFIG_T_NAME.equals(tableName)){
			ArrayList<TranslatorConfigView> configList = new ArrayList<TranslatorConfigView>();
			while(rs.next()){
				TranslatorConfigView configTableView = new TranslatorConfigView();
				configTableView.setTableValue(rs);
				configList.add(configTableView);
			}
			
			TranslatorConfigView[] viewList = new TranslatorConfigView[configList.size()];
			configList.toArray(viewList);
			return viewList;
		}
		else if(TranslatorTableConstants.ETL_FILE_T_NAME.equals(tableName)){
			ArrayList<ETLFileTableView> dataFileList = new ArrayList<ETLFileTableView>();
			while(rs.next()){
				ETLFileTableView dataFileTableView = new ETLFileTableView();
				dataFileTableView.setTableValue(rs);
				dataFileList.add(dataFileTableView);
			}
			
			ETLFileTableView[] viewList = new ETLFileTableView[dataFileList.size()];
			dataFileList.toArray(viewList);
			return viewList;
		}

		return null;
	}
}
