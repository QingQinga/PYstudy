package com.mdt.cf.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
/**
 * 
 ***************************************************
 * @Title  UpdateOpeNoUtil                                    
 * @author 林华锋
 * @Date   2017年8月22日下午1:43:38 Update
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class UpdateOpeNoUtil {

	private static Logger logger = Logger.getLogger(UpdateOpeNoUtil.class);
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	String UNIT_TYP = null;
	String OPE_NO = null;
	String url = "jdbc:db2://10.96.32.40:60700/FHISDB";
	String user = "edaetl";
	String password = "eda1234";
	public String selectUNIT_TYP(String EQ_ID) {
		try {

			Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
			
			conn = DriverManager.getConnection(url, user, password);

			ps = conn.prepareStatement("SELECT EQPT_ID, UNIT_TYP FROM CFPPPT.AEQPT WHERE EQPT_ID = ?");

			ps.setString(1, EQ_ID);

			rs = ps.executeQuery();

			while (rs.next()) {
				UNIT_TYP = rs.getString(2);
			}
          
		} catch (Exception sqle) {
			logger.error("get " + UNIT_TYP + " failed :" + sqle.getMessage());
		}finally{
			if(conn !=null || ps != null ||rs!=null){
				  try {
					rs.close();
					ps.close();
					conn.close();
				} catch (SQLException e) {
					logger.error("get " + conn + " failed :" + e.getMessage());
				}
					
			}
		}
		return UNIT_TYP;
	}


	 public String updateOPE_NO(String SUB_EQ_ID,String SHEET_ID,String Time,String esOPE_NO){
	        
		 try {

				Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
				
				conn = DriverManager.getConnection(url, user, password);
			    ps = conn.prepareStatement(
					"SELECT CR_OPE_NO FROM CFPHIS.HASHTHS_D WHERE (SHT_ID, T_STAMP) IN ( SELECT SHT_ID, MAX(T_STAMP) T_STAMP FROM CFPHIS.HASHTHS_D WHERE SHT_ID = '"
							+ SHEET_ID + "' AND CLM_CATE = 'SUHS' AND SUB_EQPT_ID = '" + SUB_EQ_ID
							+ "' AND (CLM_DATE || ' ' || REPLACE(CLM_TIME, '.', ':')) <= '" + DateFormatUtil.addDate(Time) + "' GROUP BY SHT_ID)");
				rs = ps.executeQuery();

				while (rs.next()) {
					OPE_NO = rs.getString(1);
				}

			} catch (Exception sqle) {
				logger.error("get OPE_NO:" + OPE_NO + " failed :" + sqle.getMessage());
			}finally{
				if(conn !=null || ps != null ||rs!=null){
					  try {
						rs.close();
						ps.close();
						conn.close();
					} catch (SQLException e) {
						logger.error("get " + conn + " failed :" + e.getMessage());
					}
						
				}
			}
		    String str ="";
		    if(OPE_NO!=null){
		    	if(!OPE_NO.substring(2, 3).equals("7")){
		          str = OPE_NO +"_"+SUB_EQ_ID.substring(2, 4);
		    	}else{
			      str = esOPE_NO +"_"+SUB_EQ_ID.substring(2, 4);
			    }
		    }else{
		    	str = esOPE_NO +"_"+SUB_EQ_ID.substring(2, 4);
		    }
			return str;
	 }
	 
	 public String updateNewOPENO(String EQ_ID,String OPE_NO){
		 
		 String subOPE = OPE_NO.substring(2,3);
		 
		 if(subOPE.equals("1")||subOPE.equals("2")||subOPE.equals("3")||subOPE.equals("4")||subOPE.equals("5")||subOPE.equals("6")){
			 if(EQ_ID.substring(2, 4).equals("CV")){
				 if(EQ_ID.substring(5, 7).equals("L1")){
					 
				   OPE_NO = OPE_NO.substring(0, 3)+"100"+"_"+EQ_ID.substring(2, 4);
				   
				 }else if(EQ_ID.substring(5, 7).equals("T1")){
					 
				   OPE_NO = OPE_NO.substring(0, 3)+"200"+"_"+EQ_ID.substring(2, 4); 
				   
				 }else if(EQ_ID.substring(5, 7).equals("T2")||EQ_ID.substring(5, 7).equals("U1")){
					 
				   OPE_NO = OPE_NO.substring(0, 3)+"300"+"_"+EQ_ID.substring(2, 4);
				 }
			 }else if(EQ_ID.substring(2, 4).equals("PC")||EQ_ID.substring(2, 4).equals("CO")){
				 
				 OPE_NO = OPE_NO.substring(0, 3)+"100"+"_"+EQ_ID.substring(2, 4);
				 
			 }else if(EQ_ID.substring(2, 4).equals("SM")||EQ_ID.substring(2, 4).equals("DM")||EQ_ID.substring(2, 4).equals("TI")||EQ_ID.substring(2, 4).equals("TC")||EQ_ID.substring(2, 4).equals("EX")||EQ_ID.substring(2, 4).equals("DV")){
				 
				 OPE_NO = OPE_NO.substring(0, 3)+"200"+"_"+EQ_ID.substring(2, 4);
				 
			 }else if(EQ_ID.substring(2, 4).equals("AI")||EQ_ID.substring(2, 4).equals("MC")||EQ_ID.substring(2, 4).equals("FT")||EQ_ID.substring(2, 4).equals("PH")||EQ_ID.substring(2, 4).equals("TP")||EQ_ID.substring(2, 4).equals("OV")){
				 
				 OPE_NO = OPE_NO.substring(0, 3)+"300"+"_"+EQ_ID.substring(2, 4);
			 }
		 }else{
			 return OPE_NO+"_"+EQ_ID.substring(2, 4);
		 }
		 
		 return OPE_NO;
	 }
	 
	 
	 
	 
}
