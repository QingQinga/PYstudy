package com.mdt.cf.util;


public class SystemUtil {

	private SystemUtil() {
	}

	public static long getPID() {
		String processName = java.lang.management.ManagementFactory.getRuntimeMXBean().getName();
		return Long.parseLong(processName.split("@")[0]);
	}

	public static void main(String[] args) {
		String msg = "My PID is " + SystemUtil.getPID();

		javax.swing.JOptionPane.showConfirmDialog((java.awt.Component) null,
				msg, "SystemUtils", javax.swing.JOptionPane.DEFAULT_OPTION);
		System.out.println("End");

	}

}

