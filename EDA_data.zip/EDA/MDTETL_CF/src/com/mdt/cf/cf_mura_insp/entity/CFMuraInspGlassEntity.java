package com.mdt.cf.cf_mura_insp.entity;

import java.io.Serializable;

import com.mdt.cf.entity.CFGlassBaseEntity;

/**
 ***************************************************
 * @Title CFMuraInspGlassEntity
 * @author 林华锋
 * @Date 2017年4月20日上午10:22:03
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFMuraInspGlassEntity extends CFGlassBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String TTL_DEFECT_CNT;
	private String SHOT_CNT;
	private String OK_PANEL_COUNT;
	private String NG_PANEL_COUNT;
	private String YIELD;

	public String getTTL_DEFECT_CNT() {
		return TTL_DEFECT_CNT;
	}

	public void setTTL_DEFECT_CNT(String tTL_DEFECT_CNT) {
		TTL_DEFECT_CNT = tTL_DEFECT_CNT;
	}

	public String getSHOT_CNT() {
		return SHOT_CNT;
	}

	public void setSHOT_CNT(String sHOT_CNT) {
		SHOT_CNT = sHOT_CNT;
	}

	public String getOK_PANEL_COUNT() {
		return OK_PANEL_COUNT;
	}

	public void setOK_PANEL_COUNT(String oK_PANEL_COUNT) {
		OK_PANEL_COUNT = oK_PANEL_COUNT;
	}

	public String getNG_PANEL_COUNT() {
		return NG_PANEL_COUNT;
	}

	public void setNG_PANEL_COUNT(String nG_PANEL_COUNT) {
		NG_PANEL_COUNT = nG_PANEL_COUNT;
	}

	public String getYIELD() {
		return YIELD;
	}

	public void setYIELD(String yIELD) {
		YIELD = yIELD;
	}

}
