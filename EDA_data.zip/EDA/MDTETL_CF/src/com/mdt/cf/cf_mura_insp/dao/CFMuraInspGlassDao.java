package com.mdt.cf.cf_mura_insp.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.cf.cf_mura_insp.entity.CFMuraInspGlassEntity;
import com.mdt.cf.util.DBUtil;

/**
 ***************************************************
 * @Title  CFMuraInspGlassDao                                    
 * @author 林华锋
 * @Date   2017年4月20日下午2:50:30
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFMuraInspGlassDao {
	
	private static Logger logger = Logger.getLogger(CFMuraInspGlassDao.class);

	public static boolean addCFMuraInspGlass(CFMuraInspGlassEntity Entity, Connection conn, String fid) throws Exception {
		
		String view = "CF_MURA_INSP_GLASS_V"; 
		
		String sql = "INSERT INTO " + view
		          + "(" 
				  +"OPE_NO,"
		          +"SHEET_ID,"
		          +"PRODUCT_ID,"
		          +"LOT_ID,"
		          +"RECIPE_ID,"
		          +"CASSETTE_ID,"
		          +"SLOT_NO,"
		          +"ROUTE_ID,"
		          +"EQ_ID,"
		          +"SUBEQ_ID,"
		          +"SGR_ID,"
		          +"PARENT_SGR_ID,"
		          +"START_TIME,"
		          +"END_TIME,"
		          +"SAMPLING_FLAG,"
		          +"USER_ID,"
		          +"ABNORMAL_FLAG,"
		          +"MAIN_JUDGE,"
		          +"SHEET_JUDGE,"
		          +"TTL_PANEL_CNT,"
		          +"TACK_TIME,"
		          +"COMPONENT_TYPE,"
		          +"TTL_DEFECT_CNT,"
		          +"SHOT_CNT,"
		          +"OK_PANEL_COUNT,"		
		          +"NG_PANEL_COUNT,"      
		          +"YIELD"  
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA'))"
				  +")";

		Object[] params = {Entity.getOPE_NO(),
				           Entity.getSHEET_ID(),
				           Entity.getPRODUCT_ID(),
				           Entity.getLOT_ID(),
				           Entity.getRECIPE_ID(),
				           Entity.getCASSETTE_ID(),
				           Entity.getSLOT_NO(),
				           Entity.getROUTE_ID(),
				           Entity.getEQ_ID(),
				           Entity.getSUBEQ_ID(),
				           Entity.getSGR_ID(),
				           Entity.getPARENT_SGR_ID(),
				           Entity.getSTART_TIME(),
				           Entity.getEND_TIME(),
				           Entity.getSAMPLING_FLAG(),
				           Entity.getUSER_ID(),
				           Entity.getABNORMAL_FLAG(),
				           Entity.getMAIN_JUDGE(),
				           Entity.getSHEET_JUDGE(),
				           Entity.getTTL_PANEL_CNT(),
				           Entity.getTACK_TIME(),
				           Entity.getCOMPONENT_TYPE(),
				           Entity.getTTL_DEFECT_CNT(),
				           Entity.getSHOT_CNT(),
				           Entity.getOK_PANEL_COUNT(),
				           Entity.getNG_PANEL_COUNT(),
				           Entity.getYIELD()
		                  };
                           
		boolean isErrorRet = true;

		try {

			DBUtil.executeUpdate(sql, params, conn);
			
		} catch (Exception e) {

			logger.error("FID: " + fid + "|| ----- Insert into " + view + " failed! Error Message: " + e.getMessage());

			isErrorRet = false;
            throw e;
		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {
				
				logger.error("FID: " + fid + "|| ----- An Error Cased: " + e.getMessage());
				
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}

	}
}
