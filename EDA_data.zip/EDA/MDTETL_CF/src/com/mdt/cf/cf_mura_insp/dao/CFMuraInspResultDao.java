package com.mdt.cf.cf_mura_insp.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.mdt.cf.cf_mura_insp.entity.CFMuraInspResultEntity;
import com.mdt.cf.util.DBUtil;

/**
 ***************************************************
 * @Title  CFMuraInspResultDao                                    
 * @author 林华锋
 * @Date   2017年4月20日下午3:12:31
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class CFMuraInspResultDao {
	
	private static Logger logger = Logger.getLogger(CFMuraInspResultDao.class);

	public CFMuraInspResultDao() throws Exception {
		PropertyConfigurator.configure("config/properties/log4j.properties");
	}

	public static boolean addCFMuraInspResult(CFMuraInspResultEntity Entity, Connection conn, String fid) throws Exception {
		
		String view = "CF_MURA_INSP_RESULT_V"; 
		
		String sql = "INSERT INTO " + view
		          + "(" 
				  +"OPE_NO,"
				  +"SHEET_ID,"
				  +"END_TIME,"
				  +"PARAM_COLLECTION,"
				  +"PARAM_NAME,"
				  +"SITE_NAME,"
				  +"PARAM_VALUE,"
				  +"SPEC_HIGH,"
				  +"SPEC_LOW,"
				  +"SPEC_TARGET,"
				  +"CONTROL_HIGH,"
				  +"CONTROL_LOW,"
				  +"X,"
				  +"Y,"
				  +"CHIP_ID,"
				  +"CHIP_NO,"
				  +"JUDGE,"
				  +"COLOR_NAME,"
				  +"THICKNESS_NAME"
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?"
				  +")";

		Object[] params = {Entity.getOPE_NO(),
				           Entity.getSHEET_ID(),
				           Entity.getEND_TIME(),
				           Entity.getPARAM_COLLECTION(),
				           Entity.getPARAM_NAME(),
				           Entity.getSITE_NAME(),
				           Entity.getPARAM_VALUE(),
				           Entity.getSPEC_HIGH(),
				           Entity.getSPEC_LOW(),
				           Entity.getSPEC_TARGET(),
				           Entity.getCONTROL_HIGH(),
				           Entity.getCONTROL_LOW(),
				           Entity.getX(),
				           Entity.getY(),
				           Entity.getCHIP_ID(),
				           Entity.getCHIP_NO(),
				           Entity.getJUDGE(),
				           Entity.getCOLOR_NAME(),
				           Entity.getTHICKNESS_NAME()
		                  };
                           
		boolean isErrorRet = true;

		try {
			
			DBUtil.executeUpdate(sql, params, conn);
			
		} catch (Exception e) {

			logger.error("FID: " + fid + "|| ----- Insert into " + view + " failed! Error Message: " + e.getMessage());

			isErrorRet = false;
			throw e;
		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {
				
				logger.error("FID: " + fid + "|| ----- An Error Cased: " + e.getMessage());
				
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}

	}
}
