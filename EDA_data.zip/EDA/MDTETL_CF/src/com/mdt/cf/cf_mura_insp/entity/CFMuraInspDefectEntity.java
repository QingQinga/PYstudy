package com.mdt.cf.cf_mura_insp.entity;

import java.io.Serializable;

import com.mdt.cf.entity.CFDefectBaseEntity;

/**
 ***************************************************
 * @Title  CFMuraInspDefectEntity                                    
 * @author 林华锋
 * @Date   2017年4月20日上午10:51:19
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFMuraInspDefectEntity extends CFDefectBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
}
