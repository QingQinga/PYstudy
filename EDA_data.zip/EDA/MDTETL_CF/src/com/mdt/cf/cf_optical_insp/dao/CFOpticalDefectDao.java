package com.mdt.cf.cf_optical_insp.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.cf.cf_optical_insp.entity.CFOpticalDefectEntity;
import com.mdt.cf.util.DBUtil;

/**
 ***************************************************
 * @Title  CFOpticalDefectDao                                    
 * @author 林华锋
 * @Date   2017年4月20日下午3:54:52
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFOpticalDefectDao {
	
	private static Logger logger = Logger.getLogger(CFOpticalDefectDao.class);

	public static boolean addCFOpticalDefect(CFOpticalDefectEntity Entity, Connection conn, String fid) throws Exception {
		
		String view = "CF_OPTICAL_INSP_DEFECT_V"; 
		
		String sql = "INSERT INTO " + view
		          + "(" 
				  +"OPE_NO,"
		          +"SHEET_ID,"
		          +"END_TIME,"
		          +"CHIP_ID,"
		          +"CHIP_NO,"
		          +"DEFECT_JUDGE,"
		          +"DEFECT_CODE,"
		          +"DEFECT_CODE_DESC,"
		          +"DEFECT_PATTERN,"
		          +"DEFECT_LAYER_TYPE,"
		          +"IMAGE_DATA,"
		          +"MAIN_DEFECT_FLAG,"
		          +"REJUDGE_FLAG,"
		          +"DEFECT_SEQ_NO,"
		          +"DEFECT_GROUP,"
		          +"DEFECT_SIZE,"
		          +"DEFECT_RANK,"
		          +"CAPTURE_NO,"
		          +"S,"
		          +"G,"
		          +"X,"
		          +"Y,"
		          +"X2,"
		          +"Y2,"
		          +"X3,"
		          +"Y3,"
		          +"ARRAY_X,"
		          +"ARRAY_Y,"
		          +"ARRAY_X2,"
		          +"ARRAY_Y2,"
		          +"ARRAY_X3,"
		          +"ARRAY_Y3,"
		          +"AUTO_REPAIR_NOTE,"
		          +"AUTO_LASER_NOTE,"
		          +"INK_COLOR,"
		          +"MANUAL_DEFC_CODE_JUDGE_FLAG,"
		          +"SEAL_HEAD,"
		          +"CCD_NO,"
		          +"SIZE_X,"
		          +"SIZE_Y,"
		          +"AREA_UM,"
		          +"AREA_PIXEL,"
		          +"NOTE_PRE_PROD_INSP,"
		          +"ORIGINAL_HEIGHT,"
		          +"MODIFICATION_HEIGHT,"
		          +"POLISH_TIMES,"
		          +"LASER_AREA,"
		          +"LASER_X_LENGTH,"
		          +"LASER_Y_LENGTH,"
		          +"LASER_TIMES,"
		          +"MEASURE_DIAMETER,"
		          +"INK_NEEDLE_DIAMETER,"
		          +"INK_AREA,"
		          +"INK_X_LENGTH,"
		          +"INK_Y_LENGTH,"
		          +"INK_TIMES,"
		          +"LASER_WAVELENGTH,"
		          +"LASER_SHOT_TIMES,"
		          +"LASER_ENERGY,"
		          +"GRAY_LEVEL_DELTA"
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA'))"
				  +")";

		Object[] params = {Entity.getOPE_NO(),
				           Entity.getSHEET_ID(),
				           Entity.getEND_TIME(),
				           Entity.getCHIP_ID(),
				           Entity.getCHIP_NO(),
				           Entity.getDEFECT_JUDGE(),
				           Entity.getDEFECT_CODE(),
				           Entity.getDEFECT_CODE_DESC(),
				           Entity.getDEFECT_PATTERN(),
				           Entity.getDEFECT_LAYER_TYPE(),
				           Entity.getIMAGE_DATA(),
				           Entity.getMAIN_DEFECT_FLAG(),
				           Entity.getREJUDGE_FLAG(),
				           Entity.getDEFECT_SEQ_NO(),
				           Entity.getDEFECT_GROUP(),
				           Entity.getDEFECT_SIZE(),
				           Entity.getDEFECT_RANK(),
				           Entity.getCAPTURE_NO(),
				           Entity.getS(),
				           Entity.getG(),
				           Entity.getX(),
				           Entity.getY(),
				           Entity.getX2(),
				           Entity.getY2(),
				           Entity.getX3(),
				           Entity.getY3(),
				           Entity.getARRAY_X(),
				           Entity.getARRAY_Y(),
				           Entity.getARRAY_X2(),
				           Entity.getARRAY_Y2(),
				           Entity.getARRAY_X3(),
				           Entity.getARRAY_Y3(),
				           Entity.getAUTO_REPAIR_NOTE(),
				           Entity.getAUTO_LASER_NOTE(),
				           Entity.getINK_COLOR(),
				           Entity.getMANUAL_DEFC_CODE_JUDGE_FLAG(),
				           Entity.getSEAL_HEAD(),
				           Entity.getCCD_NO(),
				           Entity.getSIZE_X(),
				           Entity.getSIZE_Y(),
				           Entity.getAREA_UM(),
				           Entity.getAREA_PIXEL(),
				           Entity.getNOTE_PRE_PROD_INSP(),
				           Entity.getORIGINAL_HEIGHT(),
				           Entity.getMODIFICATION_HEIGHT(),
				           Entity.getPOLISH_TIMES(),
				           Entity.getLASER_AREA(),
				           Entity.getLASER_X_LENGTH(),
				           Entity.getLASER_Y_LENGTH(),
				           Entity.getLASER_TIMES(),
				           Entity.getMEASURE_DIAMETER(),
				           Entity.getINK_NEEDLE_DIAMETER(),
				           Entity.getINK_AREA(),
				           Entity.getINK_X_LENGTH(),
				           Entity.getINK_Y_LENGTH(),
				           Entity.getINK_TIMES(),
				           Entity.getLASER_WAVELENGTH(),
				           Entity.getLASER_SHOT_TIMES(),
				           Entity.getLASER_ENERGY(),
				           Entity.getGRAY_LEVEL_DELTA()
		                  };
                           
		boolean isErrorRet = true;

		try {

			DBUtil.executeUpdate(sql, params,conn);

		} catch (Exception e) {

			logger.error("FID: " + fid + "|| ----- Insert into " + view + " failed! Error Message: " + e.getMessage());

			isErrorRet = false;
			throw e;
		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {

				logger.error("FID: " + fid + "|| ----- An Error Cased: " + e.getMessage());

			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}

	}
	
}
