package com.mdt.cf.cf_optical_insp.entity;

import java.io.Serializable;

import com.mdt.cf.entity.CFChipSumBaseEntity;

/**
 ***************************************************
 * @Title  CFOpticalChipSumEntity                                    
 * @author 林华锋
 * @Date   2017年4月20日上午11:41:19
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFOpticalChipSumEntity extends CFChipSumBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
}
