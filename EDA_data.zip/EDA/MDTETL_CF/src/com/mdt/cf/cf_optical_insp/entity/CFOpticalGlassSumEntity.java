package com.mdt.cf.cf_optical_insp.entity;

import java.io.Serializable;

import com.mdt.cf.entity.CFGlassSumBaseEntity;

/**
 ***************************************************
 * @Title CFOpticalGlassSumEntity
 * @author 林华锋
 * @Date 2017年4月20日上午11:10:18
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFOpticalGlassSumEntity extends CFGlassSumBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String UP_DOWN_FLAG;

	public String getUP_DOWN_FLAG() {
		return UP_DOWN_FLAG;
	}

	public void setUP_DOWN_FLAG(String uP_DOWN_FLAG) {
		UP_DOWN_FLAG = uP_DOWN_FLAG;
	}

}
