package com.mdt.cf.cf_optical_insp.entity;

import java.io.Serializable;

import com.mdt.cf.entity.CFChipBaseEntity;

/**
 ***************************************************
 * @Title CFOpticleChipEntity
 * @author 林华锋
 * @Date 2017年4月20日上午11:39:33
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFOpticalChipEntity extends CFChipBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String PANEL_RANK;

	public String getPANEL_RANK() {
		return PANEL_RANK;
	}

	public void setPANEL_RANK(String pANEL_RANK) {
		PANEL_RANK = pANEL_RANK;
	}

}
