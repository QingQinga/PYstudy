package com.mdt.cf.cf_optical_insp.entity;

import java.io.Serializable;

import com.mdt.cf.entity.CFDefectBaseEntity;

/**
 ***************************************************
 * @Title CFOpticalDefectEntity
 * @author 林华锋
 * @Date 2017年4月20日上午11:44:49
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class CFOpticalDefectEntity extends CFDefectBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String AUTO_REPAIR_NOTE;
	private String AUTO_LASER_NOTE;
	private String INK_COLOR;
	private String MANUAL_DEFC_CODE_JUDGE_FLAG;
	private String SEAL_HEAD;
	private String DEFECT_STATUS;
	private String AUTO_DEFECT_CODE;
	private String MANUAL_DEFECT_CODE;
	private String JUDGE_HISTROY;
	private String REJUDGE_DEF;
	private String UP_DOWN_FLAG;
	private String CCD_NO;
	private String SIZE_X;
	private String SIZE_Y;
	private String AREA_UM;
	private String AREA_PIXEL;
	private String NOTE_PRE_PROD_INSP;
	private String ORIGINAL_HEIGHT;
	private String MODIFICATION_HEIGHT;
	private String POLISH_TIMES;
	private String LASER_AREA;
	private String LASER_X_LENGTH;
	private String LASER_Y_LENGTH;
	private String LASER_TIMES;
	private String MEASURE_DIAMETER;
	private String INK_NEEDLE_DIAMETER;
	private String INK_AREA;
	private String INK_X_LENGTH;
	private String INK_Y_LENGTH;
	private String INK_TIMES;
	private String LASER_WAVELENGTH;
	private String LASER_SHOT_TIMES;
	private String LASER_ENERGY;
	private String GAP_LENGTH;
	private String GRAY_LEVEL_DELTA;

	public String getAUTO_REPAIR_NOTE() {
		return AUTO_REPAIR_NOTE;
	}

	public void setAUTO_REPAIR_NOTE(String aUTO_REPAIR_NOTE) {
		AUTO_REPAIR_NOTE = aUTO_REPAIR_NOTE;
	}

	public String getAUTO_LASER_NOTE() {
		return AUTO_LASER_NOTE;
	}

	public void setAUTO_LASER_NOTE(String aUTO_LASER_NOTE) {
		AUTO_LASER_NOTE = aUTO_LASER_NOTE;
	}

	public String getINK_COLOR() {
		return INK_COLOR;
	}

	public void setINK_COLOR(String iNK_COLOR) {
		INK_COLOR = iNK_COLOR;
	}

	public String getMANUAL_DEFC_CODE_JUDGE_FLAG() {
		return MANUAL_DEFC_CODE_JUDGE_FLAG;
	}

	public void setMANUAL_DEFC_CODE_JUDGE_FLAG(String mANUAL_DEFC_CODE_JUDGE_FLAG) {
		MANUAL_DEFC_CODE_JUDGE_FLAG = mANUAL_DEFC_CODE_JUDGE_FLAG;
	}

	public String getSEAL_HEAD() {
		return SEAL_HEAD;
	}

	public void setSEAL_HEAD(String sEAL_HEAD) {
		SEAL_HEAD = sEAL_HEAD;
	}

	public String getDEFECT_STATUS() {
		return DEFECT_STATUS;
	}

	public void setDEFECT_STATUS(String dEFECT_STATUS) {
		DEFECT_STATUS = dEFECT_STATUS;
	}

	public String getAUTO_DEFECT_CODE() {
		return AUTO_DEFECT_CODE;
	}

	public void setAUTO_DEFECT_CODE(String aUTO_DEFECT_CODE) {
		AUTO_DEFECT_CODE = aUTO_DEFECT_CODE;
	}

	public String getMANUAL_DEFECT_CODE() {
		return MANUAL_DEFECT_CODE;
	}

	public void setMANUAL_DEFECT_CODE(String mANUAL_DEFECT_CODE) {
		MANUAL_DEFECT_CODE = mANUAL_DEFECT_CODE;
	}

	public String getJUDGE_HISTROY() {
		return JUDGE_HISTROY;
	}

	public void setJUDGE_HISTROY(String jUDGE_HISTROY) {
		JUDGE_HISTROY = jUDGE_HISTROY;
	}

	public String getREJUDGE_DEF() {
		return REJUDGE_DEF;
	}

	public void setREJUDGE_DEF(String rEJUDGE_DEF) {
		REJUDGE_DEF = rEJUDGE_DEF;
	}

	public String getUP_DOWN_FLAG() {
		return UP_DOWN_FLAG;
	}

	public void setUP_DOWN_FLAG(String uP_DOWN_FLAG) {
		UP_DOWN_FLAG = uP_DOWN_FLAG;
	}

	public String getCCD_NO() {
		return CCD_NO;
	}

	public void setCCD_NO(String cCD_NO) {
		CCD_NO = cCD_NO;
	}

	public String getSIZE_X() {
		return SIZE_X;
	}

	public void setSIZE_X(String sIZE_X) {
		SIZE_X = sIZE_X;
	}

	public String getSIZE_Y() {
		return SIZE_Y;
	}

	public void setSIZE_Y(String sIZE_Y) {
		SIZE_Y = sIZE_Y;
	}

	public String getAREA_UM() {
		return AREA_UM;
	}

	public void setAREA_UM(String aREA_UM) {
		AREA_UM = aREA_UM;
	}

	public String getAREA_PIXEL() {
		return AREA_PIXEL;
	}

	public void setAREA_PIXEL(String aREA_PIXEL) {
		AREA_PIXEL = aREA_PIXEL;
	}

	public String getNOTE_PRE_PROD_INSP() {
		return NOTE_PRE_PROD_INSP;
	}

	public void setNOTE_PRE_PROD_INSP(String nOTE_PRE_PROD_INSP) {
		NOTE_PRE_PROD_INSP = nOTE_PRE_PROD_INSP;
	}

	public String getORIGINAL_HEIGHT() {
		return ORIGINAL_HEIGHT;
	}

	public void setORIGINAL_HEIGHT(String oRIGINAL_HEIGHT) {
		ORIGINAL_HEIGHT = oRIGINAL_HEIGHT;
	}

	public String getMODIFICATION_HEIGHT() {
		return MODIFICATION_HEIGHT;
	}

	public void setMODIFICATION_HEIGHT(String mODIFICATION_HEIGHT) {
		MODIFICATION_HEIGHT = mODIFICATION_HEIGHT;
	}

	public String getPOLISH_TIMES() {
		return POLISH_TIMES;
	}

	public void setPOLISH_TIMES(String pOLISH_TIMES) {
		POLISH_TIMES = pOLISH_TIMES;
	}

	public String getLASER_AREA() {
		return LASER_AREA;
	}

	public void setLASER_AREA(String lASER_AREA) {
		LASER_AREA = lASER_AREA;
	}

	public String getLASER_X_LENGTH() {
		return LASER_X_LENGTH;
	}

	public void setLASER_X_LENGTH(String lASER_X_LENGTH) {
		LASER_X_LENGTH = lASER_X_LENGTH;
	}

	public String getLASER_Y_LENGTH() {
		return LASER_Y_LENGTH;
	}

	public void setLASER_Y_LENGTH(String lASER_Y_LENGTH) {
		LASER_Y_LENGTH = lASER_Y_LENGTH;
	}

	public String getLASER_TIMES() {
		return LASER_TIMES;
	}

	public void setLASER_TIMES(String lASER_TIMES) {
		LASER_TIMES = lASER_TIMES;
	}

	public String getMEASURE_DIAMETER() {
		return MEASURE_DIAMETER;
	}

	public void setMEASURE_DIAMETER(String mEASURE_DIAMETER) {
		MEASURE_DIAMETER = mEASURE_DIAMETER;
	}

	public String getINK_NEEDLE_DIAMETER() {
		return INK_NEEDLE_DIAMETER;
	}

	public void setINK_NEEDLE_DIAMETER(String iNK_NEEDLE_DIAMETER) {
		INK_NEEDLE_DIAMETER = iNK_NEEDLE_DIAMETER;
	}

	public String getINK_AREA() {
		return INK_AREA;
	}

	public void setINK_AREA(String iNK_AREA) {
		INK_AREA = iNK_AREA;
	}

	public String getINK_X_LENGTH() {
		return INK_X_LENGTH;
	}

	public void setINK_X_LENGTH(String iNK_X_LENGTH) {
		INK_X_LENGTH = iNK_X_LENGTH;
	}

	public String getINK_Y_LENGTH() {
		return INK_Y_LENGTH;
	}

	public void setINK_Y_LENGTH(String iNK_Y_LENGTH) {
		INK_Y_LENGTH = iNK_Y_LENGTH;
	}

	public String getINK_TIMES() {
		return INK_TIMES;
	}

	public void setINK_TIMES(String iNK_TIMES) {
		INK_TIMES = iNK_TIMES;
	}

	public String getLASER_WAVELENGTH() {
		return LASER_WAVELENGTH;
	}

	public void setLASER_WAVELENGTH(String lASER_WAVELENGTH) {
		LASER_WAVELENGTH = lASER_WAVELENGTH;
	}

	public String getLASER_SHOT_TIMES() {
		return LASER_SHOT_TIMES;
	}

	public void setLASER_SHOT_TIMES(String lASER_SHOT_TIMES) {
		LASER_SHOT_TIMES = lASER_SHOT_TIMES;
	}

	public String getLASER_ENERGY() {
		return LASER_ENERGY;
	}

	public void setLASER_ENERGY(String lASER_ENERGY) {
		LASER_ENERGY = lASER_ENERGY;
	}

	public String getGAP_LENGTH() {
		return GAP_LENGTH;
	}

	public void setGAP_LENGTH(String gAP_LENGTH) {
		GAP_LENGTH = gAP_LENGTH;
	}

	public String getGRAY_LEVEL_DELTA() {
		return GRAY_LEVEL_DELTA;
	}

	public void setGRAY_LEVEL_DELTA(String gRAY_LEVEL_DELTA) {
		GRAY_LEVEL_DELTA = gRAY_LEVEL_DELTA;
	}

}
