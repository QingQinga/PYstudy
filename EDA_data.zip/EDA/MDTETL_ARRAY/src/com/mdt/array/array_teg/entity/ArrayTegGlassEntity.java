package com.mdt.array.array_teg.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayGlassBaseEntity;

/**
 ***************************************************
 * @Title ArrayTegGlassEntity
 * @author 林华锋
 * @Date 2017年3月24日下午3:38:12
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayTegGlassEntity extends ArrayGlassBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String PORT_NO;
	private String HEAT_ID;
	private String HEAT_TEMPERATURE;
	private String HEAT_TURN_ON_OFF;
	private String TEG_FLAG;
	private String BACKLIGHT_ID;
	private String BACKLIGHT_TURN_ON_OFF;

	public String getPORT_NO() {
		return PORT_NO;
	}

	public void setPORT_NO(String pORT_NO) {
		PORT_NO = pORT_NO;
	}

	public String getHEAT_ID() {
		return HEAT_ID;
	}

	public void setHEAT_ID(String hEAT_ID) {
		HEAT_ID = hEAT_ID;
	}

	public String getHEAT_TEMPERATURE() {
		return HEAT_TEMPERATURE;
	}

	public void setHEAT_TEMPERATURE(String hEAT_TEMPERATURE) {
		HEAT_TEMPERATURE = hEAT_TEMPERATURE;
	}

	public String getHEAT_TURN_ON_OFF() {
		return HEAT_TURN_ON_OFF;
	}

	public void setHEAT_TURN_ON_OFF(String hEAT_TURN_ON_OFF) {
		HEAT_TURN_ON_OFF = hEAT_TURN_ON_OFF;
	}

	public String getTEG_FLAG() {
		return TEG_FLAG;
	}

	public void setTEG_FLAG(String tEG_FLAG) {
		TEG_FLAG = tEG_FLAG;
	}

	public String getBACKLIGHT_ID() {
		return BACKLIGHT_ID;
	}

	public void setBACKLIGHT_ID(String bACKLIGHT_ID) {
		BACKLIGHT_ID = bACKLIGHT_ID;
	}

	public String getBACKLIGHT_TURN_ON_OFF() {
		return BACKLIGHT_TURN_ON_OFF;
	}

	public void setBACKLIGHT_TURN_ON_OFF(String bACKLIGHT_TURN_ON_OFF) {
		BACKLIGHT_TURN_ON_OFF = bACKLIGHT_TURN_ON_OFF;
	}

}
