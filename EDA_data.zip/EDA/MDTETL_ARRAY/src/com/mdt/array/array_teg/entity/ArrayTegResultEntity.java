package com.mdt.array.array_teg.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayResultBaseEntity;
/**
 ***************************************************
 * @Title  ArrayTegResultEntity                                    
 * @author 林华锋
 * @Date   2017年3月24日下午3:51:32
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayTegResultEntity extends ArrayResultBaseEntity implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
    private String SUB_SITE_NAME;

	public String getSUB_SITE_NAME() {
		return SUB_SITE_NAME;
	}

	public void setSUB_SITE_NAME(String sUB_SITE_NAME) {
		SUB_SITE_NAME = sUB_SITE_NAME;
	}

}
