package com.mdt.array.array_measure.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayGlassBaseEntity;

/**
 ***************************************************
 * @Title  ArrayMeasureGlassEntity                                    
 * @author 林华锋
 * @Date   2017年4月21日上午9:45:41
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayMeasureGlassEntity extends ArrayGlassBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;

	
	
}
