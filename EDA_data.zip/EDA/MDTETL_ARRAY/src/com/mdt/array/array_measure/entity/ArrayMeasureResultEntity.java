package com.mdt.array.array_measure.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayResultBaseEntity;

/**
 ***************************************************
 * @Title  ArrayMeasureResultEntity                                    
 * @author 林华锋
 * @Date   2017年4月21日上午9:50:22
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayMeasureResultEntity extends ArrayResultBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;
}
