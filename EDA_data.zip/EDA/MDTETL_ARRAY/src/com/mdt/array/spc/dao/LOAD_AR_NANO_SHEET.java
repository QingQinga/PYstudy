package com.mdt.array.spc.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.array.spc.entity.SpcLoaderEntity;
import com.mdt.array.util.CheckDataFileFormatUtil;
import com.mdt.array.util.StatisticUtil;

/**
 ***************************************************
 * @Title  LOAD_AR_NANO_SHEET                                    
 * @author CQ
 * @Date   2017年7月6日 下午13:58:00
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class LOAD_AR_NANO_SHEET {
	
	private static Logger logger = Logger.getLogger(LOAD_AR_NANO_SHEET.class);
//	private LoaderProperty l_prop;
	 
	public LOAD_AR_NANO_SHEET() throws Exception {
//		l_prop = new LoaderProperty();
//		PropertyConfigurator.configure(l_prop.GetLog4jConfigDir());
	}
	
    @SuppressWarnings("finally")
	public static boolean callLoader(SpcLoaderEntity entity, Connection conn) throws SQLException
	{	
    	logger.info("callLoader() start");
    	boolean ldrResult = true;
    	
		String sLoader = "begin spc_loader.load_single_point("+ 
		"'" +entity.getModule_name()+ "'," +  
		"'" +entity.getEq_id()+ "'," +
		"'" +entity.getProduct_id()+ "'," + 
		"'" +entity.getRecipe_id()+ "'," +  
		"'" +entity.getParam_name()+ "'," +
		"'" +"DEFAULT"+ "'," +
		"'" +"DEFAULT"+ "'," +		
		"'" +entity.getParam_name()+ "'," +
		
		"'" +entity.getEquip_type()+ "'," +
		"'" +entity.getSubeq_id()+ "'," +
		"'" +entity.getOpe_no()+ "'," +
		"'" +entity.getRoute_id()+ "'," +
		"'" +entity.getCassette_id()+ "'," + 
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +entity.getSheet_id()+ "'," +
		
		"to_date("+ "'"+entity.getStart_time()+"'"+",'yyyy/mm/dd_hh24:mi:ss')"+ "," +
		"'" +entity.getStart_time()+ "'," +
		
		"" +entity.getParam_value()+ "," + 
		"" +entity.getMin()+ "," +
		"" +entity.getMax()+ "," +
		"" +entity.getStd()+ "," +
		"" +entity.getAvg()+ "," +
		"" +entity.getCount()+ "," +
		"'"+entity.getRaw_data()+ "');end;";
			
		Statement stmt = null;

		try
		{	
			logger.info(sLoader);
			stmt=conn.createStatement();
			stmt.execute(sLoader);
		}
		catch(SQLException ex)
		{				  			 
			ldrResult = false;
			logger.error("Call SPC loader error : " + ex.getMessage());
		}
		finally
		{
			try
			{
				if(stmt != null )
					stmt.close();
			}
			catch(SQLException ex)
			{
				ldrResult = false;
				logger.error("Call SPC loader error : " + ex.getMessage());
			}
			
			return ldrResult;
		}	
		
	}
	
	public static boolean prepareSpcData(SpcLoaderEntity entity, String strParam_names, String strParam_values, Connection conn) throws SQLException
	{
		
		logger.info("prepareSpcData() start");
		boolean prepareResult = true;
		
		String strNonDupParam_name = CheckDataFileFormatUtil.RemoveDuplication(strParam_names);
		
		String[] nonDupParam_names = strNonDupParam_name.split(",",-1);		
		String[] param_names = strParam_names.split(",",-1);		
		String[] param_values = strParam_values.split(",",-1);
		
		String raw_data = "";
		
		try {
				entity.setModule_name("AR_NANO_SHEET");
				
				for (String nonDupParam_name : nonDupParam_names) {
					
					if(nonDupParam_name == null || nonDupParam_name.trim().equals(""))
						continue;
					
					//init
					raw_data = "";	
					entity.setParam_name(null);
		       	 	entity.setParam_value(null); 
		       	 	entity.setAvg(null);
		       	 	entity.setStd(null);
		       	 	entity.setMax(null);
		       	 	entity.setMin(null);
		       	 	entity.setCount(null);
		       	 	entity.setRaw_data(null);
					
					for (int i=0; i < param_names.length-1; i++) {
						
						if (param_names[i].equalsIgnoreCase(nonDupParam_name))
						{
							raw_data +=  param_values[i] + ";";			 
			            	 
						}				
					}
					
					entity.setParam_name(nonDupParam_name);
		       	 	entity.setParam_value(StatisticUtil.GetAvgValue(raw_data)+""); 
		       	 	entity.setAvg(StatisticUtil.GetAvgValue(raw_data)+"");
		       	 	entity.setStd(StatisticUtil.GetStandValue(raw_data)+"");
		       	 	entity.setMax(StatisticUtil.GetMaxValue(raw_data)+"");
		       	 	entity.setMin(StatisticUtil.GetMinValue(raw_data)+"");
		       	 	entity.setCount(StatisticUtil.GetCountValue(raw_data)+"");
		       	 	entity.setRaw_data(raw_data);
		       	 	
		       	 	prepareResult = callLoader(entity, conn);
		       	 	
		       	 	if (prepareResult == false)
		       	 		break;
				
				} 
		}catch (Exception ex) {
			
			prepareResult = false;		
			logger.error("Prepare SPC data error : " + ex.getMessage());				
		}
				
		return prepareResult;

	}

	

}
