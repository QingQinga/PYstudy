package com.mdt.array.spc.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.log4j.Logger;
import com.mdt.array.spc.entity.SpcLoaderEntity;

/**
 ***************************************************
 * @Title  LOAD_AR_AOI_SHEET                                    
 * @author CQ
 * @Date   2017年7月6日 下午13:58:00
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */


public class LOAD_AR_AOI_SHEET {
	
	private static Logger logger = Logger.getLogger(LOAD_AR_AOI_SHEET.class);

	 

	
    @SuppressWarnings("finally")
	public static boolean callLoader(SpcLoaderEntity entity, Connection conn) throws SQLException
	{	
    	logger.info("callLoader() start");
    	boolean ldrResult = true;
    	
		String sLoader = "begin spc_loader.load_single_point("+ 
		"'" +entity.getModule_name()+ "'," +  	
		"'" +entity.getProduct_id()+ "'," + 
		"'" +entity.getRecipe_id()+ "'," +  
		"'" +entity.getParam_name()+ "'," +
		"'" +"DEFAULT"+ "'," +
		"'" +"DEFAULT"+ "'," +
		"'" +"DEFAULT"+ "'," +		
		"'" +entity.getParam_name()+ "'," +
		
		"'" +entity.getEquip_type()+ "'," +
		"'" +entity.getEq_id()+ "'," +
		"'" +entity.getSubeq_id()+ "'," +
		"'" +entity.getOpe_no()+ "'," +
		"'" +entity.getRoute_id()+ "'," +
		"'" +entity.getCassette_id()+ "'," + 		
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +""+  "'," +
		"'" +entity.getSheet_id()+ "'," +
		
		"to_date("+ "'"+entity.getStart_time()+"'"+",'yyyy/mm/dd_hh24:mi:ss')"+ "," +
		"'" +entity.getStart_time()+ "'," +
		
		"" +entity.getParam_value()+ "," + 
		"" +entity.getMin()+ "," +
		"" +entity.getMax()+ "," +
		"" +entity.getStd()+ "," +
		"" +entity.getAvg()+ "," +
		"" +entity.getCount()+ "," +
		"'"+entity.getRaw_data()+ "');end;";
			
		Statement stmt = null;

		try
		{	
			logger.info(sLoader);
			stmt=conn.createStatement();
			stmt.execute(sLoader);
		}
		catch(SQLException ex)
		{				  			 
			ldrResult = false;
			logger.error("Call SPC loader error : " + ex.getMessage());
		}
		finally
		{
			try
			{
				if(stmt != null )
					stmt.close();
			}
			catch(SQLException ex)
			{
				ldrResult = false;
				logger.error("Call SPC loader error : " + ex.getMessage());
			}
			
			return ldrResult;
		}	
		
	}
	
	public static boolean prepareSpcData(SpcLoaderEntity entity, String strParam_names, String strParam_values, Connection conn) throws SQLException
	{
		
		logger.info("prepareSpcData() start");
		boolean prepareResult = true;
	
		String[] param_names = strParam_names.split(",",-1);		
		String[] param_values = strParam_values.split(",",-1);
		
		
		
		try {
				entity.setModule_name("AR_AOI_SHEET");
				
				int idx = 0;
				for (String param_name : param_names) 
				{
					if(param_name == null || param_name.trim().equals("")){
						idx++;
						continue;
					}
					
					//init
					
					entity.setParam_name(null);
		       	 	entity.setParam_value(null); 
		       	 	entity.setAvg(null);
		       	 	entity.setStd(null);
		       	 	entity.setMax(null);
		       	 	entity.setMin(null);
		       	 	entity.setCount(null);
		       	 	//entity.setRaw_data(null);
		       	 	
					entity.setParam_name(param_name);
		       	 	entity.setParam_value(param_values[idx]); 
		       	 	entity.setAvg(param_values[idx]);
		       	 	entity.setStd("0");
		       	 	entity.setMax(param_values[idx]);
		       	 	entity.setMin(param_values[idx]);
		       	 	entity.setCount("1");
		       	 	//entity.setRaw_data(raw_data);
		       	 	
		       	 	
		       	 	prepareResult = callLoader(entity, conn);
		       	 	
		       	 	if (prepareResult == false)
		       	 		break;		
		       	 	
		       	 	idx++;
				}
				
				
		}catch (Exception ex) {
			
			prepareResult = false;		
			logger.error("Prepare SPC data error : " + ex.getMessage());				
		}
				
		return prepareResult;

	}

	

}
