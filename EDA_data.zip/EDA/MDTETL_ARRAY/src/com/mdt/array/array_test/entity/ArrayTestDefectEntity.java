package com.mdt.array.array_test.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayDefectBaseEntity;

/**
 ***************************************************
 * @Title ArrayTestDefectEntity
 * @author 林华锋
 * @Date 2017年2月13日上午8:54:53
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayTestDefectEntity extends ArrayDefectBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String DEFECT_SITE_AVG;
	private String REPEAT_FLAG;
	private String DEFECT_TYPE;
	private String REASON;
	private String GRAY_LEVEL;
	private String DEFECT_GL_AVE;
	private String PARTICLE_SIZE;
	private String PARTICLE_SIZE_X;
	private String PARTICLE_SIZE_Y;
	private String DEFECT_VOL;
	private String TH_VOL;
	private String S2;
	private String G2;
	private String MAX_VOL;
	private String MIN_VOL;
	private String SNR;
	private String DDS;
	private String DEVIATION;
	private String ORIGINAL_X;
	private String ORIGINAL_Y;
	private String MURA_RANGE_X;
	private String MURA_RANGE_Y;

	public String getDEFECT_SITE_AVG() {
		return DEFECT_SITE_AVG;
	}

	public void setDEFECT_SITE_AVG(String dEFECT_SITE_AVG) {
		DEFECT_SITE_AVG = dEFECT_SITE_AVG;
	}

	public String getREPEAT_FLAG() {
		return REPEAT_FLAG;
	}

	public void setREPEAT_FLAG(String rEPEAT_FLAG) {
		REPEAT_FLAG = rEPEAT_FLAG;
	}

	public String getDEFECT_TYPE() {
		return DEFECT_TYPE;
	}

	public void setDEFECT_TYPE(String dEFECT_TYPE) {
		DEFECT_TYPE = dEFECT_TYPE;
	}

	public String getREASON() {
		return REASON;
	}

	public void setREASON(String rEASON) {
		REASON = rEASON;
	}

	public String getGRAY_LEVEL() {
		return GRAY_LEVEL;
	}

	public void setGRAY_LEVEL(String gRAY_LEVEL) {
		GRAY_LEVEL = gRAY_LEVEL;
	}

	public String getDEFECT_GL_AVE() {
		return DEFECT_GL_AVE;
	}

	public void setDEFECT_GL_AVE(String dEFECT_GL_AVE) {
		DEFECT_GL_AVE = dEFECT_GL_AVE;
	}

	public String getPARTICLE_SIZE() {
		return PARTICLE_SIZE;
	}

	public void setPARTICLE_SIZE(String pARTICLE_SIZE) {
		PARTICLE_SIZE = pARTICLE_SIZE;
	}

	public String getPARTICLE_SIZE_X() {
		return PARTICLE_SIZE_X;
	}

	public void setPARTICLE_SIZE_X(String pARTICLE_SIZE_X) {
		PARTICLE_SIZE_X = pARTICLE_SIZE_X;
	}

	public String getPARTICLE_SIZE_Y() {
		return PARTICLE_SIZE_Y;
	}

	public void setPARTICLE_SIZE_Y(String pARTICLE_SIZE_Y) {
		PARTICLE_SIZE_Y = pARTICLE_SIZE_Y;
	}

	public String getDEFECT_VOL() {
		return DEFECT_VOL;
	}

	public void setDEFECT_VOL(String dEFECT_VOL) {
		DEFECT_VOL = dEFECT_VOL;
	}

	public String getTH_VOL() {
		return TH_VOL;
	}

	public void setTH_VOL(String tH_VOL) {
		TH_VOL = tH_VOL;
	}

	public String getS2() {
		return S2;
	}

	public void setS2(String s2) {
		S2 = s2;
	}

	public String getG2() {
		return G2;
	}

	public void setG2(String g2) {
		G2 = g2;
	}

	public String getMAX_VOL() {
		return MAX_VOL;
	}

	public void setMAX_VOL(String mAX_VOL) {
		MAX_VOL = mAX_VOL;
	}

	public String getMIN_VOL() {
		return MIN_VOL;
	}

	public void setMIN_VOL(String mIN_VOL) {
		MIN_VOL = mIN_VOL;
	}

	public String getSNR() {
		return SNR;
	}

	public void setSNR(String sNR) {
		SNR = sNR;
	}

	public String getDDS() {
		return DDS;
	}

	public void setDDS(String dDS) {
		DDS = dDS;
	}

	public String getDEVIATION() {
		return DEVIATION;
	}

	public void setDEVIATION(String dEVIATION) {
		DEVIATION = dEVIATION;
	}

	public String getORIGINAL_X() {
		return ORIGINAL_X;
	}

	public void setORIGINAL_X(String oRIGINAL_X) {
		ORIGINAL_X = oRIGINAL_X;
	}

	public String getORIGINAL_Y() {
		return ORIGINAL_Y;
	}

	public void setORIGINAL_Y(String oRIGINAL_Y) {
		ORIGINAL_Y = oRIGINAL_Y;
	}

	public String getMURA_RANGE_X() {
		return MURA_RANGE_X;
	}

	public void setMURA_RANGE_X(String mURA_RANGE_X) {
		MURA_RANGE_X = mURA_RANGE_X;
	}

	public String getMURA_RANGE_Y() {
		return MURA_RANGE_Y;
	}

	public void setMURA_RANGE_Y(String mURA_RANGE_Y) {
		MURA_RANGE_Y = mURA_RANGE_Y;
	}

}
