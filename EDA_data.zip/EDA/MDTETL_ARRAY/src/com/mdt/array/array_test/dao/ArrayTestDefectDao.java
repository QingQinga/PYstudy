package com.mdt.array.array_test.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.array.array_test.entity.ArrayTestDefectEntity;
import com.mdt.array.util.DBUtil;

/**
 ***************************************************
 * @Title  ArrayTestDefectDao                                    
 * @author 林华锋
 * @Date   2017年4月21日上午11:27:46
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayTestDefectDao {
	
	private static Logger logger = Logger.getLogger(ArrayTestDefectDao.class);

	public static boolean addArrayTestDefect(ArrayTestDefectEntity Entity,Connection conn,String fid) throws Exception {
		
		String view = "ARRAY_TEST_DEFECT_V";
		
		String sql = "INSERT INTO " + view
				  +"(" 
				  +"OPE_NO,"
		          +"SHEET_ID,"
		          +"END_TIME,"
		          +"DEFECT_SEQ_NO,"
		          +"CHIP_ID,"
		          +"CHIP_NO,"
		          +"DEFECT_CODE,"
		          +"DEFECT_CODE_DESC,"
		          +"DEFECT_PATTERN,"
		          +"DEFECT_SIZE_TYPE,"
		          +"IMAGE_DATA,"
		          +"MAIN_DEFECT_FLAG,"
		          +"REJUDGE_FLAG,"
		          +"DEFECT_SIZE,"
		          +"S,"
		          +"G,"
		          +"X,"
		          +"Y,"
		          +"X2,"
		          +"Y2,"
		          +"X3,"
		          +"Y3,"
		          +"DEFECT_SITE_AVG,"
		          +"REPEAT_FLAG,"
		          +"DEFECT_TYPE,"
		          +"REASON,"
		          +"GRAY_LEVEL,"
		          +"DEFECT_GL_AVE,"
		          +"PARTICLE_SIZE,"
		          +"PARTICLE_SIZE_X,"
		          +"PARTICLE_SIZE_Y,"
		          +"DEFECT_VOL,"
		          +"TH_VOL,"
		          +"S2,"
		          +"G2,"
		          +"MAX_VOL,"
		          +"MIN_VOL,"
		          +"SNR,"
		          +"DDS,"
		          +"DEVIATION,"
		          +"ORIGINAL_X,"
		          +"ORIGINAL_Y,"
		          +"MURA_RANGE_X,"
		          +"MURA_RANGE_Y"
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA'))"
				  +")";

		Object[] params = {Entity.getOPE_NO(),
				           Entity.getSHEET_ID(),
				           Entity.getEND_TIME(),
				           Entity.getDEFECT_SEQ_NO(),
				           Entity.getCHIP_ID(),
				           Entity.getCHIP_NO(),
				           Entity.getDEFECT_CODE(),
				           Entity.getDEFECT_CODE_DESC(),
				           Entity.getDEFECT_PATTERN(),
				           Entity.getDEFECT_SIZE_TYPE(),
				           Entity.getIMAGE_DATA(),
				           Entity.getMAIN_DEFECT_FLAG(),
				           Entity.getREJUDGE_FLAG(),
				           Entity.getSIZE(),
				           Entity.getS(),
				           Entity.getG(),
				           Entity.getX(),
				           Entity.getY(),
				           Entity.getX2(),
				           Entity.getY2(),
				           Entity.getX3(),
				           Entity.getY3(),
				           Entity.getDEFECT_SITE_AVG(),
				           Entity.getREPEAT_FLAG(),
				           Entity.getDEFECT_TYPE(),
				           Entity.getREASON(),
				           Entity.getGRAY_LEVEL(),
				           Entity.getDEFECT_GL_AVE(),
				           Entity.getPARTICLE_SIZE(),
				           Entity.getPARTICLE_SIZE_X(),
				           Entity.getPARTICLE_SIZE_Y(),
				           Entity.getDEFECT_VOL(),
				           Entity.getTH_VOL(),
				           Entity.getS2(),
				           Entity.getG2(),
				           Entity.getMAX_VOL(),
				           Entity.getMIN_VOL(),
				           Entity.getSNR(),
				           Entity.getDDS(),
				           Entity.getDEVIATION(),
				           Entity.getORIGINAL_X(),
				           Entity.getORIGINAL_Y(),
				           Entity.getMURA_RANGE_X(),
				           Entity.getMURA_RANGE_Y()
		                  };
                           
		boolean isErrorRet = true;

		try {
			DBUtil.executeUpdate(sql, params,conn);
		} catch (Exception e) {
			logger.error(" FID: "+fid+"|| ----- Insert into "+ view +" failed! Error Message: " + e.getMessage());

			isErrorRet = false;
			throw e;
		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {
				logger.error(" FID: "+fid+"|| ----- An Error Cased: " + e.getMessage());
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}

	}
}
