package com.mdt.array.array_test.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayChipBaseEntity;

/**
 ***************************************************
 * @Title ArrayTestChipEntity
 * @author 林华锋
 * @Date 2017年2月13日上午8:48:46
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayTestChipEntity extends ArrayChipBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String PANEL_SKIP_R;
	private String PANEL_FAIL_R;
	private String PATTERN_NAME;
	private String ESS_FAIL;
    private String BLOCK_ID;
    private String BLOCK_FLAG;
	
	public String getPANEL_SKIP_R() {
		return PANEL_SKIP_R;
	}

	public void setPANEL_SKIP_R(String pANEL_SKIP_R) {
		PANEL_SKIP_R = pANEL_SKIP_R;
	}

	public String getPANEL_FAIL_R() {
		return PANEL_FAIL_R;
	}

	public void setPANEL_FAIL_R(String pANEL_FAIL_R) {
		PANEL_FAIL_R = pANEL_FAIL_R;
	}

	public String getPATTERN_NAME() {
		return PATTERN_NAME;
	}

	public void setPATTERN_NAME(String pATTERN_NAME) {
		PATTERN_NAME = pATTERN_NAME;
	}

	public String getESS_FAIL() {
		return ESS_FAIL;
	}

	public void setESS_FAIL(String eSS_FAIL) {
		ESS_FAIL = eSS_FAIL;
	}

	public String getBLOCK_ID() {
		return BLOCK_ID;
	}

	public void setBLOCK_ID(String bLOCK_ID) {
		BLOCK_ID = bLOCK_ID;
	}

	public String getBLOCK_FLAG() {
		return BLOCK_FLAG;
	}

	public void setBLOCK_FLAG(String bLOCK_FLAG) {
		BLOCK_FLAG = bLOCK_FLAG;
	}

}
