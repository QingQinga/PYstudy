package com.mdt.array.array_test.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayChipSumBaseEntity;

/**
 ***************************************************
 * @Title ArrayTestChipSumEntity
 * @author 林华锋
 * @Date 2017年2月13日上午8:51:40
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayTestChipSumEntity extends ArrayChipSumBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
}
