package com.mdt.array.array_test.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayGlassBaseEntity;

/**
 ***************************************************
 * @Title ArrayTestGlassEntity
 * @author 林华锋
 * @Date 2017年2月10日上午11:44:28
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayTestGlassEntity extends ArrayGlassBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String MURA_DESC;
	private String MURA_MARK_TYPE;
	private String LIGHT_SOURCE;
	private String MURA_GRADE;
	private String TTL_DEFECT_CNT;
	private String TTL_IMAGE_COUNT;
	private String YIELD;
	private String REJUDGE_FLAG;

	public String getMURA_DESC() {
		return MURA_DESC;
	}

	public void setMURA_DESC(String mURA_DESC) {
		MURA_DESC = mURA_DESC;
	}

	public String getMURA_MARK_TYPE() {
		return MURA_MARK_TYPE;
	}

	public void setMURA_MARK_TYPE(String mURA_MARK_TYPE) {
		MURA_MARK_TYPE = mURA_MARK_TYPE;
	}

	public String getLIGHT_SOURCE() {
		return LIGHT_SOURCE;
	}

	public void setLIGHT_SOURCE(String lIGHT_SOURCE) {
		LIGHT_SOURCE = lIGHT_SOURCE;
	}

	public String getMURA_GRADE() {
		return MURA_GRADE;
	}

	public void setMURA_GRADE(String mURA_GRADE) {
		MURA_GRADE = mURA_GRADE;
	}

	public String getTTL_DEFECT_CNT() {
		return TTL_DEFECT_CNT;
	}

	public void setTTL_DEFECT_CNT(String tTL_DEFECT_CNT) {
		TTL_DEFECT_CNT = tTL_DEFECT_CNT;
	}

	public String getTTL_IMAGE_COUNT() {
		return TTL_IMAGE_COUNT;
	}

	public void setTTL_IMAGE_COUNT(String tTL_IMAGE_COUNT) {
		TTL_IMAGE_COUNT = tTL_IMAGE_COUNT;
	}

	public String getYIELD() {
		return YIELD;
	}

	public void setYIELD(String yIELD) {
		YIELD = yIELD;
	}

	public String getREJUDGE_FLAG() {
		return REJUDGE_FLAG;
	}

	public void setREJUDGE_FLAG(String rEJUDGE_FLAG) {
		REJUDGE_FLAG = rEJUDGE_FLAG;
	}
	
}
