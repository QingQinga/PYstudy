package com.mdt.array.array_test.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayGlassSumBaseEntity;

/**
 ***************************************************
 * @Title ArrayTestSummaryEntity
 * @author 林华锋
 * @Date 2017年2月13日上午8:44:27
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayTestGlassSumEntity extends ArrayGlassSumBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String OPE_NO;
	private String SHEET_ID;
	private String END_TIME;
	private String PARAM_COLLECTION;
	private String PARAM_GROUP;
	private String PARAM_NAME;
	private String PARAM_VALUE;
	private String AVG;
	private String MAX;
	private String MIN;
	private String STD;
	private String UNIFORMITY;
	private String RANGE;
	private String SPEC_HIGH;
	private String SPEC_LOW;
	private String SPEC_TARGET;
	private String CONTROL_HIGH;
	private String CONTROL_LOW;
	private String THREE_SIGMA;
	private String PARAM_JUDGE;

	@Override
	public String getOPE_NO() {
		return OPE_NO;
	}

	@Override
	public void setOPE_NO(String oPE_NO) {
		OPE_NO = oPE_NO;
	}

	@Override
	public String getSHEET_ID() {
		return SHEET_ID;
	}

	@Override
	public void setSHEET_ID(String sHEET_ID) {
		SHEET_ID = sHEET_ID;
	}

	@Override
	public String getEND_TIME() {
		return END_TIME;
	}

	@Override
	public void setEND_TIME(String eND_TIME) {
		END_TIME = eND_TIME;
	}

	@Override
	public String getPARAM_COLLECTION() {
		return PARAM_COLLECTION;
	}

	@Override
	public void setPARAM_COLLECTION(String pARAM_COLLECTION) {
		PARAM_COLLECTION = pARAM_COLLECTION;
	}

	@Override
	public String getPARAM_GROUP() {
		return PARAM_GROUP;
	}

	@Override
	public void setPARAM_GROUP(String pARAM_GROUP) {
		PARAM_GROUP = pARAM_GROUP;
	}

	@Override
	public String getPARAM_NAME() {
		return PARAM_NAME;
	}

	@Override
	public void setPARAM_NAME(String pARAM_NAME) {
		PARAM_NAME = pARAM_NAME;
	}

	@Override
	public String getPARAM_VALUE() {
		return PARAM_VALUE;
	}

	@Override
	public void setPARAM_VALUE(String pARAM_VALUE) {
		PARAM_VALUE = pARAM_VALUE;
	}

	@Override
	public String getAVG() {
		return AVG;
	}

	@Override
	public void setAVG(String aVG) {
		AVG = aVG;
	}

	@Override
	public String getMAX() {
		return MAX;
	}

	@Override
	public void setMAX(String mAX) {
		MAX = mAX;
	}

	@Override
	public String getMIN() {
		return MIN;
	}

	@Override
	public void setMIN(String mIN) {
		MIN = mIN;
	}

	@Override
	public String getSTD() {
		return STD;
	}

	@Override
	public void setSTD(String sTD) {
		STD = sTD;
	}

	@Override
	public String getUNIFORMITY() {
		return UNIFORMITY;
	}

	@Override
	public void setUNIFORMITY(String uNIFORMITY) {
		UNIFORMITY = uNIFORMITY;
	}

	@Override
	public String getRANGE() {
		return RANGE;
	}

	@Override
	public void setRANGE(String rANGE) {
		RANGE = rANGE;
	}

	@Override
	public String getSPEC_HIGH() {
		return SPEC_HIGH;
	}

	@Override
	public void setSPEC_HIGH(String sPEC_HIGH) {
		SPEC_HIGH = sPEC_HIGH;
	}

	@Override
	public String getSPEC_LOW() {
		return SPEC_LOW;
	}

	@Override
	public void setSPEC_LOW(String sPEC_LOW) {
		SPEC_LOW = sPEC_LOW;
	}

	@Override
	public String getSPEC_TARGET() {
		return SPEC_TARGET;
	}

	@Override
	public void setSPEC_TARGET(String sPEC_TARGET) {
		SPEC_TARGET = sPEC_TARGET;
	}

	@Override
	public String getCONTROL_HIGH() {
		return CONTROL_HIGH;
	}

	@Override
	public void setCONTROL_HIGH(String cONTROL_HIGH) {
		CONTROL_HIGH = cONTROL_HIGH;
	}

	@Override
	public String getCONTROL_LOW() {
		return CONTROL_LOW;
	}

	@Override
	public void setCONTROL_LOW(String cONTROL_LOW) {
		CONTROL_LOW = cONTROL_LOW;
	}

	@Override
	public String getTHREE_SIGMA() {
		return THREE_SIGMA;
	}

	@Override
	public void setTHREE_SIGMA(String tHREE_SIGMA) {
		THREE_SIGMA = tHREE_SIGMA;
	}

	@Override
	public String getPARAM_JUDGE() {
		return PARAM_JUDGE;
	}

	@Override
	public void setPARAM_JUDGE(String pARAM_JUDGE) {
		PARAM_JUDGE = pARAM_JUDGE;
	}

}
