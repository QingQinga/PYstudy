package com.mdt.array.array_ttp.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayGlassSumBaseEntity;

/**
 * 
 ***************************************************
 * @Title  ArrayTTPGlassSumEntity                                    
 * @author 林华锋
 * @Date   2017年4月21日下午2:59:51
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayTTPGlassSumEntity extends ArrayGlassSumBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;
}
