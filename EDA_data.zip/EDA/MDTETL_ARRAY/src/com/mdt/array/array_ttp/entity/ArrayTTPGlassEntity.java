package com.mdt.array.array_ttp.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayGlassBaseEntity;

public class ArrayTTPGlassEntity extends ArrayGlassBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String VCD_UNIT_ID;
	private String EXP_UNIT_ID;
	private String COATER_UNIT_ID;
	private String MODEL_NAME;
	private String PROCESS_MODE;
	private String SHOT_CNT;
	private String POSITION_ACCURACY;

	public String getVCD_UNIT_ID() {
		return VCD_UNIT_ID;
	}

	public void setVCD_UNIT_ID(String vCD_UNIT_ID) {
		VCD_UNIT_ID = vCD_UNIT_ID;
	}

	public String getEXP_UNIT_ID() {
		return EXP_UNIT_ID;
	}

	public void setEXP_UNIT_ID(String eXP_UNIT_ID) {
		EXP_UNIT_ID = eXP_UNIT_ID;
	}

	public String getCOATER_UNIT_ID() {
		return COATER_UNIT_ID;
	}

	public void setCOATER_UNIT_ID(String cOATER_UNIT_ID) {
		COATER_UNIT_ID = cOATER_UNIT_ID;
	}

	public String getMODEL_NAME() {
		return MODEL_NAME;
	}

	public void setMODEL_NAME(String mODEL_NAME) {
		MODEL_NAME = mODEL_NAME;
	}

	public String getPROCESS_MODE() {
		return PROCESS_MODE;
	}

	public void setPROCESS_MODE(String pROCESS_MODE) {
		PROCESS_MODE = pROCESS_MODE;
	}

	public String getSHOT_CNT() {
		return SHOT_CNT;
	}

	public void setSHOT_CNT(String sHOT_CNT) {
		SHOT_CNT = sHOT_CNT;
	}

	public String getPOSITION_ACCURACY() {
		return POSITION_ACCURACY;
	}

	public void setPOSITION_ACCURACY(String pOSITION_ACCURACY) {
		POSITION_ACCURACY = pOSITION_ACCURACY;
	}

}
