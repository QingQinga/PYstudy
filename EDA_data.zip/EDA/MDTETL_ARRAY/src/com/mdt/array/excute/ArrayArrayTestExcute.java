package com.mdt.array.excute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import org.apache.log4j.Logger;

import com.mdt.array.array_test.dao.ArrayTestChipDao;
import com.mdt.array.array_test.dao.ArrayTestChipSumDao;
import com.mdt.array.array_test.dao.ArrayTestDefectDao;
import com.mdt.array.array_test.dao.ArrayTestGlassDao;
import com.mdt.array.array_test.dao.ArrayTestGlassSumDao;
import com.mdt.array.array_test.entity.ArrayTestChipEntity;
import com.mdt.array.array_test.entity.ArrayTestChipSumEntity;
import com.mdt.array.array_test.entity.ArrayTestDefectEntity;
import com.mdt.array.array_test.entity.ArrayTestGlassEntity;
import com.mdt.array.array_test.entity.ArrayTestGlassSumEntity;
import com.mdt.array.dao.ParameterDao;
import com.mdt.array.dao.ProductDao;
import com.mdt.array.dao.StepDao;
import com.mdt.array.entity.ParameterEntity;
import com.mdt.array.entity.ProductEntity;
import com.mdt.array.entity.StepEntity;
import com.mdt.array.spc.dao.LOAD_AR_TEST_SHEET;
import com.mdt.array.spc.entity.SpcLoaderEntity;
import com.mdt.array.tableview.SessionConstants;
import com.mdt.array.util.DataFileFormatUtil;
import com.mdt.array.util.DistinctParamNameUtil;
import com.mdt.array.util.EdaSpcAbstractLoader;
import com.mdt.array.util.GetOXCountUtil;
import com.mdt.array.util.UpdateOpeNoUtil;

/**
 ***************************************************
 * @Title ArrayArrayTestExcute
 * @author 林华锋
 * @Date 2017年4月21日下午3:31:24
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class ArrayArrayTestExcute extends EdaSpcAbstractLoader {

	private static Logger logger = Logger.getLogger(ArrayArrayTestExcute.class);

	public ArrayArrayTestExcute() throws Exception {
		super(SessionConstants.GET_SYSTEM_CONFIG_DIR(), SessionConstants.GET_LOG_CONFIG_DIR());
	}

	public Connection EDA_CONN = null;
	public Connection SPC_CONN = null;
	public String discern; // 识别前字符
	public String[] afterDiscern; // 识别后字符
	public BufferedReader reader;
	public String loaderData = "begin array_file_loader.load_data; end;";
	public Statement stmt = null;

	/** 实例化实体类对象 Begin **/

	public ParameterEntity parameterEntity = new ParameterEntity();
	public ProductEntity productEntity = new ProductEntity();
	public StepEntity stepEntity = new StepEntity();
	public ArrayTestGlassEntity testGlassEntity = new ArrayTestGlassEntity();
	public ArrayTestGlassSumEntity testGlassSumEntity = new ArrayTestGlassSumEntity();
	public ArrayTestChipEntity testChipEntity = new ArrayTestChipEntity();
	public ArrayTestChipSumEntity testChipSumEntity = new ArrayTestChipSumEntity();
	public ArrayTestDefectEntity testDefectEntity = new ArrayTestDefectEntity();
	public UpdateOpeNoUtil updateOpeNoUtil = new UpdateOpeNoUtil();
	public GetOXCountUtil getOXCountUtil = new GetOXCountUtil();
	
	/** 实例化实体类对象 End **/

	/** DAO */

	public ProductDao productDao;
	public ParameterDao parameterDao;
	public StepDao stepDao;
	public ArrayTestGlassDao testGlassDao;
	public ArrayTestGlassSumDao testGlassSumDao;
	public ArrayTestChipDao testChipDao;
	public ArrayTestChipSumDao testChipSumDao;
	public ArrayTestDefectDao testDefectDao;

	/** DAO */

	/****** Header_Begin 字段行 */

	public String hFILE_VERSION = null; // 文件版本
	public String hFILE_CREATED_TIME = null; // 创建时间
	public String hEQUIP_TYPE = null; // 设备类型
	public String hEQ_ID = null; // 设备ID
	public String hSubEQ_ID = null; // 子设备ID
	public String hCONTENT = null; // DataBlock内容标题

	/***** Header_End 字段行 */

	/** DOWNLOADED_SHEET_DATA_BEGIN 字段行 */

	public String dsOPE_NO = null;
	public String dsSHEET_ID = null;
	public String dsPRODUCT_ID = null;
	public String dsLOT_ID = null;
	public String dsRECIPE_ID = null;
	public String dsCASSETTE_ID = null;
	public String dsSLOT_NO = null;
	public String dsROUTE_ID = null;

	/** DOWNLOADED_SHEET_DATA_END 字段行 */

	/** EQP_SHEET_DATA_BEGIN 字段行 */

	public String esOPE_NO = null;
	public String esSHEET_ID = null;
	public String esSAMPLING_FLAG = null;
	public String esUSER_ID = null;
	public String esABNORMAL_FLAG = null;
	public String esSTART_TIME = null;
	public String esEND_TIME = null;
	public String esMAIN_JUDGE = null;
	public String esSHEET_JUDGE = null;
	public String esTTL_PANEL_CNT = null;
	public String esTACK_TIME = null;

	public String esMURA_DESC = null;
	public String esMURA_MARK_TYPE = null;
	public String esLIGHT_SOURCE = null;
	public String esMURA_GRADE = null;
	public String esTTL_DEFECT_CNT = null;
	public String esTTL_IMAGE_COUNT = null;
	public String esYIELD = null;

	/** EQP_SHEET_DATA_END 字段行 */

	/** SHEET_SUMMARY_DATA_BEGIN 字段行 */

	public String ssOPE_NO = null;
	public String ssSHEET_ID = null;
	public String ssEND_TIME = null;
	public String ssPARAM_COLLECTION = null;
	public String ssPARAM_GROUP = null;
	public String ssPARAM_NAME = null;
	public String ssPARAM_VALUE = null;
	public String ssAVG = null;
	public String ssMAX = null;
	public String ssMIN = null;
	public String ssSTD = null;
	public String ssUNIFORMITY = null;
	public String ssRANGE = null;
	public String ss3SIGMA = null;
	public String ssSPEC_HIGH = null;
	public String ssSPEC_LOW = null;
	public String ssSPEC_TARGET = null;
	public String ssCONTROL_HIGH = null;
	public String ssCONTROL_LOW = null;
	public String ssCOLOR_NAME = null;
	public String ssPARAM_JUDGE = null;

	/** SHEET_SUMMARY_DATA_END 字段行 */

	/** CHIP_DATA_BEGIN 字段行 */

	public String cOPE_NO = null;
	public String cSHEET_ID = null;
	public String cEND_TIME = null;
	public String cCHIP_ID = null;
	public String cCHIP_NO = null;
	public String cJUDGE = null;
	public String cMAIN_DEFECT_CODE = null;
	public String cTTL_DEFECT_CNT = null;

	public String cPANEL_SKIP_R = null;
	public String cPANEL_FAIL_R = null;
	public String cPATTERN_NAME = null;
	public String cESS_FAIL = null;

	/** CHIP_DATA_END 字段行 */

	/** CHIP_SUMMARY_DATA_BEGIN 字段行 */

	public String csOPE_NO = null;
	public String csSHEET_ID = null;
	public String csEND_TIME = null;
	public String csCHIP_ID = null;
	public String csCHIP_NO = null;
	public String csPARAM_COLLECTION = null;
	public String csPARAM_GROUP = null;
	public String csPARAM_NAME = null;
	public String csAVG = null;
	public String csMAX = null;
	public String csMIN = null;
	public String csSTD = null;
	public String csUNIFORMITY = null;
	public String csRANGE = null;
	public String csSPEC_HIGH = null;
	public String csSPEC_LOW = null;
	public String csSPEC_TARGET = null;
	public String csCONTROL_HIGH = null;
	public String csCONTROL_LOW = null;
	public String cs3SIGMA = null;

	/** CHIP_SUMMARY_DATA_END 字段行 */

	/** DEFECT_DATA_BEGIN 字段行 */

	public String dOPE_NO = null;
	public String dSHEET_ID = null;
	public String dEND_TIME = null;
	public String dDEFECT_SEQ_NO = null;
	public String dCHIP_ID = null;
	public String dCHIP_NO = null;
	public String dDEFECT_CODE = null;
	public String dDEFECT_CODE_DESC = null;
	public String dDEFECT_PATTERN = null;
	public String dDEFECT_SIZE_TYPE = null;
	public String dIMAGE_DATA = null;
	public String dMAIN_DEFECT_FLAG = null;
	public String dREJUDGE_FLAG = null;
	public String dSIZE = null;
	public String dS = null;
	public String dG = null;
	public String dX = null;
	public String dY = null;
	public String dX2 = null;
	public String dY2 = null;
	public String dX3 = null;
	public String dY3 = null;
	public String dDEFECT_SITE_AVG = null;
	public String dREPEAT_FLAG = null;
	public String dDEFECT_TYPE = null;
	public String dREASON = null;
	public String dGRAY_LEVEL = null;
	public String dDEFECT_GL_AVE = null;
	public String dPARTICLE_SIZE = null;
	public String dPARTICLE_SIZE_X = null;
	public String dPARTICLE_SIZE_Y = null;
	public String dDEFECT_VOL = null;
	public String dTH_VOL = null;
	public String dS2 = null;
	public String dG2 = null;
	public String dMAX_VOL = null;
	public String dMIN_VOL = null;
	public String dSNR = null;
	public String dDDS = null;
	public String dDEVIATION = null;
	public String dORIGINAL_X = null;
	public String dORIGINAL_Y = null;
	public String dMURA_RANGE_X = null;
	public String dMURA_RANGE_Y = null;

	/** DEFECT_DATA_END 字段行 */

	public static void main(String[] args) throws Exception {

		// args:{TID:0,Shop:1,Source:2,eqp_type:3,target_flag:4,WorkDir:5,max_count:6,SystemLocalConfigPath:7,LogConfigPath:8,db_find_method:9,export_log_file:10}
		if (args != null && args.length > 0) {
			SessionConstants.SET_TID(args[0]);
			SessionConstants.SET_SHOP(args[1]);
			SessionConstants.SET_SOURCE(args[2]);
			SessionConstants.SET_EQP_TYPE(args[3]);
			SessionConstants.SET_TARGET_FLAG(args[4]);
			SessionConstants.SET_WORK_DIR(args[5]);
			SessionConstants.SET_MAX_COUNT(args[6]);
			SessionConstants.SET_SYSTEM_CONFIG_DIR(args[7]);
			SessionConstants.SET_LOG_CONFIG_DIR(args[8]);
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(args[9]);
			SessionConstants.SET_EXPORT_LOG_FLAG(args[10]);
		} else {
			SessionConstants.SET_TID("ARRAY_FILE_ARRAY_TEST_1"); // translator_config_t
			SessionConstants.SET_SHOP("ARRAY");
			SessionConstants.SET_SOURCE("FILE");
			SessionConstants.SET_EQP_TYPE("ARRAY_TEST");
			SessionConstants.SET_TARGET_FLAG("0,1,2,3,4,5,6,7,8,9");
			SessionConstants.SET_WORK_DIR("E:\\Test");
			SessionConstants.SET_MAX_COUNT("1");
			SessionConstants.SET_SYSTEM_CONFIG_DIR("E:\\Test\\system.properties");
			SessionConstants.SET_LOG_CONFIG_DIR("config/properties/log4j.properties");
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD("FALSE");
			SessionConstants.SET_EXPORT_LOG_FLAG("TRUE");
		}

		try {
			ArrayArrayTestExcute ArrayTestExcute = new ArrayArrayTestExcute();

			ArrayTestExcute.run();

		} catch (Exception e) {
			logger.error("FID : " + FID + "|| There hava a error! Error Message: " + e.getMessage());
		}

	}

	@Override
	public void readyToRun(File file) throws Exception {

		logger.info("FID : " + FID + "|| 【  Translator Begin  】");

	    ReadDFSFile(file);
			
		logger.info("FID : " + FID + "|| 【   Translator End  】");
	}

	@SuppressWarnings("static-access")
	public void ReadDFSFile(File file) throws Exception {

     EDA_CONN = getEdaConnection();
		
		if (EDA_CONN.isClosed()) {
			logger.error("FID : " + FID + "|| The database connection was error");
		}
		
		EDA_CONN.setAutoCommit(false);

		try {
			String sPARAM_NAMES = ""; //for spc
			String sPARAM_VALUES = "";
			reader = new BufferedReader(new FileReader(file.getPath()));

			while ((discern = reader.readLine()) != null) {
				if (discern.length() == 0) {
					continue;
				}
				/***********************************************************************
				 * BEGIN ****************** 设备抛出csv文件，读取Header部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("HEADER_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  HEADER_BEGIN 读取开始  】");

					while ((discern = reader.readLine()) != null && getEdaSuccessFlag()) {
						if (DataFileFormatUtil.Shift(discern).startsWith("FILE_VERSION")) {
							afterDiscern = discern.split(":", -1);
							hFILE_VERSION = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("FILE_CREATED_TIME")) {
							afterDiscern = discern.split(":", -1);
							hFILE_CREATED_TIME = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQUIP_TYPE")) {
							afterDiscern = discern.split(":", -1);
							hEQUIP_TYPE = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("SUBEQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hSubEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("CONTENT")) {
							afterDiscern = discern.split(":", -1);
							hCONTENT = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).endsWith("HEADER_END")) {
							break;
						}
					}
					logger.info("FID : " + FID + "|| 【  HEADER_END 读取结束  】");

				}
				/*********************************************************************
				 * END ******************** 设备抛出csv文件，读取Header部分 ****** END *
				 ********************************************************************/

				/***********************************************************************
				 * BEGIN ***************设备抛出csv文件，读取SHEET_DATA部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("DOWNLOADED_SHEET_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  DOWNLOADED_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DOWNLOADED_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						dsOPE_NO = afterDiscern[0];
						dsROUTE_ID = afterDiscern[1];
						dsSHEET_ID = afterDiscern[2];
						dsPRODUCT_ID = afterDiscern[3];
						dsRECIPE_ID = afterDiscern[4];
						dsCASSETTE_ID = afterDiscern[5];
						dsSLOT_NO = afterDiscern[6];

						productEntity.setPRODUCT_ID(dsPRODUCT_ID);
						productEntity.setPRODUCT_GROUP("DEFAULT");

						setEdaSuccessFlag(productDao.addProductTable(productEntity, EDA_CONN,FID));

						testGlassEntity.setEQ_ID(hEQ_ID);
						testGlassEntity.setSUBEQ_ID(hSubEQ_ID);
						testGlassEntity.setROUTE_ID(dsROUTE_ID);
						testGlassEntity.setSHEET_ID(dsSHEET_ID);
						testGlassEntity.setPRODUCT_ID(dsPRODUCT_ID);
						testGlassEntity.setRECIPE_ID(dsRECIPE_ID);
						testGlassEntity.setCASSETTE_ID(dsCASSETTE_ID);
						testGlassEntity.setSLOT_NO(dsSLOT_NO);
						testGlassEntity.setLOT_ID(lot_id);
						testGlassEntity.setPARENT_LOT(parent_lot_id);

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}
					logger.info("FID : " + FID + "|| 【  DOWNLOADED_SHEET_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END *******设备抛出csv文件，读取DOWNLOADED_SHEET_DATA部分 ****** END **
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN **** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** BEGIN *******
				 ***********************************************************************/
				if (discern.startsWith("EQP_SHEET_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  EQP_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("EQP_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						esOPE_NO = afterDiscern[0];
						esSHEET_ID = afterDiscern[1];
						esSTART_TIME = afterDiscern[2];
						esEND_TIME = afterDiscern[3];
						esTACK_TIME = afterDiscern[4];
						esSAMPLING_FLAG = afterDiscern[5];
						esABNORMAL_FLAG = afterDiscern[6];
						esUSER_ID = afterDiscern[7];
						esMAIN_JUDGE = afterDiscern[8];
						esSHEET_JUDGE = afterDiscern[9];
						esTTL_PANEL_CNT = afterDiscern[10];
						esMURA_DESC = afterDiscern[11];
						esMURA_MARK_TYPE = afterDiscern[12];
						esLIGHT_SOURCE = afterDiscern[13];
						esMURA_GRADE = afterDiscern[14];
						esTTL_DEFECT_CNT = afterDiscern[15];
						esTTL_IMAGE_COUNT = afterDiscern[16];
						esYIELD = afterDiscern[17];

						esOPE_NO = updateOpeNoUtil.updateOPE_NO(esOPE_NO, dsROUTE_ID, hEQ_ID);
						
						stepEntity.setSTEP_ID(esOPE_NO);
						stepEntity.setSTEP_SEQ(esOPE_NO);
						stepEntity.setSTEP_TYPE("M");
						stepEntity.setSTEP_GROUP(hEQUIP_TYPE);

						setEdaSuccessFlag(stepDao.addStepTable(stepEntity, EDA_CONN,FID));
						
						testGlassEntity.setOPE_NO(esOPE_NO);
						testGlassEntity.setSHEET_ID(esSHEET_ID);
						testGlassEntity.setSTART_TIME(esSTART_TIME);
						testGlassEntity.setEND_TIME(esEND_TIME);
						testGlassEntity.setTACK_TIME(esTACK_TIME);
						testGlassEntity.setSAMPLING_FLAG(esSAMPLING_FLAG);
						testGlassEntity.setABNORMAL_FLAG(esABNORMAL_FLAG);
						testGlassEntity.setUSER_ID(esUSER_ID);
						testGlassEntity.setMAIN_JUDGE(esMAIN_JUDGE);
						testGlassEntity.setSHEET_JUDGE(esSHEET_JUDGE);
						testGlassEntity.setTTL_PANEL_CNT(esTTL_PANEL_CNT);
						testGlassEntity.setMURA_DESC(esMURA_DESC);
						testGlassEntity.setMURA_MARK_TYPE(esMURA_MARK_TYPE);
						testGlassEntity.setLIGHT_SOURCE(esLIGHT_SOURCE);
						testGlassEntity.setMURA_GRADE(esMURA_GRADE);
						testGlassEntity.setTTL_DEFECT_CNT(esTTL_DEFECT_CNT);
						testGlassEntity.setYIELD(esYIELD);

						setEdaSuccessFlag(testGlassDao.addArrayTestGlass(testGlassEntity, EDA_CONN,FID));

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID : " + FID + "|| 【  EQP_SHEET_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END ********** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** BEGIN *
				 ***********************************************************************/

				if (discern.startsWith("SHEET_SUMMARY_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  SHEET_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SHEET_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						ssOPE_NO = afterDiscern[0];
						ssSHEET_ID = afterDiscern[1];
						ssEND_TIME = afterDiscern[2];
						ssPARAM_COLLECTION = afterDiscern[3];
						ssPARAM_GROUP = afterDiscern[4];
						ssPARAM_NAME = afterDiscern[5];
						ssPARAM_VALUE = afterDiscern[6];
						ssAVG = afterDiscern[6];
						ssMAX = afterDiscern[7];
						ssMIN = afterDiscern[8];
						ssRANGE = afterDiscern[9];
						ssUNIFORMITY = afterDiscern[10];
						ssSTD = afterDiscern[11];
						ss3SIGMA = afterDiscern[12];
						ssSPEC_HIGH = afterDiscern[13];
						ssSPEC_LOW = afterDiscern[14];
						ssSPEC_TARGET = afterDiscern[15];
						ssCONTROL_HIGH = afterDiscern[16];
						ssCONTROL_LOW = afterDiscern[17];
						ssPARAM_JUDGE = afterDiscern[18];
						
						//for spc
						if (ssPARAM_NAME != null && ssPARAM_NAME.length() > 0 && !ssPARAM_NAME.trim().equals("")
								&& ssPARAM_VALUE != null && ssPARAM_VALUE.length() > 0 && !ssPARAM_VALUE.trim().equals("") 
								&& !ssPARAM_VALUE.trim().equalsIgnoreCase("NA"))
							{
								sPARAM_NAMES += ssPARAM_NAME + ","; 
								sPARAM_VALUES += ssPARAM_VALUE + ",";
							}

						parameterEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						parameterEntity.setPARAM_NAME(ssPARAM_NAME);
						parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						parameterEntity.setPARAM_GROUP(ssPARAM_GROUP);

						setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN,FID));

						testGlassSumEntity.setOPE_NO(esOPE_NO);
						testGlassSumEntity.setSHEET_ID(esSHEET_ID);
						testGlassSumEntity.setEND_TIME(esEND_TIME);
						testGlassSumEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						testGlassSumEntity.setPARAM_GROUP(ssPARAM_GROUP);
						testGlassSumEntity.setPARAM_NAME(ssPARAM_NAME);
						testGlassSumEntity.setPARAM_VALUE(ssPARAM_VALUE);
						testGlassSumEntity.setAVG(ssAVG);
						testGlassSumEntity.setMAX(ssMAX);
						testGlassSumEntity.setMIN(ssMIN);
						testGlassSumEntity.setRANGE(ssRANGE);
						testGlassSumEntity.setUNIFORMITY(ssUNIFORMITY);
						testGlassSumEntity.setSTD(ssSTD);
						testGlassSumEntity.setTHREE_SIGMA(ss3SIGMA);
						testGlassSumEntity.setSPEC_HIGH(ssSPEC_HIGH);
						testGlassSumEntity.setSPEC_LOW(ssSPEC_LOW);
						testGlassSumEntity.setSPEC_TARGET(ssSPEC_TARGET);
						testGlassSumEntity.setCONTROL_HIGH(ssCONTROL_HIGH);
						testGlassSumEntity.setCONTROL_LOW(ssCONTROL_LOW);
						testGlassSumEntity.setPARAM_JUDGE(ssPARAM_JUDGE);

						setEdaSuccessFlag(testGlassSumDao.addArrayTestGlassSum(testGlassSumEntity, EDA_CONN,FID));

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID : " + FID + "|| 【  SHEET_SUMMARY_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END * 设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** END ****
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取CHIP_DATA_BEGIN部分 ******** BEGIN *****
				 ***********************************************************************/
				if (discern.startsWith("CHIP_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  CHIP_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("CHIP_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						cOPE_NO = afterDiscern[0];
						cSHEET_ID = afterDiscern[1];
						cCHIP_ID = afterDiscern[2];
						cCHIP_NO = afterDiscern[3];
						cEND_TIME = afterDiscern[4];
						cJUDGE = afterDiscern[5];
						cMAIN_DEFECT_CODE = afterDiscern[6];
						cTTL_DEFECT_CNT = afterDiscern[7];
						cPANEL_SKIP_R = afterDiscern[8];
						cPANEL_FAIL_R = afterDiscern[9];
						cPATTERN_NAME = afterDiscern[10];
						cESS_FAIL = afterDiscern[11];

						testChipEntity.setOPE_NO(esOPE_NO);
						testChipEntity.setSHEET_ID(esSHEET_ID);
						testChipEntity.setCHIP_ID(cCHIP_ID);
						testChipEntity.setCHIP_NO(cCHIP_NO);
						testChipEntity.setEND_TIME(esEND_TIME);
						testChipEntity.setJUDGE(cJUDGE);
						testChipEntity.setMAIN_DEFECT_CODE(cMAIN_DEFECT_CODE);
						testChipEntity.setTTL_DEFECT_CNT(cTTL_DEFECT_CNT);
						testChipEntity.setPANEL_SKIP_R(cPANEL_SKIP_R);
						testChipEntity.setPATTERN_NAME(cPATTERN_NAME);
						testChipEntity.setESS_FAIL(cESS_FAIL);
						testChipEntity.setBLOCK_ID(esSHEET_ID+cCHIP_NO.substring(0, 1));
						testChipEntity.setBLOCK_FLAG(cCHIP_NO.substring(0, 1));
						
						setEdaSuccessFlag(testChipDao.addArrayTestChip(testChipEntity, EDA_CONN,FID));

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID : " + FID + "|| 【  CHIP_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END *** 设备抛出csv文件，读取CHIP_DATA_BEGIN部分 ******** END ********
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取CHIP_SUMMARY_DATA_BEGIN部分 ** BEGIN ***
				 ***********************************************************************/

				if (discern.startsWith("CHIP_SUMMARY_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  CHIP_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("CHIP_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						csOPE_NO = afterDiscern[0];
						csSHEET_ID = afterDiscern[1];
						csCHIP_ID = afterDiscern[2];
						csCHIP_NO = afterDiscern[3];
						csEND_TIME = afterDiscern[4];
						csPARAM_COLLECTION = afterDiscern[5];
						csPARAM_GROUP = afterDiscern[6];
						csPARAM_NAME = afterDiscern[7];
						csAVG = afterDiscern[8];
						csMAX = afterDiscern[9];
						csMIN = afterDiscern[10];
						csRANGE = afterDiscern[11];
						csUNIFORMITY = afterDiscern[12];
						csSTD = afterDiscern[13];
						cs3SIGMA = afterDiscern[14];
						csSPEC_HIGH = afterDiscern[15];
						csSPEC_LOW = afterDiscern[16];
						csSPEC_TARGET = afterDiscern[17];
						csCONTROL_HIGH = afterDiscern[18];
						csCONTROL_LOW = afterDiscern[19];

						DistinctParamNameUtil paramUtil =new DistinctParamNameUtil();
						int temp = paramUtil.selectParamName(EDA_CONN, csPARAM_NAME);
						if(temp==0){
						   parameterEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						   parameterEntity.setPARAM_NAME(csPARAM_NAME);
						   parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						   parameterEntity.setPARAM_GROUP(csPARAM_GROUP);
						   setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN, FID));
						}
						
						testChipSumEntity.setOPE_NO(esOPE_NO);
						testChipSumEntity.setSHEET_ID(esSHEET_ID);
						testChipSumEntity.setCHIP_ID(csCHIP_ID);
						testChipSumEntity.setCHIP_NO(csCHIP_NO);
						testChipSumEntity.setEND_TIME(esEND_TIME);
						testChipSumEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						testChipSumEntity.setPARAM_GROUP(csPARAM_GROUP);
						testChipSumEntity.setPARAM_NAME(csPARAM_NAME);
						testChipSumEntity.setAVG(csAVG);
						testChipSumEntity.setMAX(csMAX);
						testChipSumEntity.setMIN(csMIN);
						testChipSumEntity.setRANGE(csRANGE);
						testChipSumEntity.setUNIFORMITY(csUNIFORMITY);
						testChipSumEntity.setSTD(csSTD);
						testChipSumEntity.setTHREE_SIGMA(cs3SIGMA);
						testChipSumEntity.setSPEC_HIGH(csSPEC_HIGH);
						testChipSumEntity.setSPEC_LOW(csSPEC_LOW);
						testChipSumEntity.setSPEC_TARGET(csSPEC_TARGET);
						testChipSumEntity.setCONTROL_HIGH(csCONTROL_HIGH);
						testChipSumEntity.setCONTROL_LOW(csCONTROL_LOW);

						setEdaSuccessFlag(testChipSumDao.addArrayTestChipSum(testChipSumEntity, EDA_CONN,FID));

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID : " + FID + "|| 【  CHIP_SUMMARY_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取CHIP_SUMMARY_DATA_BEGIN部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("DEFECT_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  DEFECT_DATA_BEGIN 读取开始  】");
					discern = reader.readLine(); // 读取字段行名称
					int index = 0;
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DEFECT_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						dOPE_NO = afterDiscern[0];
						dSHEET_ID = afterDiscern[1];
						dCHIP_ID = afterDiscern[2];
						dCHIP_NO = afterDiscern[3];
						dEND_TIME = afterDiscern[4];
						dDEFECT_SEQ_NO = afterDiscern[5];
						dDEFECT_CODE = afterDiscern[6];
						dDEFECT_CODE_DESC = afterDiscern[7];
						dDEFECT_SIZE_TYPE = afterDiscern[8];
						dIMAGE_DATA = afterDiscern[9];
						dMAIN_DEFECT_FLAG = afterDiscern[10];
						dDEFECT_PATTERN = afterDiscern[11];
						dREJUDGE_FLAG = afterDiscern[12];
						dSIZE = afterDiscern[13];
						dS = afterDiscern[14];
						dG = afterDiscern[15];
						dX = afterDiscern[16];
						dY = afterDiscern[17];
						dX2 = afterDiscern[18];
						dY2 = afterDiscern[19];
						dX3 = afterDiscern[20];
						dY3 = afterDiscern[21];
						dDEFECT_SITE_AVG = afterDiscern[22];
						dREPEAT_FLAG = afterDiscern[23];
						dDEFECT_TYPE = afterDiscern[24];
						dREASON = afterDiscern[25];
						dGRAY_LEVEL = afterDiscern[26];
						dDEFECT_GL_AVE = afterDiscern[27];
						dPARTICLE_SIZE = afterDiscern[28];
						dPARTICLE_SIZE_X = afterDiscern[29];
						dPARTICLE_SIZE_Y = afterDiscern[30];
						dDEFECT_VOL = afterDiscern[31];
						dTH_VOL = afterDiscern[32];
						dS2 = afterDiscern[33];
						dG2 = afterDiscern[34];
						dMAX_VOL = afterDiscern[35];
						dMIN_VOL = afterDiscern[36];
						dSNR = afterDiscern[37];
						dDDS = afterDiscern[38];
						dDEVIATION = afterDiscern[39];
						dORIGINAL_X = afterDiscern[40];
						dORIGINAL_Y = afterDiscern[41];
						dMURA_RANGE_X = afterDiscern[42];
						dMURA_RANGE_Y = afterDiscern[43];

						testDefectEntity.setOPE_NO(esOPE_NO);
						testDefectEntity.setSHEET_ID(esSHEET_ID);
						testDefectEntity.setCHIP_ID(cCHIP_ID);
						testDefectEntity.setCHIP_NO(dCHIP_NO);
						testDefectEntity.setEND_TIME(esEND_TIME);
						testDefectEntity.setDEFECT_SEQ_NO(++index + "");
						testDefectEntity.setDEFECT_CODE(dDEFECT_CODE);
						testDefectEntity.setDEFECT_CODE_DESC(dDEFECT_CODE_DESC);
						testDefectEntity.setDEFECT_SIZE_TYPE(dDEFECT_SIZE_TYPE);
						testDefectEntity.setIMAGE_DATA(dIMAGE_DATA);
						testDefectEntity.setMAIN_DEFECT_FLAG(dMAIN_DEFECT_FLAG);
						testDefectEntity.setDEFECT_PATTERN(dDEFECT_PATTERN);
						testDefectEntity.setREJUDGE_FLAG(dREJUDGE_FLAG);
						testDefectEntity.setSIZE(dSIZE);
						testDefectEntity.setS(dS);
						testDefectEntity.setG(dG);
						testDefectEntity.setX(dX);
						testDefectEntity.setY(dY);
						testDefectEntity.setX2(dX2);
						testDefectEntity.setY2(dY2);
						testDefectEntity.setX3(dX3);
						testDefectEntity.setY3(dY3);
						testDefectEntity.setDEFECT_SITE_AVG(dDEFECT_SITE_AVG);
						testDefectEntity.setREPEAT_FLAG(dREPEAT_FLAG);
						testDefectEntity.setDEFECT_TYPE(dDEFECT_TYPE);
						testDefectEntity.setREASON(dREASON);
						testDefectEntity.setGRAY_LEVEL(dGRAY_LEVEL);
						testDefectEntity.setDEFECT_GL_AVE(dDEFECT_GL_AVE);
						testDefectEntity.setPARTICLE_SIZE(dPARTICLE_SIZE);
						testDefectEntity.setPARTICLE_SIZE_X(dPARTICLE_SIZE_X);
						testDefectEntity.setPARTICLE_SIZE_Y(dPARTICLE_SIZE_Y);
						testDefectEntity.setDEFECT_VOL(dDEFECT_VOL);
						testDefectEntity.setTH_VOL(dTH_VOL);
						testDefectEntity.setS2(dS2);
						testDefectEntity.setG2(dG2);
						testDefectEntity.setMAX_VOL(dMAX_VOL);
						testDefectEntity.setMIN_VOL(dMIN_VOL);
						testDefectEntity.setSNR(dSNR);
						testDefectEntity.setDDS(dDDS);
						testDefectEntity.setDEVIATION(dDEVIATION);
						testDefectEntity.setORIGINAL_X(dORIGINAL_X);
						testDefectEntity.setORIGINAL_Y(dORIGINAL_Y);
						testDefectEntity.setMURA_RANGE_X(dMURA_RANGE_X);
						testDefectEntity.setMURA_RANGE_Y(dMURA_RANGE_Y);
						
						setEdaSuccessFlag(testDefectDao.addArrayTestDefect(testDefectEntity, EDA_CONN,FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID : " + FID + "|| 【  DEFECT_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END ************s
				 ***********************************************************************/

			}

			try {
				
                List<String> list = getOXCountUtil.selectBlock(EDA_CONN);
                parameterEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
				parameterEntity.setPARAM_GROUP(ssPARAM_GROUP);
				parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
				testGlassSumEntity.setOPE_NO(esOPE_NO);
				testGlassSumEntity.setSHEET_ID(esSHEET_ID);
				testGlassSumEntity.setEND_TIME(esEND_TIME);
				testGlassSumEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
				for (int i = 0; i < list.size(); i++) {
					
					parameterEntity.setPARAM_NAME("BLOCK_CNT_O_"+list.get(i));
					setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN,FID));
					parameterEntity.setPARAM_NAME("BLOCK_CNT_X_"+list.get(i));
					setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN,FID));
					parameterEntity.setPARAM_NAME("BLOCK_YIELD_"+list.get(i));
					setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN,FID));
					
					testGlassSumEntity.setPARAM_NAME("BLOCK_CNT_O_"+list.get(i));
					testGlassSumEntity.setPARAM_VALUE(Integer.toString(getOXCountUtil.getOKCount(EDA_CONN, list.get(i))));
					setEdaSuccessFlag(testGlassSumDao.addBLockGlassSum(testGlassSumEntity, EDA_CONN,FID));
					testGlassSumEntity.setPARAM_NAME("BLOCK_CNT_X_"+list.get(i));
					testGlassSumEntity.setPARAM_VALUE(Integer.toString(getOXCountUtil.getNGCount(EDA_CONN, list.get(i))));
					setEdaSuccessFlag(testGlassSumDao.addBLockGlassSum(testGlassSumEntity, EDA_CONN,FID));
					testGlassSumEntity.setPARAM_NAME("BLOCK_YIELD_"+list.get(i));
					testGlassSumEntity.setPARAM_VALUE(getOXCountUtil.getYieldByBlockFlag(EDA_CONN, list.get(i)));
					setEdaSuccessFlag(testGlassSumDao.addBLockGlassSum(testGlassSumEntity, EDA_CONN,FID));
				}
				
				if (getEdaSuccessFlag()) {
					stmt = EDA_CONN.createStatement();
					stmt.executeQuery(loaderData);
					stmt.close();
				}
			} catch (Exception e) {
				reader.close();
				setEdaSuccessFlag(false);
				EDA_CONN.rollback();
				logger.error("FID : " + FID + "|| Call Loader Failed! Error Message:" + e.getMessage());
			}
			//SPC handle
			try {
				spcRunFlag = true;
				logger.info("FID : " + FID + "|| spc_enable = " + spc_enable);
				
				if (spc_enable.equalsIgnoreCase("true") && getEdaSuccessFlag()) {
					
					logger.info("FID : " + FID + "|| Start SPC running..");
					
					SPC_CONN = getSpcConnection();
					
					if (SPC_CONN.isClosed()) {
						logger.error("FID : " + FID + "|| The SPC database connection was error");
						setSpcSuccessFlag(false);
					}
					
					if (getSpcSuccessFlag()) {
						
						SpcLoaderEntity entity = new SpcLoaderEntity();
						
						entity.setProduct_id(replaceBlankToNull(dsPRODUCT_ID));
						entity.setRecipe_id(replaceBlankToNull(dsRECIPE_ID));
						entity.setEquip_type(replaceBlankToNull(hEQUIP_TYPE));
						entity.setEq_id(replaceBlankToNull(hEQ_ID));
						entity.setSubeq_id(replaceBlankToNull(hSubEQ_ID));
						entity.setOpe_no(replaceBlankToNull(dsOPE_NO));
						entity.setRoute_id(replaceBlankToNull(dsROUTE_ID));
						entity.setCassette_id(replaceBlankToNull(dsCASSETTE_ID));
						entity.setStart_time(replaceBlankToNull(esEND_TIME)); //special handle
						entity.setSheet_id(replaceBlankToNull(dsSHEET_ID));
						
						if(sPARAM_NAMES != null && sPARAM_VALUES != null
						   && !sPARAM_NAMES.trim().equals("") && !sPARAM_VALUES.trim().equals("")){
							logger.info("FID : " + FID + "|| call SPC loader.");
							setSpcSuccessFlag(LOAD_AR_TEST_SHEET.prepareSpcData(entity, sPARAM_NAMES, sPARAM_VALUES, SPC_CONN));
						}
					}
				}
				
			} catch (Exception ex) {
				
				setSpcSuccessFlag(false);
				logger.error("FID : " + FID + "|| Process SPC parsing error : " + ex.getMessage());
			}
			

		} catch (Exception ex) {

			reader.close();

			if (getEdaSuccessFlag()) {
				reader.close();
				setEdaSuccessFlag(false);
			}

		} finally {

			if (reader != null) {
				reader.close();
			}

		}
	}

	@Override
	public String getLoaderName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkFileFormat(File file) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}
	
}
