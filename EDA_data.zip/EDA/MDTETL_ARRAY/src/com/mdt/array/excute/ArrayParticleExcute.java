package com.mdt.array.excute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.array.array_particle.dao.ArrayParticleDefectDao;
import com.mdt.array.array_particle.dao.ArrayParticleGlassDao;
import com.mdt.array.array_particle.dao.ArrayParticleGlassSumDao;
import com.mdt.array.array_particle.entity.ArrayParticleDefectEntity;
import com.mdt.array.array_particle.entity.ArrayParticleGlassEntity;
import com.mdt.array.array_particle.entity.ArrayParticleGlassSumEntity;
import com.mdt.array.dao.ParameterDao;
import com.mdt.array.dao.ProductDao;
import com.mdt.array.dao.StepDao;
import com.mdt.array.entity.ParameterEntity;
import com.mdt.array.entity.ProductEntity;
import com.mdt.array.entity.StepEntity;
import com.mdt.array.spc.dao.LOAD_AR_PARTICLE_SHEET;
import com.mdt.array.spc.entity.SpcLoaderEntity;
import com.mdt.array.tableview.SessionConstants;
import com.mdt.array.util.DataFileFormatUtil;
import com.mdt.array.util.EdaSpcAbstractLoader;
import com.mdt.array.util.UpdateOpeNoUtil;

/**
 ***************************************************
 * @Title ArrayParticleExcute
 * @author 林华锋
 * @Date 2017年4月21日下午4:32:18
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class ArrayParticleExcute extends EdaSpcAbstractLoader {

	private static Logger logger = Logger.getLogger(ArrayParticleExcute.class);
    
	public ArrayParticleExcute() throws Exception{
		super(SessionConstants.GET_SYSTEM_CONFIG_DIR(), SessionConstants.GET_LOG_CONFIG_DIR());
	}
    
	public Connection EDA_CONN = null;
	public Connection SPC_CONN = null;
	public String discern; // 识别前字符
	public String[] afterDiscern; // 识别后字符
	public BufferedReader reader;
	public String loaderData = "begin array_file_loader.load_data; end;";
	public Statement stmt = null;

	/** 实例化实体类对象 Begin **/

	public ParameterEntity parameterEntity = new ParameterEntity();
	public ProductEntity productEntity = new ProductEntity();
	public StepEntity stepEntity = new StepEntity();
	public ArrayParticleGlassEntity particleGlassEntity = new ArrayParticleGlassEntity();
	public ArrayParticleGlassSumEntity particleGlassSumEntity = new ArrayParticleGlassSumEntity();
	public ArrayParticleDefectEntity particleDefectEntity = new ArrayParticleDefectEntity();
	public UpdateOpeNoUtil updateOpeNoUtil = new UpdateOpeNoUtil();
	
	/** 实例化实体类对象 End **/

	/** DAO */

	public ProductDao productDao;
	public ParameterDao parameterDao;
	public StepDao stepDao;
	public ArrayParticleGlassDao particleGlassDao;
	public ArrayParticleGlassSumDao particleGlassSumDao;
	public ArrayParticleDefectDao particleDefectDao;

	/** DAO */

	/****** Header_Begin 字段行 */

	public String hFILE_VERSION = null; // 文件版本
	public String hFILE_CREATED_TIME = null; // 创建时间
	public String hEQUIP_TYPE = null; // 设备类型
	public String hEQ_ID = null; // 设备ID
	public String hSubEQ_ID = null; // 子设备ID
	public String hCONTENT = null; // DataBlock内容标题

	/***** Header_End 字段行 */

	/** DOWNLOADED_SHEET_DATA_BEGIN 字段行 */

	public String dsOPE_NO = null;
	public String dsSHEET_ID = null;
	public String dsPRODUCT_ID = null;
	public String dsLOT_ID = null;
	public String dsRECIPE_ID = null;
	public String dsCASSETTE_ID = null;
	public String dsSLOT_NO = null;
	public String dsROUTE_ID = null;

	/** DOWNLOADED_SHEET_DATA_END 字段行 */

	/** EQP_SHEET_DATA_BEGIN 字段行 */

	public String esOPE_NO = null;
	public String esSHEET_ID = null;
	public String esSAMPLING_FLAG = null;
	public String esUSER_ID = null;
	public String esABNORMAL_FLAG = null;
	public String esSTART_TIME = null;
	public String esEND_TIME = null;
	public String esMAIN_JUDGE = null;
	public String esSHEET_JUDGE = null;
	public String esTTL_PANEL_CNT = null;
	public String esTACK_TIME = null;

	public String esFRONT_IMAGE_DATA = null;
	public String esBACK_IMAGE_DATA = null;
	public String esSYSTEM_STATUS = null;
	public String esDEFECT_OVERVIEW_IMAGE = null;
	public String esTTL_DEFECT_CNT = null;
	public String esBACK_TTL_DEFECT_CNT = null;
	public String esOVERFLOW = null;

	/** EQP_SHEET_DATA_END 字段行 */

	/** SHEET_SUMMARY_DATA_BEGIN 字段行 */

	public String ssOPE_NO = null;
	public String ssSHEET_ID = null;
	public String ssEND_TIME = null;
	public String ssPARAM_COLLECTION = null;
	public String ssPARAM_GROUP = null;
	public String ssPARAM_NAME = null;
	public String ssPARAM_VALUE = null;
	public String ssAVG = null;
	public String ssMAX = null;
	public String ssMIN = null;
	public String ssSTD = null;
	public String ssUNIFORMITY = null;
	public String ssRANGE = null;
	public String ss3SIGMA = null;
	public String ssSPEC_HIGH = null;
	public String ssSPEC_LOW = null;
	public String ssSPEC_TARGET = null;
	public String ssCONTROL_HIGH = null;
	public String ssCONTROL_LOW = null;
	public String ssCOLOR_NAME = null;
	public String ssPARAM_JUDGE = null;

	/** SHEET_SUMMARY_DATA_END 字段行 */

	/** DEFECT_DATA_BEGIN 字段行 */

	public String dOPE_NO = null;
	public String dSHEET_ID = null;
	public String dEND_TIME = null;
	public String dDEFECT_SEQ_NO = null;
	public String dCHIP_ID = null;
	public String dCHIP_NO = null;
	public String dDEFECT_CODE = null;
	public String dDEFECT_CODE_DESC = null;
	public String dDEFECT_PATTERN = null;
	public String dDEFECT_SIZE_TYPE = null;
	public String dIMAGE_DATA = null;
	public String dMAIN_DEFECT_FLAG = null;
	public String dREJUDGE_FLAG = null;
	public String dSIZE = null;
	public String dS = null;
	public String dG = null;
	public String dX = null;
	public String dY = null;
	public String dX2 = null;
	public String dY2 = null;
	public String dX3 = null;
	public String dY3 = null;

	/** DEFECT_DATA_END 字段行 */

	public static void main(String[] args) throws Exception {

		// args:{TID:0,Shop:1,Source:2,eqp_type:3,target_flag:4,WorkDir:5,max_count:6,SystemLocalConfigPath:7,LogConfigPath:8,db_find_method:9,export_log_file:10}
		if (args != null && args.length > 0) {
			SessionConstants.SET_TID(args[0]);
			SessionConstants.SET_SHOP(args[1]);
			SessionConstants.SET_SOURCE(args[2]);
			SessionConstants.SET_EQP_TYPE(args[3]);
			SessionConstants.SET_TARGET_FLAG(args[4]);
			SessionConstants.SET_WORK_DIR(args[5]);
			SessionConstants.SET_MAX_COUNT(args[6]);
			SessionConstants.SET_SYSTEM_CONFIG_DIR(args[7]);
			SessionConstants.SET_LOG_CONFIG_DIR(args[8]);
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(args[9]);
			SessionConstants.SET_EXPORT_LOG_FLAG(args[10]);
		} else {
			SessionConstants.SET_TID("ARRAY_FILE_PARTICLE_1"); // translator_config_t
			SessionConstants.SET_SHOP("ARRAY");
			SessionConstants.SET_SOURCE("FILE");
			SessionConstants.SET_EQP_TYPE("PARTICLE");
			SessionConstants.SET_TARGET_FLAG("0,1,2,3,4,5,6,7,8,9");
			SessionConstants.SET_WORK_DIR("E:\\TEST");
			SessionConstants.SET_MAX_COUNT("500");
			SessionConstants.SET_SYSTEM_CONFIG_DIR("E:\\Test\\system.properties");
			SessionConstants.SET_LOG_CONFIG_DIR("config/properties/log4j.properties");
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD("FALSE");
			SessionConstants.SET_EXPORT_LOG_FLAG("TRUE");

		}
		try {
			ArrayParticleExcute ParticleExcute = new ArrayParticleExcute();

			ParticleExcute.run();

		} catch (Exception e) {
			logger.error("There hava a error! Error Message: " + e.getMessage());
		}
	}

	@Override
	public void readyToRun(File file) throws Exception {

		logger.info("【  Translator Begin  】");

	    ReadDFSFile(file);
			
		logger.info("【   Translator End  】");
	}

	public void ReadDFSFile(File file) throws Exception {

		/** 判断是否连接 */
		EDA_CONN = getEdaConnection();

		if (EDA_CONN.isClosed()) {
			logger.error("The database connection was error");
		}

		/** 自动提交设置为false */
		EDA_CONN.setAutoCommit(false);

		try {
			String sPARAM_NAMES = ""; //for spc
			String sPARAM_VALUES = "";
			reader = new BufferedReader(new FileReader(file.getPath()));

			while ((discern = reader.readLine()) != null) {
				if (discern.length() == 0) {
					continue;
				}
				
				/***********************************************************************
				 * BEGIN ****************** 设备抛出csv文件，读取Header部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("HEADER_BEGIN")) {

					logger.info("【  HEADER_BEGIN 读取开始  】");

					while ((discern = reader.readLine()) != null && getEdaSuccessFlag()) {
						if (DataFileFormatUtil.Shift(discern).startsWith("FILE_VERSION")) {
							afterDiscern = discern.split(":", -1);
							hFILE_VERSION = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("FILE_CREATED_TIME")) {
							afterDiscern = discern.split(":", -1);
							hFILE_CREATED_TIME = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQUIP_TYPE")) {
							afterDiscern = discern.split(":", -1);
							hEQUIP_TYPE = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("SUBEQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hSubEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("CONTENT")) {
							afterDiscern = discern.split(":", -1);
							hCONTENT = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).endsWith("HEADER_END")) {
							break;
						}
					}
					logger.info("【  HEADER_END 读取结束  】");

				}
				/*********************************************************************
				 * END ******************** 设备抛出csv文件，读取Header部分 ****** END *
				 ********************************************************************/

				/***********************************************************************
				 * BEGIN ***************设备抛出csv文件，读取SHEET_DATA部分 ****** BEGIN *
				 ***********************************************************************/
				
				if (discern.startsWith("DOWNLOADED_SHEET_DATA_BEGIN")) {

					logger.info("【  DOWNLOADED_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DOWNLOADED_SHEET_DATA_END")) {
							break;
						}

                        afterDiscern = discern.split(",", -1);
                        
                        dsOPE_NO = afterDiscern[0];
                        dsROUTE_ID = afterDiscern[1];
                        dsSHEET_ID = afterDiscern[2];
                        dsPRODUCT_ID = afterDiscern[3];
                        dsRECIPE_ID = afterDiscern[4];
                        dsCASSETTE_ID = afterDiscern[5];
                        dsSLOT_NO = afterDiscern[6];

						productEntity.setPRODUCT_ID(dsPRODUCT_ID);
						productEntity.setPRODUCT_GROUP("DEFAULT");

						setEdaSuccessFlag(ProductDao.addProductTable(productEntity, EDA_CONN,FID));

						particleGlassEntity.setROUTE_ID(dsROUTE_ID);
						particleGlassEntity.setSHEET_ID(dsSHEET_ID);
						particleGlassEntity.setPRODUCT_ID(dsPRODUCT_ID);
						particleGlassEntity.setRECIPE_ID(dsRECIPE_ID);
						particleGlassEntity.setSLOT_NO(dsSLOT_NO);
						particleGlassEntity.setLOT_ID(lot_id);       //手动需修正
						particleGlassEntity.setPARENT_LOT(parent_lot_id); //手动需修正

					}
					logger.info("【  DOWNLOADED_SHEET_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END *******设备抛出csv文件，读取DOWNLOADED_SHEET_DATA部分 ****** END **
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN **** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** BEGIN *******
				 ***********************************************************************/
				if (discern.startsWith("EQP_SHEET_DATA_BEGIN")) {

					logger.info("【  EQP_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("EQP_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						esOPE_NO = afterDiscern[0];
						esSHEET_ID = afterDiscern[1];
						esSTART_TIME = afterDiscern[2];
						esEND_TIME = afterDiscern[3];
						esTACK_TIME = afterDiscern[4];
						esSAMPLING_FLAG = afterDiscern[5];
						esABNORMAL_FLAG = afterDiscern[6];
						esUSER_ID = afterDiscern[7];
						esMAIN_JUDGE = afterDiscern[8];
						esSHEET_JUDGE = afterDiscern[9];
						esTTL_PANEL_CNT = afterDiscern[10];
						esSYSTEM_STATUS = afterDiscern[11];
						esOVERFLOW = afterDiscern[12];
						esFRONT_IMAGE_DATA = afterDiscern[13];
						esBACK_IMAGE_DATA = afterDiscern[14];
						esDEFECT_OVERVIEW_IMAGE = afterDiscern[15];
						esTTL_DEFECT_CNT = afterDiscern[16];
						esBACK_TTL_DEFECT_CNT = afterDiscern[17];
						
						esOPE_NO = updateOpeNoUtil.updateOPE_NO(esOPE_NO, dsROUTE_ID, hEQ_ID);
						
						stepEntity.setSTEP_ID(esOPE_NO);
						stepEntity.setSTEP_SEQ(esOPE_NO);
						stepEntity.setSTEP_TYPE("M");
						stepEntity.setSTEP_GROUP(hEQUIP_TYPE);

						setEdaSuccessFlag(stepDao.addStepTable(stepEntity, EDA_CONN,FID));
						
						
						particleGlassEntity.setEQ_ID(hEQ_ID);
						particleGlassEntity.setSUBEQ_ID(hSubEQ_ID);
						particleGlassEntity.setOPE_NO(esOPE_NO);
						particleGlassEntity.setSHEET_ID(esSHEET_ID);
						particleGlassEntity.setSTART_TIME(esSTART_TIME);
						particleGlassEntity.setEND_TIME(esEND_TIME);
						particleGlassEntity.setTACK_TIME(esTACK_TIME);
						particleGlassEntity.setSAMPLING_FLAG(esSAMPLING_FLAG);
						particleGlassEntity.setABNORMAL_FLAG(esABNORMAL_FLAG);
						particleGlassEntity.setUSER_ID(esUSER_ID);
						particleGlassEntity.setMAIN_JUDGE(esMAIN_JUDGE);
						particleGlassEntity.setSHEET_JUDGE(esSHEET_JUDGE);
						particleGlassEntity.setTTL_PANEL_CNT(esTTL_PANEL_CNT);
						particleGlassEntity.setSYSTEM_STATUS(esSYSTEM_STATUS);
						particleGlassEntity.setOVERFLOW(esOVERFLOW);
						particleGlassEntity.setFRONT_IMAGE_DATA(esFRONT_IMAGE_DATA);
						particleGlassEntity.setBACK_IMAGE_DATA(esBACK_IMAGE_DATA);
						particleGlassEntity.setDEFECT_OVERVIEW_IMAGE(esDEFECT_OVERVIEW_IMAGE);
						particleGlassEntity.setTTL_DEFECT_CNT(esTTL_DEFECT_CNT);
						particleGlassEntity.setBACK_TTL_DEFECT_CNT(esBACK_TTL_DEFECT_CNT);

						setEdaSuccessFlag(ArrayParticleGlassDao.addArrayParticleGlass(particleGlassEntity, EDA_CONN,FID));

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("【  EQP_SHEET_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END ********** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** BEGIN *
				 ***********************************************************************/

				if (discern.startsWith("SHEET_SUMMARY_DATA_BEGIN")) {

					logger.info("【  SHEET_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SHEET_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						ssOPE_NO = afterDiscern[0];
						ssSHEET_ID = afterDiscern[1];
						ssEND_TIME = afterDiscern[2];
						ssPARAM_COLLECTION = afterDiscern[3];
						ssPARAM_GROUP = afterDiscern[4];
						ssPARAM_NAME = afterDiscern[5];
						ssPARAM_VALUE = afterDiscern[6];
						ssAVG = afterDiscern[7];
						ssMAX = afterDiscern[8];
						ssMIN = afterDiscern[9];
						ssRANGE = afterDiscern[10];
						ssUNIFORMITY = afterDiscern[11];
						ssSTD = afterDiscern[12];
						ss3SIGMA = afterDiscern[13];
						ssSPEC_HIGH = afterDiscern[14];
						ssSPEC_LOW = afterDiscern[15];
						ssSPEC_TARGET = afterDiscern[16];
						ssCONTROL_HIGH = afterDiscern[17];
						ssCONTROL_LOW = afterDiscern[18];
						ssPARAM_JUDGE = afterDiscern[19];
						
						//for spc
						if (ssPARAM_NAME != null && ssPARAM_NAME.length() > 0 && !ssPARAM_NAME.trim().equals("")
								&& ssPARAM_VALUE != null && ssPARAM_VALUE.length() > 0 && !ssPARAM_VALUE.trim().equals("") 
								&& !ssPARAM_VALUE.trim().equalsIgnoreCase("NA"))
							{
								sPARAM_NAMES += ssPARAM_NAME + ","; 
								sPARAM_VALUES += ssPARAM_VALUE + ",";
							}


						parameterEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						parameterEntity.setPARAM_NAME(ssPARAM_NAME);
						parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						parameterEntity.setPARAM_GROUP(ssPARAM_GROUP);

						setEdaSuccessFlag(ParameterDao.addParameterTable(parameterEntity, EDA_CONN,FID));
						
						particleGlassSumEntity.setOPE_NO(esOPE_NO);
						particleGlassSumEntity.setSHEET_ID(esSHEET_ID);
						particleGlassSumEntity.setEND_TIME(esEND_TIME);
						particleGlassSumEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						particleGlassSumEntity.setPARAM_GROUP(ssPARAM_GROUP);
						particleGlassSumEntity.setPARAM_NAME(ssPARAM_NAME);
						particleGlassSumEntity.setPARAM_VALUE(ssPARAM_VALUE);
						particleGlassSumEntity.setAVG(ssAVG);
						particleGlassSumEntity.setMAX(ssMAX);
						particleGlassSumEntity.setMIN(ssMIN);
						particleGlassSumEntity.setRANGE(ssRANGE);
						particleGlassSumEntity.setUNIFORMITY(ssUNIFORMITY);
						particleGlassSumEntity.setSTD(ssSTD);
						particleGlassSumEntity.setTHREE_SIGMA(ss3SIGMA);
						particleGlassSumEntity.setSPEC_HIGH(ssSPEC_HIGH);
						particleGlassSumEntity.setSPEC_LOW(ssSPEC_LOW);
						particleGlassSumEntity.setSPEC_TARGET(ssSPEC_TARGET);
						particleGlassSumEntity.setCONTROL_HIGH(ssCONTROL_HIGH);
						particleGlassSumEntity.setCONTROL_LOW(ssCONTROL_LOW);
						
						setEdaSuccessFlag(ArrayParticleGlassSumDao.addArrayParticleGlassSum(particleGlassSumEntity, EDA_CONN,FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("【  SHEET_SUMMARY_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END * 设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** END ****
				 ***********************************************************************
	
			    /************************************************************************ 
			     * BEGIN *** 设备抛出csv文件，读取DEFECT_DATA_BEGIN部分         ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("DEFECT_DATA_BEGIN")) {

					logger.info("【  DEFECT_DATA_BEGIN 读取开始  】");
					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DEFECT_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						dOPE_NO = afterDiscern[0];
						dSHEET_ID = afterDiscern[1];
						dCHIP_ID = afterDiscern[2];
						dCHIP_NO = afterDiscern[3];
						dEND_TIME = afterDiscern[4];
						dDEFECT_SEQ_NO = afterDiscern[5];
						dDEFECT_CODE = afterDiscern[6];
						dDEFECT_CODE_DESC = afterDiscern[7];
						dDEFECT_PATTERN = afterDiscern[8];
						dDEFECT_SIZE_TYPE = afterDiscern[9];
						dIMAGE_DATA = afterDiscern[10];
						dMAIN_DEFECT_FLAG = afterDiscern[11];
						dREJUDGE_FLAG = afterDiscern[12];
						dSIZE = afterDiscern[13];
						dS = afterDiscern[14];
						dG = afterDiscern[15];
						dX = afterDiscern[16];
						dY = afterDiscern[17];
						dX2 = afterDiscern[18];
						dY2 = afterDiscern[19];
						dX3 = afterDiscern[20];
						dY3 = afterDiscern[21];

						particleDefectEntity.setOPE_NO(esOPE_NO);
						particleDefectEntity.setSHEET_ID(esSHEET_ID);
						particleDefectEntity.setCHIP_ID(dCHIP_ID);
						particleDefectEntity.setCHIP_NO(dCHIP_NO);
						particleDefectEntity.setEND_TIME(esEND_TIME);
						particleDefectEntity.setDEFECT_SEQ_NO(dDEFECT_SEQ_NO);
						particleDefectEntity.setDEFECT_CODE(dDEFECT_CODE);
						particleDefectEntity.setDEFECT_PATTERN(dDEFECT_PATTERN);
						particleDefectEntity.setDEFECT_SIZE_TYPE(dDEFECT_SIZE_TYPE);
						particleDefectEntity.setIMAGE_DATA(dIMAGE_DATA);
						particleDefectEntity.setMAIN_DEFECT_FLAG(dMAIN_DEFECT_FLAG);
						particleDefectEntity.setREJUDGE_FLAG(dREJUDGE_FLAG);
						particleDefectEntity.setSIZE(dDEFECT_SIZE_TYPE);
						particleDefectEntity.setS(dS);
						particleDefectEntity.setG(dG);
						particleDefectEntity.setX(dX);
						particleDefectEntity.setY(dY);
						particleDefectEntity.setX2(dX2);
						particleDefectEntity.setY2(dY2);
						particleDefectEntity.setX3(dX3);
						particleDefectEntity.setY3(dY3);
						
						setEdaSuccessFlag(ArrayParticleDefectDao.addArrayParticleDefect(particleDefectEntity, EDA_CONN,FID));

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("【  DEFECT_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取DEFECT_DATA_END部分 ********** END *******
				 ***********************************************************************/

			}

			try {
				if (getEdaSuccessFlag()) {
					stmt = EDA_CONN.createStatement();
					stmt.executeQuery(loaderData);
					stmt.close();
				}
			} catch (Exception e) {
				reader.close();
				setEdaSuccessFlag(false);
				EDA_CONN.rollback();
				logger.error("Call Loader Failed! Error Message:" + e.getMessage());
			}
			//SPC handle
			try {
				spcRunFlag = true;
				logger.info("FID : " + FID + "|| spc_enable = " + spc_enable);
				
				if (spc_enable.equalsIgnoreCase("true") && getEdaSuccessFlag()) {
					
					logger.info("FID : " + FID + "|| Start SPC running..");
					
					SPC_CONN = getSpcConnection();
					
					if (SPC_CONN.isClosed()) {
						logger.error("FID : " + FID + "|| The SPC database connection was error");
						setSpcSuccessFlag(false);
					}
					
					if (getSpcSuccessFlag()) {
						
						SpcLoaderEntity entity = new SpcLoaderEntity();
						
						entity.setProduct_id(replaceBlankToNull(dsPRODUCT_ID));
						entity.setRecipe_id(replaceBlankToNull(dsRECIPE_ID));
						entity.setEquip_type(replaceBlankToNull(hEQUIP_TYPE));
						entity.setEq_id(replaceBlankToNull(hEQ_ID));
						entity.setSubeq_id(replaceBlankToNull(hSubEQ_ID));
						entity.setOpe_no(replaceBlankToNull(dsOPE_NO));
						entity.setRoute_id(replaceBlankToNull(dsROUTE_ID));
						entity.setCassette_id(replaceBlankToNull(dsCASSETTE_ID));
						entity.setStart_time(replaceBlankToNull(esEND_TIME)); //special handle
						entity.setSheet_id(replaceBlankToNull(dsSHEET_ID));
						
						if(sPARAM_NAMES != null && sPARAM_VALUES != null
						   && !sPARAM_NAMES.trim().equals("") && !sPARAM_VALUES.trim().equals("")){
							logger.info("FID : " + FID + "|| call SPC loader.");
							setSpcSuccessFlag(LOAD_AR_PARTICLE_SHEET.prepareSpcData(entity, sPARAM_NAMES, sPARAM_VALUES, SPC_CONN));
						}
					}
				}
				
			} catch (Exception ex) {
				
				setSpcSuccessFlag(false);
				logger.error("FID : " + FID + "|| Process SPC parsing error : " + ex.getMessage());
			}
		} catch (Exception ex) {

			reader.close();
			logger.error("Ready to run error : " + ex.getMessage());

			if (getEdaSuccessFlag()) {
				reader.close();
				setEdaSuccessFlag(false);
			}

		} finally {

			if (reader != null) {
				reader.close();
			}

		}
	}

	@Override
	public String getLoaderName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkFileFormat(File file) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

}
