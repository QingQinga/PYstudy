package com.mdt.array.excute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.array.array_measure.dao.ArrayMeasureGlassDao;
import com.mdt.array.array_measure.dao.ArrayMeasureGlassSumDao;
import com.mdt.array.array_measure.dao.ArrayMeasureResultDao;
import com.mdt.array.array_measure.entity.ArrayMeasureGlassEntity;
import com.mdt.array.array_measure.entity.ArrayMeasureGlassSumEntity;
import com.mdt.array.array_measure.entity.ArrayMeasureResultEntity;
import com.mdt.array.dao.ParameterDao;
import com.mdt.array.dao.ProductDao;
import com.mdt.array.dao.StepDao;
import com.mdt.array.entity.ParameterEntity;
import com.mdt.array.entity.ProductEntity;
import com.mdt.array.entity.StepEntity;
import com.mdt.array.spc.dao.LOAD_AR_WLI_SHEET;
import com.mdt.array.spc.entity.SpcLoaderEntity;
import com.mdt.array.tableview.SessionConstants;
import com.mdt.array.util.DataFileFormatUtil;
import com.mdt.array.util.DistinctParamNameUtil;
import com.mdt.array.util.EdaSpcAbstractLoader;
import com.mdt.array.util.UpdateOpeNoUtil;

/**
 ***************************************************
 * @Title ArrayWLIExcute
 * @author 林华锋
 * @Date 2017年4月21日下午4:58:00
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class ArrayWLIExcute extends EdaSpcAbstractLoader {

	private static Logger logger = Logger.getLogger(ArrayWLIExcute.class);

	public ArrayWLIExcute() throws Exception {
		super(SessionConstants.GET_SYSTEM_CONFIG_DIR(), SessionConstants.GET_LOG_CONFIG_DIR());
	}

	public Connection EDA_CONN = null;
	public Connection SPC_CONN = null;
	public String discern; // 识别前字符
	public String[] afterDiscern; // 识别后字符
	public BufferedReader reader;
	public String loaderData = "begin array_file_loader.load_data; end;";
	public Statement stmt = null;

	/** 实例化实体类对象 Begin **/

	public ParameterEntity parameterEntity = new ParameterEntity();
	public ProductEntity productEntity = new ProductEntity();
	public StepEntity stepEntity = new StepEntity();
	public ArrayMeasureGlassEntity measureGlassEntity = new ArrayMeasureGlassEntity();
	public ArrayMeasureGlassSumEntity measureGlassSumEntity = new ArrayMeasureGlassSumEntity();
	public ArrayMeasureResultEntity measureResultEntity = new ArrayMeasureResultEntity();
	public UpdateOpeNoUtil updateOpeNoUtil = new UpdateOpeNoUtil();
	
	/** 实例化实体类对象 End **/

	/** DAO */

	public ProductDao productDao;
	public ParameterDao parameterDao;
	public StepDao stepDao;
	public ArrayMeasureGlassDao measureGlassDao;
	public ArrayMeasureGlassSumDao measureGlassSumDao;
	public ArrayMeasureResultDao measureResultDao;

	/** DAO */

	/****** Header_Begin 字段行 */

	public String hFILE_VERSION = null; // 文件版本
	public String hFILE_CREATED_TIME = null; // 创建时间
	public String hEQUIP_TYPE = null; // 设备类型
	public String hEQ_ID = null; // 设备ID
	public String hSubEQ_ID = null; // 子设备ID
	public String hCONTENT = null; // DataBlock内容标题

	/***** Header_End 字段行 */

	/** DOWNLOADED_SHEET_DATA_BEGIN 字段行 */

	public String dsOPE_NO = null;
	public String dsSHEET_ID = null;
	public String dsPRODUCT_ID = null;
	public String dsLOT_ID = null;
	public String dsRECIPE_ID = null;
	public String dsCASSETTE_ID = null;
	public String dsSLOT_NO = null;
	public String dsROUTE_ID = null;

	/** DOWNLOADED_SHEET_DATA_END 字段行 */

	/** EQP_SHEET_DATA_BEGIN 字段行 */

	public String esOPE_NO = null;
	public String esSHEET_ID = null;
	public String esSAMPLING_FLAG = null;
	public String esUSER_ID = null;
	public String esABNORMAL_FLAG = null;
	public String esSTART_TIME = null;
	public String esEND_TIME = null;
	public String esMAIN_JUDGE = null;
	public String esSHEET_JUDGE = null;
	public String esTTL_PANEL_CNT = null;
	public String esTACK_TIME = null;

	/** EQP_SHEET_DATA_END 字段行 */

	/** SHEET_SUMMARY_DATA_BEGIN 字段行 */

	public String ssOPE_NO = null;
	public String ssSHEET_ID = null;
	public String ssEND_TIME = null;
	public String ssPARAM_COLLECTION = null;
	public String ssPARAM_GROUP = null;
	public String ssPARAM_NAME = null;
	public String ssPARAM_VALUE = null;
	public String ssAVG = null;
	public String ssMAX = null;
	public String ssMIN = null;
	public String ssSTD = null;
	public String ssUNIFORMITY = null;
	public String ssRANGE = null;
	public String ss3SIGMA = null;
	public String ssSPEC_HIGH = null;
	public String ssSPEC_LOW = null;
	public String ssSPEC_TARGET = null;
	public String ssCONTROL_HIGH = null;
	public String ssCONTROL_LOW = null;
	public String ssCOLOR_NAME = null;
	public String ssPARAM_JUDGE = null;

	/** SHEET_SUMMARY_DATA_END 字段行 */

	/** SITE_DATA_BEGIN 字段行 */

	public String sOPE_NO = null;
	public String sSHEET_ID = null;
	public String sEND_TIME = null;
	public String sSITE_NAME = null;
	public String sPARAM_COLLECTION = null;
	public String sPARAM_GROUP = null;
	public String sPARAM_NAME = null;
	public String sPARAM_VALUE = null;
	public String sX = null;
	public String sY = null;
	public String sSPEC_HIGH = null;
	public String sSPEC_LOW = null;
	public String sSPEC_TARGET = null;
	public String sCONTROL_HIGH = null;
	public String sCONTROL_LOW = null;
	public String sCHIP_ID = null;
	public String sCHIP_NO = null;
	public String sJUDGE = null;

	public String TEMPLATE_NO = null;
	public String IMAGE_DATA = null;
	public String TABLE_NO = null;
	public String HEAD_NO = null;

	/** SITE_DATA_END 字段行 */

	public static void main(String[] args) throws Exception {

		// args:{TID:0,Shop:1,Source:2,eqp_type:3,target_flag:4,WorkDir:5,max_count:6,SystemLocalConfigPath:7,LogConfigPath:8,db_find_method:9,export_log_file:10}
		if (args != null && args.length > 0) {
			SessionConstants.SET_TID(args[0]);
			SessionConstants.SET_SHOP(args[1]);
			SessionConstants.SET_SOURCE(args[2]);
			SessionConstants.SET_EQP_TYPE(args[3]);
			SessionConstants.SET_TARGET_FLAG(args[4]);
			SessionConstants.SET_WORK_DIR(args[5]);
			SessionConstants.SET_MAX_COUNT(args[6]);
			SessionConstants.SET_SYSTEM_CONFIG_DIR(args[7]);
			SessionConstants.SET_LOG_CONFIG_DIR(args[8]);
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(args[9]);
			SessionConstants.SET_EXPORT_LOG_FLAG(args[10]);
		} else {
			SessionConstants.SET_TID("ARRAY_FILE_WLI_1"); // translator_config_t
			SessionConstants.SET_SHOP("ARRAY");
			SessionConstants.SET_SOURCE("FILE");
			SessionConstants.SET_EQP_TYPE("WLI");
			SessionConstants.SET_TARGET_FLAG("0,1,2,3,4,5,6,7,8,9");
			SessionConstants.SET_WORK_DIR("D:\\Test");
			SessionConstants.SET_MAX_COUNT("1");
			SessionConstants.SET_SYSTEM_CONFIG_DIR("D:\\Test\\system.properties");
			SessionConstants.SET_LOG_CONFIG_DIR("D:/Test/log4j.properties");
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD("FALSE");
			SessionConstants.SET_EXPORT_LOG_FLAG("TRUE");
		}

		try {
			ArrayWLIExcute WLIExcute = new ArrayWLIExcute();

			WLIExcute.run();

		} catch (Exception e) {
			logger.error("There hava a error! Error Message: " + e.getMessage());
		}

	}

	@Override
	public void readyToRun(File file) throws Exception {

		logger.info("【  Translator Begin  】");

		ReadDFSFile(file);

		logger.info("【   Translator End  】");
	}

	@SuppressWarnings("static-access")
	public void ReadDFSFile(File file) throws Exception {

		/** 判断是否连接 */
		EDA_CONN = getEdaConnection();
		
		if (EDA_CONN.isClosed()) {
			logger.error("The database connection was error");
		}

		/** 自动提交设置为false */
		EDA_CONN.setAutoCommit(false);

		try {
			String sPARAM_NAMES = ""; //for spc
			String sPARAM_VALUES = "";
			reader = new BufferedReader(new FileReader(file.getPath()));

			while ((discern = reader.readLine()) != null) {
				if (discern.length() == 0) {
					continue;
				}
				/***********************************************************************
				 * BEGIN ****************** 设备抛出csv文件，读取Header部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("HEADER_BEGIN")) {

					logger.info("【  HEADER_BEGIN 读取开始  】");

					while ((discern = reader.readLine()) != null && getEdaSuccessFlag()) {
						if (DataFileFormatUtil.Shift(discern).startsWith("FILE_VERSION")) {
							afterDiscern = discern.split(":", -1);
							hFILE_VERSION = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("FILE_CREATED_TIME")) {
							afterDiscern = discern.split(":", -1);
							hFILE_CREATED_TIME = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQUIP_TYPE")) {
							afterDiscern = discern.split(":", -1);
							hEQUIP_TYPE = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("SUBEQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hSubEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("CONTENT")) {
							afterDiscern = discern.split(":", -1);
							hCONTENT = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).endsWith("HEADER_END")) {
							break;
						}
					}
					logger.info("【  HEADER_END 读取结束  】");

				}
				/*********************************************************************
				 * END ******************** 设备抛出csv文件，读取Header部分 ****** END *
				 ********************************************************************/

				/***********************************************************************
				 * BEGIN ***************设备抛出csv文件，读取SHEET_DATA部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("DOWNLOADED_SHEET_DATA_BEGIN")) {

					logger.info("【  DOWNLOADED_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DOWNLOADED_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						dsOPE_NO = afterDiscern[0];
						dsROUTE_ID = afterDiscern[1];
						dsSHEET_ID = afterDiscern[2];
						dsPRODUCT_ID = afterDiscern[3];
						dsRECIPE_ID = afterDiscern[4];
						dsCASSETTE_ID = afterDiscern[5];
						dsSLOT_NO = afterDiscern[6];

						productEntity.setPRODUCT_ID(dsPRODUCT_ID);
						productEntity.setPRODUCT_GROUP("DEFAULT");

						setEdaSuccessFlag(productDao.addProductTable(productEntity, EDA_CONN,FID));

						measureGlassEntity.setROUTE_ID(dsROUTE_ID);
						measureGlassEntity.setPRODUCT_ID(dsPRODUCT_ID);
						measureGlassEntity.setRECIPE_ID(dsRECIPE_ID);
						measureGlassEntity.setCASSETTE_ID(dsCASSETTE_ID);
						measureGlassEntity.setSLOT_NO(dsSLOT_NO);
						measureGlassEntity.setLOT_ID(lot_id);
						measureGlassEntity.setPARENT_LOT(parent_lot_id);

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}
					logger.info("【  DOWNLOADED_SHEET_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END *******设备抛出csv文件，读取DOWNLOADED_SHEET_DATA部分 ****** END **
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN **** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** BEGIN *******
				 ***********************************************************************/
				if (discern.startsWith("EQP_SHEET_DATA_BEGIN")) {

					logger.info("【  EQP_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {

						if (DataFileFormatUtil.Shift(discern).startsWith("EQP_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						esOPE_NO = afterDiscern[0];
						esSHEET_ID = afterDiscern[1];
						esSTART_TIME = afterDiscern[2];
						esEND_TIME = afterDiscern[3];
						esTACK_TIME = afterDiscern[4];
						esSAMPLING_FLAG = afterDiscern[5];
						esABNORMAL_FLAG = afterDiscern[6];
						esUSER_ID = afterDiscern[7];
						esMAIN_JUDGE = afterDiscern[8];
						esSHEET_JUDGE = afterDiscern[9];
						esTTL_PANEL_CNT = afterDiscern[10];
						
						esOPE_NO = updateOpeNoUtil.updateOPE_NO(esOPE_NO, dsROUTE_ID, hEQ_ID);
						
						stepEntity.setSTEP_ID(esOPE_NO);
						stepEntity.setSTEP_SEQ(esOPE_NO);
						stepEntity.setSTEP_TYPE("M");
						stepEntity.setSTEP_GROUP(hEQUIP_TYPE);

						setEdaSuccessFlag(stepDao.addStepTable(stepEntity, EDA_CONN,FID));
						
						measureGlassEntity.setEQ_ID(hEQ_ID);
						measureGlassEntity.setSUBEQ_ID(hSubEQ_ID);
						measureGlassEntity.setOPE_NO(esOPE_NO);
						measureGlassEntity.setSHEET_ID(esSHEET_ID);
						measureGlassEntity.setSTART_TIME(esSTART_TIME);
						measureGlassEntity.setEND_TIME(esEND_TIME);
						measureGlassEntity.setTACK_TIME(esTACK_TIME);
						measureGlassEntity.setSAMPLING_FLAG(esSAMPLING_FLAG);
						measureGlassEntity.setABNORMAL_FLAG(esABNORMAL_FLAG);
						measureGlassEntity.setUSER_ID(esUSER_ID);
						measureGlassEntity.setMAIN_JUDGE(esMAIN_JUDGE);
						measureGlassEntity.setSHEET_JUDGE(esSHEET_JUDGE);
						measureGlassEntity.setTTL_PANEL_CNT(esTTL_PANEL_CNT);

						setEdaSuccessFlag(measureGlassDao.addArrayMeasureGlass(measureGlassEntity, EDA_CONN,FID));

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("【  EQP_SHEET_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END ********** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** BEGIN *
				 ***********************************************************************/

				if (discern.startsWith("SHEET_SUMMARY_DATA_BEGIN")) {

					logger.info("【  SHEET_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SHEET_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						ssOPE_NO = afterDiscern[0];
						ssSHEET_ID = afterDiscern[1];
						ssEND_TIME = afterDiscern[2];
						ssPARAM_COLLECTION = afterDiscern[3];
						ssPARAM_GROUP = afterDiscern[4];
						ssPARAM_NAME = afterDiscern[5];
						ssPARAM_VALUE = afterDiscern[6];
						ssAVG = afterDiscern[7];
						ssMAX = afterDiscern[8];
						ssMIN = afterDiscern[9];
						ssRANGE = afterDiscern[10];
						ssUNIFORMITY = afterDiscern[11];
						ssSTD = afterDiscern[12];
						ss3SIGMA = afterDiscern[13];
						ssSPEC_HIGH = afterDiscern[14];
						ssSPEC_LOW = afterDiscern[15];
						ssSPEC_TARGET = afterDiscern[16];
						ssCONTROL_HIGH = afterDiscern[17];
						ssCONTROL_LOW = afterDiscern[18];
						ssPARAM_JUDGE = afterDiscern[19];

						parameterEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						parameterEntity.setPARAM_NAME(ssPARAM_NAME);
						parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						parameterEntity.setPARAM_GROUP(ssPARAM_GROUP);

						setEdaSuccessFlag(ParameterDao.addParameterTable(parameterEntity, EDA_CONN,FID));
						
						measureGlassSumEntity.setOPE_NO(esOPE_NO);
						measureGlassSumEntity.setSHEET_ID(esSHEET_ID);
						measureGlassSumEntity.setEND_TIME(esEND_TIME);
						measureGlassSumEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						measureGlassSumEntity.setPARAM_GROUP(ssPARAM_GROUP);
						measureGlassSumEntity.setPARAM_NAME(ssPARAM_NAME);
						measureGlassSumEntity.setPARAM_VALUE(ssPARAM_VALUE);
						measureGlassSumEntity.setAVG(ssAVG);
						measureGlassSumEntity.setMAX(ssMAX);
						measureGlassSumEntity.setMIN(ssMIN);
						measureGlassSumEntity.setRANGE(ssRANGE);
						measureGlassSumEntity.setUNIFORMITY(ssUNIFORMITY);
						measureGlassSumEntity.setSTD(ssSTD);
						measureGlassSumEntity.setTHREE_SIGMA(ss3SIGMA);
						measureGlassSumEntity.setSPEC_HIGH(ssSPEC_HIGH);
						measureGlassSumEntity.setSPEC_LOW(ssSPEC_LOW);
						measureGlassSumEntity.setSPEC_TARGET(ssSPEC_TARGET);
						measureGlassSumEntity.setCONTROL_HIGH(ssCONTROL_HIGH);
						measureGlassSumEntity.setCONTROL_LOW(ssCONTROL_LOW);
						measureGlassSumEntity.setPARAM_JUDGE(ssPARAM_JUDGE);

						setEdaSuccessFlag(measureGlassSumDao.addArrayMeasureGlassSum(measureGlassSumEntity, EDA_CONN,FID));

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("【  SHEET_SUMMARY_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END * 设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** END ****
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("SITE_DATA_BEGIN")) {

					logger.info("【  SITE_DATA_BEGIN 读取开始  】");
					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SITE_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						sOPE_NO = afterDiscern[0];
						sSHEET_ID = afterDiscern[1];
						sCHIP_ID = afterDiscern[2];
						sCHIP_NO = afterDiscern[3];
						sEND_TIME = afterDiscern[4];
						sPARAM_COLLECTION = afterDiscern[5];
						sPARAM_GROUP = afterDiscern[6];
						sPARAM_NAME = afterDiscern[7];
						sSITE_NAME = afterDiscern[8];
						sPARAM_VALUE = afterDiscern[9];
						sJUDGE = afterDiscern[10];
						sX = afterDiscern[11];
						sY = afterDiscern[12];
						sSPEC_HIGH = afterDiscern[13];
						sSPEC_LOW = afterDiscern[14];
						sSPEC_TARGET = afterDiscern[15];
						sCONTROL_HIGH = afterDiscern[16];
						sCONTROL_LOW = afterDiscern[17];
						
						//for SPC
						if (sPARAM_NAME != null && sPARAM_NAME.length() > 0 && !sPARAM_NAME.trim().equals("")
								&& sPARAM_VALUE != null && sPARAM_VALUE.length() > 0 && !sPARAM_VALUE.trim().equals("") 
								&& !sPARAM_VALUE.trim().equalsIgnoreCase("NA"))
							{
								sPARAM_NAMES += sPARAM_NAME + ","; 
								sPARAM_VALUES += sPARAM_VALUE + ",";
							}

						measureResultEntity.setOPE_NO(esOPE_NO);
						measureResultEntity.setSHEET_ID(esSHEET_ID);
						measureResultEntity.setCHIP_ID(sCHIP_ID);
						measureResultEntity.setCHIP_NO(sCHIP_NO);
						measureResultEntity.setEND_TIME(esEND_TIME);
						measureResultEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						measureResultEntity.setPARAM_GROUP(sPARAM_GROUP);
						measureResultEntity.setPARAM_NAME(sPARAM_NAME);
						measureResultEntity.setSITE_NAME(sSITE_NAME);
						measureResultEntity.setPARAM_VALUE(sPARAM_VALUE);
						measureResultEntity.setJUDGE(sJUDGE);
						measureResultEntity.setX(sX);
						measureResultEntity.setY(sY);
						measureResultEntity.setSPEC_HIGH(sSPEC_HIGH);
						measureResultEntity.setSPEC_LOW(sSPEC_LOW);
						measureResultEntity.setSPEC_TARGET(sSPEC_TARGET);
						measureResultEntity.setCONTROL_HIGH(sCONTROL_HIGH);
						measureResultEntity.setCONTROL_LOW(sCONTROL_LOW);
						
						DistinctParamNameUtil paramUtil =new DistinctParamNameUtil();
						int temp = paramUtil.selectParamName(EDA_CONN, sPARAM_NAME);
						if(temp==0){
						   parameterEntity.setPARAM_COLLECTION(esOPE_NO+"_"+dsRECIPE_ID);
						   parameterEntity.setPARAM_NAME(sPARAM_NAME);
						   parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						   parameterEntity.setPARAM_GROUP(sPARAM_GROUP);

						   setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN, FID));
						}
						
						if(DataFileFormatUtil.isNumber(sPARAM_VALUE.trim())||sPARAM_VALUE.trim().equals("NA")){
						  
							measureResultEntity.setPARAM_VALUE(sPARAM_VALUE.trim());
							setEdaSuccessFlag(ArrayMeasureResultDao.addArrayMeasureResult(measureResultEntity, EDA_CONN,FID));
						}else{
						   
							measureResultEntity.setPARAM_VALUE_STR(sPARAM_VALUE.trim());
							setEdaSuccessFlag(ArrayMeasureResultDao.addArrayMeasureResultStr(measureResultEntity, EDA_CONN,FID));
						}
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("【  SITE_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END *******
				 ***********************************************************************/

			}

			try {
				if (getEdaSuccessFlag()) {
					stmt = EDA_CONN.createStatement();
					stmt.executeQuery(loaderData);
					stmt.close();
				}
			} catch (Exception e) {
				reader.close();
				setEdaSuccessFlag(false);
				EDA_CONN.rollback();
				logger.error("Call Loader Failed! Error Message:" + e.getMessage());
			}
			
			//SPC handle
			try {
				spcRunFlag = true;
				logger.info("FID : " + FID + "|| spc_enable = " + spc_enable);
				if (spc_enable.equalsIgnoreCase("true") && getEdaSuccessFlag()) {
					
					logger.info("FID : " + FID + "|| Start SPC running..");
					
					SPC_CONN = getSpcConnection();
					
					if (SPC_CONN.isClosed()) {
						logger.error("FID : " + FID + "|| The SPC database connection was error");
						setSpcSuccessFlag(false);
					}
					
					if (getSpcSuccessFlag()) {
						
						SpcLoaderEntity entity = new SpcLoaderEntity();
						
						entity.setEq_id(replaceBlankToNull(hEQ_ID));
						entity.setProduct_id(replaceBlankToNull(dsPRODUCT_ID));
						entity.setRecipe_id(replaceBlankToNull(dsRECIPE_ID));
						entity.setEquip_type(replaceBlankToNull(hEQUIP_TYPE));
						entity.setSubeq_id(replaceBlankToNull(hSubEQ_ID));
						entity.setOpe_no(replaceBlankToNull(dsOPE_NO));
						entity.setRoute_id(replaceBlankToNull(dsROUTE_ID));
						entity.setCassette_id(replaceBlankToNull(dsCASSETTE_ID));
						entity.setStart_time(replaceBlankToNull(esEND_TIME)); //special handle
						entity.setSheet_id(replaceBlankToNull(dsSHEET_ID));
						
						if(sPARAM_NAMES != null && sPARAM_VALUES != null
						   && !sPARAM_NAMES.trim().equals("") && !sPARAM_VALUES.trim().equals("")){
							logger.info("FID : " + FID + "|| call SPC loader.");
							setSpcSuccessFlag(LOAD_AR_WLI_SHEET.prepareSpcData(entity, sPARAM_NAMES, sPARAM_VALUES, SPC_CONN));
						}
					}
				}
			} catch (Exception ex) {
				
				setSpcSuccessFlag(false);
				logger.error("FID : " + FID + "|| Process SPC parsing error : " + ex.getMessage());
			}

		} catch (Exception ex) {

			reader.close();

			if (getEdaSuccessFlag()) {
				reader.close();
				setEdaSuccessFlag(false);
			}

		} finally {

			if (reader != null) {
				reader.close();
			}

		}
	}

	@Override
	public String getLoaderName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkFileFormat(File file) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}
}
