package com.mdt.array.array_particle.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayGlassBaseEntity;

/**
 ***************************************************
 * @Title ArrayParticleGlassEntity
 * @author 林华锋
 * @Date 2017年3月24日下午3:30:15
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayParticleGlassEntity extends ArrayGlassBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String FRONT_IMAGE_DATA;
	private String BACK_IMAGE_DATA;
	private String SYSTEM_STATUS;
	private String DEFECT_OVERVIEW_IMAGE;
	private String TTL_DEFECT_CNT;
	private String BACK_TTL_DEFECT_CNT;
	private String OVERFLOW;

	public String getFRONT_IMAGE_DATA() {
		return FRONT_IMAGE_DATA;
	}

	public void setFRONT_IMAGE_DATA(String fRONT_IMAGE_DATA) {
		FRONT_IMAGE_DATA = fRONT_IMAGE_DATA;
	}

	public String getBACK_IMAGE_DATA() {
		return BACK_IMAGE_DATA;
	}

	public void setBACK_IMAGE_DATA(String bACK_IMAGE_DATA) {
		BACK_IMAGE_DATA = bACK_IMAGE_DATA;
	}

	public String getSYSTEM_STATUS() {
		return SYSTEM_STATUS;
	}

	public void setSYSTEM_STATUS(String sYSTEM_STATUS) {
		SYSTEM_STATUS = sYSTEM_STATUS;
	}

	public String getDEFECT_OVERVIEW_IMAGE() {
		return DEFECT_OVERVIEW_IMAGE;
	}

	public void setDEFECT_OVERVIEW_IMAGE(String dEFECT_OVERVIEW_IMAGE) {
		DEFECT_OVERVIEW_IMAGE = dEFECT_OVERVIEW_IMAGE;
	}

	public String getTTL_DEFECT_CNT() {
		return TTL_DEFECT_CNT;
	}

	public void setTTL_DEFECT_CNT(String tTL_DEFECT_CNT) {
		TTL_DEFECT_CNT = tTL_DEFECT_CNT;
	}

	public String getBACK_TTL_DEFECT_CNT() {
		return BACK_TTL_DEFECT_CNT;
	}

	public void setBACK_TTL_DEFECT_CNT(String bACK_TTL_DEFECT_CNT) {
		BACK_TTL_DEFECT_CNT = bACK_TTL_DEFECT_CNT;
	}

	public String getOVERFLOW() {
		return OVERFLOW;
	}

	public void setOVERFLOW(String oVERFLOW) {
		OVERFLOW = oVERFLOW;
	}

}
