package com.mdt.array.array_particle.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayDefectBaseEntity;

/**
 ***************************************************
 * @Title  ArrayParticleDefectEntity                                    
 * @author 林华锋
 * @Date   2017年4月20日下午5:08:26
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class ArrayParticleDefectEntity extends ArrayDefectBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;

}
