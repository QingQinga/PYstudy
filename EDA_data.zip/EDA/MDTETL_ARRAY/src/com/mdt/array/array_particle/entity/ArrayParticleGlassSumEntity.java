package com.mdt.array.array_particle.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayGlassSumBaseEntity;

/**
 ***************************************************
 * @Title  ArrayParticleGlassSumEntity                                    
 * @author 林华锋
 * @Date   2017年6月27日下午3:53:01
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class ArrayParticleGlassSumEntity extends ArrayGlassSumBaseEntity implements Serializable{
	private static final long serialVersionUID = 1L;
}
