package com.mdt.array.array_particle.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.array.array_particle.entity.ArrayParticleGlassSumEntity;
import com.mdt.array.util.DBUtil;

public class ArrayParticleGlassSumDao {

    private static Logger logger = Logger.getLogger(ArrayParticleGlassSumDao.class);
	
	public static boolean addArrayParticleGlassSum(ArrayParticleGlassSumEntity Entity,Connection conn,String fid) throws Exception {
		
		String view = "ARRAY_PARTICLE_GLASS_SUMMARY_V";
		
		String sql = "INSERT INTO " + view
				  +"(" 
				  +"OPE_NO,"
				  +"SHEET_ID,"
				  +"END_TIME,"
				  +"PARAM_COLLECTION,"
				  +"PARAM_NAME,"
				  +"PARAM_VALUE,"
				  +"AVG,"
				  +"MAX,"
				  +"MIN,"
				  +"STD,"
				  +"UNIFORMITY,"
				  +"RANGE,"
				  +"SPEC_HIGH,"
				  +"SPEC_LOW,"
				  +"SPEC_TARGET,"
				  +"CONTROL_HIGH,"
				  +"CONTROL_LOW,"
				  +"THREE_SIGMA,"
				  +"PARAM_JUDGE"
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"?"
				  +")";

		Object[] params = {Entity.getOPE_NO(),
				           Entity.getSHEET_ID(),
				           Entity.getEND_TIME(),
				           Entity.getPARAM_COLLECTION(),
				           Entity.getPARAM_NAME(),
				           Entity.getPARAM_VALUE(),
				           Entity.getAVG(),
				           Entity.getMAX(),
				           Entity.getMIN(),
				           Entity.getSTD(),
				           Entity.getUNIFORMITY(),
				           Entity.getRANGE(),
				           Entity.getSPEC_HIGH(),
				           Entity.getSPEC_LOW(),
				           Entity.getSPEC_TARGET(),
				           Entity.getCONTROL_HIGH(),
				           Entity.getCONTROL_LOW(),
				           Entity.getTHREE_SIGMA(),
				           Entity.getPARAM_JUDGE()
		                  };
                           
                           
		boolean isErrorRet = true;

		try {

			DBUtil.executeUpdate(sql, params,conn);
		} catch (Exception e) {
			logger.error(" FID: "+fid+"|| ----- Insert into "+ view +" failed! Error Message: " + e.getMessage());

			isErrorRet = false;
			throw e;
		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {
				logger.error(" FID: "+fid+"|| ----- An Error Cased: " + e.getMessage());
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}

	}
	
	
}
