package com.mdt.array.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.array.connection.EDADBConnection;

/**
 ***************************************************
 * @Title LogDBUtil
 * @author 林华锋
 * @Date 2017年3月22日上午10:15:33
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class LogDBUtil {
	
	public static Logger logger = Logger.getLogger(LogDBUtil.class);
 
	public static Connection EDA_Conn;
	public static Statement stmt = null;
	public static String DB_NAME = "";
	public static String DB_HOSTNAME = "";
	public static String DB_USERNAME = "";
	public static String DB_PWD = "";

	public static String getDBName() {

		String DB_NAME_SQL = "select PARA_VALUE from MDTCIM.EDA_CONFIG where PARA_NAME = 'LOG_DB_NAME'"; // 数据库名称
		try {
			EDA_Conn = EDADBConnection.getEDA_CONN();
			stmt = EDA_Conn.createStatement();
			ResultSet rs = stmt.executeQuery(DB_NAME_SQL);
			if (rs.next()) {
				DB_NAME = rs.getString("PARA_VALUE");
			}
		} catch (Exception e) {
			logger.info(" Get DBName Failed! Error Message: " + e.getMessage());
		}

		return DB_NAME;

	}

	public static String getDBHostName() {

		String DB_HOSTNAME_SQL = "select PARA_VALUE from MDTCIM.EDA_CONFIG where PARA_NAME = 'LOG_DB_IP'"; // 主机地址

		try {
			EDA_Conn = EDADBConnection.getEDA_CONN();

			stmt = EDA_Conn.createStatement();

			ResultSet rs = stmt.executeQuery(DB_HOSTNAME_SQL);

			if (rs.next()) {
				DB_HOSTNAME = rs.getString(1);
			}
		} catch (Exception e) {
			logger.info(" Get DBHostName Failed! Error Message: " + e.getMessage());
			e.printStackTrace();
		}

		return DB_HOSTNAME;

	}

	public static String getUserName() {

		String DB_USER_SQL = "select PARA_VALUE from MDTCIM.EDA_CONFIG where PARA_NAME = 'LOG_DB_UID'"; // 用户名

		try {
			EDA_Conn = EDADBConnection.getEDA_CONN();
			stmt = EDA_Conn.createStatement();
			ResultSet rs = stmt.executeQuery(DB_USER_SQL);
			if (rs.next()) {
				DB_USERNAME = rs.getString(1);
			}
		} catch (Exception e) {
			logger.info(" Get DBUserName Failed! Error Message: " + e.getMessage());
		}

		return DB_USERNAME;
	}

	public static String getDBPwd() {
		String DB_PWD_SQL = "select PARA_VALUE from MDTCIM.EDA_CONFIG where PARA_NAME = 'LOG_DB_PWD'"; // 密码
		try {
			EDA_Conn = EDADBConnection.getEDA_CONN();
			stmt = EDA_Conn.createStatement();
			ResultSet rs = stmt.executeQuery(DB_PWD_SQL);
			if (rs.next()) {
				DB_PWD = rs.getString(1);
			}
		} catch (Exception e) {
			logger.info(" Get DBPWD Failed! Error Message: " + e.getMessage());
		}

		return DB_PWD;
	}

	public void getLogDBProperties() {
		String dburl="jdbc:mysql://"+ getDBHostName()+":"+"3306"+"/"+getDBName()+"?useUnicode=true&characterEncoding=UTF-8";
		System.setProperty("db.url", dburl);
		System.setProperty("db.username", getUserName());
		System.setProperty("db.pwd", getDBPwd());       
	}

}
