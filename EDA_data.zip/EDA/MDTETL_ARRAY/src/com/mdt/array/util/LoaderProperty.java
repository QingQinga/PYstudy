package com.mdt.array.util;

import java.util.*;
import java.io.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
 
/**
 *
 * @author  HuChen
 */

public class LoaderProperty {
	    
		private static Logger logger = Logger.getLogger(LoaderProperty.class);   
	    //---------------------------Environment Variable-------------------------------
		public static final String MAX_LOAD_AMOUNT_KEY="MAX_LOAD_AMOUNT";
		public static final String TRANSLATOR_WORK_PATH_KEY = "TRANSLATOR_WORK_PATH";
		public static final String LOG4J_CONFIG_DIR_KEY ="LOG4JPROPERTIES_DIR";
        public static final String DATA_FILE_HOME_PATH_KEY="DATA_FILE_HOME_PATH";
        public static final String SYSTEM_GLOBAL_CONFIG_KEY="SYSTEM_GLOBAL_CONFIG";
        public static final String SYSTEM_LOCAL_CONFIG_KEY="SYSTEM_LOCAL_CONFIG";
        public static final String TRANSLATOR_CLASS_PATH_KEY = "TRANSLATOR_CLASS_PATH";
        public static final String JAVA_OPTIONS = "JAVA_OPTIONS";
		//---------------------------SYSTEM CONFIG-------------------------------
	    public static final String LOCK_KEY			="LOADER_LOCK_PORT";
		public static final String PORT_KEY			="DATABASE_PORT";
		public static final String MAIL_SERVER_ACTIVATE_KEY	="MAIL_SERVER_ACTIVATE";
		
		public static final String TRANSLATOR_HOSTNAME_KEY		="TRANSLATOR_DATABASE_HOSTNAME";
		public static final String TRANSLATOR_SID_KEY			="TRANSLATOR_DATABASE_SID";
		public static final String TRANSLATOR_USER_ID_KEY		="TRANSLATOR_USER_ID";
		public static final String TRANSLATOR_PASSWORD_KEY		="TRANSLATOR_USER_PASSWORD";
		public static final String TRANSLATOR_USER_PREFIX_KEY	="TRANSLATOR_USER_PREFIX";
		
		public static final String EDA_HOSTNAME_KEY		="EDADATABASE_HOSTNAME";
		public static final String EDA_SID_KEY			="EDADATABASE_SID";
		public static final String EDAUSER_ID_KEY		="EDALOADER_USER_ID";
		public static final String EDAPASSWORD_KEY		="EDALOADER_USER_PASSWORD";
		public static final String EDAUSER_PREFIX_KEY	="EDAUSER_PREFIX";
		
		public static final String SPC_HOSTNAME_KEY		="SPCDATABASE_HOSTNAME";
		public static final String SPC_SID_KEY			="SPCDATABASE_SID";
		public static final String SPCUSER_ID_KEY		="SPCLOADER_USER_ID";
		public static final String SPCPASSWORD_KEY		="SPCLOADER_USER_PASSWORD";
		public static final String SPCUSER_PREFIX_KEY	="SPCUSER_PREFIX";
		
		public static final String LOG_HOSTNAME_KEY		="LOGDATABASE_HOSTNAME";
		public static final String LOG_SID_KEY			="LOGDATABASE_SID";
		public static final String LOGUSER_ID_KEY		="LOGLOADER_USER_ID";
		public static final String LOGPASSWORD_KEY		="LOGLOADER_USER_PASSWORD";
		public static final String LOGUSER_PREFIX_KEY	="LOGUSER_PREFIX";
		
        public static final String EDA_ENABLE_KEY ="EDA_ENABLE";
        public static final String SPC_ENABLE_KEY ="SPC_ENABLE";
        public static final String LOG_ENABLE_KEY ="LOG_ENABLE";
        
        //--------------------------Mail Server Info-------------------------------
        public static final String Mail_Server_Host_KEY		="Mail_Server_Host";
        public static final String Mail_Server_Port_KEY		="Mail_Server_Port";
        public static final String Mail_User_Name_KEY		="Mail_User_Name";
        public static final String Mail_Password_KEY		="Mail_PassWord";
        public static final String Mail_From_Address_KEY		="Mail_From_Address";
        public static final String Mail_To_Address_KEY		="Mail_To_Address";
        public static final String Mail_Activate_Server_KEY		="Mail_Activate_Server";
        
        //--------------------------Get File List From DB Info-------------------------------
        public static final String TID = "TID";
        public static final String EQP_TYPE_KEY		="EQP_TYPE";
        public static final String SHOP_KEY		="SHOP";
        public static final String DATA_SOURCE_KEY		="DATA_SOURCE";
        public static final String TARGET_FLAG = "TARGET_FLAG";
        public static final String ACTIVATE_DB_FIND_METHOD_KEY		="ACTIVATE_DB_FIND_METHOD";
        public static final String WORK_DIR = "WORK_DIR";
        public static final String MAX_COUNT = "MAX_COUNT";
        public static final String KEEP_NUM = "KEEP_NUM"; 
        public static final String EXPORT_LOG_FLAG = "EXPORT_LOG_FLAG";
        public static final String DFS_ROOT_PATH = "DFS_ROOT_PATH";
        
	    /** Creates a new instance of LoaderProperty */
	    public LoaderProperty() throws Exception
	    {
	    	GetEnvironmentUtil env = new GetEnvironmentUtil();
	        
	        Env_Properties = env.getEnvironment();
	        
	        if(!GetSystemGlobalConfig().equalsIgnoreCase(""))
	        	Sys_Properties = SystemConfigUtil.getProperties(GetSystemGlobalConfig());
	        else
	        	Sys_Properties = SystemConfigUtil.getProperties(GetSystemLocalConfig());
	        
	        String log4jConfigDir =  GetLog4jConfigDir();
	        if(log4jConfigDir != null){
	        	PropertyConfigurator.configure(log4jConfigDir);
	        }
	    }
	    
	    public LoaderProperty(String systemGlobalConfig, String log4jConfigDir) throws Exception
	    {
	    	GetEnvironmentUtil env = new GetEnvironmentUtil();
	        
	        Env_Properties = env.getEnvironment();
	        Sys_Properties = SystemConfigUtil.getProperties(systemGlobalConfig);
	        PropertyConfigurator.configure(log4jConfigDir);
	        
	    }
	    
	    /**Get global config path */
	    public String GetSystemGlobalConfig() throws Exception
	    {
		       String s = Env_Properties.getProperty(SYSTEM_GLOBAL_CONFIG_KEY);
		       if(s == null)
		       	   return "";
		       else
		    	   return s;
	    }
	    
	    /**getActivateDbFindMtehod */
	    public String getActivateDbFindMtehod() throws Exception
	    {
	    	String s = Env_Properties.getProperty(ACTIVATE_DB_FIND_METHOD_KEY);
	    	if(s == null)
	    		logger.error(ACTIVATE_DB_FIND_METHOD_KEY + " not found or doesn't contain any value");
	
	    	return s;
	    }
	    
	    
	    /**GetWorkDir */
	    public String GetWorkDir() throws Exception
	    {
	    	String s = Env_Properties.getProperty(WORK_DIR);
	    	if(s == null)
	    		logger.error(WORK_DIR + " not found or doesn't contain any value");
	
	    	return s;
	    }
	    
	    
	    /**Get data TID */
	    public String GetTID() throws Exception
	    {
	    	String s = Env_Properties.getProperty(TID);
	    	if(s == null)
	    		logger.error(TID + " not found or doesn't contain any value");
	
	    	return s;
	    }
	    
	    /**Get data eqpType */
	    public String GetEqpType() throws Exception
	    {
	    	String s = Env_Properties.getProperty(EQP_TYPE_KEY);
	    	if(s == null)
	    		logger.error(EQP_TYPE_KEY + " not found or doesn't contain any value");
	
	    	return s;
	    }
	    
	    /**Get data file Shop */
	    public String GetDataSource() throws Exception
	    {
	    	String s = Env_Properties.getProperty(DATA_SOURCE_KEY);
	    	if(s == null)
	    		logger.error(DATA_SOURCE_KEY + " not found or doesn't contain any value");
	
	    	return s;
	    }
	    
	    /**GetExportLogFlag*/
	    public String GetExportLogFlag() throws Exception
	    {
	    	String s = Env_Properties.getProperty(EXPORT_LOG_FLAG);
	    	if(s == null)
	    		logger.error(EXPORT_LOG_FLAG + " not found or doesn't contain any value");
	
	    	return s;
	    }
	    
	    /**Get TargetFlag */
	    public String GetTargetFlag() throws Exception
	    {
	    	String s = Env_Properties.getProperty(TARGET_FLAG);
	    	if(s == null)
	    		logger.error(TARGET_FLAG + " not found or doesn't contain any value");
	
	    	return s;
	    }
	    
	    /**Get data file Shop */
	    public String GetShop() throws Exception
	    {
	    	String s = Env_Properties.getProperty(SHOP_KEY);
	    	if(s == null)
	    		logger.error(SHOP_KEY + " not found or doesn't contain any value");
	
	    	return s;
	    }
	    
	    /**Get local config path */
	    public String GetSystemLocalConfig() throws Exception
	    {
		       String s = Env_Properties.getProperty(SYSTEM_LOCAL_CONFIG_KEY);
		       if(s == null)
		       	   return "";
		       else
		    	   return s;
	    }
	    
	    
	    /**GetMaxCount */
	    public String GetMaxCount() throws Exception
	    {
		       String s = Env_Properties.getProperty(MAX_COUNT);
		       if(s == null)
		    		logger.error(MAX_COUNT + " not found or doesn't contain any value");
		
		    	return s;
	    }
	    
	    /**GetKeepNum */
	    public String GetKeepNum() throws Exception
	    {
		       String s = Env_Properties.getProperty(KEEP_NUM);
		       if(s == null)
		    		logger.error(KEEP_NUM + " not found or doesn't contain any value");
		
		    	return s;
	    }
	    
	    
	    /**Get translator glass path */
	    public String GetTranslatorGlassPath() throws Exception
	    {
	    	String s = Env_Properties.getProperty(TRANSLATOR_CLASS_PATH_KEY);
	    	if(s == null)
	    		return "";
	    	else
	    		return s;
	    }

	    /** Get data file shop folder */
	    public String GetDataFileHomePath() throws Exception
	    {
	       String s = Env_Properties.getProperty(DATA_FILE_HOME_PATH_KEY);
	       if(s == null)
	           logger.error(DATA_FILE_HOME_PATH_KEY + " not found or doesn't contain any value");
	       
		    checkDirExists(s);
		    return s;
	    }
	    
	    public String GetTranslatorWorkPath() throws Exception
	    {
	    	String s = Env_Properties.getProperty(TRANSLATOR_WORK_PATH_KEY);
		       if(s == null)
		           logger.error(TRANSLATOR_WORK_PATH_KEY + " not found or doesn't contain any value");
		       
			    checkDirExists(s);
			    return s;
	    }
    
	    /** Get log config path */
	    public String GetLog4jConfigDir() throws Exception
	    {
//	    	Set a = Env_Properties.keySet();
//	    	String[] b = new String[a.size()];
//	    	a.toArray(b);
//	    	for(int i =0;i < b.length;i++){
//	    		System.out.println("name="+b[i]+",value="+Env_Properties.getProperty(b[i]));
//	    	}
	    	String dir = Env_Properties.getProperty(LOG4J_CONFIG_DIR_KEY);
	        if(dir == null)
	            throw new Exception(LOG4J_CONFIG_DIR_KEY + " not found or doesn't contain any value");
	        
	        dir += File.separator + "log4j.properties";
	        
	        //System.out.println("dir2="+dir);
	        return dir;
	    }
	    
	    
	    /**translator deal with how many files*/
	    public String GetLoadAmount() throws Exception
	    {
	        String s = Env_Properties.getProperty(MAX_LOAD_AMOUNT_KEY);
			if(s == null)
			    logger.error(MAX_LOAD_AMOUNT_KEY + " not found or doesn't contain any value");
			
			return s;
	    }


		public String getLock() throws Exception
	    {
	        String s = Env_Properties.getProperty(LOCK_KEY);
			if(s == null)
				logger.error(LOCK_KEY + " not found or doesn't contain any value");
			
			return s;
	    }

		
	    /**Get DB Port*/
	    public String GetPort() throws Exception
	    {
	        String s = Sys_Properties.getProperty(PORT_KEY,null);
			if(s == null)
				logger.error(PORT_KEY + " not found or doesn't contain any value");
	
			return s;
	    }
	    
	    /**Get EDA whether start */
	    public String GetEda_Eenble() throws Exception
	    {
		       String s = Sys_Properties.getProperty(EDA_ENABLE_KEY);
		       if(s == null)
		       	   logger.error(EDA_ENABLE_KEY + " not found or doesn't contain any value");
	       	   return s;
	    }
    
	    /**Get SPC whether start */
	    public String GetSpc_Eenble() throws Exception
	    {
		       String dir = Sys_Properties.getProperty(SPC_ENABLE_KEY);
		       if(dir == null)
		       	   logger.error(SPC_ENABLE_KEY + " not found or doesn't contain any value");
	       	   return dir;
	    }
	    
	    /**Get LOG whether start */
	    public String GetLog_Eenble() throws Exception
	    {
		       String dir = Sys_Properties.getProperty(LOG_ENABLE_KEY);
		       if(dir == null)
		       	   logger.error(LOG_ENABLE_KEY + " not found or doesn't contain any value");
	       	   return dir;
	    }
	    
	    /**Get TRANSLATOR DB user prefix*/
	    public String GetTranslatorUserPrefix() throws Exception
	    {
	        String s = Sys_Properties.getProperty(TRANSLATOR_USER_PREFIX_KEY,null);
			if(s == null)
				logger.error(TRANSLATOR_USER_PREFIX_KEY + " not found or doesn't contain any value");
			
			return s;    
	    }

	    /**Get EDA DB user prefix*/
	    public String GetEdaUserPrefix() throws Exception
	    {
	        String s = Sys_Properties.getProperty(EDAUSER_PREFIX_KEY,null);
			if(s == null)
				logger.error(EDAUSER_PREFIX_KEY + " not found or doesn't contain any value");
			
			return s;    
	    }
    
	    /**Get SPC DB user prefix*/
	    public String GetSpcUserPrefix() throws Exception
	    {
	        String s = Sys_Properties.getProperty(SPCUSER_PREFIX_KEY,null);
			if(s == null)
				logger.error(SPCUSER_PREFIX_KEY + " not found or doesn't contain any value");
			
			return s;    
	    }
	    
	    /**Get LOG DB user prefix*/
	    public String GetLogUserPrefix() throws Exception
	    {
	        String s = Sys_Properties.getProperty(LOGUSER_PREFIX_KEY,null);
			if(s == null)
				logger.error(LOGUSER_PREFIX_KEY + " not found or doesn't contain any value");
			
			return s;    
	    }
	    
	    /**Get TRANSLATOR DB user name*/
	    public String GetTranslatorUsername() throws Exception
	    {
	        String s = Sys_Properties.getProperty(TRANSLATOR_USER_ID_KEY,null);

			if(s == null)
				logger.error(TRANSLATOR_USER_ID_KEY + " not found or doesn't contain any value");
			return s;

	    }

	    /**Get EDA DB user name*/
	    public String GetEdaUsername() throws Exception
	    {
	        String s = Sys_Properties.getProperty(EDAUSER_ID_KEY,null);

			if(s == null)
				logger.error(EDAUSER_ID_KEY + " not found or doesn't contain any value");
			return s;

	    }
    
	    /**Get SPC DB user name*/
	    public String GetSpcUsername() throws Exception
	    {
	        String s = Sys_Properties.getProperty(SPCUSER_ID_KEY,null);
			if(s == null)
				logger.error(SPCUSER_ID_KEY + " not found or doesn't contain any value");
			return s;
	    }
	    
	    /**Get LOG DB user name*/
	    public String GetLogUsername() throws Exception
	    {
	        String s = Sys_Properties.getProperty(LOGUSER_ID_KEY,null);
			if(s == null)
				logger.error(LOGUSER_ID_KEY + " not found or doesn't contain any value");
			return s;
	    }
	    
	    /**Get TRANSLATOR DB password*/
		public String GetTranslatorPassword() throws Exception
	    {
	        String s = Sys_Properties.getProperty(TRANSLATOR_PASSWORD_KEY,null);
			if(s == null)
				logger.error(TRANSLATOR_PASSWORD_KEY + " not found or doesn't contain any value");
			
			return s;
	    }

	    /**Get EDA DB password*/
		public String GetEdaPassword() throws Exception
	    {
	        String s = Sys_Properties.getProperty(EDAPASSWORD_KEY,null);
			if(s == null)
				logger.error(EDAPASSWORD_KEY + " not found or doesn't contain any value");
			
			return s;
	    }
	
		/**Get SPC DB password*/
		public String GetSpcPassword() throws Exception
	    {
	        String s = Sys_Properties.getProperty(SPCPASSWORD_KEY,null);
			if(s == null)
				logger.error(SPCPASSWORD_KEY + " not found or doesn't contain any value");
			
			return s;
	    }
		
		/**Get LOG DB password*/
		public String GetLogPassword() throws Exception
	    {
	        String s = Sys_Properties.getProperty(LOGPASSWORD_KEY,null);
			if(s == null)
				logger.error(LOGPASSWORD_KEY + " not found or doesn't contain any value");
			
			return s;
	    }
		
		/**Get TRANSLATOR DB host name*/
	    public String GetTranslatorHostname() throws Exception
	    {
	        String s = Sys_Properties.getProperty(TRANSLATOR_HOSTNAME_KEY,null);
			if(s == null)
				logger.error(TRANSLATOR_HOSTNAME_KEY + " not found or doesn't contain any value");
		
			return s;
	    }

		/**Get EDA DB host name*/
	    public String GetEdaHostname() throws Exception
	    {
	        String s = Sys_Properties.getProperty(EDA_HOSTNAME_KEY,null);
			if(s == null)
				logger.error(EDA_HOSTNAME_KEY + " not found or doesn't contain any value");
		
			return s;
	    }
	    
		/**Get SPC DB host name*/
	    public String GetSpcHostname() throws Exception
	    {
	        String s = Sys_Properties.getProperty(SPC_HOSTNAME_KEY,null);
			if(s == null)
				logger.error(SPC_HOSTNAME_KEY + " not found or doesn't contain any value");
		
			return s;
	    }
	    
		/**Get LOG DB host name*/
	    public String GetLogHostname() throws Exception
	    {
	        String s = Sys_Properties.getProperty(LOG_HOSTNAME_KEY,null);
			if(s == null)
				logger.error(LOG_HOSTNAME_KEY + " not found or doesn't contain any value");
		
			return s;
	    }
	    
	    /**Get TRANSLATOR DB SID*/
	    public String GetTranslatorSid() throws Exception
	    {
	        String s = Sys_Properties.getProperty(TRANSLATOR_SID_KEY,null);
			if(s == null)
				logger.error(TRANSLATOR_SID_KEY + " not found or doesn't contain any value");
			
			return s;
	    }

	    /**Get EDA DB SID*/
	    public String GetEdaSid() throws Exception
	    {
	        String s = Sys_Properties.getProperty(EDA_SID_KEY,null);
			if(s == null)
				logger.error(EDA_SID_KEY + " not found or doesn't contain any value");
			
			return s;
	    }
    
	    /**Get SPC DB SID*/
	    public String GetSpcSid() throws Exception
	    {
	        String s = Sys_Properties.getProperty(SPC_SID_KEY,null);
			if(s == null)
				logger.error(SPC_SID_KEY + " not found or doesn't contain any value");
			
			return s;
	    }
	    
	    /**Get LOG DB SID*/
	    public String GetLogSid() throws Exception
	    {
	        String s = Sys_Properties.getProperty(LOG_SID_KEY,null);
			if(s == null)
				logger.error(LOG_SID_KEY + " not found or doesn't contain any value");
			
			return s;
	    }

	    public String getMailServer() throws Exception
	    {
	    	 String s = Sys_Properties.getProperty(MAIL_SERVER_ACTIVATE_KEY,null);

	    	 if(s == null)
	    		 logger.error(MAIL_SERVER_ACTIVATE_KEY + " not found or doesn't contain any value");
	    	 
	    	 return s;
	    }

        /**Mail server host*/
        public String getMailServerHost() throws Exception
	    {
	    	 String s = Sys_Properties.getProperty(Mail_Server_Host_KEY,null);

	    	 if(s == null)
	    		 logger.error(Mail_Server_Host_KEY + " not found or doesn't contain any value");
	    	 
	    	 return s;
	    }
        
        /**Mail server port*/
        public String getMailServerPort() throws Exception
	    {
	    	 String s = Sys_Properties.getProperty(Mail_Server_Port_KEY,null);

	    	 if(s == null)
	    		 logger.error(Mail_Server_Port_KEY + " not found or doesn't contain any value");
	    	 
	    	 return s;
	    }
        
        /**Mail user name*/
        public String getMailUserName() throws Exception
	    {
	    	 String s = Sys_Properties.getProperty(Mail_User_Name_KEY,null);

	    	 if(s == null)
	    		 logger.error(Mail_User_Name_KEY + " not found or doesn't contain any value");
	    	 
	    	 return s;
	    }
        
        /**Mail password*/
        public String getMailPassword() throws Exception
	    {
	    	 String s = Sys_Properties.getProperty(Mail_Password_KEY,null);

	    	 if(s == null)
	    		 logger.error(Mail_Password_KEY + " not found or doesn't contain any value");
	    	 
	    	 return s;
	    }
        
        /**Mail from address*/
        public String getFromAddress() throws Exception
	    {
	    	 String s = Sys_Properties.getProperty(Mail_From_Address_KEY,null);

	    	 if(s == null)
	    		 logger.error(Mail_From_Address_KEY + " not found or doesn't contain any value");
	    	 
	    	 return s;
	    }
        
        /**Mail from address*/
        public String getToAddress() throws Exception
	    {
	    	 String s = Sys_Properties.getProperty(Mail_To_Address_KEY,null);

	    	 if(s == null)
	    		 logger.error(Mail_To_Address_KEY + " not found or doesn't contain any value");
	    	 
	    	 return s;
	    }
        
        /**Mail Activate Server*/
        public String getMailActivateServer() throws Exception
	    {
	    	 String s = Sys_Properties.getProperty(Mail_Activate_Server_KEY,null);

	    	 if(s == null)
	    		 logger.error(Mail_Activate_Server_KEY + " not found or doesn't contain any value");
	    	 
	    	 return s;
	    }
        
	    
	    /**GetExportLogFlag*/
	    public String GetDfsRootPath() throws Exception
	    {
	    	String s = Sys_Properties.getProperty(DFS_ROOT_PATH);
	    	if(s == null)
	    		logger.error(EXPORT_LOG_FLAG + " not found or doesn't contain any value");
	
	    	return s;
	    }
        
	    /**Check path is Exists*/
	    private void checkDirExists(String path) throws Exception
	    {
	       File dir = new File(path);
	       if(!dir.isDirectory())
	       {
	           logger.error(path + "  is not a valid directory");
	       }
	    }

	    public Properties GetEnvProperties()
	    {
	        return Env_Properties;
	    }
	    
	    public Properties GetSysProperties()
	    {
	        return Sys_Properties;
	    }
	    private Properties Env_Properties;
	    
	    private Properties Sys_Properties;
}
