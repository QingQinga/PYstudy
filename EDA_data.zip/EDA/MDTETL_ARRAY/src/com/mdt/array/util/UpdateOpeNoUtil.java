package com.mdt.array.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
/**
 * 
 ***************************************************
 * @Title  UpdateOpeNoUtil                                    
 * @author 林华锋
 * @Date   2017年8月22日下午1:43:38 Update
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class UpdateOpeNoUtil {

	private static Logger logger = Logger.getLogger(UpdateOpeNoUtil.class);
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	String UNIT_TYP = null;
	String OPE_NO = null;
	String url = "jdbc:db2://10.96.32.38:60500/AHISDB";
	String user = "edaetl";
	String password = "eda1234";
	
    String str = "";
	 public String updateOPE_NO(String OPE_NO,String PRODUCT_ID,String EQ_ID){
	        
		 String sql ="SELECT (CASE WHEN D.UNIT_TYP <> 'M' AND D.ROOT_EQPT_ID <> SUBSTR(D.EQPT_ID, 1, 7) THEN A.CR_OPE_NO || '_' || SUBSTR(D.EQPT_ID, 3, 2) ELSE A.CR_OPE_NO END) STEP_ID FROM ARYPPT.AROUTE A INNER JOIN ARYPPT.AOPER B ON A.CR_OPE_ID = B.OPE_ID INNER JOIN ARYPPT.AEQPTGR C ON B.EQPTG_ID = C.EQPTG_ID INNER JOIN ARYPPT.AEQPT D ON C.EQPT_ID = D.ROOT_EQPT_ID"
					+ " WHERE A.ROUTE_ID ='"+PRODUCT_ID.trim()+"' AND A.CR_OPE_NO = '"+OPE_NO.trim()+"' AND D.EQPT_ID = '"+EQ_ID.trim()+"'";
		 try {
               
				Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
				
				conn = DriverManager.getConnection(url, user, password);
			    ps = conn.prepareStatement(sql);
				rs = ps.executeQuery();

				while (rs.next()) {
					OPE_NO = rs.getString(1);
				}
				str = OPE_NO;

			} catch (Exception sqle) {
				logger.error("get OPE_NO:" + OPE_NO + " failed :" + sqle.getMessage());
			}finally{
				if(conn !=null || ps != null ||rs!=null){
					  try {
						rs.close();
						ps.close();
						conn.close();
					} catch (SQLException e) {
						logger.error("get " + conn + " failed :" + e.getMessage());
					}
						
				}
			}
			return str;
	 }
	
}
