package com.mdt.array.util;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 ***************************************************
 * @Title GetOXCountUtil
 * @author 林华锋
 * @Date 2018年2月6日上午9:10:07
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class GetOXCountUtil {

	PreparedStatement ps = null;
	ResultSet rs = null;
	int count = 0;
	public int getOKCount(Connection conn, String BLOCK_FLAG) {
        
		try {
			String sql = "select count(0) from edaldr.ARRAY_TEST_CHIP_V where JUDGE = ? and BLOCK_FLAG =?";

			ps = conn.prepareStatement(sql);

			ps.setString(1, "OK");
			ps.setString(2, BLOCK_FLAG);

			rs = ps.executeQuery();

			while (rs.next()) {
				count = rs.getInt(1);
				
			}

		} catch (Exception sqle) {

		} finally {
			if (ps != null || rs != null) {
				try {
					rs.close();
					ps.close();

				} catch (Exception e) {

				}

			}

		}
		return count;
	}

	public int getNGCount(Connection conn, String BLOCK_FLAG) {

		try {
			String sql = "select count(0) from edaldr.ARRAY_TEST_CHIP_V where JUDGE = ? and BLOCK_FLAG =?";

			ps = conn.prepareStatement(sql);

			ps.setString(1, "NG");
			ps.setString(2, BLOCK_FLAG);

			rs = ps.executeQuery();

			while (rs.next()) {
				count = rs.getInt(1);
			}

		} catch (Exception sqle) {

		} finally {
			if (ps != null || rs != null) {
				try {
					rs.close();
					ps.close();

				} catch (Exception e) {

				}

			}

		}
		return count;
	}
	
	@SuppressWarnings("static-access")
	public String getYieldByBlockFlag(Connection conn, String BLOCK_FLAG){
		String str ="";
		double okNum = getOKCount(conn,BLOCK_FLAG); 
		double ngNum = getNGCount(conn,BLOCK_FLAG);
		double yeild = okNum/(okNum+ngNum);
		double a =  Double.parseDouble(str.format("%.4f", yeild));
		double b =  100;
		double result = mul(a, b);
		return Double.toString(result);
	}
	
	public  List<String> selectBlock(Connection conn){
		List<String> list = new ArrayList<String>(); 
		try {
			String sql = "SELECT DISTINCT(BLOCK_FLAG) FROM edaldr.ARRAY_TEST_CHIP_V";

			ps = conn.prepareStatement(sql);

			rs = ps.executeQuery();

			while (rs.next()) {
			  String BLOCK_FLAG = rs.getString(1);
			  list.add(BLOCK_FLAG);
			}

		} catch (Exception sqle) {

		} finally {
			if (ps != null || rs != null) {
				try {
					rs.close();
					ps.close();

				} catch (Exception e) {

				}

			}

		}
		return list;
	}
	
	public static Double mul(Double value1, Double value2) {
		BigDecimal b1 = new BigDecimal(Double.toString(value1));
		BigDecimal b2 = new BigDecimal(Double.toString(value2));
		return b1.multiply(b2).doubleValue();
	}
}
