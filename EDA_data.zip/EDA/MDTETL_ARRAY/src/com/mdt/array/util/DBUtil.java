package com.mdt.array.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.mdt.array.tableview.SessionConstants;

/**
 ***************************************************
 * @Title DBConnection 数据库连接
 * @author 林华锋
 * @Date 2017年2月13日下午4:58:57
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class DBUtil {

	private static Logger logger = Logger.getLogger(DBUtil.class);

	public static Connection conn = null;
	public static PreparedStatement pstmt = null;
	public static Statement stmt = null;

	public DBUtil() throws Exception {
		PropertyConfigurator.configure(SessionConstants.GET_LOG_CONFIG_DIR());
	}

	public static Connection getConn(String Url, String UserName, String Pwd) {

		try {
			// Class.forName("oracle.jdbc.driver.OracleDriver");
			DriverManager.deregisterDriver(new oracle.jdbc.driver.OracleDriver());
			conn = DriverManager.getConnection(Url, UserName, Pwd);
		} catch (Exception e) {
			logger.error("【   <" + Url + ">  】" + " Database connected Failed! Error Message:" + e.getMessage());
		}
		return conn;
	}

	/**
	 * 执行更新框架
	 * 
	 * @param sql
	 *            SQL语句
	 * @param params
	 *            实体类参数
	 * @return int
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static int executeUpdate(String sql, Object[] params, Connection conn) throws SQLException, ClassNotFoundException {

		pstmt = conn.prepareStatement(sql);

		if (params != null & params.length != 0) {
			for (int i = 0; i < params.length; i++) {
				pstmt.setObject(i + 1, params[i]);
			}
		}

		int result = pstmt.executeUpdate();
		
		return result;
	}

	/**
	 * 关闭所有连接
	 * 
	 * @param stmt
	 * @param pstmt
	 * @param conn
	 */
	public static void closeAll() {
		try {
			if (stmt != null) {
				stmt.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		} catch (SQLException e) {
			logger.error(
					" ##### Statement,PreparedStatement,Connection aren't Closed! Error Message: " + e.getMessage());
		} finally {
			stmt = null;
			pstmt = null;
			conn = null;
		}

	}
    
}
