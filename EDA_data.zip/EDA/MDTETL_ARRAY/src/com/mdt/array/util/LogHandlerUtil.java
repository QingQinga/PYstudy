package com.mdt.array.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.net.InetAddress;

import com.mdt.array.tableview.ETLFileTableView;

public class LogHandlerUtil {

	// log param
	// array:FID,TID,SOURCE,EQUIP_TYPE,FILE_SRC_DIR,FILE_NAME,FILE_TYPE,SYSTEM,DATA_BLOCK,ERROR_TYPE,INFO,ERROR_MSG,IP

	public static String ip_address = "unknown";

	public static String[] getLogParams(ETLFileTableView view, String tid, String system, String data_block,
			String info, String errorMsg) {
		return new String[] {};
	}

	public static String[] getLogParams(ETLFileTableView view, String tid, String source, String system,
			String data_block, String error_type, String info, String errorMsg) {
		String[] logParams = new String[13];

		logParams = getLogBaseParams(logParams, view, tid, source, null);
		logParams[7] = system;
		logParams[8] = data_block;
		logParams[9] = error_type;
		if (info == null || info.equals("null"))
			logParams[10] = "Null exception";
		else
			logParams[10] = info;
		logParams[11] = errorMsg;

		return logParams;
	}

	public static String[] getLogParams(String eqp_type, String tid, String system, String data_block, String info,
			String errorMsg) {
		return new String[] {};
	}

	public static String[] getLogParams(String eqp_type, String tid, String source, String system, String data_block,
			String error_type, String info, String errorMsg) {
		String[] logParams = new String[13];

		try {
			InetAddress inetAddress = InetAddress.getLocalHost();
			ip_address = inetAddress.getHostAddress();
		} catch (Exception ex) {
		}

		logParams = getLogBaseParams(logParams, null, tid, source, eqp_type);
		logParams[7] = system;
		logParams[8] = data_block;
		logParams[9] = error_type;
		if (info == null || info.equals("null"))
			logParams[10] = "Null exception";
		else
			logParams[10] = info;
		logParams[11] = errorMsg;

		return logParams;
	}

	public static String[] getLogBaseParams(String[] logParams, ETLFileTableView view, String tid, String source,
			String eqp_type) {

		String ip_address = "unknown";
		try {
			InetAddress inetAddress = InetAddress.getLocalHost();
			ip_address = inetAddress.getHostAddress();
		} catch (Exception ex) {
		}

		if (view == null) {
			logParams[0] = "";
			logParams[3] = eqp_type;
			logParams[4] = "NA";
			logParams[5] = "NA";
			logParams[6] = "NA";
		} else {
			logParams[0] = view.getFID();
			logParams[3] = view.getEQUIP_TYPE();
			logParams[4] = view.getFILE_SRC_DIR();
			logParams[5] = view.getFILE_NAME();
			logParams[6] = view.getFILE_TYPE();
		}
		logParams[1] = tid;
		logParams[2] = source;
		logParams[12] = ip_address;

		return logParams;
	}

	public static String getStackTraceMessage(Exception ex) {
		Writer w = new StringWriter();
		ex.printStackTrace(new PrintWriter(w));
		String smsg = w.toString();
		return smsg;
	}
}
