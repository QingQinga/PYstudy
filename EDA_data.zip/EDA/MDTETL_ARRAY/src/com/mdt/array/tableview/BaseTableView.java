package com.mdt.array.tableview;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;

public class BaseTableView {
//	public String[] columnsName = new String[0];
//	public String[] columnsType = new String[0];
	
	@SuppressWarnings("rawtypes")
	public HashMap data = new HashMap();
	
	BaseTableView(){
		
	}
	
	@SuppressWarnings("unchecked")
	public void setTableValue(ResultSet rs) throws SQLException{
		if(rs != null){
			ResultSetMetaData md = rs.getMetaData();
			int columnCount = md.getColumnCount();
			
			for(int i = 0;i < columnCount;i++){
				if(md.getColumnType(i+1) == Types.VARCHAR){
					String value = rs.getString(md.getColumnName(i+1));
					data.put(md.getColumnName(i+1).toUpperCase(),value);
				}else if(md.getColumnType(i+1) == Types.NUMERIC || md.getColumnType(i+1) == Types.INTEGER){
					NumberFormat format = new DecimalFormat("###");
					BigDecimal DecimalValue = rs.getBigDecimal(md.getColumnName(i+1));
					if(DecimalValue != null){
						String value = format.format(DecimalValue);
						data.put(md.getColumnName(i+1).toUpperCase(),value);
					}
				}else if(md.getColumnType(i+1) == Types.DATE || md.getColumnType(i+1) == Types.TIMESTAMP){
					SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); 
					if(rs.getTimestamp(md.getColumnName(i+1)) != null){
						String value = format.format(rs.getTimestamp(md.getColumnName(i+1)).getTime());
						data.put(md.getColumnName(i+1).toUpperCase(), value);
					}
				}
				
			}
		}
		
//		public void setTableValue(ResultSet rs) throws SQLException{
//			if(rs != null){
//				ResultSetMetaData md = rs.getMetaData();
//				int columnCount = md.getColumnCount();
//				
//				for(int i = 0;i < columnCount;i++){
//					if(md.getColumnType(i+1) == Types.VARCHAR){
//						String value = rs.getString(md.getColumnName(i+1));
//						data.put(md.getColumnName(i+1).toUpperCase(),value);
//					}else if(md.getColumnType(i+1) == Types.NUMERIC || md.getColumnType(i+1) == Types.INTEGER){
//						
//						double value = rs.getDouble(md.getColumnName(i+1));
//							data.put(md.getColumnName(i+1).toUpperCase(),String.valueOf(value));
//						
//					}else if(md.getColumnType(i+1) == Types.DATE || md.getColumnType(i+1) == Types.TIMESTAMP){
//						SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); 
//						if(rs.getTimestamp(md.getColumnName(i+1)) != null){
//							String value = format.format(rs.getTimestamp(md.getColumnName(i+1)).getTime());
//							data.put(md.getColumnName(i+1).toUpperCase(), value);
//						}
//					}
//					
//				}
//			}
	}
}
