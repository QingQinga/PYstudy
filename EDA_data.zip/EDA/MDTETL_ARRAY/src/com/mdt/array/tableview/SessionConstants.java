package com.mdt.array.tableview;

import java.util.HashMap;

public class SessionConstants {

//	public static String C_MOUNT_DRIVE = "Y:";
//	public static String C_MOUNT_IP = "172.16.4.250";
//	public static String C_MOUNT_ID = "administrator";
//	public static String C_MOUNT_PW = "csot0822";
//	public static String C_MOUNT_PATH = "hedc\\EDC\\MODULE\\MADIB";
	
	@SuppressWarnings("rawtypes")
	private static HashMap sessionDataMap = new HashMap();
	
	private static String P_TID = "TID";
	private static String P_SHOP = "SHOP";
	private static String P_SOURCE = "SOURCE";
	private static String P_EQP_TYPE = "EQP_TYPE";
	private static String P_TARGET_FLAG = "TARGET_FLAG";
	private static String P_WORK_DIR = "WORK_DIR";
	private static String P_MAX_COUNT = "MAX_COUNT";
	private static String P_SYSTEM_CONFIG_DIR = "SYSTEM_CONFIG_DIR";
	private static String P_LOG_CONFIG_DIR = "LOG_CONFIG_DIR";
	private static String P_ACTIVATE_DB_FIND_METHOD = "ACTIVATE_DB_FIND_METHOD";
	private static String P_EXPORT_LOG_FLAG = "EXPORT_LOG_FLAG";
	private static String P_LOG_SOURCE = "LOG_SOURCE";
	
	public static String V_DB_LINK = "D2RPTDB1";
	public static String V_EDC_SUBEQ_SOURCE = "EDC-SUB-EQP";
	
	public static String get(String key){
		return (String)sessionDataMap.get(key);
	}
	
	public static String GET_TID() {
		return get(P_TID);
	}
	@SuppressWarnings("unchecked")
	public static void SET_TID(String TID) {
		sessionDataMap.put(P_TID, TID);
	}
	
	public static String GET_SHOP() {
		return get(P_SHOP);
	}
	@SuppressWarnings("unchecked")
	public static void SET_SHOP(String SHOP) {
		sessionDataMap.put(P_SHOP, SHOP);
	}
	
	public static String GET_SOURCE() {
		return get(P_SOURCE);
	}
	@SuppressWarnings("unchecked")
	public static void SET_SOURCE(String SOURCE) {
		sessionDataMap.put(P_SOURCE, SOURCE);
	}
	
	public static String GET_EQP_TYPE() {
		return get(P_EQP_TYPE);
	}
	@SuppressWarnings("unchecked")
	public static void SET_EQP_TYPE(String EQP_TYPE) {
		sessionDataMap.put(P_EQP_TYPE, EQP_TYPE);
	}
	
	public static String GET_TARGET_FLAG() {
		return get(P_TARGET_FLAG);
	}
	@SuppressWarnings("unchecked")
	public static void SET_TARGET_FLAG(String TARGET_FLAG) {
		sessionDataMap.put(P_TARGET_FLAG, TARGET_FLAG);
	}
	
	public static String GET_WORK_DIR() {
		return get(P_WORK_DIR);
	}
	@SuppressWarnings("unchecked")
	public static void SET_WORK_DIR(String WORK_DIR) {
		sessionDataMap.put(P_WORK_DIR, WORK_DIR);
	}
	
	public static String GET_MAX_COUNT() {
		return get(P_MAX_COUNT);
	}
	@SuppressWarnings("unchecked")
	public static void SET_MAX_COUNT(String MAX_COUNT) {
		sessionDataMap.put(P_MAX_COUNT, MAX_COUNT);
	}

	public static String GET_SYSTEM_CONFIG_DIR() {
		return get(P_SYSTEM_CONFIG_DIR);
	}
	@SuppressWarnings("unchecked")
	public static void SET_SYSTEM_CONFIG_DIR(String SYSTEM_CONFIG_DIR) {
		sessionDataMap.put(P_SYSTEM_CONFIG_DIR, SYSTEM_CONFIG_DIR);
	}
	
	public static String GET_LOG_CONFIG_DIR() {
		return get(P_LOG_CONFIG_DIR);
	}
	@SuppressWarnings("unchecked")
	public static void SET_LOG_CONFIG_DIR(String LOG_CONFIG_DIR) {
		sessionDataMap.put(P_LOG_CONFIG_DIR,LOG_CONFIG_DIR);
	}
	
	public static String GET_ACTIVATE_DB_FIND_METHOD() {
		return get(P_ACTIVATE_DB_FIND_METHOD);
	}
	@SuppressWarnings("unchecked")
	public static void SET_ACTIVATE_DB_FIND_METHOD(String ACTIVATE_DB_FIND_METHOD) {
		sessionDataMap.put(P_ACTIVATE_DB_FIND_METHOD,ACTIVATE_DB_FIND_METHOD);
	}
	
	public static String GET_EXPORT_LOG_FLAG() {
		return get(P_EXPORT_LOG_FLAG);
	}
	@SuppressWarnings("unchecked")
	public static void SET_EXPORT_LOG_FLAG(String EXPORT_LOG_FLAG) {
		sessionDataMap.put(P_EXPORT_LOG_FLAG,EXPORT_LOG_FLAG);
	}
	
	public static String GET_LOG_SOURCE() {
		return get(P_LOG_SOURCE);
	}
	@SuppressWarnings("unchecked")
	public static void SET_LOG_SOURCE(String LOG_SOURCE){
		sessionDataMap.put(P_LOG_SOURCE,LOG_SOURCE);
	}
	
}
