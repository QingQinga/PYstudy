package com.mdt.array.entity;

import java.io.Serializable;

/**
 ***************************************************
 * @Title ArrayGlassSumBaseEntity
 * @author 林华锋
 * @Date 2017年4月20日下午4:48:24
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayGlassSumBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;

	private String OPE_NO;
	private String SHEET_ID;
	private String END_TIME;
	private String PARAM_COLLECTION;
	private String PARAM_GROUP;
	private String PARAM_NAME;
	private String PARAM_VALUE;
	private String AVG;
	private String MAX;
	private String MIN;
	private String STD;
	private String UNIFORMITY;
	private String RANGE;
	private String SPEC_HIGH;
	private String SPEC_LOW;
	private String SPEC_TARGET;
	private String CONTROL_HIGH;
	private String CONTROL_LOW;
	private String THREE_SIGMA;
	private String PARAM_JUDGE;

	public String getOPE_NO() {
		return OPE_NO;
	}

	public void setOPE_NO(String oPE_NO) {
		OPE_NO = oPE_NO;
	}

	public String getSHEET_ID() {
		return SHEET_ID;
	}

	public void setSHEET_ID(String sHEET_ID) {
		SHEET_ID = sHEET_ID;
	}

	public String getEND_TIME() {
		return END_TIME;
	}

	public void setEND_TIME(String eND_TIME) {
		END_TIME = eND_TIME;
	}

	public String getPARAM_COLLECTION() {
		return PARAM_COLLECTION;
	}

	public void setPARAM_COLLECTION(String pARAM_COLLECTION) {
		PARAM_COLLECTION = pARAM_COLLECTION;
	}

	public String getPARAM_GROUP() {
		return PARAM_GROUP;
	}

	public void setPARAM_GROUP(String pARAM_GROUP) {
		PARAM_GROUP = pARAM_GROUP;
	}

	public String getPARAM_NAME() {
		return PARAM_NAME;
	}

	public void setPARAM_NAME(String pARAM_NAME) {
		PARAM_NAME = pARAM_NAME;
	}

	public String getPARAM_VALUE() {
		return PARAM_VALUE;
	}

	public void setPARAM_VALUE(String pARAM_VALUE) {
		PARAM_VALUE = pARAM_VALUE;
	}

	public String getAVG() {
		return AVG;
	}

	public void setAVG(String aVG) {
		AVG = aVG;
	}

	public String getMAX() {
		return MAX;
	}

	public void setMAX(String mAX) {
		MAX = mAX;
	}

	public String getMIN() {
		return MIN;
	}

	public void setMIN(String mIN) {
		MIN = mIN;
	}

	public String getSTD() {
		return STD;
	}

	public void setSTD(String sTD) {
		STD = sTD;
	}

	public String getUNIFORMITY() {
		return UNIFORMITY;
	}

	public void setUNIFORMITY(String uNIFORMITY) {
		UNIFORMITY = uNIFORMITY;
	}

	public String getRANGE() {
		return RANGE;
	}

	public void setRANGE(String rANGE) {
		RANGE = rANGE;
	}

	public String getSPEC_HIGH() {
		return SPEC_HIGH;
	}

	public void setSPEC_HIGH(String sPEC_HIGH) {
		SPEC_HIGH = sPEC_HIGH;
	}

	public String getSPEC_LOW() {
		return SPEC_LOW;
	}

	public void setSPEC_LOW(String sPEC_LOW) {
		SPEC_LOW = sPEC_LOW;
	}

	public String getSPEC_TARGET() {
		return SPEC_TARGET;
	}

	public void setSPEC_TARGET(String sPEC_TARGET) {
		SPEC_TARGET = sPEC_TARGET;
	}

	public String getCONTROL_HIGH() {
		return CONTROL_HIGH;
	}

	public void setCONTROL_HIGH(String cONTROL_HIGH) {
		CONTROL_HIGH = cONTROL_HIGH;
	}

	public String getCONTROL_LOW() {
		return CONTROL_LOW;
	}

	public void setCONTROL_LOW(String cONTROL_LOW) {
		CONTROL_LOW = cONTROL_LOW;
	}

	public String getTHREE_SIGMA() {
		return THREE_SIGMA;
	}

	public void setTHREE_SIGMA(String tHREE_SIGMA) {
		THREE_SIGMA = tHREE_SIGMA;
	}

	public String getPARAM_JUDGE() {
		return PARAM_JUDGE;
	}

	public void setPARAM_JUDGE(String pARAM_JUDGE) {
		PARAM_JUDGE = pARAM_JUDGE;
	}

}
