package com.mdt.array.entity;

import java.io.Serializable;

/**
 ***************************************************
 * @Title ArrayDefectBaseEntity
 * @author 林华锋
 * @Date 2017年4月20日下午4:54:47
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayDefectBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String OPE_NO;
	private String SHEET_ID;
	private String END_TIME;
	private String DEFECT_SEQ_NO;
	private String CHIP_ID;
	private String CHIP_NO;
	private String DEFECT_CODE;
	private String DEFECT_CODE_DESC;
	private String DEFECT_PATTERN;
	private String DEFECT_SIZE_TYPE;
	private String IMAGE_DATA;
	private String MAIN_DEFECT_FLAG;
	private String REJUDGE_FLAG;
	private String SIZE;
	private String S;
	private String G;
	private String X;
	private String Y;
	private String X2;
	private String Y2;
	private String X3;
	private String Y3;

	public String getOPE_NO() {
		return OPE_NO;
	}

	public void setOPE_NO(String oPE_NO) {
		OPE_NO = oPE_NO;
	}

	public String getSHEET_ID() {
		return SHEET_ID;
	}

	public void setSHEET_ID(String sHEET_ID) {
		SHEET_ID = sHEET_ID;
	}

	public String getEND_TIME() {
		return END_TIME;
	}

	public void setEND_TIME(String eND_TIME) {
		END_TIME = eND_TIME;
	}

	public String getDEFECT_SEQ_NO() {
		return DEFECT_SEQ_NO;
	}

	public void setDEFECT_SEQ_NO(String dEFECT_SEQ_NO) {
		DEFECT_SEQ_NO = dEFECT_SEQ_NO;
	}

	public String getCHIP_ID() {
		return CHIP_ID;
	}

	public void setCHIP_ID(String cHIP_ID) {
		CHIP_ID = cHIP_ID;
	}

	public String getCHIP_NO() {
		return CHIP_NO;
	}

	public void setCHIP_NO(String cHIP_NO) {
		CHIP_NO = cHIP_NO;
	}

	public String getDEFECT_CODE() {
		return DEFECT_CODE;
	}

	public void setDEFECT_CODE(String dEFECT_CODE) {
		DEFECT_CODE = dEFECT_CODE;
	}

	public String getDEFECT_CODE_DESC() {
		return DEFECT_CODE_DESC;
	}

	public void setDEFECT_CODE_DESC(String dEFECT_CODE_DESC) {
		DEFECT_CODE_DESC = dEFECT_CODE_DESC;
	}

	public String getDEFECT_PATTERN() {
		return DEFECT_PATTERN;
	}

	public void setDEFECT_PATTERN(String dEFECT_PATTERN) {
		DEFECT_PATTERN = dEFECT_PATTERN;
	}

	public String getDEFECT_SIZE_TYPE() {
		return DEFECT_SIZE_TYPE;
	}

	public void setDEFECT_SIZE_TYPE(String dEFECT_SIZE_TYPE) {
		DEFECT_SIZE_TYPE = dEFECT_SIZE_TYPE;
	}

	public String getIMAGE_DATA() {
		return IMAGE_DATA;
	}

	public void setIMAGE_DATA(String iMAGE_DATA) {
		IMAGE_DATA = iMAGE_DATA;
	}

	public String getMAIN_DEFECT_FLAG() {
		return MAIN_DEFECT_FLAG;
	}

	public void setMAIN_DEFECT_FLAG(String mAIN_DEFECT_FLAG) {
		MAIN_DEFECT_FLAG = mAIN_DEFECT_FLAG;
	}

	public String getREJUDGE_FLAG() {
		return REJUDGE_FLAG;
	}

	public void setREJUDGE_FLAG(String rEJUDGE_FLAG) {
		REJUDGE_FLAG = rEJUDGE_FLAG;
	}

	public String getSIZE() {
		return SIZE;
	}

	public void setSIZE(String sIZE) {
		SIZE = sIZE;
	}

	public String getS() {
		return S;
	}

	public void setS(String s) {
		S = s;
	}

	public String getG() {
		return G;
	}

	public void setG(String g) {
		G = g;
	}

	public String getX() {
		return X;
	}

	public void setX(String x) {
		X = x;
	}

	public String getY() {
		return Y;
	}

	public void setY(String y) {
		Y = y;
	}

	public String getX2() {
		return X2;
	}

	public void setX2(String x2) {
		X2 = x2;
	}

	public String getY2() {
		return Y2;
	}

	public void setY2(String y2) {
		Y2 = y2;
	}

	public String getX3() {
		return X3;
	}

	public void setX3(String x3) {
		X3 = x3;
	}

	public String getY3() {
		return Y3;
	}

	public void setY3(String y3) {
		Y3 = y3;
	}

}
