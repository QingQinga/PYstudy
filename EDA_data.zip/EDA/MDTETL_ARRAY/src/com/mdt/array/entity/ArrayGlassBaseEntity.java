package com.mdt.array.entity;

import java.io.Serializable;

/**
 ***************************************************
 * @Title ArrayGlassBaseEntity
 * @author 林华锋
 * @Date 2017年4月20日下午4:46:03
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayGlassBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String OPE_NO;
	private String SHEET_ID;
	private String PRODUCT_ID;
	private String LOT_ID;
	private String RECIPE_ID;
	private String CASSETTE_ID;
	private String SLOT_NO;
	private String ROUTE_ID;
	private String PRE_OPE_NO;
	private String PRE_OPE_ID;
	private String PRE_EQUIP_ID;
	private String PRE_RECIPE_ID;
	private String PRE_START_TIME;
	private String PRE_END_TIME;
	private String EQ_ID;
	private String SUBEQ_ID;
	private String SAMPLING_FLAG;
	private String USER_ID;
	private String ABNORMAL_FLAG;
	private String START_TIME;
	private String END_TIME;
	private String MAIN_JUDGE;
	private String SHEET_JUDGE;
	private String HP_HOT_CHAMBER_NO;
	private String HP_COLD_CHAMBER_NO;
	private String HP_HOT_CHAMBER_UNIT_ID;
	private String HP_COLD_CHAMBER_UNIT_ID;
	private String TTL_PANEL_CNT;
	private String TACK_TIME;

	private String PARENT_LOT;

	public String getOPE_NO() {
		return OPE_NO;
	}

	public void setOPE_NO(String oPE_NO) {
		OPE_NO = oPE_NO;
	}

	public String getSHEET_ID() {
		return SHEET_ID;
	}

	public void setSHEET_ID(String sHEET_ID) {
		SHEET_ID = sHEET_ID;
	}

	public String getPRODUCT_ID() {
		return PRODUCT_ID;
	}

	public void setPRODUCT_ID(String pRODUCT_ID) {
		PRODUCT_ID = pRODUCT_ID;
	}

	public String getLOT_ID() {
		return LOT_ID;
	}

	public void setLOT_ID(String lOT_ID) {
		LOT_ID = lOT_ID;
	}

	public String getRECIPE_ID() {
		return RECIPE_ID;
	}

	public void setRECIPE_ID(String rECIPE_ID) {
		RECIPE_ID = rECIPE_ID;
	}

	public String getCASSETTE_ID() {
		return CASSETTE_ID;
	}

	public void setCASSETTE_ID(String cASSETTE_ID) {
		CASSETTE_ID = cASSETTE_ID;
	}

	public String getSLOT_NO() {
		return SLOT_NO;
	}

	public void setSLOT_NO(String sLOT_NO) {
		SLOT_NO = sLOT_NO;
	}

	public String getROUTE_ID() {
		return ROUTE_ID;
	}

	public void setROUTE_ID(String rOUTE_ID) {
		ROUTE_ID = rOUTE_ID;
	}

	public String getPRE_OPE_NO() {
		return PRE_OPE_NO;
	}

	public void setPRE_OPE_NO(String pRE_OPE_NO) {
		PRE_OPE_NO = pRE_OPE_NO;
	}

	public String getPRE_OPE_ID() {
		return PRE_OPE_ID;
	}

	public void setPRE_OPE_ID(String pRE_OPE_ID) {
		PRE_OPE_ID = pRE_OPE_ID;
	}

	public String getPRE_EQUIP_ID() {
		return PRE_EQUIP_ID;
	}

	public void setPRE_EQUIP_ID(String pRE_EQUIP_ID) {
		PRE_EQUIP_ID = pRE_EQUIP_ID;
	}

	public String getPRE_RECIPE_ID() {
		return PRE_RECIPE_ID;
	}

	public void setPRE_RECIPE_ID(String pRE_RECIPE_ID) {
		PRE_RECIPE_ID = pRE_RECIPE_ID;
	}

	public String getPRE_START_TIME() {
		return PRE_START_TIME;
	}

	public void setPRE_START_TIME(String pRE_START_TIME) {
		PRE_START_TIME = pRE_START_TIME;
	}

	public String getPRE_END_TIME() {
		return PRE_END_TIME;
	}

	public void setPRE_END_TIME(String pRE_END_TIME) {
		PRE_END_TIME = pRE_END_TIME;
	}

	public String getEQ_ID() {
		return EQ_ID;
	}

	public void setEQ_ID(String eQ_ID) {
		EQ_ID = eQ_ID;
	}

	public String getSUBEQ_ID() {
		return SUBEQ_ID;
	}

	public void setSUBEQ_ID(String sUBEQ_ID) {
		SUBEQ_ID = sUBEQ_ID;
	}

	public String getSAMPLING_FLAG() {
		return SAMPLING_FLAG;
	}

	public void setSAMPLING_FLAG(String sAMPLING_FLAG) {
		SAMPLING_FLAG = sAMPLING_FLAG;
	}

	public String getUSER_ID() {
		return USER_ID;
	}

	public void setUSER_ID(String uSER_ID) {
		USER_ID = uSER_ID;
	}

	public String getABNORMAL_FLAG() {
		return ABNORMAL_FLAG;
	}

	public void setABNORMAL_FLAG(String aBNORMAL_FLAG) {
		ABNORMAL_FLAG = aBNORMAL_FLAG;
	}

	public String getSTART_TIME() {
		return START_TIME;
	}

	public void setSTART_TIME(String sTART_TIME) {
		START_TIME = sTART_TIME;
	}

	public String getEND_TIME() {
		return END_TIME;
	}

	public void setEND_TIME(String eND_TIME) {
		END_TIME = eND_TIME;
	}

	public String getMAIN_JUDGE() {
		return MAIN_JUDGE;
	}

	public void setMAIN_JUDGE(String mAIN_JUDGE) {
		MAIN_JUDGE = mAIN_JUDGE;
	}

	public String getSHEET_JUDGE() {
		return SHEET_JUDGE;
	}

	public void setSHEET_JUDGE(String sHEET_JUDGE) {
		SHEET_JUDGE = sHEET_JUDGE;
	}

	public String getHP_HOT_CHAMBER_NO() {
		return HP_HOT_CHAMBER_NO;
	}

	public void setHP_HOT_CHAMBER_NO(String hP_HOT_CHAMBER_NO) {
		HP_HOT_CHAMBER_NO = hP_HOT_CHAMBER_NO;
	}

	public String getHP_COLD_CHAMBER_NO() {
		return HP_COLD_CHAMBER_NO;
	}

	public void setHP_COLD_CHAMBER_NO(String hP_COLD_CHAMBER_NO) {
		HP_COLD_CHAMBER_NO = hP_COLD_CHAMBER_NO;
	}

	public String getHP_HOT_CHAMBER_UNIT_ID() {
		return HP_HOT_CHAMBER_UNIT_ID;
	}

	public void setHP_HOT_CHAMBER_UNIT_ID(String hP_HOT_CHAMBER_UNIT_ID) {
		HP_HOT_CHAMBER_UNIT_ID = hP_HOT_CHAMBER_UNIT_ID;
	}

	public String getHP_COLD_CHAMBER_UNIT_ID() {
		return HP_COLD_CHAMBER_UNIT_ID;
	}

	public void setHP_COLD_CHAMBER_UNIT_ID(String hP_COLD_CHAMBER_UNIT_ID) {
		HP_COLD_CHAMBER_UNIT_ID = hP_COLD_CHAMBER_UNIT_ID;
	}

	public String getTTL_PANEL_CNT() {
		return TTL_PANEL_CNT;
	}

	public void setTTL_PANEL_CNT(String tTL_PANEL_CNT) {
		TTL_PANEL_CNT = tTL_PANEL_CNT;
	}

	public String getTACK_TIME() {
		return TACK_TIME;
	}

	public void setTACK_TIME(String tACK_TIME) {
		TACK_TIME = tACK_TIME;
	}

	public String getPARENT_LOT() {
		return PARENT_LOT;
	}

	public void setPARENT_LOT(String pARENT_LOT) {
		PARENT_LOT = pARENT_LOT;
	}

}
