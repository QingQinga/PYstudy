package com.mdt.array.entity;

import java.io.Serializable;

/**
 ***************************************************
 * @Title ArrayGlassCommonEnity
 * @author 林华锋
 * @Date 2017年3月24日下午3:12:36
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class ArrayChipBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String OPE_NO;
	private String SHEET_ID;
	private String END_TIME;
	private String CHIP_ID;
	private String CHIP_NO;
	private String JUDGE;
	private String MAIN_DEFECT_CODE;
	private String TTL_DEFECT_CNT;

	public String getOPE_NO() {
		return OPE_NO;
	}

	public void setOPE_NO(String oPE_NO) {
		OPE_NO = oPE_NO;
	}

	public String getSHEET_ID() {
		return SHEET_ID;
	}

	public void setSHEET_ID(String sHEET_ID) {
		SHEET_ID = sHEET_ID;
	}

	public String getEND_TIME() {
		return END_TIME;
	}

	public void setEND_TIME(String eND_TIME) {
		END_TIME = eND_TIME;
	}

	public String getCHIP_ID() {
		return CHIP_ID;
	}

	public void setCHIP_ID(String cHIP_ID) {
		CHIP_ID = cHIP_ID;
	}

	public String getCHIP_NO() {
		return CHIP_NO;
	}

	public void setCHIP_NO(String cHIP_NO) {
		CHIP_NO = cHIP_NO;
	}

	public String getJUDGE() {
		return JUDGE;
	}

	public void setJUDGE(String jUDGE) {
		JUDGE = jUDGE;
	}

	public String getMAIN_DEFECT_CODE() {
		return MAIN_DEFECT_CODE;
	}

	public void setMAIN_DEFECT_CODE(String mAIN_DEFECT_CODE) {
		MAIN_DEFECT_CODE = mAIN_DEFECT_CODE;
	}

	public String getTTL_DEFECT_CNT() {
		return TTL_DEFECT_CNT;
	}

	public void setTTL_DEFECT_CNT(String tTL_DEFECT_CNT) {
		TTL_DEFECT_CNT = tTL_DEFECT_CNT;
	}

}
