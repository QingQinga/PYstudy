package com.mdt.array.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.array.entity.ProductEntity;
import com.mdt.array.util.DBUtil;

/**
 ***************************************************
 * @Title ProductDao 处理基本表 Product
 * @author 林华锋
 * @Date 2017年2月14日下午3:17:17
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class ProductDao {

	private static Logger logger = Logger.getLogger(ProductDao.class);

	/**
	 * 基本表Product插入语句
	 * @param productEntity 实体类对象
	 * @param conn 数据库连接
	 * @return
	 */
	public static boolean addProductTable(ProductEntity Entity, Connection conn,String fid) {
		String loaderProduct = "begin array_base_loader.load_product; end;";
		String sql = "INSERT INTO LDR_ARRAY_PRODUCT_T (" 
		           + "product_id,"
		           + "product_group" 
		           + ") VALUES ("
				   + "?,"
				   + "?)";
        Object[] params ={Entity.getPRODUCT_ID(),Entity.getPRODUCT_GROUP()};
		 
        boolean isErrorRet = true;
				
		try {
			DBUtil.executeUpdate(sql, params, conn);
			logger.info("FID: " + fid + "|| Insert ldr_array_product_t Success!");
			DBUtil.stmt = conn.createStatement();
			DBUtil.stmt.execute(loaderProduct);
			logger.info("FID: " + fid + "|| Call Product Loader Success!");
		} catch (Exception ex) {
			logger.error("FID: " + fid + "|| Insert ldr_array_product_t Failed! Error Message: " + ex.getMessage());
			isErrorRet = false;
		} finally {	
			
			 try
				{
					if(DBUtil.pstmt != null)	
						DBUtil.pstmt.close();
					DBUtil.stmt.close();	
				}
				catch(SQLException ex)
				{
					logger.error("FID: " + fid + "|| An Error Caused: " + ex.getMessage());
					isErrorRet =false;
				}
		}

		if (isErrorRet){
			return true;
		}else{
			return false;
		}
	}

}
