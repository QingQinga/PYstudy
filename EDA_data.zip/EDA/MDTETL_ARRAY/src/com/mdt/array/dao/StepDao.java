package com.mdt.array.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.array.entity.StepEntity;
import com.mdt.array.util.DBUtil;

/**
 ***************************************************
 * @Title StepDao 处理基本表Step
 * @author 林华锋
 * @Date 2017年2月14日下午3:17:28
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class StepDao {

	private static Logger logger = Logger.getLogger(StepDao.class);
	public static Statement stmt ;
	/**
	 * 基本表Step 插入语句
	 * 
	 * @param stepEntity
	 *            Step类对象
	 * @param conn
	 *            数据库连接
	 * @return
	 */
	public static boolean addStepTable(StepEntity Entity, Connection conn, String fid) {
        
		String loaderStep = "begin array_base_loader.load_step; end;";
		String sql = "INSERT INTO ldr_array_step_t (" + "STEP_ID,STEP_GROUP,STEP_SEQ,STEP_TYPE" + ") VALUES (" + "?,?,?,?)";
        Object[] params = {Entity.getSTEP_ID(),Entity.getSTEP_GROUP(),Entity.getSTEP_SEQ(),Entity.getSTEP_TYPE()};
		
        boolean isErrorRet = true;
        
		try {
            DBUtil.executeUpdate(sql, params, conn);
			logger.info("FID: " + fid + "|| INSERT ldr_ARRAY_step_t SUCCESS!");
			stmt = conn.createStatement();
			stmt.execute(loaderStep);
			logger.info("FID: " + fid + "|| CALL Step Loader Success!");
		} catch (Exception ex) {
			logger.error("FID: " + fid + "|| INSERT ldr_ARRAY_step_t Failed! Error Message:" + ex.getMessage());
			isErrorRet = false;
		} finally {
			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
					stmt.close();
				}
			} catch (SQLException ex) {
				logger.error("FID: " + fid + "|| An Error Caused:" + ex.getMessage());
				isErrorRet = false;
			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}
	}
}
