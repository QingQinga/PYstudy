package com.mdt.array.connection;

import java.sql.Connection;

import org.apache.log4j.Logger;

import com.mdt.array.util.DBUtil;

/**
 ***************************************************
 * @Title SPCConnection 创建连接EDA数据库
 * @author qing
 * @Date 2017年7月5日下午2:52:58
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class SPCDBConnection {

	private static Logger logger = Logger.getLogger(SPCDBConnection.class);

	public static Connection SPC_CONN;
	public static String DBName = "SPC";
	public static String UserName = "spcldr";
	public static String UserPwd = "spcldr2017";
	public static String HostName = "10.96.1.56";
	public static String DB_Url = "jdbc:oracle:thin:@" + HostName + ":" + "1521" + ":" + DBName;

	public static Connection getSPC_CONN() throws Exception {
		if (SPC_CONN == null || SPC_CONN.isClosed()) {
			setSPC_CONN();
		}
		return SPC_CONN;
	}

	public static void setSPC_CONN() {

		try {
			SPC_CONN = DBUtil.getConn(DB_Url, UserName, UserPwd);
		} catch (Exception e) {
			logger.error("<" + DB_Url + ">" + "SPCDB Connected Failed! Error Message:" + e.getMessage());
		}
	}

}
