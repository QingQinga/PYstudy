package com.mdt.array.array_cdovl.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayResultBaseEntity;
/**
 ***************************************************
 * @Title  ArrayCdovlResultEntity                                    
 * @author 林华锋
 * @Date   2017年4月20日下午5:16:17
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayCdovlResultEntity extends ArrayResultBaseEntity implements Serializable {
 
	private static final long serialVersionUID = 1L;

	private String TEMPLATE_NO;
	private String IMAGE_DATA;
	private String TABLE_NO;
	private String HEAD_NO;
    private String SHOT_ID;
    private String SEQ_IN_SHOT;
    
    
	public String getTEMPLATE_NO() {
		return TEMPLATE_NO;
	}

	public void setTEMPLATE_NO(String tEMPLATE_NO) {
		TEMPLATE_NO = tEMPLATE_NO;
	}

	public String getIMAGE_DATA() {
		return IMAGE_DATA;
	}

	public void setIMAGE_DATA(String iMAGE_DATA) {
		IMAGE_DATA = iMAGE_DATA;
	}

	public String getTABLE_NO() {
		return TABLE_NO;
	}

	public void setTABLE_NO(String tABLE_NO) {
		TABLE_NO = tABLE_NO;
	}

	public String getHEAD_NO() {
		return HEAD_NO;
	}

	public void setHEAD_NO(String hEAD_NO) {
		HEAD_NO = hEAD_NO;
	}

	public String getSHOT_ID() {
		return SHOT_ID;
	}

	public void setSHOT_ID(String sHOT_ID) {
		SHOT_ID = sHOT_ID;
	}

	public String getSEQ_IN_SHOT() {
		return SEQ_IN_SHOT;
	}

	public void setSEQ_IN_SHOT(String sEQ_IN_SHOT) {
		SEQ_IN_SHOT = sEQ_IN_SHOT;
	}

	
	
}
