package com.mdt.array.array_cdovl.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.array.array_cdovl.entity.ArrayCdovlResultEntity;
import com.mdt.array.util.DBUtil;

/**
 ***************************************************
 * @Title  ArrayCdovlResultDao                                    
 * @author 林华锋
 * @Date   2017年4月21日下午2:47:04
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class ArrayCdovlResultDao {
	
	private static Logger logger = Logger.getLogger(ArrayCdovlResultDao.class);

	public static boolean addArrayCdovlResult(ArrayCdovlResultEntity Entity, Connection conn, String fid) throws Exception {
		
		String view = "ARRAY_CDOVL_RESULT_V";
		
		String sql = "INSERT INTO " + view
				  +"(" 
				  +"OPE_NO,"
				  +"SHEET_ID,"
				  +"END_TIME,"
				  +"SITE_NAME,"
				  +"PARAM_COLLECTION,"
				  +"PARAM_NAME,"
				  +"PARAM_VALUE,"
				  +"X,"
				  +"Y,"
				  +"SPEC_HIGH,"
				  +"SPEC_LOW,"
				  +"SPEC_TARGET,"
				  +"CONTROL_HIGH,"
				  +"CONTROL_LOW,"
				  +"CHIP_ID,"
				  +"CHIP_NO,"
				  +"JUDGE,"
				  +"TEMPLATE_NO,"
				  +"IMAGE_DATA,"
				  +"TABLE_NO,"
				  +"HEAD_NO,"
				  +"SHOT_ID,"
				  +"SEQ_IN_SHOT"
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA'))"
				  +")";
        
		Object[] params = {Entity.getOPE_NO(),
				           Entity.getSHEET_ID(),
				           Entity.getEND_TIME(),
				           Entity.getSITE_NAME(),
				           Entity.getPARAM_COLLECTION(),
				           Entity.getPARAM_NAME(),
				           Entity.getPARAM_VALUE(),
				           Entity.getX(),
				           Entity.getY(),
				           Entity.getSPEC_HIGH(),
				           Entity.getSPEC_LOW(),
				           Entity.getSPEC_TARGET(),
				           Entity.getCONTROL_HIGH(),
				           Entity.getCONTROL_LOW(),
				           Entity.getCHIP_ID(),
				           Entity.getCHIP_NO(),
				           Entity.getJUDGE(),
				           Entity.getTEMPLATE_NO(),
				           Entity.getIMAGE_DATA(),
				           Entity.getTABLE_NO(),
				           Entity.getHEAD_NO(),
				           Entity.getSHOT_ID(),
				           Entity.getSEQ_IN_SHOT()
		                  };
                           
		boolean isErrorRet = true;

		try {

			DBUtil.executeUpdate(sql, params, conn);

		} catch (Exception e) {

			logger.error("FID: " + fid + "|| ----- Insert into " + view + " failed! Error Message: " + e.getMessage());

			isErrorRet = false;
			throw e;
		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {

				logger.error("FID: " + fid + "|| ----- An Error Cased: " + e.getMessage());

			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}

	}
	
	/**
	 * 当param_value 为 string 时调用
	 * @param Entity
	 * @param conn
	 * @param fid
	 * @return
	 * @throws Exception
	 */
    public static boolean addArrayCdovlResultStr(ArrayCdovlResultEntity Entity, Connection conn, String fid) throws Exception {
		
		String view = "ARRAY_CDOVL_RESULT_V";
		
		String sql = "INSERT INTO " + view
				  +"(" 
				  +"OPE_NO,"
				  +"SHEET_ID,"
				  +"END_TIME,"
				  +"SITE_NAME,"
				  +"PARAM_COLLECTION,"
				  +"PARAM_NAME,"
				  +"PARAM_VALUE_STR,"
				  +"X,"
				  +"Y,"
				  +"SPEC_HIGH,"
				  +"SPEC_LOW,"
				  +"SPEC_TARGET,"
				  +"CONTROL_HIGH,"
				  +"CONTROL_LOW,"
				  +"CHIP_ID,"
				  +"CHIP_NO,"
				  +"JUDGE,"
				  +"TEMPLATE_NO,"
				  +"IMAGE_DATA,"
				  +"TABLE_NO,"
				  +"HEAD_NO,"
				  +"SHOT_ID,"
				  +"SEQ_IN_SHOT"
		          +") VALUES ("
			      +"?,"
			      +"?,"
			      +"TO_DATE(?,'yyyy-MM-dd HH24:mi:ss'),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA')),"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"?,"
			      +"TO_NUMBER(NULLIF(TO_CHAR(?),'NA'))"
				  +")";
        
		Object[] params = {Entity.getOPE_NO(),
				           Entity.getSHEET_ID(),
				           Entity.getEND_TIME(),
				           Entity.getSITE_NAME(),
				           Entity.getPARAM_COLLECTION(),
				           Entity.getPARAM_NAME(),
				           Entity.getPARAM_VALUE_STR(),
				           Entity.getX(),
				           Entity.getY(),
				           Entity.getSPEC_HIGH(),
				           Entity.getSPEC_LOW(),
				           Entity.getSPEC_TARGET(),
				           Entity.getCONTROL_HIGH(),
				           Entity.getCONTROL_LOW(),
				           Entity.getCHIP_ID(),
				           Entity.getCHIP_NO(),
				           Entity.getJUDGE(),
				           Entity.getTEMPLATE_NO(),
				           Entity.getIMAGE_DATA(),
				           Entity.getTABLE_NO(),
				           Entity.getHEAD_NO(),
				           Entity.getSHOT_ID(),
				           Entity.getSEQ_IN_SHOT()
		                  };
                           
		boolean isErrorRet = true;

		try {

			DBUtil.executeUpdate(sql, params, conn);

		} catch (Exception e) {

			logger.error("FID: " + fid + "|| ----- Insert into " + view + " failed! Error Message: " + e.getMessage());

			isErrorRet = false;
			throw e;
		} finally {

			try {
				if (DBUtil.pstmt != null) {
					DBUtil.pstmt.close();
				}
			} catch (SQLException e) {

				logger.error("FID: " + fid + "|| ----- An Error Cased: " + e.getMessage());

			}
		}

		if (isErrorRet) {
			return true;
		} else {
			return false;
		}

	}
	
	
	

}
