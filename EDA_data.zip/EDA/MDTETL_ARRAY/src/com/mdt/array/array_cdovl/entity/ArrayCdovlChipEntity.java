package com.mdt.array.array_cdovl.entity;

import java.io.Serializable;

import com.mdt.array.entity.ArrayChipBaseEntity;

/**
 ***************************************************
 * @Title  ArrayCdvolChipEntity                                    
 * @author 林华锋
 * @Date   2017年4月20日下午5:13:12
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ArrayCdovlChipEntity extends ArrayChipBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
}
