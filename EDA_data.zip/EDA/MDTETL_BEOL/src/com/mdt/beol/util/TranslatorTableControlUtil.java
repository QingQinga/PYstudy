package com.mdt.beol.util;


import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.mdt.beol.tableview.ETLFileTableView;
import com.mdt.beol.tableview.SessionConstants;
import com.mdt.beol.tableview.TranslatorConfigView;
import com.mdt.beol.tableview.TranslatorTableConstants;


public class TranslatorTableControlUtil {
	
	private static Logger logger = Logger.getLogger(TranslatorTableControlUtil.class);

	public static TranslatorConfigView[] getConfigDataList(Connection conn,String[] paramValueList) throws SQLException{//paramValueList = {String Shop, String Source, String EquipType}
		
		String sqlStr = "select * from " + TranslatorTableConstants.TRANSLATOR_CONFIG_T_NAME + " where SHOP = ? and SOURCE = ? and EQUIP_TYPE = ?";
				
		try{
			
			//logger.info("select * from TRANSLATOR_CONFIG_T where SHOP = '"+paramValueList[0]+"' and SOURCE = '"+paramValueList[1]+"' and EQUIP_TYPE = '"+paramValueList[2]+"'");
			
			TranslatorConfigView[] viewList = (TranslatorConfigView[])SQLHelper.getTableResult(conn, sqlStr, paramValueList, TranslatorTableConstants.TRANSLATOR_CONFIG_T_NAME);
			return viewList;
		}catch(SQLException ex){
			//add error message to log
			throw ex;
		}
	}
	
	public static TranslatorConfigView[] getConfigData(Connection conn,String TID) throws SQLException{
		
		String sqlStr = "select * from " + TranslatorTableConstants.TRANSLATOR_CONFIG_T_NAME + " where TID = '" + TID + "'";
		
		ResultSet rs = null;
		PreparedStatement stmt = null;
		TranslatorConfigView[] viewList = null;
		try {
			stmt = conn.prepareStatement(sqlStr);
			rs = stmt.executeQuery();
			
			Object obj = SQLHelper.resultSet2DataList(rs,TranslatorTableConstants.TRANSLATOR_CONFIG_T_NAME);
			viewList = (TranslatorConfigView[])obj;
			
		} catch (SQLException exp) {
			
			throw exp;
		} finally {
			if(rs!=null)
				rs.close();			
			if(stmt!=null)
				stmt.close();			
		}
		
		return viewList;
	}
	
	public static void updateConfigPID(Connection conn, String TID, String PID) throws Exception{
		String sqlStr = "update " + TranslatorTableConstants.TRANSLATOR_CONFIG_T_NAME +
			" set PID = '" + PID + "'" + " where TID = '" + TID + "'";
		
		PreparedStatement stmt = null;
		try{
			stmt = conn.prepareStatement(sqlStr);
			stmt.execute();
		}catch(Exception ex){
			
			throw ex;
		}finally{
			if(stmt != null)
				stmt.close();
		}
	}
	
	public static void updateConfigParentPID(Connection conn, String TID, String PARENT_PID) throws Exception{
		String sqlStr = "update " + TranslatorTableConstants.TRANSLATOR_CONFIG_T_NAME +
			" set PARENT_PID = '" + PARENT_PID + "'" + " where TID = '" + TID + "'";
		
		PreparedStatement stmt = null;
		try{
			stmt = conn.prepareStatement(sqlStr);
			stmt.execute();
		}catch(Exception ex){
			
			throw ex;
		}finally{
			if(stmt != null)
				stmt.close();
		}
	}
	
	public static void updateConfigRunFlag(Connection conn, String TID, String RUN_FLAG) throws Exception{
		String sqlStr = "update " + TranslatorTableConstants.TRANSLATOR_CONFIG_T_NAME +
			" set RUN_FLAG = '" + RUN_FLAG + "'" + " where TID = '" + TID + "'";
		
		PreparedStatement stmt = null;
		try{
			stmt = conn.prepareStatement(sqlStr);
			stmt.execute();
		}catch(Exception ex){
			
			throw ex;
		}finally{
			if(stmt != null)
				stmt.close();
		}
	}
	
	public static void setETLFileValue(Connection conn,String[] paramValueList) throws SQLException{
		
		String sqlStr = "insert into " + TranslatorTableConstants.ETL_FILE_T_NAME + " ("+
		"FID,EQUIP_TYPE,TARGET_FLAG,FILE_SOURCE,FILE_TYPE,SHOP,SITE,FILE_SRC_DIR,FILE_SIZE,FILE_NAME,FILE_CREATE_TIME" + 
		") values + (" +
		"?,?,?,?,?,?,?,?,?,?,?" +
		")";
		
		PreparedStatement stmt = null;
		try{
			stmt = conn.prepareStatement(sqlStr);
			SQLHelper.setInputParamData(stmt,paramValueList);
			stmt.execute();
			//conn.commit();
		}catch(SQLException sex){
			//add error message to log
			throw sex;
		}finally{
			if(stmt != null)
				stmt.close();
		}
	}
	
	public static ETLFileTableView[] getETLFileList(Connection conn, String[] paramValueList , String max_count) throws SQLException{//FILE_SOURCE,SHOP,EQUIP_TYPE,TARGET_FLAG
		
		String[] targetFlags = paramValueList[3].split(",");
		
		String sqlStr = "select * from " + TranslatorTableConstants.ETL_FILE_T_NAME + 
								" where parse_flag is null and rownum <= ? and FILE_SOURCE = ? and SHOP = ? and EQUIP_TYPE = ?";
		
		String targetStr = " and (";
		for (int i = 0; i < targetFlags.length; i++) {
			targetStr = targetStr +  "TARGET_FLAG = ?";
			if(i+1 < targetFlags.length)
				targetStr = targetStr +  " or ";
		}
		sqlStr = sqlStr + targetStr + ") order by FILE_CREATE_TIME";

		
		try{
			String[] newParamValueList = null;
			newParamValueList = new String[paramValueList.length + 1 + targetFlags.length-1];
		
			newParamValueList[0] = max_count.trim();
			newParamValueList[1] = paramValueList[0].trim();
			newParamValueList[2] = paramValueList[1].trim();
			newParamValueList[3] = paramValueList[2].trim();
			
			for (int i = 0; i < targetFlags.length; i++) {
				newParamValueList[i+4] = targetFlags[i].trim();
			}
	        logger.info(sqlStr);
	        long t1 = System.currentTimeMillis();
			ETLFileTableView[] viewList = (ETLFileTableView[])SQLHelper.getTableResult(conn, sqlStr, newParamValueList, TranslatorTableConstants.ETL_FILE_T_NAME);
	        long t2 = System.currentTimeMillis();
	        logger.info("Query data_file_t time="+(t2-t1));
			return viewList;
		}catch(SQLException ex){
			//add error message to log
			logger.error("[getDataFileList]="+ex.getMessage());
			throw ex;
		}
		
	}
	
	public static void deleteETLFile(Connection conn, String[] paramValueList)throws SQLException{//FID
		
		String sqlStr = "delete from " + TranslatorTableConstants.ETL_FILE_T_NAME +
						" where FID = ?";
		
		PreparedStatement stmt = null;
		try{
			stmt = conn.prepareStatement(sqlStr);
			SQLHelper.setInputParamData(stmt,paramValueList);
			stmt.execute();
			//conn.commit();
		}catch(SQLException sex){
			throw sex;
		}finally{
			if(stmt != null)
				stmt.close();
		}
	}
		
	public static void updateETLFileHst(Connection conn, String systemType, String[] paramValueList) throws Exception{//EDA||SPC||ALL : STATUS_FLAG,FID
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
		String finishTime = dateFormat.format(date);
		
		PreparedStatement stmt = null;
		try{
			String[] newParamValueList = new String[paramValueList.length + 1];
			newParamValueList[0] = paramValueList[0];
			newParamValueList[1] = finishTime;
			newParamValueList[2] = paramValueList[1];
			newParamValueList[3] = paramValueList[2];
						
			String sqlStr = "update " + TranslatorTableConstants.ETL_FILE_HST_T_NAME + " set update_time = sysdate,";
			
			if("TRANSLATOR".equalsIgnoreCase(systemType))
			{
				newParamValueList = paramValueList;
				sqlStr = sqlStr + "TID = ?,DATA_FILE_SRC_DIR = ? where FID = ?";
			}
			else if("EDA".equalsIgnoreCase(systemType)){
				sqlStr = sqlStr + "EDA_STATUS = ?,EDA_FINISH_TIME = to_date(?,'yyyy/mm/dd hh24:mi:ss'),EDA_ERROR_MSG = ? where FID = ?"; 
			}
			else if("SPC".equalsIgnoreCase(systemType)){
				sqlStr = sqlStr + "SPC_STATUS = ?,SPC_FINISH_TIME = to_date(?,'yyyy/mm/dd hh24:mi:ss'),SPC_ERROR_MSG = ? where FID = ?";
			}
			/*
			else{
				sqlStr = sqlStr + "EDA_STATUS_FLAG = ?," +
								  "FINISH_EDA_TIME = to_date(?,'yyyy/mm/dd hh24:mi:ss')," +
								  "SPC_STATUS_FLAG = ?," +
								  "FINISH_SPC_TIME = to_date(?,'yyyy/mm/dd hh24:mi:ss') where FID = ?";
				newParamValueList = new String[5];
				newParamValueList[0] = paramValueList[0];
				newParamValueList[1] = finishTime;
				newParamValueList[2] = paramValueList[0];
				newParamValueList[3] = finishTime;
				newParamValueList[4] = paramValueList[1];
				
			}
			 */
			stmt = conn.prepareStatement(sqlStr);
			SQLHelper.setInputParamData(stmt,newParamValueList);
			stmt.execute();
			//conn.commit();
		}catch(Exception ex){
			throw ex;
		}finally{
			if(stmt != null)
				stmt.close();
		}
	}
		
	public static void transferETLFileToHst(Connection conn, String[] paramValueList)throws SQLException{//TID,FID
		
		String tablename = TranslatorTableConstants.ETL_FILE_HST_T_NAME;
		
		String sqlStr = "insert into " + tablename +
						"(" +
						" FID," +
						" SHOP," +
						" EQUIP_TYPE," +
						" EQUIP_ID," +
						" PRODUCT_ID," +
						" FILE_SOURCE," +
						" FILE_SRC_DIR," +
						" CURRENT_FILE_SRC_DIR," +
						" FILE_NAME," +
						" FILE_TYPE," +
						" FILE_SIZE," +
						" TARGET_FLAG," +
						" FILE_CREATE_TIME," +
						" FILE_ENTER_DB_TIME," +
						" PARSE_FLAG," +
						" UPDATE_TIME" +    
						")" +
						"values (" +
						"?,?,?,?,?," +
						"?,?,?,?,?," +
						"?,?,to_date(?,'yyyy-MM-dd HH24:mi:ss'),to_date(?,'yyyy-MM-dd HH24:mi:ss'),?,sysdate)";

		PreparedStatement stmt = null;
		try{
			stmt = conn.prepareStatement(sqlStr);
			SQLHelper.setInputParamData(stmt,paramValueList);
			stmt.execute();
			//conn.commit();
		}catch(SQLException sex){
			logger.error("transferETLFileToHst fail : " + sex.getMessage());
			throw sex;
			
		}finally{
			if(stmt != null)
			stmt.close();
		}
	}
	
	public static void updateETLFileParseFlag (Connection conn, String FID) throws SQLException{
		String sqlStr = "update " + TranslatorTableConstants.ETL_FILE_T_NAME + " set " +
						"PARSE_FLAG = 'Y' where FID = ?"; 
		
		PreparedStatement stmt = null;
		String[] paramValueList = new String[1];
		paramValueList[0] = FID;
		try{
			stmt = conn.prepareStatement(sqlStr);
			SQLHelper.setInputParamData(stmt,paramValueList);
			stmt.execute();
			//conn.commit();
		}catch(SQLException sex){
			throw sex;
		}finally{
			if(stmt != null)
				stmt.close();
		}
	}	
	
	public static void updateETLFileCurrentSrcDir (Connection conn, String[] paramValueList) throws SQLException{
		String sqlStr = "update " + TranslatorTableConstants.ETL_FILE_HST_T_NAME + " set " +
						"CURRENT_FILE_SRC_DIR = ? where FID = ?"; 
		
		PreparedStatement stmt = null;
		try{
			stmt = conn.prepareStatement(sqlStr);
			SQLHelper.setInputParamData(stmt,paramValueList);
			stmt.execute();
			//conn.commit();
		}catch(SQLException sex){
			throw sex;
		}finally{
			if(stmt != null)
				stmt.close();
		}
	}
	
	
}
