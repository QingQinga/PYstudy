package com.mdt.beol.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
/**
 ***************************************************
 * @Title  DataFileFormatUtil                                    
 * @author 林华锋
 * @Date   2017年4月20日下午4:50:30
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class DataFileFormatUtil {
    
	private static Logger logger = Logger.getLogger(DataFileFormatUtil.class);
	
    /**
	 * 将小写转为大写
	 * 
	 * @param str
	 * @return
	 */
	public static String Shift(String str) {
		int size = str.length();
		char[] chs = str.toCharArray();

		for (int i = 0; i < size; i++) {
			if (chs[i] <= 'z' && chs[i] >= 'a') {
				chs[i] = (char) (chs[i] - 32);
			}
		}
		return new String(chs);
	}
	
    /**
     * 将字符串转换成日期格式
     * @param entityParam 实体类字段名
     * @return
     */
	public static Date StringToDate(String entityParam) {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = null;
		try {
			date =format.parse(entityParam);
		} catch (ParseException e) {
			logger.error(" ##### Change the Format Failed! Error Message: " +e.getMessage());
		}
		date = java.sql.Date.valueOf(entityParam); 
		return date;
	}
		
}
