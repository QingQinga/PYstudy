package com.mdt.beol.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 * 
 * @author HuChen
 * @version 1.0
 */
public class CheckDataFileFormatUtil {

	/************************************
	 * If data file of filed first char is "P" or "E"
	 * 2011.12.13 Changed by Gaiseric : if not begin with "D" or "M" or "",then it is production and return true
	 * @param GlassType
	 *            :Machines column
	 * @return true(NOT MQC),false(MQC)
	 *************************************/
	public static boolean GetGlassTypeIsMqc(String GlassType) throws Exception {
		if(GlassType == null || GlassType.equals("")){
			//2012.04.06 Added by Gaiseric 
			return true;
		}else{
			String type = GlassType.substring(0, 1);
			if (type.equalsIgnoreCase("D") || type.equalsIgnoreCase("M")
					|| type.equalsIgnoreCase("")) {
				return false;
			} else {
				return true;
			}
		}
	}

	/**
	 * 2011.12.13 Added by Gaiseric 
	 * This method is split "Glass_Type" into three items:Owner Type,Owner ID,Production Type
	 * 2011.12.25 Added by Gaiseric : Remove the charactor of "』" from Glass_Type
	 * @param Glass_Type format is [Owner Type]_[Owner ID]_[Production Type]
	 * @return A String[3] var:String[0] is Owner_Type;String[1] is
	 *         Owner_ID;String[2] is Glass_Type;
	 */
	public static String[] GetOwnerStrings(String Glass_Type) {
		String[] OwnerStrings = new String[3];
		for (int cnt = 0; cnt < 3; cnt++) {
			OwnerStrings[cnt] = "";
		}
		if (Glass_Type != null) {
			//Remove the charactor of "』"
			//Glass_Type = Glass_Type.replace("』", "");
			String[] tmp = Glass_Type.split("_", -1);
			for (int cnt = 0; cnt < tmp.length; cnt++) {
				if(cnt>2){
					break;
				}else{
					OwnerStrings[cnt] = tmp[cnt].trim();	
				}				
			}
		}
		return OwnerStrings;
	}

	/************************************
	 * Remove repeat character
	 * 
	 * @param str
	 *            :Original character
	 * @return string like:xx1,xx1,xx2,xx1,xx3,Original character锟斤拷xx1,xx2,xx3
	 *************************************/
	@SuppressWarnings("unchecked")
	public static String RemoveDuplication(String str) {
		String[] Str1 = str.split(",");
		String iRetStr = "";
		ArrayList list = new ArrayList();
		for (int i = 0; i < Str1.length; i++) {
			if (!list.contains(Str1[i])) {
				list.add(Str1[i]);
			}
		}
		for (int i = 0; i < list.size(); i++) {
			iRetStr += list.get(i) + ",";
		}

		return iRetStr;
	}

	/************************************
	 * Turn lowercase change to Capital letters
	 * 
	 * @param str
	 *            :Original character
	 * @return smaple:zzz =>ZZZ
	 *************************************/
	public static String Shift(String str) {
		int size = str.length();
		char[] chs = str.toCharArray();
		for (int i = 0; i < size; i++) {
			if (chs[i] <= 'z' && chs[i] >= 'a') {
				chs[i] = (char) (chs[i] - 32);
			}
		}

		return new String(chs);
	}

	/************************************
	 * According to the rules first argument string interception
	 * 
	 * @param str
	 *            :Original character
	 * @param rules
	 * @return smaple:AA_BB,return AA
	 *************************************/
	public static String GetFirstValue(String str, String rules)
			throws Exception {
		String[] names = str.split(rules, -1);

		return names[0].trim();
	}

	/************************************
	 * Check the string type
	 * 
	 * @param str
	 *            :Original character
	 * @return boolean:if this string type equals number,return true
	 *************************************/
	public static boolean CheckNum(String str) {
		if (str.trim().matches("^[+-]?[\\d]+?\\.?([\\d]+)?$")) {
			return true;
		}else {
			return false;
		}
	}
	
	public static boolean Judge_Query(Connection conn,String module_name,String eqp_id,String param_name)
	{
        ResultSet rs=null;
        Statement sttm=null;
        String SqlStr =null;
        int count=0;
        
        SqlStr ="SELECT COUNT(1) AS COUNT FROM SPC_PARAM_CONFIG_T WHERE MODULE_NAME='"+module_name+"' AND EQP_ID=UPPER('"+eqp_id+"') AND PARAM_NAME=UPPER('"+param_name+"')";
        try
        {
        	sttm=conn.createStatement(); 
        	rs=sttm.executeQuery(SqlStr);
        	if(rs.next())
        		count=rs.getInt(1);
       		if(count != 0) 
       		 	return true;
       		else
       		    return false;  
        }
        catch(Exception e)
        { 
        	//System.out.println( "Query database error，SQL statements for： "+ SqlStr+ "\n Error message for" + e.getMessage()); 
        	return false;
        }
        finally
        {
        	try
        	{
        		if(rs != null)
        			rs.close();  
        		if(sttm != null)
        			sttm.close();         			
        	}
        	catch (Exception e) {
        		 //System.out.println( "Release connection error，Error message for： "   +   e.getMessage());  
			}
        }
	}
	
	public static boolean Judge_Query(Connection conn,String module_name,String param_name)
	{
        ResultSet rs=null;
        Statement sttm=null;
        String SqlStr =null;
        int count=0;
        
        SqlStr ="SELECT COUNT(1) AS COUNT FROM SPC_PARAM_CONFIG_T WHERE MODULE_NAME='"+module_name+"' AND PARAM_NAME=UPPER('"+param_name+"')";
        try
        {
        	sttm=conn.createStatement(); 
        	rs=sttm.executeQuery(SqlStr);
        	if(rs.next())
        		count=rs.getInt(1);
       		if(count != 0) 
       		 	return true;
       		else
       		    return false;  
        }
        catch(Exception e)
        { 
        	//System.out.println( "Query database error，SQL statements for： "+ SqlStr+ "\n Error message for" + e.getMessage()); 
        	return false;
        }
        finally
        {
        	try
        	{
        		if(rs != null)
        			rs.close();  
        		if(sttm != null)
        			sttm.close();         			
        	}
        	catch (Exception e) {
        		 //System.out.println( "Release connection error，Error message for： "   +   e.getMessage());  
			}
        }
	}
	
	public static ArrayList SourceParamName(Connection conn,String factory,String translator_type,String translator_name)
	{
        ResultSet rs=null;
        Statement sttm=null;
        String SqlStr =null;
       
        SqlStr=" SELECT DISTINCT A.SOURCE_PARAM_NAME " +
        		" FROM SPC_TRANSLATOR_CONFIG_T T, SPC_PARAM_CONFIG_T A " +
        		" WHERE T.MODULE_NAME = A.MODULE_NAME "+
        		" AND T.FACTORY = '"+factory+"' "+
        		" AND T.TRANSLATOR_TYPE = '"+translator_type+"' "+
        		" AND T.TRANSLATOR_NAME = '"+translator_name+"' ";
        
        ArrayList list = new ArrayList();
        try
        {
        	sttm=conn.createStatement();
        	if(SqlStr != null)
        	{
	        	rs=sttm.executeQuery(SqlStr);
	        	ResultSetMetaData   rsmd   =   rs.getMetaData(); 
	        	int columnCount = rsmd.getColumnCount(); 
	        	while   (rs.next())   
	        	{ 
	        		String value = null; 
	                for(int i=1;i<=columnCount;i++)   { 
	                    value = rs.getObject(i).toString();
	                } 
	                list.add(value); 
	            } 
	        	return list;
        	}
        	else
        		return null;
        }
        catch(Exception e)
        {
        	//System.out.println( "Query database error;SQL statements for: "+ SqlStr+ "\n Error message for" + e.getMessage()); 
        	return null;
        }
        finally
        {
        	try
        	{
        		if(rs != null)
        			rs.close();  
        		if(sttm != null)
        			sttm.close(); 	        			
        	}
        	catch (Exception e) {
        		 //System.out.println( "Release connection error;Error message for: "   +   e.getMessage()); 
			}
        }
	}
	
	public static boolean isValidDate(String inDate,String fromcatType) {//ex:fromcatType=""yyyy-mm-dd"

	    if (inDate == null)
	    	return false;

	    //set the format to use as a constructor argument
	    SimpleDateFormat dateFormat = new SimpleDateFormat(fromcatType);

	    if (inDate.trim().length() != dateFormat.toPattern().length())
	    	return false;

	    dateFormat.setLenient(false);

	    try {
	      //parse the inDate parameter
	      dateFormat.parse(inDate.trim());
	    }
	    catch (ParseException pe) {
	      return false;
	    }
	    return true;
	  }
}
