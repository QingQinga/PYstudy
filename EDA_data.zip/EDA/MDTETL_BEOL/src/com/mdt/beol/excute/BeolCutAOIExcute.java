package com.mdt.beol.excute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.beol.beol_optical_insp.dao.BeolOpticalChipDao;
import com.mdt.beol.beol_optical_insp.dao.BeolOpticalChipSumDao;
import com.mdt.beol.beol_optical_insp.dao.BeolOpticalComponentDao;
import com.mdt.beol.beol_optical_insp.dao.BeolOpticalDefectDao;
import com.mdt.beol.beol_optical_insp.dao.BeolOpticalResultDao;
import com.mdt.beol.beol_optical_insp.entity.BeolOpticalChipEntity;
import com.mdt.beol.beol_optical_insp.entity.BeolOpticalChipSumEntity;
import com.mdt.beol.beol_optical_insp.entity.BeolOpticalComponentEntity;
import com.mdt.beol.beol_optical_insp.entity.BeolOpticalDefectEntity;
import com.mdt.beol.beol_optical_insp.entity.BeolOpticalResultEntity;
import com.mdt.beol.dao.ParameterDao;
import com.mdt.beol.dao.ProductDao;
import com.mdt.beol.dao.StepDao;
import com.mdt.beol.entity.ParameterEntity;
import com.mdt.beol.entity.ProductEntity;
import com.mdt.beol.entity.StepEntity;
import com.mdt.beol.tableview.SessionConstants;
import com.mdt.beol.util.DataFileFormatUtil;
import com.mdt.beol.util.EdaSpcAbstractLoader;

/**
 ***************************************************
 * @Title  CellCutAOIExcute                                    
 * @author 林华锋
 * @Date   2017年4月15日上午8:50:23
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */

public class BeolCutAOIExcute extends EdaSpcAbstractLoader {
	
	private static Logger logger = Logger.getLogger(BeolCutAOIExcute.class);

	public BeolCutAOIExcute() throws Exception{
		super(SessionConstants.GET_SYSTEM_CONFIG_DIR(), SessionConstants.GET_LOG_CONFIG_DIR());
	}

	public Connection EDA_CONN = null;
	public Connection SPC_CONN = null;
	public String discern; // 识别前字符
	public String[] afterDiscern; // 识别后字符
	public BufferedReader reader;
	public String loaderData = "begin cell1_file_loader.load_data; end;";
	public Statement stmt = null;

	/** 实例化实体类对象 Begin **/

	public ParameterEntity parameterEntity = new ParameterEntity();
	public ProductEntity productEntity = new ProductEntity();
	public StepEntity stepEntity = new StepEntity();
	public BeolOpticalComponentEntity opticalComponentEntity = new BeolOpticalComponentEntity();
	public BeolOpticalChipEntity opticalChipEntity = new BeolOpticalChipEntity();
	public BeolOpticalChipSumEntity opticalChipSumEntity = new BeolOpticalChipSumEntity();
	public BeolOpticalDefectEntity defectEntity = new BeolOpticalDefectEntity();
	public BeolOpticalResultEntity resultEntity = new BeolOpticalResultEntity();
	
	/** 实例化实体类对象 End **/

	/** DAO */

	public ProductDao productDao;
	public ParameterDao parameterDao;
	public StepDao stepDao;
	public BeolOpticalComponentDao opticalComponentDao;
	public BeolOpticalChipDao opticalChipDao;
	public BeolOpticalChipSumDao opticalChipSumDao;
	public BeolOpticalResultDao opticalResultDao;
	public BeolOpticalDefectDao opticalDefectDao;

	/** DAO */

	/****** Header_Begin 字段行 */

	public String hFILE_VERSION = null; // 文件版本
	public String hFILE_CREATED_TIME = null; // 创建时间
	public String hEQUIP_TYPE = null; // 设备类型
	public String hEQ_ID = null; // 设备ID
	public String hSubEQ_ID = null; // 子设备ID
	public String hCONTENT = null; // DataBlock内容标题

	/***** Header_End 字段行 */

	/** DOWNLOADED_SHEET_DATA_BEGIN 字段行 */

	public String dsOPE_NO = null;
	public String dsSHEET_ID = null;
	public String dsPRODUCT_ID = null;
	public String dsRECIPE_ID = null;
	public String dsCASSETTE_ID = null;
	public String dsSLOT_NO = null;
	public String dsROUTE_ID = null;
	public String dsARRAY_LOT_ID = null;
	public String dsARRAY_SHEET_ID = null;
	public String dsCF_LOT_ID = null;
	public String dsCF_SHEET_ID = null;
	public String dsCELL_LOT_ID = null;
	public String dsBATCH_ID = null;
	public String dsPRE_OPE_NO = null;
	public String dsPRE_OPE_ID = null;
	public String dsPRE_EQUIP_ID = null;
	public String dsPRE_SUB_EQUIP_ID = null;
	public String dsPRE_RECIPE_ID = null;
	public String dsPRE_START_TIME = null;
	public String dsPRE_END_TIME = null;
	public String dsEQ_ID = null;
	public String dsSUBEQ_ID = null;

	/** DOWNLOADED_SHEET_DATA_END 字段行 */

	/** EQP_SHEET_DATA_BEGIN 字段行 */

	public String esOPE_NO = null;
	public String esSHEET_ID = null;
	public String esSTART_TIME = null;
	public String esEND_TIME = null;
	public String esSAMPLING_FLAG = null;
	public String esUSER_ID = null;
	public String esABNORMAL_FLAG = null;
	public String esMAIN_JUDGE = null;
	public String esSHEET_JUDGE = null;
	public String esTTL_PANEL_CNT = null;
	public String esTACK_TIME = null;
	public String esCOMPONENT_TYPE = null;
	public String esOK_PANEL_COUNT = null;
	public String esNG_PANEL_COUNT = null;
	public String esYIELD = null;

	/** EQP_SHEET_DATA_END 字段行 */

	/** SHEET_SUMMARY_DATA_BEGIN 字段行 */

	public String ssOPE_NO = null;
	public String ssSHEET_ID = null;
	public String ssEND_TIME = null;
	public String ssPARAM_COLLECTION = null;
	public String ssPARAM_GROUP = null;
	public String ssPARAM_NAME = null;
	public String ssAVG = null;
	public String ssMAX = null;
	public String ssMIN = null;
	public String ssSTD = null;
	public String ssUNIFORMITY = null;
	public String ssRANGE = null;
	public String ss3SIGMA = null;
	public String ssSPEC_HIGH = null;
	public String ssSPEC_LOW = null;
	public String ssSPEC_TARGET = null;
	public String ssCONTROL_HIGH = null;
	public String ssCONTROL_LOW = null;

	/** SHEET_SUMMARY_DATA_END 字段行 */

	/** CHIP_DATA_BEGIN 字段行 */

	public String cOPE_NO = null;
	public String cSHEET_ID = null;
	public String cEND_TIME = null;
	public String cCHIP_ID = null;
	public String cCHIP_NO = null;
	public String cCHIP_JUDGE = null;
	public String cMAIN_DEFECT_CODE = null;
	public String cPANEL_RANK = null;
	public String cPANEL_TTL_DEFECT_CNT = null;

	/** CHIP_DATA_END 字段行 */

	/** CHIP_SUMMARY_DATA_BEGIN 字段行 */

	public String csOPE_NO = null;
	public String csSHEET_ID = null;
	public String csEND_TIME = null;
	public String csCHIP_ID = null;
	public String csCHIP_NO = null;
	public String csPARAM_COLLECTION = null;
	public String csPARAM_GROUP = null;
	public String csPARAM_NAME = null;
	public String csAVG = null;
	public String csMAX = null;
	public String csMIN = null;
	public String csSTD = null;
	public String csUNIFORMITY = null;
	public String csRANGE = null;
	public String csSPEC_HIGH = null;
	public String csSPEC_LOW = null;
	public String csSPEC_TARGET = null;
	public String csCONTROL_HIGH = null;
	public String csCONTROL_LOW = null;
	public String cs3SIGMA = null;

	/** CHIP_SUMMARY_DATA_END 字段行 */

	/** SITE_DATA_BEGIN 字段行 */

	public String sOPE_NO = null;
	public String sSHEET_ID = null;
	public String sEND_TIME = null;
	public String sPARAM_COLLECTION = null;
	public String sPARAM_GROUP = null;
	public String sPARAM_NAME = null;
	public String sSITE_NAME = null;
	public String sPARAM_VALUE = null;
	public String sSPEC_HIGH = null;
	public String sSPEC_LOW = null;
	public String sSPEC_TARGET = null;
	public String sCONTROL_HIGH = null;
	public String sCONTROL_LOW = null;
	public String sX = null;
	public String sY = null;
	public String sCHIP_ID = null;
	public String sCHIP_NO = null;
	public String sJUDGE = null;

	/** SITE_DATA_END 字段行 */

	/** DEFECT_DATA_BEGIN 字段行 */

	public String dOPE_NO = null;
	public String dSHEET_ID = null;
	public String dEND_TIME = null;
	public String dCHIP_ID = null;
	public String dCHIP_NO = null;
	public String dDEFECT_JUDGE = null;
	public String dDEFECT_CODE = null;
	public String dDEFECT_CODE_DESC = null;
	public String dDEFECT_PATTERN = null;
	public String dDEFECT_LAYER_TYPE = null;
	public String dIMAGE_DATA = null;
	public String dMAIN_DEFECT_FLAG = null;
	public String dREJUDGE_FLAG = null;
	public String dDEFECT_SEQ_NO = null;
	public String dDEFECT_GROUP = null;
	public String dDEFECT_SIZE = null;
	public String dDEFECT_RANK = null;
	public String dCAPTURE_NO = null;
	public String dS = null;
	public String dG = null;
	public String dX = null;
	public String dY = null;
	public String dX2 = null;
	public String dY2 = null;
	public String dX3 = null;
	public String dy3 = null;
	public String dARRAY_X = null;
	public String dARRAY_Y = null;
	public String dARRAY_X2 = null;
	public String dARRAY_Y2 = null;
	public String dARRAY_X3 = null;
	public String dARRAY_Y3 = null;

	/** DEFECT_DATA_END 字段行 */
	
	/**
	 * ExcuteCenter
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		// args:{TID:0,Shop:1,Source:2,eqp_type:3,target_flag:4,WorkDir:5,max_count:6,SystemLocalConfigPath:7,LogConfigPath:8,db_find_method:9,export_log_file:10}
		if (args != null && args.length > 0) {
			SessionConstants.SET_TID(args[0]);
			SessionConstants.SET_SHOP(args[1]);
			SessionConstants.SET_SOURCE(args[2]);
			SessionConstants.SET_EQP_TYPE(args[3]);
			SessionConstants.SET_TARGET_FLAG(args[4]);
			SessionConstants.SET_WORK_DIR(args[5]);
			SessionConstants.SET_MAX_COUNT(args[6]);
			SessionConstants.SET_SYSTEM_CONFIG_DIR(args[7]);
			SessionConstants.SET_LOG_CONFIG_DIR(args[8]);
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(args[9]);
			SessionConstants.SET_EXPORT_LOG_FLAG(args[10]);
		} else {
			SessionConstants.SET_TID("BEOL_FILE_CUT_AOI_1"); // translator_config_t
			SessionConstants.SET_SHOP("BEOl");
			SessionConstants.SET_SOURCE("FILE");
			SessionConstants.SET_EQP_TYPE("CUT_AOI");
			SessionConstants.SET_TARGET_FLAG("0,1,2,3,4,5,6,7,8,9");
			SessionConstants.SET_WORK_DIR("D:\\MDT_Data");
			SessionConstants.SET_MAX_COUNT("100");
			SessionConstants.SET_SYSTEM_CONFIG_DIR("D:\\MDT_Data\\system.properties");
			SessionConstants.SET_LOG_CONFIG_DIR("D:\\MDT_Data\\log4j.properties");
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD("FALSE");
			SessionConstants.SET_EXPORT_LOG_FLAG("TRUE");
		}

		try {
			BeolCutAOIExcute CutAOIExcute = new BeolCutAOIExcute();

			CutAOIExcute.run();

		} catch (Exception e) {
			logger.error("FID: " + FID+ "|| There hava a error! Error Message: " + e.getMessage());
		}

	}

	@Override
	public void readyToRun(File file) throws Exception {

		logger.info("FID: " + FID+ " || 【 Translator Begin 】");
		
		ReadDFSFile(file);
			
		logger.info("FID: " + FID+ " || 【 Translator Begin 】");
	}

	@SuppressWarnings("static-access")
	public void ReadDFSFile(File file) throws Exception {
        
		EDA_CONN = getEdaConnection();
		
		if (EDA_CONN.isClosed()) {
			logger.error("FID: " + FID+ "  The database connection was error");
		}
		
		EDA_CONN.setAutoCommit(false);

		try {
			reader = new BufferedReader(new FileReader(file.getPath()));

			while ((discern = reader.readLine()) != null) {
				if (discern.length() == 0) {
					continue;
				}
				/***********************************************************************
				 * BEGIN ****************** 设备抛出csv文件，读取Header部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("HEADER_BEGIN")) {

					logger.info("FID: " + FID+ "|| 【  HEADER_BEGIN 读取开始  】");

					while ((discern = reader.readLine()) != null && getEdaSuccessFlag()) {
						if (DataFileFormatUtil.Shift(discern).startsWith("FILE_VERSION")) {
							afterDiscern = discern.split(":", -1);
							hFILE_VERSION = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("FILE_CREATED_TIME")) {
							afterDiscern = discern.split(":", -1);
							hFILE_CREATED_TIME = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQUIP_TYPE")) {
							afterDiscern = discern.split(":", -1);
							hEQUIP_TYPE = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("SUBEQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hSubEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("CONTENT")) {
							afterDiscern = discern.split(":", -1);
							hCONTENT = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).endsWith("HEADER_END")) {
							break;
						}
					}
					logger.info("FID: " + FID+ "|| 【  HEADER_END 读取结束  】");

				}
				/*********************************************************************
				 * END ******************** 设备抛出csv文件，读取Header部分 ****** END *
				 ********************************************************************/

				/***********************************************************************
				 * BEGIN ***************设备抛出csv文件，读取SHEET_DATA部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("DOWNLOADED_SHEET_DATA_BEGIN")) {

					logger.info("FID: " + FID+ "|| 【  DOWNLOADED_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DOWNLOADED_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}
					logger.info("FID: " + FID+ "|| 【  DOWNLOADED_SHEET_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END *******设备抛出csv文件，读取DOWNLOADED_SHEET_DATA部分 ****** END **
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN **** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** BEGIN *******
				 ***********************************************************************/
				if (discern.startsWith("EQP_SHEET_DATA_BEGIN")) {

					logger.info("FID: " + FID+ "|| 【  EQP_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("EQP_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID: " + FID+ "|| 【  EQP_SHEET_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END ********** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** BEGIN *
				 ***********************************************************************/

				if (discern.startsWith("SHEET_SUMMARY_DATA_BEGIN")) {

					logger.info("FID: " + FID+ "|| 【  SHEET_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SHEET_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID: " + FID+ "|| 【  SHEET_SUMMARY_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END * 设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** END ****
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取CHIP_DATA_BEGIN部分 ******** BEGIN *****
				 ***********************************************************************/
				if (discern.startsWith("CHIP_DATA_BEGIN")) {

					logger.info("FID: " + FID+ "|| 【  CHIP_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("CHIP_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID: " + FID+ "|| 【  CHIP_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END *** 设备抛出csv文件，读取CHIP_DATA_BEGIN部分 ******** END ********
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取CHIP_SUMMARY_DATA_BEGIN部分 ** BEGIN ***
				 ***********************************************************************/

				if (discern.startsWith("CHIP_SUMMARY_DATA_BEGIN")) {

					logger.info("FID: " + FID+ "|| 【  CHIP_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("CHIP_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID: " + FID+ "|| 【  CHIP_SUMMARY_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取CHIP_SUMMARY_DATA_BEGIN部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("SITE_DATA_BEGIN")) {

					logger.info("FID: " + FID+ "|| 【  SITE_DATA_BEGIN 读取开始  】");

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SITE_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);
                        
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID: " + FID+ "|| 【  SITE_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END *******
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("DEFECT_DATA_BEGIN")) {

					logger.info("FID: " + FID+ "|| 【  SITE_DATA_BEGIN 读取开始  】");

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DEFECT_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID: " + FID+ "|| 【  SITE_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END *******
				 ***********************************************************************/

			}

			try {
				if (getEdaSuccessFlag()) {
					stmt = EDA_CONN.createStatement();
					stmt.executeQuery(loaderData);
					stmt.close();
				}
			} catch (Exception e) {
				reader.close();
				setEdaSuccessFlag(false);
				EDA_CONN.rollback();
				logger.error("FID: " + FID+ "|| Call Loader Failed! Error Message:" + e.getMessage());
			}

		} catch (Exception ex) {

			reader.close();

			if (getEdaSuccessFlag()) {
				reader.close();
				setEdaSuccessFlag(false);
			}

		} finally {

			if (reader != null) {
				reader.close();
			}

		}
	}

	@Override
	public String getLoaderName() {
		
		return null;
	}

	@Override
	public boolean checkFileFormat(File file) throws Exception {
		
		return false;
	}
}
