package com.mdt.beol.excute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.mdt.beol.beol_gmo.dao.BeolGmoChipDao;
import com.mdt.beol.beol_gmo.dao.BeolGmoChipSumDao;
import com.mdt.beol.beol_gmo.dao.BeolGmoComponentDao;
import com.mdt.beol.beol_gmo.dao.BeolGmoComponentSumDao;
import com.mdt.beol.beol_gmo.dao.BeolGmoDefectDao;
import com.mdt.beol.beol_gmo.entity.BeolGmoChipEntity;
import com.mdt.beol.beol_gmo.entity.BeolGmoChipSumEntity;
import com.mdt.beol.beol_gmo.entity.BeolGmoComponentEntity;
import com.mdt.beol.beol_gmo.entity.BeolGmoComponentSumEntity;
import com.mdt.beol.beol_gmo.entity.BeolGmoDefectEntity;
import com.mdt.beol.dao.ParameterDao;
import com.mdt.beol.dao.ProductDao;
import com.mdt.beol.dao.StepDao;
import com.mdt.beol.entity.ParameterEntity;
import com.mdt.beol.entity.ProductEntity;
import com.mdt.beol.entity.StepEntity;
import com.mdt.beol.tableview.SessionConstants;
import com.mdt.beol.util.DataFileFormatUtil;
import com.mdt.beol.util.EdaSpcAbstractLoader;

/**
 ***************************************************
 * @Title  CellOvenExcute                                    
 * @author 林华锋
 * @Date   2017年4月19日下午4:54:32
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class BeolOvenExcute extends EdaSpcAbstractLoader {

	private static Logger logger = Logger.getLogger(BeolGmoExcute.class);

	public BeolOvenExcute() throws Exception{
		super(SessionConstants.GET_SYSTEM_CONFIG_DIR(), SessionConstants.GET_LOG_CONFIG_DIR());
	}

	public Connection EDA_CONN = null;
	public Connection SPC_CONN = null;
	public String discern; // 识别前字符
	public String[] afterDiscern; // 识别后字符
	public BufferedReader reader;
	public String loaderData = "begin cell1_file_loader.load_data; end;";
	public Statement stmt = null;

	/** 实例化实体类对象 Begin **/

	public ParameterEntity parameterEntity = new ParameterEntity();
	public ProductEntity productEntity = new ProductEntity();
	public StepEntity stepEntity = new StepEntity();
	public BeolGmoComponentEntity gmoComponentEntity = new BeolGmoComponentEntity();
	public BeolGmoComponentSumEntity gmoComponentSumEntity = new BeolGmoComponentSumEntity();
	public BeolGmoChipEntity gmoChipEntity = new BeolGmoChipEntity();
	public BeolGmoChipSumEntity gmoChipSumEntity = new BeolGmoChipSumEntity();
    public BeolGmoDefectEntity gmoDefectEntity = new BeolGmoDefectEntity();
	
	/** 实例化实体类对象 End **/

	/** DAO */

	public ProductDao productDao;
	public ParameterDao parameterDao;
	public StepDao stepDao;
	public BeolGmoChipDao gmoChipDao;
	public BeolGmoChipSumDao gmoChipSumDao;
	public BeolGmoComponentDao gmoComponentDao;
	public BeolGmoComponentSumDao gmoComponentSumDao;
	public BeolGmoDefectDao gmoDefectDao;
	
	/** DAO */
	
	/****** Header_Begin 字段行 */

	public String hFILE_VERSION = null; // 文件版本
	public String hFILE_CREATED_TIME = null; // 创建时间
	public String hEQUIP_TYPE = null; // 设备类型
	public String hEQ_ID = null; // 设备ID
	public String hSubEQ_ID = null; // 子设备ID
	public String hCONTENT = null; // DataBlock内容标题

	/***** Header_End 字段行 */

	/** DOWNLOADED_SHEET_DATA_BEGIN 字段行 */


	public String dsOPE_NO = null;
	public String dsSHEET_ID = null;
	public String dsPRODUCT_ID = null;
	public String dsRECIPE_ID = null;
	public String dsCASSETTE_ID = null;
	public String dsSLOT_NO = null;
	public String dsROUTE_ID = null;

	/** DOWNLOADED_SHEET_DATA_END 字段行 */

	/** EQP_SHEET_DATA_BEGIN 字段行 */

    public String esOPE_NO = null;
	public String esSHEET_ID = null;
	public String esSTART_TIME = null;
	public String esEND_TIME = null;
	public String esSAMPLING_FLAG = null;
	public String esUSER_ID = null;
	public String esABNORMAL_FLAG = null;
	public String esMAIN_JUDGE = null;
	public String esSHEET_JUDGE = null;
	public String esTTL_PANEL_CNT = null;
	public String esTACK_TIME = null;
	public String esCOMPONENT_TYPE = null;
	public String esOK_PANEL_COUNT = null;
	public String esNG_PANEL_COUNT = null;
	public String esYIELD = null;
	public String esTTL_DEFECT_CNT = null;
	public String esSHOT_CNT = null;
	
	/** EQP_SHEET_DATA_END 字段行 */

	/** SHEET_SUMMARY_DATA_BEGIN 字段行 */

	public String ssOPE_NO = null;
	public String ssSHEET_ID = null;
	public String ssEND_TIME = null;
	public String ssPARAM_COLLECTION = null;
	public String ssPARAM_GROUP = null;
	public String ssPARAM_NAME = null;
	public String ssAVG = null;
	public String ssMAX = null;
	public String ssMIN = null;
	public String ssSTD = null;
	public String ssUNIFORMITY = null;
	public String ssRANGE = null;
	public String ss3SIGMA = null;
	public String ssSPEC_HIGH = null;
	public String ssSPEC_LOW = null;
	public String ssSPEC_TARGET = null;
	public String ssCONTROL_HIGH = null;
	public String ssCONTROL_LOW = null;
    public String ssCOLOR_NAME = null;
    public String ssTHICKNESS_NAME = null;
	
	/** SHEET_SUMMARY_DATA_END 字段行 */

	/** CHIP_DATA_BEGIN 字段行 */

	public String cOPE_NO = null;
	public String cSHEET_ID = null;
	public String cEND_TIME = null;
	public String cCHIP_ID = null;
	public String cCHIP_NO = null;
	public String cCHIP_JUDGE = null;
	public String cMAIN_DEFECT_CODE = null;
	public String cPANEL_RANK = null;
	public String cPANEL_TTL_DEFECT_CNT = null;

	/** CHIP_DATA_END 字段行 */

	/** CHIP_SUMMARY_DATA_BEGIN 字段行 */

	public String csOPE_NO = null;
	public String csSHEET_ID = null;
	public String csEND_TIME = null;
	public String csCHIP_ID = null;
	public String csCHIP_NO = null;
	public String csPARAM_COLLECTION = null;
	public String csPARAM_GROUP = null;
	public String csPARAM_NAME = null;
	public String csAVG = null;
	public String csMAX = null;
	public String csMIN = null;
	public String csSTD = null;
	public String csUNIFORMITY = null;
	public String csRANGE = null;
	public String csSPEC_HIGH = null;
	public String csSPEC_LOW = null;
	public String csSPEC_TARGET = null;
	public String csCONTROL_HIGH = null;
	public String csCONTROL_LOW = null;
	public String cs3SIGMA = null;

	/** CHIP_SUMMARY_DATA_END 字段行 */

	/** SITE_DATA_BEGIN 字段行 */

	public String sOPE_NO = null;
	public String sSHEET_ID = null;
	public String sEND_TIME = null;
	public String sPARAM_COLLECTION = null;
	public String sPARAM_GROUP = null;
	public String sPARAM_NAME = null;
	public String sSITE_NAME = null;
	public String sPARAM_VALUE = null;
	public String sSPEC_HIGH = null;
	public String sSPEC_LOW = null;
	public String sSPEC_TARGET = null;
	public String sCONTROL_HIGH = null;
	public String sCONTROL_LOW = null;
	public String sX = null;
	public String sY = null;
	public String sCHIP_ID = null;
	public String sCHIP_NO = null;
	public String sJUDGE = null;
    public String sCOLOR_NAME = null;
    public String sTHICKNESS_NAME = null;
 
	/** SITE_DATA_END 字段行 */

	/** DEFECT_DATA_BEGIN 字段行 */

	public String dOPE_NO = null;
	public String dSHEET_ID = null;
	public String dEND_TIME = null;
	public String dCHIP_ID = null;
	public String dCHIP_NO = null;
	public String dDEFECT_JUDGE = null;
	public String dDEFECT_CODE = null;
	public String dDEFECT_CODE_DESC = null;
	public String dDEFECT_PATTERN = null;
	public String dDEFECT_LAYER_TYPE = null;
	public String dIMAGE_DATA = null;
	public String dMAIN_DEFECT_FLAG = null;
	public String dREJUDGE_FLAG = null;
	public String dDEFECT_SEQ_NO = null;
	public String dDEFECT_GROUP = null;
	public String dDEFECT_SIZE = null;
	public String dDEFECT_RANK = null;
	public String dCAPTURE_NO = null;
	public String dS = null;
	public String dG = null;
	public String dX = null;
	public String dY = null;
	public String dX2 = null;
	public String dY2 = null;
	public String dX3 = null;
	public String dy3 = null;
	public String dARRAY_X = null;
	public String dARRAY_Y = null;
	public String dARRAY_X2 = null;
	public String dARRAY_Y2 = null;
	public String dARRAY_X3 = null;
	public String dARRAY_Y3 = null;
	
	/** DEFECT_DATA_END 字段行 */
	
	public static void main(String[] args) throws Exception {

		// args:{TID:0,Shop:1,Source:2,eqp_type:3,target_flag:4,WorkDir:5,max_count:6,SystemLocalConfigPath:7,LogConfigPath:8,db_find_method:9,export_log_file:10}
		if (args != null && args.length > 0) {
			SessionConstants.SET_TID(args[0]);
			SessionConstants.SET_SHOP(args[1]);
			SessionConstants.SET_SOURCE(args[2]);
			SessionConstants.SET_EQP_TYPE(args[3]);
			SessionConstants.SET_TARGET_FLAG(args[4]);
			SessionConstants.SET_WORK_DIR(args[5]);
			SessionConstants.SET_MAX_COUNT(args[6]);
			SessionConstants.SET_SYSTEM_CONFIG_DIR(args[7]);
			SessionConstants.SET_LOG_CONFIG_DIR(args[8]);
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(args[9]);
			SessionConstants.SET_EXPORT_LOG_FLAG(args[10]);
		} else {
			SessionConstants.SET_TID("BEOL_FILE_OVEN_1"); // translator_config_t
			SessionConstants.SET_SHOP("BEOL");
			SessionConstants.SET_SOURCE("FILE");
			SessionConstants.SET_EQP_TYPE("OVEN");
			SessionConstants.SET_TARGET_FLAG("0,1,2,3,4,5,6,7,8,9");
			SessionConstants.SET_WORK_DIR("E:\\TEST");
			SessionConstants.SET_MAX_COUNT("100");
			SessionConstants.SET_SYSTEM_CONFIG_DIR("E:\\TEST\\system.properties");
			SessionConstants.SET_LOG_CONFIG_DIR("E:\\TEST\\log4j.properties");
			SessionConstants.SET_ACTIVATE_DB_FIND_METHOD("FALSE");
			SessionConstants.SET_EXPORT_LOG_FLAG("FALSE");
		}

		try {
			BeolOvenExcute OvenExcute = new BeolOvenExcute();

			OvenExcute.run();

		} catch (Exception e) {
			logger.error("FID : " + FID + "||  There hava a error! Error Message: " + e.getMessage());
		}

	}

	@Override
	public void readyToRun(File file) throws Exception {

		logger.info("FID : " + FID + "||  【 Translator Begin 】");
		
		ReadDFSFile(file);
			
		logger.info("FID : " + FID + "||  【 Translator End 】");
	}

	@SuppressWarnings("static-access")
	public void ReadDFSFile(File file) throws Exception {
        
		EDA_CONN = getEdaConnection();
		
		if (EDA_CONN.isClosed()) {
			logger.error("FID : " + FID + "|| The database connection was error");
		}
		
		EDA_CONN.setAutoCommit(false);
		
		try {
			reader = new BufferedReader(new FileReader(file.getPath()));

			while ((discern = reader.readLine()) != null) {
				if (discern.length() == 0) {
					continue;
				}
				/***********************************************************************
				 * BEGIN ****************** 设备抛出csv文件，读取Header部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("HEADER_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  HEADER_BEGIN 读取开始  】");

					while ((discern = reader.readLine()) != null && getEdaSuccessFlag()) {
						if (DataFileFormatUtil.Shift(discern).startsWith("FILE_VERSION")) {
							afterDiscern = discern.split(":", -1);
							hFILE_VERSION = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("FILE_CREATED_TIME")) {
							afterDiscern = discern.split(":", -1);
							hFILE_CREATED_TIME = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQUIP_TYPE")) {
							afterDiscern = discern.split(":", -1);
							hEQUIP_TYPE = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("EQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("SUBEQ_ID")) {
							afterDiscern = discern.split(":", -1);
							hSubEQ_ID = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).startsWith("CONTENT")) {
							afterDiscern = discern.split(":", -1);
							hCONTENT = afterDiscern[1].trim();

						} else if (DataFileFormatUtil.Shift(discern).endsWith("HEADER_END")) {
							break;
						}
					}
					logger.info("FID : " + FID + "|| 【  HEADER_END 读取结束  】");

				}
				/*********************************************************************
				 * END ******************** 设备抛出csv文件，读取Header部分 ****** END *
				 ********************************************************************/

				/***********************************************************************
				 * BEGIN ***************设备抛出csv文件，读取SHEET_DATA部分 ****** BEGIN *
				 ***********************************************************************/
				if (discern.startsWith("DOWNLOADED_SHEET_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  DOWNLOADED_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DOWNLOADED_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);
						
						dsOPE_NO =afterDiscern[0];
						dsROUTE_ID =afterDiscern[1];
						dsSHEET_ID =afterDiscern[2];
						dsPRODUCT_ID =afterDiscern[3];
						dsRECIPE_ID =afterDiscern[4];
						dsCASSETTE_ID =afterDiscern[5];
						dsSLOT_NO =afterDiscern[6];
                        
						stepEntity.setSTEP_ID(dsOPE_NO);
						stepEntity.setSTEP_SEQ(dsOPE_NO);
						stepEntity.setSTEP_TYPE("M");
						stepEntity.setSTEP_GROUP(hEQUIP_TYPE);
						
						setEdaSuccessFlag(stepDao.addStepTable(stepEntity, EDA_CONN,FID));
								
						productEntity.setPRODUCT_ID(dsPRODUCT_ID);
						productEntity.setPRODUCT_GROUP("DEFAULT");
						
						setEdaSuccessFlag(productDao.addProductTable(productEntity, EDA_CONN,FID));
									
						gmoComponentEntity.setOPE_NO(dsOPE_NO);
						gmoComponentEntity.setROUTE_ID(dsROUTE_ID);
						gmoComponentEntity.setSHEET_ID(dsSHEET_ID);
						gmoComponentEntity.setPRODUCT_ID(dsPRODUCT_ID);
						gmoComponentEntity.setRECIPE_ID(dsRECIPE_ID);
						gmoComponentEntity.setCASSETTE_ID(dsCASSETTE_ID);
						gmoComponentEntity.setSLOT_NO(dsSLOT_NO);
						gmoComponentEntity.setGLASS_ID(dsSHEET_ID);	
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
						
					}
					logger.info("FID : " + FID + "|| 【  DOWNLOADED_SHEET_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END *******设备抛出csv文件，读取DOWNLOADED_SHEET_DATA部分 ****** END **
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN **** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** BEGIN *******
				 ***********************************************************************/
				if (discern.startsWith("EQP_SHEET_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  EQP_SHEET_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("EQP_SHEET_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						esOPE_NO = afterDiscern[0];
						esSHEET_ID = afterDiscern[1];
						esCOMPONENT_TYPE = afterDiscern[2];
						esSTART_TIME = afterDiscern[3];
						esEND_TIME = afterDiscern[4];
						esTACK_TIME = afterDiscern[5];
						esSAMPLING_FLAG = afterDiscern[6];
						esABNORMAL_FLAG = afterDiscern[7];
						esUSER_ID = afterDiscern[8];
						esMAIN_JUDGE = afterDiscern[9];
						esSHEET_JUDGE = afterDiscern[10];
						esTTL_PANEL_CNT = afterDiscern[11];
						esSHOT_CNT = afterDiscern[12];
						esTTL_DEFECT_CNT = afterDiscern[13];
						esOK_PANEL_COUNT = afterDiscern[0];
						esNG_PANEL_COUNT = afterDiscern[0];
						esYIELD = afterDiscern[0];
                        
						gmoComponentEntity.setEQ_ID(hEQ_ID);
						gmoComponentEntity.setSUBEQ_ID(hSubEQ_ID);
						gmoComponentEntity.setSTART_TIME(esSTART_TIME);
						gmoComponentEntity.setEND_TIME(esEND_TIME);
						gmoComponentEntity.setSAMPLING_FLAG(esSAMPLING_FLAG);
						gmoComponentEntity.setUSER_ID(esUSER_ID);
						gmoComponentEntity.setABNORMAL_FLAG(esABNORMAL_FLAG);
						gmoComponentEntity.setMAIN_JUDGE(esMAIN_JUDGE);
						gmoComponentEntity.setSHEET_JUDGE(esSHEET_JUDGE);
						gmoComponentEntity.setTTL_PANEL_CNT(esTTL_PANEL_CNT);
						gmoComponentEntity.setTACK_TIME(esTACK_TIME);
						gmoComponentEntity.setCOMPONENT_TYPE(esCOMPONENT_TYPE);
						gmoComponentEntity.setOK_PANEL_COUNT(esOK_PANEL_COUNT);
						gmoComponentEntity.setNG_PANEL_COUNT(esNG_PANEL_COUNT);
						gmoComponentEntity.setYIELD(esYIELD);
						gmoComponentEntity.setTTL_DEFECT_CNT(esTTL_DEFECT_CNT);

						
						setEdaSuccessFlag(gmoComponentDao.addCellGmoCompenent(gmoComponentEntity,EDA_CONN,FID));
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID : " + FID + "|| 【  EQP_SHEET_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END ********** 设备抛出csv文件，读取EQP_SHEET_DATA部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** BEGIN *
				 ***********************************************************************/

				if (discern.startsWith("SHEET_SUMMARY_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  SHEET_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SHEET_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						ssOPE_NO = afterDiscern[0];
						ssSHEET_ID = afterDiscern[1];
						ssEND_TIME = afterDiscern[2];
						ssPARAM_COLLECTION = afterDiscern[3];
						ssPARAM_GROUP = afterDiscern[4];
						ssPARAM_NAME = afterDiscern[5];
						ssAVG = afterDiscern[6];
						ssMAX = afterDiscern[7];
						ssMIN = afterDiscern[8];
						ssRANGE = afterDiscern[9];
						ssUNIFORMITY = afterDiscern[10];
						ssSTD = afterDiscern[11];
						ss3SIGMA = afterDiscern[12];
						ssSPEC_HIGH = afterDiscern[13];
						ssSPEC_LOW = afterDiscern[14];
						ssSPEC_TARGET = afterDiscern[15];
						ssCONTROL_HIGH = afterDiscern[16];
						ssCONTROL_LOW = afterDiscern[17];
						ssCOLOR_NAME =  afterDiscern[18];
						ssTHICKNESS_NAME = afterDiscern[19];
						
						parameterEntity.setPARAM_COLLECTION(dsRECIPE_ID);
						parameterEntity.setPARAM_NAME(ssPARAM_NAME);
						parameterEntity.setPARAM_COLLECTION_GROUP("DEFAULT");
						parameterEntity.setPARAM_GROUP(ssPARAM_GROUP);
						
						setEdaSuccessFlag(parameterDao.addParameterTable(parameterEntity, EDA_CONN,FID));
						
						gmoComponentSumEntity.setOPE_NO(ssOPE_NO);
						gmoComponentSumEntity.setSHEET_ID(ssSHEET_ID);
						gmoComponentSumEntity.setEND_TIME(ssEND_TIME);
						gmoComponentSumEntity.setPARAM_COLLECTION(ssPARAM_COLLECTION);
						gmoComponentSumEntity.setPARAM_NAME(ssPARAM_NAME);
						gmoComponentSumEntity.setAVG(ssAVG);
						gmoComponentSumEntity.setMAX(ssMAX);
						gmoComponentSumEntity.setMIN(ssMIN);
						gmoComponentSumEntity.setSTD(ssSTD);
						gmoComponentSumEntity.setUNIFORMITY(ssUNIFORMITY);
						gmoComponentSumEntity.setRANGE(ssRANGE);
						gmoComponentSumEntity.setThree_SIGMA(ss3SIGMA);
						gmoComponentSumEntity.setSPEC_HIGH(ssSPEC_HIGH);
						gmoComponentSumEntity.setSPEC_LOW(ssSPEC_LOW);
						gmoComponentSumEntity.setSPEC_TARGET(ssSPEC_TARGET);
						gmoComponentSumEntity.setCONTROL_HIGH(ssCONTROL_HIGH);
						gmoComponentSumEntity.setCONTROL_LOW(ssCONTROL_LOW);
						
						gmoComponentSumDao.addCellGmoComponentSum(gmoComponentSumEntity,EDA_CONN,FID);
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
						
					}

					logger.info("FID : " + FID + "|| 【  SHEET_SUMMARY_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END * 设备抛出csv文件，读取SHEET_SUMMARY_DATA_BEGIN部分 ****** END ****
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取CHIP_DATA_BEGIN部分 ******** BEGIN *****
				 ***********************************************************************/
				if (discern.startsWith("CHIP_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  CHIP_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("CHIP_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						cOPE_NO = afterDiscern[0];
						cSHEET_ID = afterDiscern[1];
						cCHIP_ID = afterDiscern[2];
						cCHIP_NO = afterDiscern[3];
						cEND_TIME = afterDiscern[4];
						//UserID = afterDiscern[5];
						cCHIP_JUDGE = afterDiscern[6];
						cMAIN_DEFECT_CODE = afterDiscern[7];
						cPANEL_TTL_DEFECT_CNT = afterDiscern[8];
						cPANEL_RANK = afterDiscern[9];
                        
						gmoChipEntity.setOPE_NO(cOPE_NO);
						gmoChipEntity.setSHEET_ID(cSHEET_ID);
						gmoChipEntity.setEND_TIME(cEND_TIME);
						gmoChipEntity.setCHIP_ID(cCHIP_ID);
						gmoChipEntity.setCHIP_NO(cCHIP_NO);
						gmoChipEntity.setCHIP_JUDGE(cCHIP_JUDGE);
						gmoChipEntity.setMAIN_DEFECT_CODE(cMAIN_DEFECT_CODE);
						gmoChipEntity.setPANEL_RANK(cPANEL_RANK);
						gmoChipEntity.setPANEL_TTL_DEFECT_CNT(cPANEL_TTL_DEFECT_CNT);
						
						gmoChipDao.addCellGmoChip(gmoChipEntity,EDA_CONN,FID);
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID : " + FID + "|| 【  CHIP_DATA_END 读取结束  】");
				}
				/***********************************************************************
				 * END *** 设备抛出csv文件，读取CHIP_DATA_BEGIN部分 ******** END ********
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取CHIP_SUMMARY_DATA_BEGIN部分 ** BEGIN ***
				 ***********************************************************************/

				if (discern.startsWith("CHIP_SUMMARY_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  CHIP_SUMMARY_DATA_BEGIN 读取开始  】");

					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("CHIP_SUMMARY_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);
                        
						csOPE_NO = afterDiscern[0];
						csSHEET_ID = afterDiscern[1];
						csCHIP_ID = afterDiscern[2];
						csCHIP_NO = afterDiscern[3];
						csEND_TIME = afterDiscern[4];
						csPARAM_COLLECTION = afterDiscern[5];
						csPARAM_GROUP = afterDiscern[6];
						csPARAM_NAME = afterDiscern[7];
						csAVG = afterDiscern[8];
						csMAX = afterDiscern[9];
						csMIN = afterDiscern[10];
						csRANGE = afterDiscern[11];
						csUNIFORMITY = afterDiscern[12];
						csSTD = afterDiscern[13];
						cs3SIGMA = afterDiscern[14];
						csSPEC_HIGH = afterDiscern[15];
						csSPEC_LOW = afterDiscern[16];
						csSPEC_TARGET = afterDiscern[17];
						csCONTROL_HIGH = afterDiscern[18];
						csCONTROL_LOW = afterDiscern[19];

						gmoChipSumEntity.setOPE_NO(csOPE_NO);
						gmoChipSumEntity.setSHEET_ID(csSHEET_ID);
						gmoChipSumEntity.setEND_TIME(csEND_TIME);
						gmoChipSumEntity.setCHIP_ID(csCHIP_ID);
						gmoChipSumEntity.setCHIP_NO(csCHIP_NO);
						gmoChipSumEntity.setPARAM_COLLECTION(csPARAM_COLLECTION);
						gmoChipSumEntity.setPARAM_NAME(csPARAM_NAME);
						gmoChipSumEntity.setAVG(csAVG);
						gmoChipSumEntity.setMAX(csMAX);
						gmoChipSumEntity.setMIN(csMIN);
						gmoChipSumEntity.setSTD(csSTD);
						gmoChipSumEntity.setUNIFORMITY(csUNIFORMITY);
						gmoChipSumEntity.setRANGE(csRANGE);
						gmoChipSumEntity.setSPEC_HIGH(csSPEC_HIGH);
						gmoChipSumEntity.setSPEC_LOW(csSPEC_LOW);
						gmoChipSumEntity.setSPEC_TARGET(csSPEC_TARGET);
						gmoChipSumEntity.setCONTROL_HIGH(csCONTROL_HIGH);
						gmoChipSumEntity.setCONTROL_LOW(csCONTROL_LOW);
						gmoChipSumEntity.setTHREE_SIGMA(cs3SIGMA);
						
						gmoChipSumDao.addCellGmoChipSum(gmoChipSumEntity,EDA_CONN,FID);
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}
					}

					logger.info("FID : " + FID + "|| 【  CHIP_SUMMARY_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取CHIP_SUMMARY_DATA_BEGIN部分 ****** END ***
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("SITE_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  SITE_DATA_BEGIN 读取开始  】");

					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("SITE_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						sOPE_NO = afterDiscern[0];
						sSHEET_ID = afterDiscern[1];
						sCHIP_ID = afterDiscern[2];
						sCHIP_NO = afterDiscern[3];
						sEND_TIME = afterDiscern[4];
						sPARAM_COLLECTION = afterDiscern[5];
						sPARAM_GROUP = afterDiscern[6];
						sPARAM_NAME = afterDiscern[7];
						sSITE_NAME = afterDiscern[8];
						sPARAM_VALUE = afterDiscern[9];
						sJUDGE = afterDiscern[10];
						sX = afterDiscern[10];
						sY = afterDiscern[11];
						sSPEC_HIGH = afterDiscern[12];
						sSPEC_LOW = afterDiscern[13];
						sSPEC_TARGET = afterDiscern[14];
						sCONTROL_HIGH = afterDiscern[15];
						sCONTROL_LOW = afterDiscern[16];
					    sCOLOR_NAME = afterDiscern[17];
					    sTHICKNESS_NAME = afterDiscern[18];
										    
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID : " + FID + "|| 【  SITE_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END *******
				 ***********************************************************************/

				/***********************************************************************
				 * BEGIN *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** BEGIN ***
				 ***********************************************************************/
				if (discern.startsWith("DEFECT_DATA_BEGIN")) {

					logger.info("FID : " + FID + "|| 【  DEFECT_DATA_BEGIN 读取开始  】");
					discern = reader.readLine(); // 读取字段行名称
					while ((discern = reader.readLine()) != null) {
						if (DataFileFormatUtil.Shift(discern).startsWith("DEFECT_DATA_END")) {
							break;
						}

						afterDiscern = discern.split(",", -1);

						dOPE_NO = afterDiscern[0];
						dSHEET_ID = afterDiscern[1];
						dCHIP_ID = afterDiscern[2];
						dCHIP_NO = afterDiscern[3];
						dEND_TIME = afterDiscern[4];
						dDEFECT_SEQ_NO = afterDiscern[5];
						dDEFECT_JUDGE = afterDiscern[6];
						dDEFECT_GROUP = afterDiscern[7];
						dDEFECT_CODE = afterDiscern[8];
						dDEFECT_CODE_DESC = afterDiscern[9];
						dDEFECT_LAYER_TYPE = afterDiscern[10];
						dIMAGE_DATA = afterDiscern[11];
						dMAIN_DEFECT_FLAG = afterDiscern[12];
						dDEFECT_PATTERN = afterDiscern[13];
						dREJUDGE_FLAG = afterDiscern[14];
						dDEFECT_SIZE = afterDiscern[15];
						dS = afterDiscern[16];
						dG = afterDiscern[17];
						dDEFECT_RANK = afterDiscern[18];//panelRank
						dCAPTURE_NO = afterDiscern[19];
						dX = afterDiscern[20];
						dY = afterDiscern[21];
						dX2 = afterDiscern[22];
						dY2 = afterDiscern[23];
						dX3 = afterDiscern[24];
						dy3 = afterDiscern[25];
						dARRAY_X = afterDiscern[26];
						dARRAY_Y = afterDiscern[27];
						dARRAY_X2 = afterDiscern[28];
						dARRAY_Y2 = afterDiscern[29];
						dARRAY_X3 = afterDiscern[30];
						dARRAY_Y3 = afterDiscern[31];
						
						gmoDefectEntity.setOPE_NO(dOPE_NO);
						gmoDefectEntity.setSHEET_ID(dSHEET_ID);
						gmoDefectEntity.setEND_TIME(dEND_TIME);
						gmoDefectEntity.setCHIP_ID(dCHIP_ID);
						gmoDefectEntity.setCHIP_NO(dCHIP_NO);
						gmoDefectEntity.setDEFECT_JUDGE(dDEFECT_JUDGE);
						gmoDefectEntity.setDEFECT_CODE(dDEFECT_CODE);
						gmoDefectEntity.setDEFECT_CODE_DESC(dDEFECT_CODE_DESC);
						gmoDefectEntity.setDEFECT_PATTERN(dDEFECT_PATTERN);
						gmoDefectEntity.setDEFECT_LAYER_TYPE(dDEFECT_LAYER_TYPE);
						gmoDefectEntity.setIMAGE_DATA(dIMAGE_DATA);
						gmoDefectEntity.setMAIN_DEFECT_FLAG(dMAIN_DEFECT_FLAG);
						gmoDefectEntity.setREJUDGE_FLAG(dREJUDGE_FLAG);
						gmoDefectEntity.setDEFECT_SEQ_NO(dDEFECT_SEQ_NO);
						gmoDefectEntity.setDEFECT_GROUP(dDEFECT_GROUP);
						gmoDefectEntity.setDEFECT_SIZE(dDEFECT_SIZE);
						gmoDefectEntity.setDEFECT_RANK(dDEFECT_RANK);
						gmoDefectEntity.setCAPTURE_NO(dCAPTURE_NO);
						gmoDefectEntity.setS(dS);
						gmoDefectEntity.setG(dG);
						gmoDefectEntity.setX(dX);
						gmoDefectEntity.setY(dY);
						gmoDefectEntity.setX2(dX2);
						gmoDefectEntity.setY2(dY2);
						gmoDefectEntity.setX3(dX3);
						gmoDefectEntity.setY3(dy3);
						gmoDefectEntity.setARRAY_X(dARRAY_X);
						gmoDefectEntity.setARRAY_Y(dARRAY_Y);
						gmoDefectEntity.setARRAY_X2(dARRAY_X2);
						gmoDefectEntity.setARRAY_Y2(dARRAY_Y2);
						gmoDefectEntity.setARRAY_X3(dARRAY_X3);
						gmoDefectEntity.setARRAY_Y3(dARRAY_X3);
						
						gmoDefectDao.addCellGmoDefect(gmoDefectEntity,EDA_CONN,FID);
						
						if (!getEdaSuccessFlag()) {
							reader.close();
							break;
						}

					}

					logger.info("FID : " + FID + "|| 【  DEFECT_DATA_END 读取结束  】");
				}

				/***********************************************************************
				 * END *** 设备抛出csv文件，读取SITE_DATA_BEGIN部分 ********** END *******
				 ***********************************************************************/

			}

			try {
				if (getEdaSuccessFlag()) {
					stmt = EDA_CONN.createStatement();
					stmt.executeQuery(loaderData);
					stmt.close();
				}
			} catch (Exception e) {
				reader.close();
				setEdaSuccessFlag(false);
				EDA_CONN.rollback();
				logger.error("FID : " + FID + "|| Call Loader Failed! Error Message:" + e.getMessage());
			}

		} catch (Exception ex) {

			reader.close();
            
			if (getEdaSuccessFlag()) {
				reader.close();
				setEdaSuccessFlag(false);
			}

		} finally {
			
			if (reader != null) {
				reader.close();
			}

		}
	}

	@Override
	public String getLoaderName() {
		
		return null;
	}

	@Override
	public boolean checkFileFormat(File file) throws Exception {
		
		return false;
	}
}
