package com.mdt.beol.beol_optical_insp.entity;

import java.io.Serializable;

import com.mdt.beol.entity.BeolChipBaseEntity;

/**
 ***************************************************
 * @Title CellOpticalChipEntity
 * @author 林华锋
 * @Date 2017年4月10日上午10:07:24
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class BeolOpticalChipEntity extends BeolChipBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
}
