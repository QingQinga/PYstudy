package com.mdt.beol.beol_optical_insp.entity;

import java.io.Serializable;

import com.mdt.beol.entity.BeolResultBaseEntity;

/**
 ***************************************************
 * @Title CellOpticalResultEntity
 * @author 林华锋
 * @Date 2017年4月13日下午1:38:46
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class BeolOpticalResultEntity extends BeolResultBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String LAYER;
	private String UP_DOWN_FLAG;

	public String getLAYER() {
		return LAYER;
	}

	public void setLAYER(String lAYER) {
		LAYER = lAYER;
	}

	public String getUP_DOWN_FLAG() {
		return UP_DOWN_FLAG;
	}

	public void setUP_DOWN_FLAG(String uP_DOWN_FLAG) {
		UP_DOWN_FLAG = uP_DOWN_FLAG;
	}

}
