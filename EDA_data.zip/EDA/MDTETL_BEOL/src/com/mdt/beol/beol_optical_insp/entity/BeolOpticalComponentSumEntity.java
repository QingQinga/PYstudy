package com.mdt.beol.beol_optical_insp.entity;

import java.io.Serializable;

import com.mdt.beol.entity.BeolComponentSumBaseEntity;

/**
 ***************************************************
 * @Title CellOpticalComponentSumEntity
 * @author 林华锋
 * @Date 2017年4月15日下午4:15:11
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class BeolOpticalComponentSumEntity extends BeolComponentSumBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String UP_DOWN_FLAG;

	public String getUP_DOWN_FLAG() {
		return UP_DOWN_FLAG;
	}

	public void setUP_DOWN_FLAG(String uP_DOWN_FLAG) {
		UP_DOWN_FLAG = uP_DOWN_FLAG;
	}

}
