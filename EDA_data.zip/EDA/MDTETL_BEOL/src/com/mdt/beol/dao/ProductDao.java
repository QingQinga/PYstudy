package com.mdt.beol.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mdt.beol.entity.ProductEntity;
import com.mdt.beol.util.DBUtil;

/**
 ***************************************************
 * @Title ProductDao 处理基本表 Product
 * @author 林华锋
 * @Date 2017年2月14日下午3:17:17
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ProductDao {

	private static Logger logger = Logger.getLogger(ProductDao.class);
    
	/**
	 * 基本表Product插入语句
	 * @param productEntity 实体类对象
	 * @param conn 数据库连接
	 * @return
	 */
	public static boolean addProductTable(ProductEntity Entity, Connection conn, String fid) {
		String loaderProduct = "begin cell1_base_loader.load_product; end;";
		String sql = "INSERT INTO ldr_cell_product_t (" + "product_id,product_group" + ") VALUES ("
				+ "?,?)";
        Object[] params ={Entity.getPRODUCT_ID(),Entity.getPRODUCT_GROUP()};
		 
        boolean isErrorRet = true;
				
		logger.info("FID: " + fid+ "|| LDR_ARRAY_PRODUCT_T SQL: " + sql);
		try {
			DBUtil.executeUpdate(sql, params,conn);
			logger.info("FID: " + fid+ "|| INSERT ldr_cell_product_t SUCCESS! 插入LDR_ARRAY_PRODUCT_T成功！");
			DBUtil.stmt = conn.createStatement();
			DBUtil.stmt.execute(loaderProduct);
			logger.info("FID: " + fid+ "|| CALL Product Loader Success!");
		} catch (Exception ex) {
			logger.error("FID: " + fid+ "|| INSERT ldr_cell_product_t Failed! Error Message: " + ex.getMessage());
			isErrorRet = false;
		} finally {	
			
			 try
				{
					if(DBUtil.pstmt != null)	
						DBUtil.pstmt.close();
					DBUtil.stmt.close();	
				}
				catch(SQLException ex)
				{
					logger.error("FID: " + fid+ "|| An Error Caused: "+ex.getMessage());
					isErrorRet =false;
				}
		}

		if (isErrorRet){
			return true;
		}else{
			return false;
		}
	}

}
