package com.mdt.beol.dispatcher;

import java.io.File;
import java.sql.Connection;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.mdt.beol.tableview.SessionConstants;
import com.mdt.beol.tableview.TranslatorConfigView;
import com.mdt.beol.util.DBUtil;
import com.mdt.beol.util.GetEnvironmentUtil;
import com.mdt.beol.util.LoaderProperty;
import com.mdt.beol.util.LogHandlerUtil;
import com.mdt.beol.util.SystemUtil;
import com.mdt.beol.util.TranslatorTableControlUtil;

public class Dispatcher {
	
	private static Logger logger = Logger.getLogger(Dispatcher.class);
	private Connection translator_conn;
	private LoaderProperty l_prop = null;
	// private String LINEBREAKS = System.getProperty("line.separator");
	String shop = "";
	String source = "";
	String eqp_type = "";
	String export_log_file = "false";
	static int systemType = 0; // 0: Windows OS; 1: not Windows OS (as Linux OS)

	private static String JAVA_OPTIONS = "";

	public Dispatcher() throws Exception {
		PropertyConfigurator.configure(SessionConstants.GET_LOG_CONFIG_DIR() + File.separator + "log4j.properties");
	}
	
	public static void main(String[] args) throws Exception {
		
		GetEnvironmentUtil env = new GetEnvironmentUtil();
		systemType = GetEnvironmentUtil.getSystemType();
		Properties Env_Properties = env.getEnvironment();

		String systemConfig = Env_Properties.getProperty(LoaderProperty.SYSTEM_LOCAL_CONFIG_KEY);
		SessionConstants.SET_SYSTEM_CONFIG_DIR(systemConfig);
		
		String log4jConfigPath = Env_Properties.getProperty(LoaderProperty.LOG4J_CONFIG_DIR_KEY); // modified																								// by
																									// Tyron
		SessionConstants.SET_LOG_CONFIG_DIR(log4jConfigPath);
		
		String activate_db_find_method = Env_Properties.getProperty(LoaderProperty.ACTIVATE_DB_FIND_METHOD_KEY);
		SessionConstants.SET_ACTIVATE_DB_FIND_METHOD(activate_db_find_method);

		JAVA_OPTIONS = Env_Properties.getProperty(LoaderProperty.JAVA_OPTIONS); // -Xms512M
																				// -Xmx768M

		if (JAVA_OPTIONS == null || JAVA_OPTIONS.equalsIgnoreCase("null"))
			JAVA_OPTIONS = "";

		Dispatcher dispatcher = new Dispatcher();
		dispatcher.source = args[0];
		dispatcher.shop = args[1];
		dispatcher.eqp_type = args[2];

		try {
			dispatcher.export_log_file = args[3];

		} catch (Exception ex) {
			dispatcher.export_log_file = "true";
		}

		dispatcher.l_prop = new LoaderProperty(systemConfig, log4jConfigPath + File.separator + "log4j.properties");
		try {
			logger.info("=======================Dispatcher started=======================");
			dispatcher.run();
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			ex.printStackTrace();
		}
		logger.info("=======================Dispatcher end=======================");
	}

	@SuppressWarnings("unused")
	public void run() throws Exception {

		String parent_pid = new Long(SystemUtil.getPID()).toString();

		Connection conn = getTranslatorConnection();

		String[] paramValueList = new String[3];
		paramValueList[0] = this.shop;
		paramValueList[1] = this.source;
		paramValueList[2] = this.eqp_type;
		String workJarBasePath = l_prop.GetTranslatorWorkPath();

		String classPath = "";
		if (systemType == 0)
			classPath = workJarBasePath + ";" + workJarBasePath + File.separator + "activation.jar;" + workJarBasePath
					+ File.separator + "dsn.jar;" + workJarBasePath + File.separator + "imap.jar;" + workJarBasePath
					+ File.separator + "jspsmartupload.jar;" + workJarBasePath + File.separator + "jxl.jar;"
					+ workJarBasePath + File.separator + "log4j.jar;" + workJarBasePath + File.separator + "mail.jar;"
					+ workJarBasePath + File.separator + "mailapi.jar;" + workJarBasePath + File.separator
					+ "mysql-connector-java-5.1.18-bin.jar;" + workJarBasePath + File.separator + "ojdbc6.jar;"
					+ workJarBasePath + File.separator + "pop3.jar;" + workJarBasePath + File.separator + "smtp.jar;" 
					+ workJarBasePath + File.separator + "commons-io-2.5.jar;" + workJarBasePath + File.separator + "sqljdbc4.jar;"
					// workJarBasePath2;
					+ workJarBasePath + File.separator + "Translator.jar";
		else
			classPath = workJarBasePath + ":" + workJarBasePath + File.separator + "activation.jar:" + workJarBasePath
					+ File.separator + "dsn.jar:" + workJarBasePath + File.separator + "imap.jar:" + workJarBasePath
					+ File.separator + "jspsmartupload.jar:" + workJarBasePath + File.separator + "jxl.jar:"
					+ workJarBasePath + File.separator + "log4j.jar:" + workJarBasePath + File.separator + "mail.jar:"
					+ workJarBasePath + File.separator + "mailapi.jar:" + workJarBasePath + File.separator
					+ "mysql-connector-java-5.1.18-bin.jar:" + workJarBasePath + File.separator + "ojdbc6.jar:"
					+ workJarBasePath + File.separator + "pop3.jar:" + workJarBasePath + File.separator + "smtp.jar:" 
					+ workJarBasePath + File.separator + "commons-io-2.5.jar:" + workJarBasePath + File.separator + "sqljdbc4.jar:"
					// workJarBasePath2:
					+ workJarBasePath + File.separator + "Translator.jar";

		TranslatorConfigView[] translatorConfigView = null;

		try {
			translatorConfigView = TranslatorTableControlUtil.getConfigDataList(conn, paramValueList);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			ex.printStackTrace();
		}

		if (checkRunStatusNow(conn, translatorConfigView)) {
			if (translatorConfigView != null && translatorConfigView.length > 0) {
				Process[] ps = new Process[translatorConfigView.length];
				String cmd = "";
				int cmd_count = 0;

				for (int i = 0; i < translatorConfigView.length; i++) {
					String TID = translatorConfigView[i].getTID();
					String target_flag = translatorConfigView[i].getTargetFlagList();
					if (target_flag.equals("*")) {
						target_flag = "0,1,2,3,4,5,6,7,8,9";
					}
					String workDir = translatorConfigView[i].getWorkDir();
					String hander_class = translatorConfigView[i].getHandlerClass();
					String max_count = translatorConfigView[i].getMaxCount();
					if (max_count == null || max_count.trim().length() == 0) {
						max_count = "empty";
					}

					// use hander_class to call java
					// then set target_flag,shop,eqpType,file_source to run

					try {
						// -Xms512M -Xmx768M
						TranslatorTableControlUtil.updateConfigParentPID(conn, TID, parent_pid);
						// class param :
						// TID,Shop,Source,eqp_type,target_flag,fileSrcDir,hander_class,max_count,SystemLocalConfigDir,LogConfigFile
						if (JAVA_OPTIONS != null && JAVA_OPTIONS.length() > 0 && !JAVA_OPTIONS.equalsIgnoreCase("null"))
							cmd = "/usr/java/jdk1.7.0_80/bin/java -Djava.security.egd=file:///dev/urandom " + JAVA_OPTIONS;
						else
							cmd = "/usr/java/jdk1.7.0_80/bin/java -Djava.security.egd=file:///dev/urandom ";
						cmd = cmd + " -classpath " + classPath + " " + hander_class + " " + TID + " " + this.shop + " "
								+ this.source + " " + this.eqp_type;
						cmd = cmd + " " + target_flag + " " + workDir + " " + max_count + " "
								+ SessionConstants.GET_SYSTEM_CONFIG_DIR() + " " + SessionConstants.GET_LOG_CONFIG_DIR()
								+ File.separator + "log4j.properties";
							    // + File.separator + "log4j_" + i + ".properties";
						cmd = cmd + " " + SessionConstants.GET_ACTIVATE_DB_FIND_METHOD() + " " + export_log_file;
//						logger.debug("cmd_" + cmd_count + "=" + cmd);
//						System.out.print("cmd_" + cmd_count + "=" + cmd);
						// logger.error("cmd_" + cmd_count +
						// ",hander_class="+hander_class);

						ps[i] = Runtime.getRuntime().exec(cmd);
						cmd_count++;
						TranslatorTableControlUtil.updateConfigRunFlag(conn, TID, "Y");

					} catch (Exception ex) {
						
						logger.error(cmd);
						// add log
						logger.error("Run " + hander_class + " failed. TID:" + TID + " SHOP:" + this.shop + " SOURCE:"
								+ this.source + " EQUIP_TYPE:" + this.eqp_type + " TARGET_FLAG:" + target_flag);
						logger.error(LogHandlerUtil.getStackTraceMessage(ex));
						ex.printStackTrace();
					}
				}

				try {
					int count = 0;
					while (!subProcessIsEnd(conn, translatorConfigView)) {
						count++;
						Thread.sleep(3000);
					}

					// clear parent pid
					for (int i = 0; i < translatorConfigView.length; i++) {
						TranslatorTableControlUtil.updateConfigParentPID(conn, translatorConfigView[i].getTID(), "");
					}

				} catch (Exception ex) {
					logger.error(LogHandlerUtil.getStackTraceMessage(ex));
					ex.printStackTrace();
				}
			} else {
				logger.error("Can't find any translator config data." + " SHOP:" + this.shop + " SOURCE:" + this.source
						+ " EQUIP_TYPE:" + this.eqp_type);
			}
		}
		logger.info("run end");
		// System.out.println("run end");
	}
	
	public void setTranslatorConnection(Connection conn)
	{
		translator_conn = conn;
	}
    
    public void setTranlatorConnection() throws Exception
	{
		if(translator_conn == null || translator_conn.isClosed()){
			String user;
			String url ="";
			if(l_prop.GetTranslatorUserPrefix().toUpperCase().compareTo(l_prop.GetTranslatorUsername().toUpperCase())==0)
				user = l_prop.GetTranslatorUsername();
			else
				user = l_prop.GetTranslatorUserPrefix() + "$U$" + l_prop.GetTranslatorUsername();
			url = "jdbc:oracle:thin:@" + l_prop.GetTranslatorHostname() + ":" + l_prop.GetPort() + ":" + l_prop.GetTranslatorSid();
			try
			{
				translator_conn = DBUtil.getConn(url, user, l_prop.GetTranslatorPassword());
			}
			catch (Exception e) {
				logger.error("Create Translator DB connection  faild.error message:" + e.getMessage());	
			}
		}
	}
	
	public Connection getTranslatorConnection() throws Exception {
		if (translator_conn == null || translator_conn.isClosed()) {
			setTranlatorConnection();
		}
		return translator_conn;
	}

	public boolean subProcessIsEnd(Connection conn, TranslatorConfigView[] configTableView) throws Exception {
		boolean isSubRunEnd = false;
		for (int i = 0; i < configTableView.length; i++) {
			TranslatorConfigView[] viewList = TranslatorTableControlUtil.getConfigData(conn,
					configTableView[i].getTID());

			if (viewList[0] != null) {
				if (viewList[0].getRunFlag() != null && viewList[0].getRunFlag().length() > 0) {
					isSubRunEnd = false;
					break;
				} else if (i + 1 == configTableView.length)
					isSubRunEnd = true;
			}
		}

		return isSubRunEnd;
	}

	public boolean checkRunStatusNow(Connection conn, TranslatorConfigView[] configTableView) throws Exception {// true:befaule
																												// schedule																								// running
		boolean isSubRunEnd = false;
		for (int i = 0; i < configTableView.length; i++) {

			if (configTableView[i] != null) {
				if (configTableView[i].getRunFlag() != null && configTableView[i].getRunFlag().length() > 0) {
					isSubRunEnd = false;
					break;
				} else if (i + 1 == configTableView.length)
					isSubRunEnd = true;
			}
		}
		return isSubRunEnd;
	}

}
