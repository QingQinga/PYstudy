package com.mdt.beol.connection;

import java.sql.Connection;

import org.apache.log4j.Logger;

import com.mdt.beol.util.DBUtil;

/**
 ***************************************************
 * @Title EDAConnection 创建连接EDA数据库
 * @author 林华锋
 * @Date 2017年2月14日下午2:52:58
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class EDADBConnection {
    
	private static Logger logger = Logger.getLogger(EDADBConnection.class);
    
    public static Connection EDA_CONN;
	public static String DBName = "EDA";
	public static String UserName="edaldr";
	public static String UserPwd="edaldr2017";
    public static String HostName="10.96.1.15";
    public static String DB_Url = "jdbc:oracle:thin:@" + HostName + ":" + "1521" + ":" + DBName;
	
    public static Connection getEDA_CONN() throws Exception {
		if (EDA_CONN == null || EDA_CONN.isClosed()) {
			setEDA_CONN();
		}
		return EDA_CONN;
	}

	public static void setEDA_CONN() {
			
		try {
			EDA_CONN = DBUtil.getConn(DB_Url, UserName, UserPwd);
		} catch (Exception e) {
            logger.error("<"+DB_Url+">"+"EDADB Connected Failed! Error Message:"+e.getMessage());
		}
	}

}
