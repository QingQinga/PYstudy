package com.mdt.beol.entity;
/**
 ***************************************************
 * @Title  ProductEntity                                    
 * @author 林华锋
 * @Date   2017年6月23日下午1:50:55
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class ProductEntity {
	
	private String PRODUCT_ID;
	private String PRODUCT_GROUP;
	private String DATA_START_TIME;
	private String DATA_END_TIME;
	private String UPDATE_TIME;

	public String getPRODUCT_ID() {
		return PRODUCT_ID;
	}

	public void setPRODUCT_ID(String pRODUCT_ID) {
		PRODUCT_ID = pRODUCT_ID;
	}

	public String getPRODUCT_GROUP() {
		return PRODUCT_GROUP;
	}

	public void setPRODUCT_GROUP(String pRODUCT_GROUP) {
		PRODUCT_GROUP = pRODUCT_GROUP;
	}

	public String getDATA_START_TIME() {
		return DATA_START_TIME;
	}

	public void setDATA_START_TIME(String dATA_START_TIME) {
		DATA_START_TIME = dATA_START_TIME;
	}

	public String getDATA_END_TIME() {
		return DATA_END_TIME;
	}

	public void setDATA_END_TIME(String dATA_END_TIME) {
		DATA_END_TIME = dATA_END_TIME;
	}

	public String getUPDATE_TIME() {
		return UPDATE_TIME;
	}

	public void setUPDATE_TIME(String uPDATE_TIME) {
		UPDATE_TIME = uPDATE_TIME;
	}

}
