package com.mdt.beol.beol_gmo.entity;

import java.io.Serializable;

import com.mdt.beol.entity.BeolComponentSumBaseEntity;
/**
 ***************************************************
 * @Title  CellGmoComponentSumEntity                                    
 * @author 林华锋
 * @Date   2017年4月15日下午4:18:05
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class BeolGmoComponentSumEntity extends BeolComponentSumBaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
}
