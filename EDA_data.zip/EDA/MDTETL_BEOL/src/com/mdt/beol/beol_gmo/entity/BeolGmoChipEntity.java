package com.mdt.beol.beol_gmo.entity;

import java.io.Serializable;

import com.mdt.beol.entity.BeolChipBaseEntity;

/**
 ***************************************************
 * @Title  CellGmoChipEntity                                    
 * @author 林华锋
 * @Date   2017年4月15日下午1:45:28
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class BeolGmoChipEntity extends BeolChipBaseEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
}
