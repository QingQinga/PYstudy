package com.mdt.beol.beol_gmo.entity;

import java.io.Serializable;

import com.mdt.beol.entity.BeolComponentBaseEntity;

/**
 ***************************************************
 * @Title CellGmoComponentEntity
 * @author 林华锋
 * @Date 2017年4月15日下午1:47:21
 * @CopyRight 福建华佳彩有限公司
 ***************************************************
 */
public class BeolGmoComponentEntity extends BeolComponentBaseEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String TTL_DEFECT_CNT;

	public String getTTL_DEFECT_CNT() {
		return TTL_DEFECT_CNT;
	}

	public void setTTL_DEFECT_CNT(String tTL_DEFECT_CNT) {
		TTL_DEFECT_CNT = tTL_DEFECT_CNT;
	}

}
