#!/bin/sh

export SYSTEM_LOCAL_CONFIG=/home/translator/translator/ARRAY/CDOVL/ARRAY_FILE_CDOVL_1/system.properties
export TRANSLATOR_WORK_PATH=/home/translator/translator/ARRAY/CDOVL/ARRAY_FILE_CDOVL_1
export LOG4JPROPERTIES_DIR=/home/translator/translator/ARRAY/CDOVL/ARRAY_FILE_CDOVL_1/config/properties
export ACTIVATE_DB_FIND_METHOD=true
export JAVA_OPTIONS="-Xms256M -Xmx1024M"

#start javaw -Xms128M -Xmx512M -jar Translator.jar $1 $2 $3

exec /usr/java/jdk1.7.0_80/bin/java -Xms128M -Xmx512M -jar /home/translator/translator/ARRAY/CDOVL/ARRAY_FILE_CDOVL_1/Translator.jar $1 $2 $3

#exec /usr/java/jdk1.7.0_80/bin/java -Xms128M -Xmx512M -jar /home/translator/translator/ARRAY/CDOVL/ARRAY_FILE_CDOVL_1/Translator.jar ARRAY FILE CDOVL